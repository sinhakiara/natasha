'use client'

import { useSession } from 'next-auth/react'
import { ReactNode } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, AlertTriangle } from 'lucide-react'

interface Role {
  role: string
  organizationId: string
  organization: {
    id: string
    name: string
  }
}

interface RBACGuardProps {
  children: ReactNode
  requiredRoles?: string[]
  requiredPermissions?: string[]
  fallback?: ReactNode
  organizationId?: string
}

export function RBACGuard({ 
  children, 
  requiredRoles = [], 
  requiredPermissions = [],
  fallback,
  organizationId 
}: RBACGuardProps) {
  const { data: session, status } = useSession()

  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!session) {
    return (
      fallback || (
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
              <span>Authentication Required</span>
            </CardTitle>
            <CardDescription>
              You need to sign in to access this feature.
            </CardDescription>
          </CardHeader>
        </Card>
      )
    )
  }

  // Check if user has required roles
  const userRoles = session.user.organizations || []
  
  if (requiredRoles.length > 0) {
    const hasRequiredRole = userRoles.some((userRole: Role) => {
      if (organizationId && userRole.organizationId !== organizationId) {
        return false
      }
      return requiredRoles.includes(userRole.role)
    })

    if (!hasRequiredRole) {
      return (
        fallback || (
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-red-500" />
                <span>Access Denied</span>
              </CardTitle>
              <CardDescription>
                You don't have the required permissions to access this feature.
              </CardDescription>
            </CardHeader>
          </Card>
        )
      )
    }
  }

  // Check permissions (simplified for demo)
  if (requiredPermissions.length > 0) {
    const hasPermission = userRoles.some((userRole: Role) => {
      if (organizationId && userRole.organizationId !== organizationId) {
        return false
      }
      
      // Map roles to permissions
      const rolePermissions: Record<string, string[]> = {
        ADMIN: ['read', 'write', 'delete', 'manage_users', 'manage_organizations'],
        MEMBER: ['read', 'write'],
        VIEWER: ['read']
      }
      
      return requiredPermissions.every(permission => 
        rolePermissions[userRole.role]?.includes(permission)
      )
    })

    if (!hasPermission) {
      return (
        fallback || (
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-red-500" />
                <span>Insufficient Permissions</span>
              </CardTitle>
              <CardDescription>
                You don't have the required permissions to perform this action.
              </CardDescription>
            </CardHeader>
          </Card>
        )
      )
    }
  }

  return <>{children}</>
}

// Higher-order component for page-level protection
export function withAuth<P extends object>(
  Component: React.ComponentType<P>,
  options: {
    requiredRoles?: string[]
    requiredPermissions?: string[]
    organizationId?: string
  } = {}
) {
  return function AuthenticatedComponent(props: P) {
    return (
      <RBACGuard {...options}>
        <Component {...props} />
      </RBACGuard>
    )
  }
}