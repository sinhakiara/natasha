'use client'

import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { User, Building, Shield, Mail } from 'lucide-react'
import { SignOutButton } from './sign-out-button'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'

interface Role {
  role: string
  organizationId: string
  organization: {
    id: string
    name: string
  }
}

export function UserProfile() {
  const { data: session } = useSession()

  if (!session) {
    return null
  }

  const userRoles = session.user.organizations || []
  
  // Deduplicate organizations by ID
  const uniqueOrganizations = userRoles.reduce((acc, current) => {
    const x = acc.find(item => item.organization.id === current.organization.id);
    if (!x) {
      return acc.concat([current]);
    } else {
      return acc;
    }
  }, [] as typeof userRoles)

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'ADMIN': return 'bg-red-500 text-white'
      case 'MEMBER': return 'bg-blue-500 text-white'
      case 'VIEWER': return 'bg-green-500 text-white'
      default: return 'bg-gray-500 text-white'
    }
  }

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'ADMIN': return <Shield className="h-4 w-4" />
      case 'MEMBER': return <User className="h-4 w-4" />
      case 'VIEWER': return <User className="h-4 w-4" />
      default: return <User className="h-4 w-4" />
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="h-9">
          <Avatar className="h-6 w-6 mr-2">
            <AvatarImage src={session.user.image || ''} />
            <AvatarFallback className="text-xs">
              {session.user.name?.charAt(0) || session.user.email?.charAt(0) || 'U'}
            </AvatarFallback>
          </Avatar>
          <span className="hidden sm:inline-block">
            {session.user.name || session.user.email?.split('@')[0]}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 bg-card/95 backdrop-blur-sm border-border/80 shadow-lg">
        <div className="p-4">
          {/* User Info */}
          <div className="flex items-center space-x-3 mb-4">
            <Avatar className="h-10 w-10">
              <AvatarImage src={session.user.image || ''} />
              <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                {session.user.name?.charAt(0) || session.user.email?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-sm truncate text-foreground">
                {session.user.name || 'User'}
              </h3>
              <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                <Mail className="h-3 w-3 flex-shrink-0" />
                <span className="truncate">{session.user.email}</span>
              </div>
            </div>
          </div>

          {/* Organizations and Roles */}
          {uniqueOrganizations.length > 0 && (
            <div className="space-y-2 mb-4">
              <h4 className="font-medium text-xs text-muted-foreground uppercase tracking-wider bg-muted/50 px-2 py-1 rounded">
                Organizations & Roles
              </h4>
              <div className="space-y-1">
                {uniqueOrganizations.map((userRole: Role, index: number) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted/60 rounded-md border border-border/50">
                    <div className="flex items-center space-x-2 min-w-0">
                      <Building className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                      <span className="font-medium text-xs truncate text-foreground">
                        {userRole.organization.name}
                      </span>
                    </div>
                    <Badge className={`${getRoleColor(userRole.role)} text-xs flex-shrink-0 border-0 shadow-sm`}>
                      {getRoleIcon(userRole.role)}
                      <span className="ml-1">{userRole.role}</span>
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Permissions Summary */}
          <div className="space-y-2 mb-4">
            <h4 className="font-medium text-xs text-muted-foreground uppercase tracking-wider bg-muted/50 px-2 py-1 rounded">
              Your Permissions
            </h4>
            <div className="flex flex-wrap gap-1">
              {uniqueOrganizations.some((role: Role) => role.role === 'ADMIN') && (
                <Badge variant="outline" className="text-xs bg-primary/5 border-primary/20 text-foreground">Manage Users</Badge>
              )}
              {uniqueOrganizations.some((role: Role) => ['ADMIN', 'MEMBER'].includes(role.role)) && (
                <Badge variant="outline" className="text-xs bg-primary/5 border-primary/20 text-foreground">Create Scans</Badge>
              )}
              {uniqueOrganizations.some((role: Role) => ['ADMIN', 'MEMBER'].includes(role.role)) && (
                <Badge variant="outline" className="text-xs bg-primary/5 border-primary/20 text-foreground">Manage Monitors</Badge>
              )}
              <Badge variant="outline" className="text-xs bg-primary/5 border-primary/20 text-foreground">View Reports</Badge>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-2 border-t border-border/50">
            <SignOutButton className="w-full" />
          </div>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}