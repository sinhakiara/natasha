'use client'

import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Shield, AlertTriangle } from 'lucide-react'

interface AuthGuardProps {
  children: React.ReactNode
  requiredRoles?: string[]
  requiredPermissions?: string[]
  redirectTo?: string
}

export function AuthGuard({ 
  children, 
  requiredRoles = [],
  requiredPermissions = [],
  redirectTo = '/auth/signin'
}: AuthGuardProps) {
  const { data: session, status } = useSession()
  const router = useRouter()

  useEffect(() => {
    if (status === 'loading') return

    // Check if user is authenticated
    if (!session) {
      router.push(redirectTo)
      return
    }

    // Check roles and permissions only if session exists
    if (session) {
      const userRoles = session.user.organizations || []
      
      if (requiredRoles.length > 0) {
        const hasRequiredRole = userRoles.some((userRole: any) => 
          requiredRoles.includes(userRole.role)
        )

        if (!hasRequiredRole) {
          router.push('/unauthorized')
          return
        }
      }

      if (requiredPermissions.length > 0) {
        const hasPermission = userRoles.some((userRole: any) => {
          const rolePermissions: Record<string, string[]> = {
            ADMIN: ['read', 'write', 'delete', 'manage_users', 'manage_organizations'],
            MEMBER: ['read', 'write'],
            VIEWER: ['read']
          }
          
          return requiredPermissions.every(permission => 
            rolePermissions[userRole.role]?.includes(permission)
          )
        })

        if (!hasPermission) {
          router.push('/unauthorized')
          return
        }
      }
    }
  }, [session, status, requiredRoles, requiredPermissions, router, redirectTo])

  if (status === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!session) {
    return null // Will redirect in useEffect
  }

  return <>{children}</>
}

// Unauthorized page component
export function UnauthorizedPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <AlertTriangle className="h-12 w-12 text-yellow-500" />
          </div>
          <CardTitle className="text-2xl">Access Denied</CardTitle>
          <CardDescription>
            You don't have permission to access this resource.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => window.history.back()}
            >
              Go Back
            </Button>
            <Button 
              className="w-full"
              onClick={() => window.location.href = '/'}
            >
              Go to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}