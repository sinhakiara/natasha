'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Wifi, WifiOff } from 'lucide-react'
import { useSocket } from '@/hooks/useSocket'

export function SocketTest() {
  const [lastMessage, setLastMessage] = useState<string>('')
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting')
  
  const { isConnected, socket } = useSocket({ 
    userId: 'test-user',
    autoConnect: true 
  })

  useEffect(() => {
    setConnectionStatus(isConnected ? 'connected' : 'disconnected')
  }, [isConnected])

  useEffect(() => {
    if (socket) {
      const handleMessage = (msg: any) => {
        setLastMessage(JSON.stringify(msg))
      }

      socket.on('message', handleMessage)
      socket.on('connect', () => {
        setConnectionStatus('connected')
        setLastMessage('Connected to WebSocket server')
      })
      socket.on('disconnect', () => {
        setConnectionStatus('disconnected')
        setLastMessage('Disconnected from WebSocket server')
      })

      return () => {
        socket.off('message', handleMessage)
        socket.off('connect')
        socket.off('disconnect')
      }
    }
  }, [socket])

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected': return 'bg-green-100 text-green-800'
      case 'connecting': return 'bg-yellow-100 text-yellow-800'
      case 'disconnected': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = () => {
    return connectionStatus === 'connected' ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getStatusIcon()}
          WebSocket Connection Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span>Status:</span>
          <Badge className={getStatusColor()}>
            {connectionStatus.toUpperCase()}
          </Badge>
        </div>
        <div>
          <span className="text-sm text-gray-600">Last Message:</span>
          <div className="mt-1 p-2 bg-gray-50 rounded text-sm font-mono break-all">
            {lastMessage || 'No messages yet'}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}