import { DefaultSession, DefaultUser } from 'next-auth'
import { Organization, OrganizationMember } from '@prisma/client'

declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      organizations?: (OrganizationMember & {
        organization: Organization
      })[]
    } & DefaultSession['user']
  }

  interface User extends DefaultUser {
    organizations?: (OrganizationMember & {
      organization: Organization
    })[]
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string
    organizations?: (OrganizationMember & {
      organization: Organization
    })[]
  }
}