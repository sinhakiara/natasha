'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Search, 
  ArrowLeft,
  FileText,
  Shield,
  Bug,
  Code,
  Eye,
  ExternalLink,
  Copy,
  Key,
  Database,
  AlertCircle,
  CheckCircle,
  Trash2,
  Lock,
  Unlock,
  Zap,
  Target,
  TrendingUp,
  Activity,
  Wifi,
  WifiOff,
  GitBranch,
  Server,
  Cloud,
  Globe,
  Terminal
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface EnhancedSecretFinding {
  id: string
  type: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  title: string
  description: string
  secret: string
  redactedSecret: string
  file: string
  line: number
  commit?: string
  author?: string
  date?: string
  repository: string
  branch: string
  provider: 'github' | 'gitlab' | 'bitbucket' | 'local'
  confidence: number
  isValid: boolean
  status: 'active' | 'resolved' | 'false_positive' | 'ignored'
  tags: string[]
  remediation: {
    steps: string[]
    priority: 'immediate' | 'high' | 'medium' | 'low'
    estimatedTime: string
  }
  impact: {
    financial?: number
    reputational?: number
    compliance?: string[]
  }
  firstSeen: string
  lastSeen: string
}

interface EnhancedSecretScan {
  id: string
  name: string
  target: string
  type: 'ENHANCED_SECRET_SCAN'
  status: string
  config: any
  startedAt?: string
  completedAt?: string
  createdAt: string
  findings: EnhancedSecretFinding[]
  _count: {
    findings: number
    critical: number
    high: number
    medium: number
    low: number
  }
  statistics: {
    filesScanned: number
    secretsFound: number
    falsePositives: number
    scanDuration: number
    averageConfidence: number
  }
}

export default function EnhancedSecretScanDetailsPage() {
  const { data: session } = useSession()
  const params = useParams()
  const router = useRouter()
  const scanId = params.id as string
  const [scan, setScan] = useState<EnhancedSecretScan | null>(null)
  const [findings, setFindings] = useState<EnhancedSecretFinding[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDeleting, setIsDeleting] = useState(false)
  const [visibleSecrets, setVisibleSecrets] = useState<Set<string>>(new Set())
  const { toast } = useToast()

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3' // Admin user ID as fallback

  useEffect(() => {
    if (scanId) {
      fetchScanDetails()
    }
  }, [scanId])

  const fetchScanDetails = async () => {
    try {
      setIsLoading(true)
      
      // Fetch scan details
      const scanResponse = await fetch(`/api/scans?userId=${userId}`)
      if (scanResponse.ok) {
        const scanData = await scanResponse.json()
        const foundScan = scanData.scans?.find((s: EnhancedSecretScan) => s.id === scanId)
        if (foundScan) {
          setScan(foundScan)
        }
      }

      // Fetch findings
      const findingsResponse = await fetch(`/api/scans/${scanId}/findings`)
      if (findingsResponse.ok) {
        const findingsData = await findingsResponse.json()
        setFindings(findingsData.findings || [])
      }
    } catch (error) {
      console.error('Error fetching scan details:', error)
      toast({
        title: "Error",
        description: "Failed to fetch scan details",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteScan = async () => {
    if (!confirm('Are you sure you want to delete this scan and all its findings? This action cannot be undone.')) {
      return
    }

    try {
      setIsDeleting(true)
      
      const response = await fetch(`/api/scans/${scanId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Scan deleted successfully",
        })
        router.push('/')
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to delete scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error deleting scan:', error)
      toast({
        title: "Error",
        description: "Failed to delete scan",
        variant: "destructive"
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <div className="h-3 w-3 animate-spin rounded-full border-2 border-blue-600 border-t-transparent" />
      case 'FAILED':
        return <AlertCircle className="h-3 w-3" />
      case 'PENDING':
        return <div className="h-3 w-3 rounded-full border-2 border-yellow-600 border-t-transparent" />
      default:
        return <div className="h-3 w-3 rounded-full border-2 border-gray-600 border-t-transparent" />
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'ENHANCED_SECRET_SCAN':
        return <Zap className="h-5 w-5" />
      case 'SECRET_SCAN':
        return <Search className="h-5 w-5" />
      case 'VULNERABILITY_SCAN':
        return <Bug className="h-5 w-5" />
      case 'CODE_SCAN':
        return <Code className="h-5 w-5" />
      default:
        return <Shield className="h-5 w-5" />
    }
  }

  const getTypeName = (type: string) => {
    switch (type) {
      case 'ENHANCED_SECRET_SCAN':
        return 'Enhanced Secret Scan'
      case 'SECRET_SCAN':
        return 'Secret Scan'
      case 'VULNERABILITY_SCAN':
        return 'Vulnerability Scan'
      case 'CODE_SCAN':
        return 'Code Scan'
      default:
        return 'Custom Scan'
    }
  }

  const getFindingSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getFindingIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'secret': return <Key className="h-4 w-4" />
      case 'aws_access_key': return <Cloud className="h-4 w-4" />
      case 'github_pat': return <GitBranch className="h-4 w-4" />
      case 'api_key': return <Key className="h-4 w-4" />
      case 'jwt_token': return <Shield className="h-4 w-4" />
      default: return <AlertCircle className="h-4 w-4" />
    }
  }

  const getProviderIcon = (provider: string) => {
    switch (provider) {
      case 'github': return <GitBranch className="h-4 w-4" />
      case 'gitlab': return <Server className="h-4 w-4" />
      case 'bitbucket': return <Cloud className="h-4 w-4" />
      case 'local': return <Terminal className="h-4 w-4" />
      default: return <Globe className="h-4 w-4" />
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: "Text copied to clipboard",
    })
  }

  const maskSecret = (secret: string) => {
    if (secret.length <= 8) return '*'.repeat(secret.length)
    return secret.substring(0, 4) + '*'.repeat(secret.length - 8) + secret.substring(secret.length - 4)
  }

  const toggleSecretVisibility = (findingId: string) => {
    setVisibleSecrets(prev => {
      const newSet = new Set(prev)
      if (newSet.has(findingId)) {
        newSet.delete(findingId)
      } else {
        newSet.add(findingId)
      }
      return newSet
    })
  }

  const formatTarget = (target: string) => {
    if (target.length > 80) {
      return target.substring(0, 80) + '...'
    }
    return target
  }

  const formatConfidence = (confidence: number) => {
    return `${Math.round(confidence * 100)}%`
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'bg-green-100 text-green-800 border-green-200'
    if (confidence >= 0.6) return 'bg-yellow-100 text-yellow-800 border-yellow-200'
    return 'bg-red-100 text-red-800 border-red-200'
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" disabled>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64"></div>
          </div>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (!scan) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => {
              // Navigate back to main page with scans tab active
              window.location.href = '/?tab=scans'
            }}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Scanner
          </Button>
        </div>
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Scan Not Found</h3>
            <p className="text-gray-500 mb-4">The requested scan could not be found.</p>
            <Button onClick={() => router.push('/')}>
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <RBACGuard requiredPermissions={['write']}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => {
              // Navigate back to main page with scans tab active
              window.location.href = '/?tab=scans'
            }}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Scanner
            </Button>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">{scan.name}</h1>
              <p className="text-muted-foreground">
                {getTypeName(scan.type)} - {formatTarget(scan.target)}
              </p>
            </div>
          </div>
          <Button
            variant="destructive"
            size="sm"
            onClick={handleDeleteScan}
            disabled={isDeleting}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            {isDeleting ? 'Deleting...' : 'Delete Scan'}
          </Button>
        </div>

        {/* Scan Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getTypeIcon(scan.type)}
              Scan Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <div className="text-sm font-medium text-gray-500">Status</div>
                <Badge className={getStatusColor(scan.status)}>
                  {getStatusIcon(scan.status)}
                  {scan.status}
                </Badge>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Target</div>
                <div className="text-sm font-mono text-gray-900 truncate">{formatTarget(scan.target)}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Duration</div>
                <div className="text-sm text-gray-900">
                  {scan.completedAt && scan.startedAt 
                    ? `${Math.round((new Date(scan.completedAt).getTime() - new Date(scan.startedAt).getTime()) / 1000)} seconds`
                    : 'N/A'
                  }
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Findings</div>
                <div className="text-sm text-gray-900">{findings.length}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Statistics */}
        {scan.statistics && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Enhanced Scan Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {scan.statistics.filesScanned || 0}
                  </div>
                  <div className="text-sm text-blue-600">Files Scanned</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">
                    {scan.statistics.secretsFound || 0}
                  </div>
                  <div className="text-sm text-purple-600">Secrets Found</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">
                    {scan.statistics.falsePositives || 0}
                  </div>
                  <div className="text-sm text-orange-600">False Positives</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {Math.round(scan.statistics.averageConfidence * 100) || 0}%
                  </div>
                  <div className="text-sm text-green-600">Avg Confidence</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-gray-600">
                    {scan.statistics.scanDuration || 0}s
                  </div>
                  <div className="text-sm text-gray-600">Scan Duration</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Summary Stats */}
        {findings.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Findings Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'critical').length}
                  </div>
                  <div className="text-sm text-red-600">Critical</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'high').length}
                  </div>
                  <div className="text-sm text-orange-600">High</div>
                </div>
                <div className="text-center p-3 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'medium').length}
                  </div>
                  <div className="text-sm text-yellow-600">Medium</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'low').length}
                  </div>
                  <div className="text-sm text-green-600">Low</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'info').length}
                  </div>
                  <div className="text-sm text-blue-600">Info</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Findings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Enhanced Security Findings ({findings.length})
            </CardTitle>
            <CardDescription>
              Detailed view of all enhanced security findings with validation scores and remediation guidance
            </CardDescription>
          </CardHeader>
          <CardContent>
            {findings.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Security Findings</h3>
                <p className="text-gray-500">This scan did not detect any security issues.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {findings.map((finding, index) => (
                  <div key={finding.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-2">
                        {getFindingIcon(finding.type)}
                        <h3 className="font-medium text-gray-900">{finding.title || 'Security Finding'}</h3>
                        <Badge className={getFindingSeverityColor(finding.severity)}>
                          {finding.severity?.toUpperCase() || 'UNKNOWN'}
                        </Badge>
                        <Badge className={getConfidenceColor(finding.confidence)}>
                          {formatConfidence(finding.confidence)} Confidence
                        </Badge>
                        {finding.provider && (
                          <Badge variant="outline" className="flex items-center gap-1">
                            {getProviderIcon(finding.provider)}
                            {finding.provider}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-1">
                        {finding.file && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(finding.file)}
                            title="Copy file path"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        )}
                        {finding.repository && finding.repository.startsWith('http') && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(finding.repository, '_blank')}
                            title="View repository"
                          >
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="font-medium text-gray-700">File</div>
                        <div className="font-mono text-gray-600">{finding.file || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="font-medium text-gray-700">Line</div>
                        <div className="text-gray-600">{finding.line || 'N/A'}</div>
                      </div>
                      {finding.commit && (
                        <div>
                          <div className="font-medium text-gray-700">Commit</div>
                          <div className="font-mono text-gray-600 truncate">{finding.commit}</div>
                        </div>
                      )}
                      {finding.author && (
                        <div>
                          <div className="font-medium text-gray-700">Author</div>
                          <div className="text-gray-600">{finding.author}</div>
                        </div>
                      )}
                    </div>

                    <div>
                      <div className="font-medium text-gray-700 mb-2">Secret</div>
                      <div className="flex items-center space-x-2">
                        <code className="bg-gray-100 px-3 py-2 rounded text-sm font-mono flex-1">
                          {visibleSecrets.has(finding.id) ? finding.secret : finding.redactedSecret}
                        </code>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleSecretVisibility(finding.id)}
                        >
                          {visibleSecrets.has(finding.id) ? (
                            <>
                              <Unlock className="h-3 w-3 mr-1" />
                              Hide
                            </>
                          ) : (
                            <>
                              <Lock className="h-3 w-3 mr-1" />
                              Show
                            </>
                          )}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(finding.secret)}
                        >
                          <Copy className="h-3 w-3 mr-1" />
                          Copy
                        </Button>
                      </div>
                    </div>

                    {finding.description && (
                      <div>
                        <div className="font-medium text-gray-700 mb-1">Description</div>
                        <div className="text-gray-600 text-sm">{finding.description}</div>
                      </div>
                    )}

                    {finding.remediation && (
                      <div>
                        <div className="font-medium text-gray-700 mb-2">Remediation</div>
                        <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
                          <div className="text-sm text-yellow-800 mb-2">
                            <strong>Priority:</strong> {finding.remediation.priority} | 
                            <strong> Estimated Time:</strong> {finding.remediation.estimatedTime}
                          </div>
                          <ul className="text-sm text-yellow-700 space-y-1">
                            {finding.remediation.steps.map((step, stepIndex) => (
                              <li key={stepIndex} className="flex items-start">
                                <span className="mr-2">•</span>
                                <span>{step}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {finding.tags && finding.tags.length > 0 && (
                      <div>
                        <div className="font-medium text-gray-700 mb-1">Tags</div>
                        <div className="flex flex-wrap gap-1">
                          {finding.tags.map((tag, tagIndex) => (
                            <Badge key={tagIndex} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t">
                      <div>
                        First Seen: {finding.firstSeen ? new Date(finding.firstSeen).toLocaleDateString() : 'N/A'}
                      </div>
                      <div>
                        Last Seen: {finding.lastSeen ? new Date(finding.lastSeen).toLocaleDateString() : 'N/A'}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span>Status:</span>
                        <Badge variant="outline" className="text-xs">
                          {finding.status}
                        </Badge>
                        <span className={`flex items-center ${finding.isValid ? 'text-green-600' : 'text-red-600'}`}>
                          {finding.isValid ? <CheckCircle className="h-3 w-3 mr-1" /> : <AlertCircle className="h-3 w-3 mr-1" />}
                          {finding.isValid ? 'Valid' : 'Invalid'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </RBACGuard>
  )
}