import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const scanId = id

    const findings = await db.finding.findMany({
      where: { scanId },
      orderBy: { createdAt: 'desc' },
      take: 100
    })

    return NextResponse.json({ findings })
  } catch (error) {
    console.error('Error fetching findings:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}