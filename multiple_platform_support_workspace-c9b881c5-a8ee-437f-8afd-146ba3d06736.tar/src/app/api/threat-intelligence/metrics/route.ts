import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<Record<string, never>> }
) {
  try {
    const searchParams = await request.nextUrl.searchParams
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Get user's alerts for metrics calculation
    const alerts = await db.alert.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' }
    })

    // Calculate metrics
    const totalThreats = alerts.length
    const activeThreats = alerts.filter(alert => !alert.isRead).length
    const criticalThreats = alerts.filter(alert => alert.severity === 'CRITICAL' && !alert.isRead).length
    const resolvedThreats = alerts.filter(alert => alert.isRead).length
    const falsePositives = alerts.filter(alert => alert.type === 'FALSE_POSITIVE').length

    // Calculate average response time (mock data)
    const averageResponseTime = 2.5 // hours

    // Generate threats by type data
    const threatsByType = alerts.reduce((acc, alert) => {
      const type = alert.type.toLowerCase().replace(' ', '_')
      acc[type] = (acc[type] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    // Generate threats by severity data
    const threatsBySeverity = alerts.reduce((acc, alert) => {
      const severity = alert.severity.toLowerCase()
      acc[severity] = (acc[severity] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    // Generate trend data
    const generateTrendData = (days: number) => {
      const data = []
      for (let i = days - 1; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - i)
        data.push({
          date: date.toISOString().split('T')[0],
          count: Math.floor(Math.random() * 10) + 1
        })
      }
      return data
    }

    const generateWeeklyTrendData = (weeks: number) => {
      const data = []
      for (let i = weeks - 1; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - (i * 7))
        data.push({
          week: `Week ${weeks - i}`,
          count: Math.floor(Math.random() * 50) + 10
        })
      }
      return data
    }

    const generateMonthlyTrendData = (months: number) => {
      const data = []
      for (let i = months - 1; i >= 0; i--) {
        const date = new Date()
        date.setMonth(date.getMonth() - i)
        data.push({
          month: date.toLocaleDateString('en-US', { month: 'short' }),
          count: Math.floor(Math.random() * 200) + 50
        })
      }
      return data
    }

    const metrics = {
      totalThreats,
      activeThreats,
      criticalThreats,
      resolvedThreats,
      falsePositives,
      averageResponseTime,
      threatsByType,
      threatsBySeverity,
      trends: {
        daily: generateTrendData(7),
        weekly: generateWeeklyTrendData(4),
        monthly: generateMonthlyTrendData(6)
      }
    }

    return NextResponse.json({ metrics })
  } catch (error) {
    console.error('Error fetching threat intelligence metrics:', error)
    return NextResponse.json({ error: 'Failed to fetch metrics' }, { status: 500 })
  }
}