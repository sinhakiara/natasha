import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Get total alerts count
    const totalAlerts = await db.alert.count({
      where: { userId }
    })

    // Get unread alerts count
    const unreadAlerts = await db.alert.count({
      where: { userId, isRead: false }
    })

    // Get critical alerts count
    const criticalAlerts = await db.alert.count({
      where: { userId, severity: 'CRITICAL' }
    })

    // Get high alerts count
    const highAlerts = await db.alert.count({
      where: { userId, severity: 'HIGH' }
    })

    // Get medium alerts count
    const mediumAlerts = await db.alert.count({
      where: { userId, severity: 'MEDIUM' }
    })

    // Get low alerts count
    const lowAlerts = await db.alert.count({
      where: { userId, severity: 'LOW' }
    })

    // Get active monitors count
    const activeMonitors = await db.monitor.count({
      where: { userId, isActive: true }
    })

    // Get total monitors count
    const totalMonitors = await db.monitor.count({
      where: { userId }
    })

    // Get recent scans count (last 24 hours)
    const oneDayAgo = new Date()
    oneDayAgo.setDate(oneDayAgo.getDate() - 1)
    
    const recentScans = await db.scan.count({
      where: {
        userId,
        createdAt: { gte: oneDayAgo }
      }
    })

    // Get total scans count
    const totalScans = await db.scan.count({
      where: { userId }
    })

    // Get completed scans count
    const completedScans = await db.scan.count({
      where: { userId, status: 'COMPLETED' }
    })

    // Get total leaks count (through monitors)
    const totalLeaks = await db.leak.count({
      where: {
        monitor: {
          userId
        }
      }
    })

    // Get critical leaks count (through monitors)
    const criticalLeaks = await db.leak.count({
      where: {
        monitor: {
          userId
        },
        severity: 'CRITICAL'
      }
    })

    // Get total tokens count
    const totalTokens = await db.tokenVerification.count({
      where: { userId }
    })

    // Get valid tokens count
    const validTokens = await db.tokenVerification.count({
      where: { userId, isValid: true }
    })

    // Get total network assets count (using domains as network assets)
    const totalNetworkAssets = await db.domain.count({
      where: { 
        organization: {
          members: {
            some: {
              userId
            }
          }
        }
      }
    })

    // Generate trend data for the last 7 days
    const trendData = []
    for (let i = 6; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      const startOfDay = new Date(date.setHours(0, 0, 0, 0))
      const endOfDay = new Date(date.setHours(23, 59, 59, 999))

      const dayMonitors = await db.monitor.count({
        where: {
          userId,
          createdAt: { lte: endOfDay }
        }
      })

      const dayScans = await db.scan.count({
        where: {
          userId,
          createdAt: { gte: startOfDay, lte: endOfDay }
        }
      })

      const dayLeaks = await db.leak.count({
        where: {
          monitor: {
            userId
          },
          createdAt: { gte: startOfDay, lte: endOfDay }
        }
      })

      const dayTokens = await db.tokenVerification.count({
        where: {
          userId,
          createdAt: { gte: startOfDay, lte: endOfDay }
        }
      })

      const dayAssets = await db.domain.count({
        where: {
          createdAt: { gte: startOfDay, lte: endOfDay }
        }
      })

      trendData.push({
        period: date.toLocaleDateString('en-US', { weekday: 'short' }),
        monitors: dayMonitors,
        scans: dayScans,
        leaks: dayLeaks,
        tokens: dayTokens,
        assets: dayAssets
      })
    }

    // Calculate severity breakdown
    const severityBreakdown = {
      critical: criticalAlerts + criticalLeaks,
      high: highAlerts,
      medium: mediumAlerts,
      low: lowAlerts
    }

    const metrics = {
      totalMonitors,
      activeMonitors,
      totalScans,
      completedScans,
      totalLeaks,
      criticalLeaks,
      totalTokens,
      validTokens,
      totalNetworkAssets,
      recentAlerts: unreadAlerts
    }

    return NextResponse.json({
      metrics,
      trendData,
      severityBreakdown,
      alerts: {
        total: totalAlerts,
        unread: unreadAlerts,
        critical: criticalAlerts,
        high: highAlerts,
        medium: mediumAlerts,
        low: lowAlerts
      }
    })
  } catch (error) {
    console.error('Error fetching monitoring stats:', error)
    return NextResponse.json({ error: 'Failed to fetch monitoring stats' }, { status: 500 })
  }
}