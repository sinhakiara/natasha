import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : undefined

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const verifications = await db.tokenVerification.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json({ verifications })
  } catch (error) {
    console.error('Error fetching token verifications:', error)
    return NextResponse.json({ error: 'Failed to fetch token verifications' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { token, type, service, userId } = body

    if (!userId || !token || !type || !service) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const verification = await db.tokenVerification.create({
      data: {
        token,
        type,
        service,
        userId,
        status: 'PENDING',
      },
    })

    // Start real verification process
    performTokenVerification(verification.id, token, type, service)

    return NextResponse.json({ verification })
  } catch (error) {
    console.error('Error creating token verification:', error)
    return NextResponse.json({ error: 'Failed to create token verification' }, { status: 500 })
  }
}

async function performTokenVerification(verificationId: string, token: string, type: string, service: string) {
  try {
    console.log(`Starting token verification for ${type} token at ${service}`)
    
    // Import AI SDK for enhanced verification
    const ZAI = await import('z-ai-web-dev-sdk')
    const zai = await ZAI.create()
    
    let isValid = false
    let metadata: any = {
      verifiedAt: new Date().toISOString(),
      service: service,
      tokenType: type
    }

    // Perform actual verification based on token type
    switch (type) {
      case 'GITHUB':
        isValid = await verifyGitHubToken(token, service, metadata)
        break
      case 'AWS':
        isValid = await verifyAWSToken(token, service, metadata)
        break
      case 'SLACK':
        isValid = await verifySlackToken(token, service, metadata)
        break
      case 'DISCORD':
        isValid = await verifyDiscordToken(token, service, metadata)
        break
      default:
        isValid = await verifyGenericToken(token, service, metadata, zai)
    }

    // Use AI to validate the token format and provide additional insights
    try {
      const aiPrompt = `
      Analyze the following token for validity and provide security insights:
      
      Token Type: ${type}
      Service: ${service}
      Token (first 10 chars): ${token.substring(0, 10)}...
      
      Provide analysis on:
      - Token format validity
      - Potential security risks
      - Best practices for this token type
      - Recommended actions
      
      Return a JSON object with the following structure:
      {
        "formatValid": true,
        "securityRisk": "LOW|MEDIUM|HIGH",
        "insights": ["insight1", "insight2"],
        "recommendations": ["recommendation1", "recommendation2"],
        "confidence": 0.85
      }
      `
      
      const aiResponse = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a security expert specializing in token validation and API security.'
          },
          {
            role: 'user',
            content: aiPrompt
          }
        ],
        temperature: 0.1
      })
      
      const aiAnalysis = JSON.parse(aiResponse.choices[0]?.message?.content || '{}')
      metadata.aiAnalysis = aiAnalysis
      
      // Adjust validity based on AI analysis if needed
      if (aiAnalysis.formatValid === false) {
        isValid = false
      }
      
    } catch (error) {
      console.error('Error in AI token analysis:', error)
    }

    // Update verification with results
    await db.tokenVerification.update({
      where: { id: verificationId },
      data: {
        isValid,
        status: isValid ? 'VERIFIED' : 'FAILED',
        metadata: JSON.stringify(metadata)
      }
    })

    console.log(`Token verification completed for ${verificationId}: ${isValid ? 'VALID' : 'INVALID'}`)

  } catch (error) {
    console.error('Error during token verification:', error)
    
    // Update verification with error status
    await db.tokenVerification.update({
      where: { id: verificationId },
      data: {
        isValid: false,
        status: 'ERROR',
        metadata: JSON.stringify({ 
          error: 'Verification process failed',
          details: error.message 
        })
      }
    })
  }
}

async function verifyGitHubToken(token: string, service: string, metadata: any): Promise<boolean> {
  try {
    const response = await fetch('https://api.github.com/user', {
      headers: {
        'Authorization': `token ${token}`,
        'User-Agent': 'Security-Sentinel/1.0'
      }
    })

    if (response.ok) {
      const userData = await response.json()
      metadata.username = userData.login
      metadata.scopes = response.headers.get('x-oauth-scopes')?.split(',') || []
      metadata.userId = userData.id
      metadata.avatarUrl = userData.avatar_url
      
      // Check token expiration (GitHub PATs don't expose expiration directly, but we can check scopes)
      metadata.hasRepoScope = metadata.scopes.includes('repo')
      metadata.hasUserScope = metadata.scopes.includes('user')
      
      return true
    }
    
    metadata.error = 'GitHub API returned error'
    metadata.errorDetails = await response.text()
    return false
  } catch (error) {
    console.error('Error verifying GitHub token:', error)
    metadata.error = 'Connection error'
    metadata.errorDetails = error.message
    return false
  }
}

async function verifyAWSToken(token: string, service: string, metadata: any): Promise<boolean> {
  try {
    // For AWS, we can only validate the format, not the actual validity without AWS credentials
    // AWS Access Key ID format: AKIAIOSFODNN7EXAMPLE (20 characters, starts with AKIA)
    const accessKeyPattern = /^AKIA[0-9A-Z]{16}$/
    const secretKeyPattern = /^[0-9a-zA-Z/+]{40}$/
    
    if (accessKeyPattern.test(token)) {
      metadata.tokenType = 'AWS_ACCESS_KEY_ID'
      metadata.formatValid = true
      metadata.service = 'AWS'
      
      // Note: We cannot validate actual AWS credentials without proper AWS setup
      metadata.validationNote = 'Format validated, actual AWS credentials validation requires AWS setup'
      return true
    } else if (secretKeyPattern.test(token)) {
      metadata.tokenType = 'AWS_SECRET_ACCESS_KEY'
      metadata.formatValid = true
      metadata.service = 'AWS'
      metadata.validationNote = 'Format validated, actual AWS credentials validation requires AWS setup'
      return true
    }
    
    metadata.formatValid = false
    metadata.error = 'Invalid AWS token format'
    return false
  } catch (error) {
    console.error('Error verifying AWS token:', error)
    metadata.error = 'Validation error'
    metadata.errorDetails = error.message
    return false
  }
}

async function verifySlackToken(token: string, service: string, metadata: any): Promise<boolean> {
  try {
    // Slack token formats:
    // Bot tokens: xoxb-TOKEN_STRING
    // User tokens: xoxp-TOKEN_STRING
    // Webhook URLs: https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX
    
    if (token.startsWith('xoxb-') || token.startsWith('xoxp-')) {
      // Try to validate with Slack API (this requires a proper Slack app setup)
      const response = await fetch('https://slack.com/api/auth.test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Bearer ${token}`
        },
        body: 'token=' + encodeURIComponent(token)
      })

      if (response.ok) {
        const result = await response.json()
        if (result.ok) {
          metadata.team = result.team
          metadata.user = result.user
          metadata.teamId = result.team_id
          metadata.userId = result.user_id
          metadata.scope = result.scope
          return true
        }
      }
      
      metadata.error = 'Slack API validation failed'
      metadata.errorDetails = 'Invalid or expired Slack token'
      return false
    } else if (token.startsWith('https://hooks.slack.com/services/')) {
      // Test webhook URL
      const response = await fetch(token, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: 'Token validation test',
          attachments: [{
            text: 'This is a test message to validate the webhook URL'
          }]
        })
      })

      if (response.ok) {
        metadata.webhookValid = true
        metadata.webhookType = 'Incoming Webhook'
        return true
      }
      
      metadata.error = 'Slack webhook validation failed'
      metadata.errorDetails = 'Invalid or expired Slack webhook URL'
      return false
    }
    
    metadata.formatValid = false
    metadata.error = 'Invalid Slack token format'
    return false
  } catch (error) {
    console.error('Error verifying Slack token:', error)
    metadata.error = 'Connection error'
    metadata.errorDetails = error.message
    return false
  }
}

async function verifyDiscordToken(token: string, service: string, metadata: any): Promise<boolean> {
  try {
    // Discord token formats:
    // Bot tokens: Bot TOKEN_STRING
    // Webhook URLs: https://discord.com/api/webhooks/ID/TOKEN
    
    if (token.startsWith('https://discord.com/api/webhooks/')) {
      // Test webhook URL
      const response = await fetch(token, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          content: 'Token validation test',
          embeds: [{
            title: 'Validation Test',
            description: 'This is a test message to validate the webhook URL'
          }]
        })
      })

      if (response.ok) {
        const webhookInfo = await response.json()
        metadata.webhookValid = true
        metadata.webhookType = 'Discord Webhook'
        metadata.webhookId = webhookInfo.id
        if (webhookInfo.name) metadata.webhookName = webhookInfo.name
        return true
      }
      
      metadata.error = 'Discord webhook validation failed'
      metadata.errorDetails = 'Invalid or expired Discord webhook URL'
      return false
    }
    
    // For Discord bot tokens, we can only validate format without proper bot setup
    const botTokenPattern = /^[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}$/
    if (botTokenPattern.test(token)) {
      metadata.formatValid = true
      metadata.tokenType = 'Discord Bot Token'
      metadata.validationNote = 'Format validated, actual Discord bot validation requires proper bot setup'
      return true
    }
    
    metadata.formatValid = false
    metadata.error = 'Invalid Discord token format'
    return false
  } catch (error) {
    console.error('Error verifying Discord token:', error)
    metadata.error = 'Connection error'
    metadata.errorDetails = error.message
    return false
  }
}

async function verifyGenericToken(token: string, service: string, metadata: any, zai: any): Promise<boolean> {
  try {
    // Use AI to analyze generic tokens
    const aiPrompt = `
    Analyze the following token for format validity and provide insights:
    
    Token: ${token.substring(0, 20)}... (truncated for security)
    Service: ${service}
    
    Analyze for:
    - Token format patterns
    - Potential token type classification
    - Security considerations
    - Best practices
    
    Return a JSON object with the following structure:
    {
      "formatValid": true,
      "tokenType": "API_KEY|AUTH_TOKEN|WEBHOOK|OTHER",
      "securityRisk": "LOW|MEDIUM|HIGH",
      "insights": ["insight1", "insight2"],
      "confidence": 0.75
    }
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a security expert specializing in token analysis and API security.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.1
    })
    
    const aiAnalysis = JSON.parse(aiResponse.choices[0]?.message?.content || '{}')
    
    metadata.aiAnalysis = aiAnalysis
    metadata.tokenType = aiAnalysis.tokenType || 'UNKNOWN'
    metadata.securityRisk = aiAnalysis.securityRisk || 'MEDIUM'
    
    return aiAnalysis.formatValid || false
  } catch (error) {
    console.error('Error verifying generic token:', error)
    metadata.error = 'AI analysis failed'
    metadata.errorDetails = error.message
    return false
  }
}