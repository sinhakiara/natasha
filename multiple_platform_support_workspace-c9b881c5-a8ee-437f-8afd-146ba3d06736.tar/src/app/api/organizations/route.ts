import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    const session = await requireAuth(request)
    const userId = session.user.id

    // Get organizations where user is a member
    const organizations = await db.organization.findMany({
      where: {
        members: {
          some: {
            userId: userId
          }
        }
      },
      include: {
        _count: {
          select: {
            members: true,
            domains: true,
            monitors: true,
            scans: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ organizations })
  } catch (error) {
    console.error('Error fetching organizations:', error)
    if (error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    return NextResponse.json({ error: 'Failed to fetch organizations' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await requireAuth(request)
    const body = await request.json()
    const { name, description } = body
    const userId = session.user.id

    if (!name) {
      return NextResponse.json({ error: 'Organization name is required' }, { status: 400 })
    }

    // Create organization
    const organization = await db.organization.create({
      data: {
        name,
        description: description || null,
      }
    })

    // Add the creating user as an admin member
    await db.organizationMember.create({
      data: {
        userId,
        organizationId: organization.id,
        role: 'ADMIN'
      }
    })

    const organizationWithCounts = await db.organization.findUnique({
      where: { id: organization.id },
      include: {
        _count: {
          select: {
            members: true,
            domains: true,
            monitors: true,
            scans: true
          }
        }
      }
    })

    return NextResponse.json({ organization: organizationWithCounts })
  } catch (error) {
    console.error('Error creating organization:', error)
    if (error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    return NextResponse.json({ error: 'Failed to create organization' }, { status: 500 })
  }
}