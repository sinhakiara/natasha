import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdminAccess } from '@/lib/auth-helpers'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; memberId: string }> }
) {
  try {
    const { id, memberId } = await params
    const organizationId = id

    // Check if user has admin access to this organization
    const { membership } = await requireAdminAccess(request, organizationId)

    // Check if member exists and belongs to the organization
    const member = await db.organizationMember.findUnique({
      where: {
        id: memberId,
        organizationId
      }
    })

    if (!member) {
      return NextResponse.json({ error: 'Member not found' }, { status: 404 })
    }

    // Don't allow removing the last admin
    const adminCount = await db.organizationMember.count({
      where: {
        organizationId,
        role: 'ADMIN'
      }
    })

    if (member.role === 'ADMIN' && adminCount === 1) {
      return NextResponse.json({ error: 'Cannot remove the last admin' }, { status: 400 })
    }

    // Don't allow users to remove themselves (they should leave organization instead)
    if (member.userId === membership.userId) {
      return NextResponse.json({ error: 'Cannot remove yourself from organization' }, { status: 400 })
    }

    // Remove the member
    await db.organizationMember.delete({
      where: { id: memberId }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error removing organization member:', error)
    if (error.message === 'Unauthorized' || error.message === 'Access denied to this organization' || error.message === 'Admin access required') {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }
    return NextResponse.json({ error: 'Failed to remove organization member' }, { status: 500 })
  }
}