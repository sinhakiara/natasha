'use client'

import { useEffect, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'

interface UseSocketOptions {
  userId?: string
  autoConnect?: boolean
}

export const useSocket = (options: UseSocketOptions = {}) => {
  const { userId, autoConnect = true } = options
  const socketRef = useRef<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)

  useEffect(() => {
    if (autoConnect && userId) {
      // Initialize socket connection
      socketRef.current = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3000', {
        path: '/api/socketio',
        transports: ['websocket', 'polling'],
        timeout: 10000,
        retries: 3
      })

      const socket = socketRef.current

      // Connection event handlers
      socket.on('connect', () => {
        console.log('Socket connected:', socket.id)
        setIsConnected(true)
        
        // Join monitoring room for this user
        socket.emit('join_monitoring', userId)
        
        // Subscribe to alerts
        socket.emit('subscribe_alerts', userId)
      })

      socket.on('disconnect', (reason) => {
        console.log('Socket disconnected:', reason)
        setIsConnected(false)
      })

      socket.on('connect_error', (error) => {
        console.error('Socket connection error:', error)
        setIsConnected(false)
      })

      // Handle scan updates
      socket.on('scan_progress', (data: { scanId: string; progress: number; status: string }) => {
        console.log('Scan progress update:', data)
        // Custom event handlers will be attached by the component
      })

      // Handle monitoring events
      socket.on('monitoring_event', (event: { type: string; data: any; userId: string }) => {
        console.log('Monitoring event:', event)
      })

      // Handle new alerts
      socket.on('new_alert', (alert: any) => {
        console.log('New alert:', alert)
      })

      // Handle monitoring stats
      socket.on('monitoring_stats', (stats: any) => {
        console.log('Monitoring stats:', stats)
      })
    }

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect()
        socketRef.current = null
        setIsConnected(false)
      }
    }
  }, [userId, autoConnect])

  const joinScanRoom = (scanId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('join_scan', scanId)
      socketRef.current.join(`scan_${scanId}`)
    }
  }

  const leaveScanRoom = (scanId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('leave_scan', scanId)
      socketRef.current.leave(`scan_${scanId}`)
    }
  }

  const emitScanUpdate = (scanId: string, progress: number, status: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('scan_update', { scanId, progress, status })
    }
  }

  const onScanProgress = (callback: (data: { scanId: string; progress: number; status: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.on('scan_progress', callback)
    }
  }

  const offScanProgress = (callback: (data: { scanId: string; progress: number; status: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.off('scan_progress', callback)
    }
  }

  const onMonitoringEvent = (callback: (event: { type: string; data: any; userId: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.on('monitoring_event', callback)
    }
  }

  const offMonitoringEvent = (callback: (event: { type: string; data: any; userId: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.off('monitoring_event', callback)
    }
  }

  const onNewAlert = (callback: (alert: any) => void) => {
    if (socketRef.current) {
      socketRef.current.on('new_alert', callback)
    }
  }

  const offNewAlert = (callback: (alert: any) => void) => {
    if (socketRef.current) {
      socketRef.current.off('new_alert', callback)
    }
  }

  const onThreatUpdate = (callback: (data: { threat: any; action: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.on('threat_update', callback)
    }
  }

  const offThreatUpdate = (callback: (data: { threat: any; action: string }) => void) => {
    if (socketRef.current) {
      socketRef.current.off('threat_update', callback)
    }
  }

  const joinThreatRoom = (userId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('join_threat_intelligence', userId)
      socketRef.current.join(`threat_intel_${userId}`)
    }
  }

  const leaveThreatRoom = (userId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('leave_threat_intelligence', userId)
      socketRef.current.leave(`threat_intel_${userId}`)
    }
  }

  return {
    socket: socketRef.current,
    isConnected,
    joinScanRoom,
    leaveScanRoom,
    emitScanUpdate,
    onScanProgress,
    offScanProgress,
    onMonitoringEvent,
    offMonitoringEvent,
    onNewAlert,
    offNewAlert,
    onThreatUpdate,
    offThreatUpdate,
    joinThreatRoom,
    leaveThreatRoom
  }
}