import { db } from '@/lib/db'

// Secret patterns for detecting various types of leaks
const SECRET_PATTERNS = {
  // API Keys
  'api_key': /(?:api_key|apikey|api-key)[\s\'":=]+([a-zA-Z0-9_\-]{16,})/gi,
  'aws_access_key': /AKIA[0-9A-Z]{16}/gi,
  'aws_secret_key': /[0-9a-zA-Z/+]{40}/gi,
  'github_token': /gh[pousr]_[0-9a-zA-Z_]{36}/gi,
  'slack_token': /xox[baprs]-[0-9a-zA-Z-]{43,}/gi,
  'discord_token': /[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}/gi,
  
  // Database URLs
  'database_url': /(?:postgresql|mysql|mongodb|redis):\/\/[^\s\'"<>]+/gi,
  
  // Private keys
  'private_key': /-----BEGIN(?: [A-Z]+)? PRIVATE KEY-----[\s\S]*?-----END(?: [A-Z]+)? PRIVATE KEY-----/gi,
  
  // Webhooks
  'webhook_url': /https?:\/\/hooks\.slack\.com\/services\/[A-Z0-9]+\/[A-Z0-9]+\/[A-Za-z0-9_]+/gi,
  
  // Credentials
  'password': /(?:password|pwd|pass)[\s\'":=]+([^\s\'"<>]+)/gi,
  'bearer_token': /bearer[\s\'":=]+([a-zA-Z0-9_\-\.~=]+)/gi,
}

interface GitHubRepoContent {
  path: string
  content: string
  sha: string
  url: string
}

interface GitHubMonitorConfig {
  includeExtensions?: string[]
  excludePaths?: string[]
  maxFileSize?: number
  checkCommits?: boolean
  checkPullRequests?: boolean
}

export class GitHubMonitor {
  private config: GitHubMonitorConfig

  constructor(config: GitHubMonitorConfig = {}) {
    this.config = {
      includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.rs', '.c', '.cpp', '.h', '.json', '.yaml', '.yml', '.env', '.conf', '.config'],
      excludePaths: ['node_modules', '.git', 'dist', 'build', 'vendor'],
      maxFileSize: 1024 * 1024, // 1MB
      checkCommits: true,
      checkPullRequests: true,
      ...config
    }
  }

  async monitorRepository(monitorId: string, owner: string, repo: string, githubToken?: string): Promise<void> {
    try {
      console.log(`Starting monitoring for ${owner}/${repo}`)
      
      // Get repository contents
      const contents = await this.getRepositoryContents(owner, repo, githubToken)
      
      // Scan each file for secrets
      for (const item of contents) {
        if (item.type === 'file' && this.shouldScanFile(item.path)) {
          const fileContent = await this.getFileContent(owner, repo, item.path, githubToken)
          if (fileContent) {
            const leaks = this.scanForSecrets(fileContent, item.path)
            
            // Report any found leaks
            for (const leak of leaks) {
              await this.reportLeak(monitorId, leak)
            }
          }
        }
      }

      // Monitor recent commits if enabled
      if (this.config.checkCommits) {
        await this.monitorRecentCommits(monitorId, owner, repo, githubToken)
      }

      // Monitor pull requests if enabled
      if (this.config.checkPullRequests) {
        await this.monitorPullRequests(monitorId, owner, repo, githubToken)
      }

    } catch (error) {
      console.error(`Error monitoring repository ${owner}/${repo}:`, error)
      throw error
    }
  }

  private async getRepositoryContents(owner: string, repo: string, githubToken?: string, path: string = ''): Promise<any[]> {
    const headers: Record<string, string> = {
      'Accept': 'application/vnd.github.v3+json'
    }

    if (githubToken) {
      headers['Authorization'] = `token ${githubToken}`
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`
    const response = await fetch(url, { headers })

    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()
    
    if (Array.isArray(data)) {
      const contents: any[] = []
      
      for (const item of data) {
        if (item.type === 'dir') {
          const subContents = await this.getRepositoryContents(owner, repo, githubToken, item.path)
          contents.push(...subContents)
        } else {
          contents.push(item)
        }
      }
      
      return contents
    }

    return [data]
  }

  private async getFileContent(owner: string, repo: string, path: string, githubToken?: string): Promise<string | null> {
    const headers: Record<string, string> = {
      'Accept': 'application/vnd.github.v3+json'
    }

    if (githubToken) {
      headers['Authorization'] = `token ${githubToken}`
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`
    const response = await fetch(url, { headers })

    if (!response.ok) {
      console.error(`Error fetching file ${path}: ${response.status} ${response.statusText}`)
      return null
    }

    const data = await response.json()
    
    if (data.content) {
      return Buffer.from(data.content, 'base64').toString('utf-8')
    }

    return null
  }

  private shouldScanFile(path: string): boolean {
    // Check file extension
    const ext = path.substring(path.lastIndexOf('.')).toLowerCase()
    if (this.config.includeExtensions && !this.config.includeExtensions.includes(ext)) {
      return false
    }

    // Check excluded paths
    if (this.config.excludePaths) {
      for (const excludePath of this.config.excludePaths) {
        if (path.includes(excludePath)) {
          return false
        }
      }
    }

    return true
  }

  private scanForSecrets(content: string, filePath: string): Array<{
    type: string
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
    title: string
    description: string
    content: string
    source: string
    metadata: Record<string, any>
  }> {
    const leaks: Array<any> = []

    for (const [patternName, pattern] of Object.entries(SECRET_PATTERNS)) {
      const matches = content.matchAll(pattern)
      
      for (const match of matches) {
        const secret = match[1] || match[0]
        
        // Skip false positives
        if (this.isFalsePositive(secret, patternName)) {
          continue
        }

        const leak = {
          type: this.mapPatternToLeakType(patternName),
          severity: this.getSeverityForPattern(patternName),
          title: `${this.mapPatternToLeakType(patternName)} detected in ${filePath}`,
          description: `A potential ${patternName.replace(/_/g, ' ')} was found in the file ${filePath}`,
          content: this.redactSecret(secret),
          source: filePath,
          metadata: {
            pattern: patternName,
            line: this.getLineNumber(content, match.index),
            file: filePath,
            matchedText: secret,
            context: this.getContext(content, match.index, 50)
          }
        }

        leaks.push(leak)
      }
    }

    return leaks
  }

  private isFalsePositive(secret: string, patternName: string): boolean {
    // Common false positive patterns
    const falsePositives = [
      /example/i,
      /test/i,
      /dummy/i,
      /placeholder/i,
      /your_/i,
      /change_me/i,
      /secret$/i.test(secret) && secret.length < 10,
      /^password$/i.test(secret),
    ]

    return falsePositives.some(fp => fp.test(secret))
  }

  private mapPatternToLeakType(patternName: string): string {
    const mapping: Record<string, string> = {
      'api_key': 'API_KEY',
      'aws_access_key': 'API_KEY',
      'aws_secret_key': 'API_KEY',
      'github_token': 'TOKEN',
      'slack_token': 'TOKEN',
      'discord_token': 'TOKEN',
      'database_url': 'DATABASE_URL',
      'private_key': 'CERTIFICATE',
      'webhook_url': 'WEBHOOK',
      'password': 'PASSWORD',
      'bearer_token': 'TOKEN',
    }

    return mapping[patternName] || 'CUSTOM'
  }

  private getSeverityForPattern(patternName: string): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
    const severity: Record<string, 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'> = {
      'api_key': 'HIGH',
      'aws_access_key': 'CRITICAL',
      'aws_secret_key': 'CRITICAL',
      'github_token': 'HIGH',
      'slack_token': 'HIGH',
      'discord_token': 'HIGH',
      'database_url': 'HIGH',
      'private_key': 'CRITICAL',
      'webhook_url': 'MEDIUM',
      'password': 'HIGH',
      'bearer_token': 'HIGH',
    }

    return severity[patternName] || 'MEDIUM'
  }

  private redactSecret(secret: string): string {
    if (secret.length <= 8) {
      return '*'.repeat(secret.length)
    }
    
    const visibleChars = 4
    return secret.substring(0, visibleChars) + '*'.repeat(secret.length - visibleChars * 2) + secret.substring(secret.length - visibleChars)
  }

  private getLineNumber(content: string, index: number): number {
    const lines = content.substring(0, index).split('\n')
    return lines.length
  }

  private getContext(content: string, index: number, contextSize: number): string {
    const start = Math.max(0, index - contextSize)
    const end = Math.min(content.length, index + contextSize)
    return content.substring(start, end)
  }

  private async reportLeak(monitorId: string, leak: any): Promise<void> {
    try {
      // Store the leak in the database
      await fetch('/api/leaks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          monitorId,
          ...leak
        })
      })

      console.log(`Leak reported: ${leak.title}`)
    } catch (error) {
      console.error('Error reporting leak:', error)
    }
  }

  private async monitorRecentCommits(monitorId: string, owner: string, repo: string, githubToken?: string): Promise<void> {
    const headers: Record<string, string> = {
      'Accept': 'application/vnd.github.v3+json'
    }

    if (githubToken) {
      headers['Authorization'] = `token ${githubToken}`
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/commits?per_page=10`
    const response = await fetch(url, { headers })

    if (!response.ok) {
      console.error(`Error fetching commits: ${response.status} ${response.statusText}`)
      return
    }

    const commits = await response.json()

    for (const commit of commits) {
      // Check commit message for secrets
      if (commit.commit && commit.commit.message) {
        const messageLeaks = this.scanForSecrets(commit.commit.message, `commit:${commit.sha}`)
        for (const leak of messageLeaks) {
          leak.source = `commit:${commit.sha}`
          leak.description += ` in commit message`
          await this.reportLeak(monitorId, leak)
        }
      }

      // Check each file in the commit
      if (commit.files) {
        for (const file of commit.files) {
          if (file.patch && this.shouldScanFile(file.filename)) {
            const patchLeaks = this.scanForSecrets(file.patch, `commit:${commit.sha}:${file.filename}`)
            for (const leak of patchLeaks) {
              leak.source = `commit:${commit.sha}:${file.filename}`
              leak.description += ` in commit diff`
              await this.reportLeak(monitorId, leak)
            }
          }
        }
      }
    }
  }

  private async monitorPullRequests(monitorId: string, owner: string, repo: string, githubToken?: string): Promise<void> {
    const headers: Record<string, string> = {
      'Accept': 'application/vnd.github.v3+json'
    }

    if (githubToken) {
      headers['Authorization'] = `token ${githubToken}`
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/pulls?state=open&per_page=10`
    const response = await fetch(url, { headers })

    if (!response.ok) {
      console.error(`Error fetching pull requests: ${response.status} ${response.statusText}`)
      return
    }

    const prs = await response.json()

    for (const pr of prs) {
      // Check PR title and body
      if (pr.title) {
        const titleLeaks = this.scanForSecrets(pr.title, `pr:${pr.number}:title`)
        for (const leak of titleLeaks) {
          leak.source = `pr:${pr.number}:title`
          leak.description += ` in PR title`
          await this.reportLeak(monitorId, leak)
        }
      }

      if (pr.body) {
        const bodyLeaks = this.scanForSecrets(pr.body, `pr:${pr.number}:body`)
        for (const leak of bodyLeaks) {
          leak.source = `pr:${pr.number}:body`
          leak.description += ` in PR body`
          await this.reportLeak(monitorId, leak)
        }
      }

      // Check PR files
      const prFilesUrl = `https://api.github.com/repos/${owner}/${repo}/pulls/${pr.number}/files`
      const filesResponse = await fetch(prFilesUrl, { headers })

      if (filesResponse.ok) {
        const files = await filesResponse.json()

        for (const file of files) {
          if (file.patch && this.shouldScanFile(file.filename)) {
            const patchLeaks = this.scanForSecrets(file.patch, `pr:${pr.number}:${file.filename}`)
            for (const leak of patchLeaks) {
              leak.source = `pr:${pr.number}:${file.filename}`
              leak.description += ` in PR diff`
              await this.reportLeak(monitorId, leak)
            }
          }
        }
      }
    }
  }
}