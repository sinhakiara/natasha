import { getServerSession } from 'next-auth'
import { authOptions } from './auth'
import { db } from './db'

export interface UserPermission {
  canManageUsers: boolean
  canManageOrganizations: boolean
  canCreateScans: boolean
  canManageMonitors: boolean
  canViewReports: boolean
  userRole: string
  organizationId: string
}

export async function getUserPermissions(organizationId: string): Promise<UserPermission | null> {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return null
    }

    // Get user's role in the organization
    const userMembership = await db.organizationMember.findUnique({
      where: {
        userId_organizationId: {
          userId: session.user.id,
          organizationId
        }
      }
    })

    if (!userMembership) {
      return null
    }

    const role = userMembership.role

    // Define permissions based on role
    const permissions = {
      ADMIN: {
        canManageUsers: true,
        canManageOrganizations: true,
        canCreateScans: true,
        canManageMonitors: true,
        canViewReports: true
      },
      MEMBER: {
        canManageUsers: false,
        canManageOrganizations: false,
        canCreateScans: true,
        canManageMonitors: true,
        canViewReports: true
      },
      VIEWER: {
        canManageUsers: false,
        canManageOrganizations: false,
        canCreateScans: false,
        canManageMonitors: false,
        canViewReports: true
      }
    }

    return {
      ...permissions[role],
      userRole: role,
      organizationId
    }
  } catch (error) {
    console.error('Error getting user permissions:', error)
    return null
  }
}

export async function requireAuth(request: Request) {
  const session = await getServerSession(authOptions)
  
  if (!session?.user?.id) {
    throw new Error('Unauthorized')
  }
  
  return session
}

export async function requireOrganizationAccess(request: Request, organizationId: string) {
  const session = await requireAuth(request)
  
  const userMembership = await db.organizationMember.findUnique({
    where: {
      userId_organizationId: {
        userId: session.user.id,
        organizationId
      }
    }
  })

  if (!userMembership) {
    throw new Error('Access denied to this organization')
  }
  
  return {
    session,
    membership: userMembership
  }
}

export async function requireAdminAccess(request: Request, organizationId: string) {
  const { session, membership } = await requireOrganizationAccess(request, organizationId)
  
  if (membership.role !== 'ADMIN') {
    throw new Error('Admin access required')
  }
  
  return {
    session,
    membership
  }
}

export async function requireMemberOrAdminAccess(request: Request, organizationId: string) {
  const { session, membership } = await requireOrganizationAccess(request, organizationId)
  
  if (!['ADMIN', 'MEMBER'].includes(membership.role)) {
    throw new Error('Member or admin access required')
  }
  
  return {
    session,
    membership
  }
}