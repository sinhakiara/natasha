import GitCTFLab from '@/components/git-ctf-lab'

export default function Home() {
  return <GitCTFLab />
}