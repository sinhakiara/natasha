# 🚀 GitLab CTF Platform

A modern, interactive Git learning platform with Capture The Flag (CTF) challenges designed to teach Git forensic analysis, security auditing, and recovery techniques through hands-on exercises.

## ✨ Features

This platform provides an immersive learning experience with:

### 🎯 Core Platform
- **⚡ Next.js 15** - The React framework for production with App Router
- **📘 TypeScript 5** - Type-safe JavaScript for better developer experience
- **🎨 Tailwind CSS 4** - Utility-first CSS framework for rapid UI development

### 🧩 UI Components & Styling
- **🧩 shadcn/ui** - High-quality, accessible components built on Radix UI
- **🎯 Lucide React** - Beautiful & consistent icon library
- **🌈 Framer Motion** - Production-ready motion library for React

### 🔧 Git Learning Features
- **🖥️ Interactive Terminal Simulator** - Practice Git commands in a safe environment
- **🏆 CTF Challenges** - Real-world Git forensic scenarios
- **📚 Progressive Learning** - From basic to advanced Git operations
- **🎮 Gamified Experience** - Points, achievements, and progress tracking

### 🎯 Challenge Categories
- **🔍 Forensic Analysis** - Find hidden data in commit history
- **🛠️ Recovery Operations** - Restore corrupted repositories
- **🔒 Security Auditing** - Identify vulnerabilities in Git workflows
- **🧠 Advanced Techniques** - Complex Git scenarios and problem-solving

## 🎯 Why This Platform?

- **🏎️ Interactive Learning** - Hands-on Git practice with real scenarios
- **🎨 Beautiful UI** - Modern, responsive interface with smooth animations
- **🔒 Type Safety** - Full TypeScript configuration
- **📱 Mobile-Friendly** - Works seamlessly on all devices
- **🎮 Gamified Experience** - Engaging challenges with achievements
- **📊 Progress Tracking** - Monitor your learning journey
- **🚀 Production Ready** - Optimized for deployment

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000) to see the platform running.

## 🎯 Learning Path

The platform offers a comprehensive Git learning journey:

### 🌱 Beginner Challenges
- **Basic Git Operations** - Learn fundamental commands
- **Commit History Analysis** - Understanding Git's timeline
- **Simple File Operations** - Track and manage changes

### 🚀 Intermediate Challenges  
- **Branch Management** - Work with multiple branches
- **Merge Operations** - Combine changes safely
- **Reset Operations** - Undo changes effectively

### 🎓 Advanced Challenges
- **Repository Recovery** - Fix corrupted repositories
- **Security Auditing** - Find vulnerabilities in Git history
- **Complex Forensics** - Advanced analysis techniques

## 📁 Project Structure

```
src/
├── app/                 # Next.js App Router pages
│   ├── challenges/     # Individual challenge pages
│   └── layout.tsx       # Root layout
├── components/          # Reusable React components
│   ├── git-*.tsx        # Git learning components
│   └── ui/             # shadcn/ui components
├── hooks/              # Custom React hooks
└── lib/                # Utility functions and configurations
    ├── git-environment.ts # Git simulation engine
    └── socket.ts       # WebSocket support
```

## 🎨 Available Features

### 🧩 Interactive Components
- **Git Terminal Simulator** - Practice Git commands safely
- **Challenge Interface** - Structured learning scenarios
- **Progress Tracking** - Visual feedback on achievements
- **Real-time Feedback** - Instant validation of commands

### 🎯 Challenge Types
- **Lost Commit Recovery** - Find deleted commits
- **Secret Message Detection** - Uncover hidden data
- **Repository Repair** - Fix broken Git repositories
- **Security Audits** - Identify vulnerabilities
- **Branch Analysis** - Navigate complex branch structures

### 🎮 Gamification Features
- **Achievement System** - Unlock badges and milestones
- **Progress Tracking** - Monitor learning journey
- **Score System** - Earn points for completed challenges
- **Difficulty Levels** - Progressive challenge complexity

## 🚀 Deployment

The platform is ready for production deployment:

```bash
# Build optimized production version
npm run build

# Start production server
npm start
```

## 🤝 Contributing

This platform is designed to help developers master Git through interactive challenges. Contributions to improve the learning experience are welcome!

---

Built with ❤️ for the Git learning community. Happy coding! 🚀
