'use client'

import { useState, useEffect } from 'react'
import { GitCommit, FileText, AlertTriangle, CheckCircle } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

interface GitAnimatedNodeProps {
  commit: {
    id: string
    message: string
    hash: string
    files: string[]
    hasSecret: boolean
    timestamp: number
    isDeleted: boolean
  }
  isSelected: boolean
  onClick: () => void
  index: number
}

const GitAnimatedNode = ({ commit, isSelected, onClick, index }: GitAnimatedNodeProps) => {
  const [isHovered, setIsHovered] = useState(false)
  const [showFiles, setShowFiles] = useState(false)

  const nodeVariants = {
    hidden: { 
      opacity: 0, 
      x: -50,
      scale: 0.8
    },
    visible: { 
      opacity: commit.isDeleted ? 0.5 : 1, 
      x: 0,
      scale: 1,
      transition: {
        duration: 0.5,
        delay: index * 0.1
      }
    },
    hover: { 
      scale: 1.02,
      transition: { duration: 0.2 }
    },
    selected: {
      scale: 1.01,
      boxShadow: "0 0 0 3px rgba(59, 130, 246, 0.5)"
    }
  }

  const lineVariants = {
    hidden: { height: 0 },
    visible: { 
      height: "100%",
      transition: { duration: 0.5, delay: index * 0.1 }
    }
  }

  return (
    <motion.div
      variants={nodeVariants}
      initial="hidden"
      animate={isSelected ? "selected" : (isHovered ? "hover" : "visible")}
      whileHover="hover"
      className={`relative flex items-center gap-4 p-4 rounded-lg border cursor-pointer transition-all duration-300 ${
        commit.isDeleted 
          ? 'opacity-50 bg-slate-100 dark:bg-slate-800' 
          : 'bg-white dark:bg-slate-900 hover:shadow-lg'
      }`}
      onClick={onClick}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      {/* Connection line */}
      {index > 0 && (
        <motion.div
          variants={lineVariants}
          initial="hidden"
          animate="visible"
          className="absolute left-8 top-0 w-0.5 bg-slate-300 dark:bg-slate-600"
          style={{ height: '-24px', top: '-24px' }}
        />
      )}
      
      {/* Commit node */}
      <motion.div
        className="relative z-10"
        animate={{
          rotate: isHovered ? 360 : 0,
          scale: isHovered ? 1.1 : 1
        }}
        transition={{ duration: 0.3 }}
      >
        <div className={`w-4 h-4 rounded-full ${
          commit.hasSecret ? 'bg-red-500 animate-pulse' : 'bg-green-500'
        }`}>
          {commit.hasSecret && (
            <motion.div
              className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
          )}
        </div>
      </motion.div>
      
      {/* Commit details */}
      <div className="flex-1">
        <motion.div 
          className="flex items-center gap-2 mb-1"
          animate={{ x: isHovered ? 5 : 0 }}
        >
          <GitCommit className="h-4 w-4 text-slate-500" />
          <motion.span 
            className="font-mono text-sm text-slate-600 dark:text-slate-300"
            animate={{ color: isHovered ? '#3b82f6' : '#64748b' }}
          >
            {commit.hash}
          </motion.span>
          
          <AnimatePresence>
            {commit.hasSecret && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
              >
                <div className="px-2 py-1 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded-full text-xs font-medium flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  Secret
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {commit.isDeleted && (
            <div className="px-2 py-1 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full text-xs font-medium flex items-center gap-1">
              <CheckCircle className="h-3 w-3" />
              Deleted
            </div>
          )}
        </motion.div>
        
        <motion.p 
          className="font-medium text-slate-800 dark:text-slate-100"
          animate={{ y: isHovered ? -2 : 0 }}
        >
          {commit.message}
        </motion.p>
        
        <motion.div 
          className="text-sm text-slate-500 mt-1"
          animate={{ opacity: showFiles ? 1 : 0.7 }}
        >
          <button
            onClick={(e) => {
              e.stopPropagation()
              setShowFiles(!showFiles)
            }}
            className="hover:text-slate-700 dark:hover:text-slate-300 transition-colors"
          >
            Files: {commit.files.length} {showFiles ? '▼' : '►'}
          </button>
          
          <AnimatePresence>
            {showFiles && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="mt-2 space-y-1"
              >
                {commit.files.map((file, fileIndex) => (
                  <motion.div
                    key={fileIndex}
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: fileIndex * 0.1 }}
                    className="flex items-center gap-2 ml-4 p-2 bg-slate-50 dark:bg-slate-800 rounded"
                  >
                    <FileText className="h-3 w-3" />
                    <span className="text-xs">{file}</span>
                    {commit.hasSecret && file.includes('config') && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-xs text-red-500"
                      >
                        ⚠️ Contains secret
                      </motion.div>
                    )}
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
      
      {/* Timestamp */}
      <motion.div 
        className="text-xs text-slate-400"
        animate={{ opacity: isHovered ? 1 : 0.7 }}
      >
        {new Date(commit.timestamp).toLocaleTimeString()}
      </motion.div>
    </motion.div>
  )
}

export default GitAnimatedNode