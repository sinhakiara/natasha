'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Terminal, 
  Play, 
  CheckCircle, 
  AlertTriangle, 
  Zap,
  Shield,
  Eye,
  Trash2,
  RotateCcw
} from 'lucide-react'

interface GitOperationCardProps {
  operation: {
    type: 'soft-reset' | 'hard-reset' | 'reflog' | 'show' | 'checkout'
    description: string
    command: string
  }
  onExecute: () => void
  isExecuting: boolean
  completed?: boolean
}

const GitOperationCard = ({ operation, onExecute, isExecuting, completed }: GitOperationCardProps) => {
  const [isHovered, setIsHovered] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const getOperationIcon = (type: string) => {
    switch (type) {
      case 'soft-reset':
        return <RotateCcw className="h-5 w-5" />
      case 'hard-reset':
        return <Trash2 className="h-5 w-5" />
      case 'reflog':
        return <Eye className="h-5 w-5" />
      case 'show':
        return <Eye className="h-5 w-5" />
      case 'checkout':
        return <Zap className="h-5 w-5" />
      default:
        return <Terminal className="h-5 w-5" />
    }
  }

  const getOperationColor = (type: string) => {
    switch (type) {
      case 'soft-reset':
        return 'bg-blue-500'
      case 'hard-reset':
        return 'bg-red-500'
      case 'reflog':
        return 'bg-purple-500'
      case 'show':
        return 'bg-green-500'
      case 'checkout':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getOperationRisk = (type: string) => {
    switch (type) {
      case 'soft-reset':
        return { level: 'low', color: 'bg-green-100 text-green-800', text: 'Safe' }
      case 'hard-reset':
        return { level: 'high', color: 'bg-red-100 text-red-800', text: 'High Risk' }
      case 'reflog':
        return { level: 'low', color: 'bg-green-100 text-green-800', text: 'Safe' }
      case 'show':
        return { level: 'low', color: 'bg-green-100 text-green-800', text: 'Safe' }
      case 'checkout':
        return { level: 'medium', color: 'bg-yellow-100 text-yellow-800', text: 'Medium Risk' }
      default:
        return { level: 'low', color: 'bg-green-100 text-green-800', text: 'Safe' }
    }
  }

  const risk = getOperationRisk(operation.type)

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5 }
    },
    hover: { 
      y: -2,
      scale: 1.01,
      transition: { duration: 0.2 }
    },
    executing: {
      scale: 0.99,
      transition: { duration: 0.1 }
    }
  }

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate={isExecuting ? "executing" : (isHovered ? "hover" : "visible")}
      whileHover="hover"
      className="h-full"
    >
      <Card 
        className={`h-full cursor-pointer transition-all duration-300 ${
          completed ? 'border-green-500 bg-green-50 dark:bg-green-950' : ''
        } ${isExecuting ? 'ring-2 ring-blue-500' : ''}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <motion.div
                animate={{ rotate: isHovered ? 360 : 0 }}
                transition={{ duration: 0.5 }}
                className={`p-2 rounded-lg ${getOperationColor(operation.type)} text-white`}
              >
                {getOperationIcon(operation.type)}
              </motion.div>
              <span className="capitalize">
                {operation.type.split('-').map(word => 
                  word.charAt(0).toUpperCase() + word.slice(1)
                ).join(' ')}
              </span>
            </CardTitle>
            
            <AnimatePresence>
              {completed && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                >
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge 
              variant="secondary" 
              className={`${risk.color} text-xs font-medium`}
            >
              {risk.text}
            </Badge>
            {risk.level === 'high' && (
              <AlertTriangle className="h-4 w-4 text-red-500" />
            )}
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <motion.p 
            className="text-sm text-slate-600 dark:text-slate-300"
            animate={{ opacity: showDetails ? 1 : 0.8 }}
          >
            {operation.description}
          </motion.p>
          
          <motion.div 
            className="bg-slate-100 dark:bg-slate-800 p-3 rounded-lg font-mono text-sm relative overflow-hidden"
            whileHover={{ scale: 1.02 }}
          >
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-slate-500" />
              <span>{operation.command}</span>
            </div>
            
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/10 to-transparent"
              animate={{ x: ['-100%', '100%'] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              style={{ display: isHovered ? 'block' : 'none' }}
            />
          </motion.div>
          
          <Button 
            onClick={onExecute}
            className="w-full relative overflow-hidden"
            disabled={isExecuting}
            variant={completed ? "secondary" : "default"}
          >
            <AnimatePresence mode="wait">
              {isExecuting ? (
                <motion.div
                  key="executing"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex items-center gap-2"
                >
                  <motion.div
                    className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  />
                  Executing...
                </motion.div>
              ) : completed ? (
                <motion.div
                  key="completed"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex items-center gap-2"
                >
                  <CheckCircle className="h-4 w-4" />
                  Completed
                </motion.div>
              ) : (
                <motion.div
                  key="execute"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex items-center gap-2"
                >
                  <Play className="h-4 w-4" />
                  Execute
                </motion.div>
              )}
            </AnimatePresence>
          </Button>
          
          <motion.button
            onClick={() => setShowDetails(!showDetails)}
            className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 transition-colors w-full text-left"
            whileHover={{ scale: 1.02 }}
          >
            {showDetails ? 'Hide Details' : 'Show Details'} {showDetails ? '▲' : '▼'}
          </motion.button>
          
          <AnimatePresence>
            {showDetails && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="text-xs text-slate-600 dark:text-slate-400 space-y-2"
              >
                <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded">
                  <strong>What it does:</strong> {operation.description}
                </div>
                <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded">
                  <strong>When to use:</strong> This operation is best used when you need to {operation.description.toLowerCase()}.
                </div>
                {risk.level === 'high' && (
                  <div className="p-2 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded">
                    <strong>⚠️ Warning:</strong> This operation cannot be undone easily. Make sure you understand the consequences before executing.
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  )
}

export default GitOperationCard