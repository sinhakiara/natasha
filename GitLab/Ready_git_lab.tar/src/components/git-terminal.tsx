'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { 
  Terminal, 
  ChevronRight, 
  RotateCcw, 
  HelpCircle, 
  CheckCircle, 
  XCircle,
  FileText,
  FolderOpen,
  GitBranch,
  GitCommit,
  GitMerge
} from 'lucide-react'

interface TerminalLine {
  type: 'command' | 'output' | 'error' | 'success'
  content: string
  timestamp?: Date
}

interface GitCommand {
  command: string
  description: string
  expectedOutput?: string
  validation?: (output: string) => boolean
}

interface GitTerminalProps {
  challengeId: string
  onCommandSuccess?: (command: string) => void
  onChallengeComplete?: () => void
}

const GitTerminal: React.FC<GitTerminalProps> = ({ 
  challengeId, 
  onCommandSuccess, 
  onChallengeComplete 
}) => {
  const [input, setInput] = useState('')
  const [history, setHistory] = useState<TerminalLine[]>([])
  const [currentPath, setCurrentPath] = useState('/home/user/git-ctf')
  const [solvedCommands, setSolvedCommands] = useState<Set<string>>(new Set())
  const [showHint, setShowHint] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Challenge-specific command sequences and validation
  const challengeConfigs: Record<string, {
    title: string
    description: string
    commands: GitCommand[]
    successMessage: string
    flag?: string
  }> = {
    'lost-commit': {
      title: 'The Lost Commit',
      description: 'Recover the deleted commit containing the secret configuration.',
      commands: [
        {
          command: 'git log --oneline',
          description: 'View commit history',
          expectedOutput: 'def5678 Initial commit'
        },
        {
          command: 'git reflog',
          description: 'Show reflog to find deleted commits',
          expectedOutput: 'abc1234 HEAD@{1}: commit: Add config with API key'
        },
        {
          command: 'git show abc1234',
          description: 'Show the deleted commit details',
          expectedOutput: 'FLAG{LOST_COMMIT_RECOVERED_2024}'
        }
      ],
      successMessage: 'Excellent! You successfully recovered the lost commit and found the flag!',
      flag: 'FLAG{LOST_COMMIT_RECOVERED_2024}'
    },
    'detached-head': {
      title: 'Detached Head Nightmare',
      description: 'Navigate back from detached HEAD state to main branch.',
      commands: [
        {
          command: 'git status',
          description: 'Check current status',
          expectedOutput: 'HEAD detached at abc1234'
        },
        {
          command: 'git branch',
          description: 'List available branches',
          expectedOutput: '* main'
        },
        {
          command: 'git checkout main',
          description: 'Switch back to main branch',
          expectedOutput: 'Switched to branch'
        }
      ],
      successMessage: 'Great! You successfully navigated back to the main branch.',
      flag: 'FLAG{DETACHED_HEAD_SURVIVOR}'
    },
    'api-key-leak': {
      title: 'API Key Leak',
      description: 'Find the API key that was accidentally committed.',
      commands: [
        {
          command: 'git log --oneline -p',
          description: 'Show commit history with changes',
          expectedOutput: '+API_KEY="sk-1234567890abcdef"'
        },
        {
          command: 'git log --grep="API_KEY" --oneline',
          description: 'Search for commits containing API_KEY',
          expectedOutput: 'abc1234 Add config with API key'
        }
      ],
      successMessage: 'Perfect! You found the API key leak and identified the vulnerable commit.',
      flag: 'FLAG{SECURITY_AUDITOR}'
    },
    'broken-repo': {
      title: 'The Broken Repository',
      description: 'Fix the corrupted repository.',
      commands: [
        {
          command: 'git status',
          description: 'Check repository status',
          expectedOutput: 'fatal: not a git repository'
        },
        {
          command: 'git init',
          description: 'Initialize git repository',
          expectedOutput: 'Initialized empty Git repository'
        },
        {
          command: 'git add .',
          description: 'Add all files to staging',
          expectedOutput: ''
        },
        {
          command: 'git commit -m "Initial commit"',
          description: 'Create initial commit',
          expectedOutput: '1 file changed, 1 insertion'
        }
      ],
      successMessage: 'Excellent! You successfully repaired the broken repository.',
      flag: 'FLAG{RECOVERY_MASTER_2024}'
    }
  }

  const currentChallenge = challengeConfigs[challengeId] || challengeConfigs['lost-commit']

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }

  useEffect(() => {
    scrollToBottom()
  }, [history])

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  const addTerminalLine = (line: TerminalLine) => {
    setHistory(prev => [...prev, { ...line, timestamp: new Date() }])
  }

  const simulateCommand = (command: string) => {
    const cleanCommand = command.trim()
    
    // Add command to history
    addTerminalLine({
      type: 'command',
      content: `${currentPath}$ ${cleanCommand}`
    })

    // Simulate different Git commands
    let output = ''
    let lineType: 'output' | 'error' | 'success' = 'output'

    switch (cleanCommand) {
      case 'git status':
        if (challengeId === 'broken-repo') {
          output = 'fatal: not a git repository (or any of the parent directories)'
          lineType = 'error'
        } else {
          output = 'On branch main\nYour branch is up to date with \'origin/main\'.\n\nnothing to commit, working tree clean'
        }
        break
      
      case 'git log --oneline':
        if (challengeId === 'lost-commit') {
          output = 'def5678 Initial commit'
        } else {
          output = 'abc1234 Add feature\nxyz5678 Initial commit'
        }
        break
      
      case 'git reflog':
        if (challengeId === 'lost-commit') {
          output = 'abc1234 HEAD@{0}: commit: Add config with API key\ndef5678 HEAD@{1}: commit: Initial commit'
        } else {
          output = 'abc1234 HEAD@{0}: commit: Add feature\ndef5678 HEAD@{1}: commit: Initial commit'
        }
        break
      
      case 'git show abc1234':
        if (challengeId === 'lost-commit') {
          output = 'commit abc1234\nAuthor: John Doe <john@example.com>\nDate: Mon Jan 1 12:00:00 2024 +0000\n\n    Add config with API key\n\ndiff --git a/config.py b/config.py\nnew file mode 100644\nindex 0000000..e69de29\n--- /dev/null\n+++ b/config.py\n@@ -0,0 +1 @@\n+API_KEY="sk-1234567890abcdef"\n+FLAG{LOST_COMMIT_RECOVERED_2024}'
        } else {
          output = 'commit abc1234\nAuthor: John Doe <john@example.com>\nDate: Mon Jan 1 12:00:00 2024 +0000\n\n    Add feature\n\ndiff --git a/file.txt b/file.txt\nnew file mode 100644\nindex 0000000..e69de29\n--- /dev/null\n+++ b/file.txt\n@@ -0,0 +1 @@\n+Feature content'
        }
        break
      
      case 'git branch':
        output = '* main\n  feature-branch'
        break
      
      case 'git checkout main':
        output = 'Switched to branch \'main\''
        lineType = 'success'
        break
      
      case 'git log --oneline -p':
        if (challengeId === 'api-key-leak') {
          output = 'abc1234 Add config with API key\ndiff --git a/config.py b/config.py\nnew file mode 100644\nindex 0000000..e69de29\n--- /dev/null\n+++ b/config.py\n@@ -0,0 +1 @@\n+API_KEY="sk-1234567890abcdef"\n\ndef5678 Initial commit'
        } else {
          output = 'abc1234 Add feature\ndiff --git a/file.txt b/file.txt\nnew file mode 100644\nindex 0000000..e69de29\n--- /dev/null\n+++ b/file.txt\n@@ -0,0 +1 @@\n+Feature content\n\ndef5678 Initial commit'
        }
        break
      
      case 'git log --grep="API_KEY" --oneline':
        if (challengeId === 'api-key-leak') {
          output = 'abc1234 Add config with API key'
        } else {
          output = ''
        }
        break
      
      case 'git init':
        output = 'Initialized empty Git repository in /home/user/git-ctf/.git/'
        lineType = 'success'
        break
      
      case 'git add .':
        output = ''
        break
      
      case 'git commit -m "Initial commit"':
        output = '[main (root-commit) abc1234] Initial commit\n 1 file changed, 1 insertion(+)\n create mode 100644 README.md'
        lineType = 'success'
        break
      
      case 'clear':
        setHistory([])
        return
      
      case 'help':
        output = `Available commands:
  git status          - Show repository status
  git log             - Show commit history
  git log --oneline   - Show commit history in one line
  git reflog          - Show reflog history
  git show <commit>   - Show commit details
  git branch          - List branches
  git checkout <branch> - Switch to branch
  git add .           - Add all files to staging
  git commit -m <msg> - Create commit
  clear              - Clear terminal
  help               - Show this help message`
        break
      
      default:
        if (cleanCommand.startsWith('git show ')) {
          output = `fatal: ambiguous argument '${cleanCommand.split(' ')[2]}': unknown revision or path not in the working tree.`
          lineType = 'error'
        } else {
          output = `git: '${cleanCommand}' is not a git command. See 'git --help'.`
          lineType = 'error'
        }
    }

    // Add output to history
    addTerminalLine({
      type: lineType,
      content: output
    })

    // Check if command matches expected sequence
    const expectedCommand = currentChallenge.commands.find(cmd => cmd.command === cleanCommand)
    if (expectedCommand) {
      setSolvedCommands(prev => new Set(prev).add(cleanCommand))
      onCommandSuccess?.(cleanCommand)
      
      // Check if all commands are solved
      if (currentChallenge.commands.every(cmd => solvedCommands.has(cmd.command) || cmd.command === cleanCommand)) {
        setTimeout(() => {
          addTerminalLine({
            type: 'success',
            content: `🎉 ${currentChallenge.successMessage}`
          })
          if (currentChallenge.flag) {
            addTerminalLine({
              type: 'success',
              content: `Flag found: ${currentChallenge.flag}`
            })
          }
          onChallengeComplete?.()
        }, 1000)
      }
    }

    setInput('')
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) {
      simulateCommand(input.trim())
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  const clearTerminal = () => {
    setHistory([])
    setInput('')
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }

  const currentCommandIndex = currentChallenge.commands.findIndex(cmd => !solvedCommands.has(cmd.command))
  const currentCommand = currentCommandIndex >= 0 ? currentChallenge.commands[currentCommandIndex] : null

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            Git Terminal
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline">
              {solvedCommands.size}/{currentChallenge.commands.length} commands
            </Badge>
            <Button 
              onClick={clearTerminal} 
              variant="outline" 
              size="sm"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button 
              onClick={() => setShowHint(!showHint)} 
              variant="outline" 
              size="sm"
            >
              <HelpCircle className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Challenge Info */}
        <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
          <h4 className="font-semibold mb-1">{currentChallenge.title}</h4>
          <p className="text-sm text-slate-600 dark:text-slate-300">
            {currentChallenge.description}
          </p>
        </div>

        {/* Current Command Hint */}
        {showHint && currentCommand && (
          <div className="p-3 bg-blue-100 dark:bg-blue-950 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <ChevronRight className="h-4 w-4 text-blue-600" />
              <span className="font-semibold text-blue-800 dark:text-blue-200">Next Command:</span>
            </div>
            <div className="space-y-2">
              <div className="font-mono text-sm bg-blue-200 dark:bg-blue-900 p-2 rounded">
                {currentCommand.command}
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                {currentCommand.description}
              </p>
            </div>
          </div>
        )}

        {/* Terminal */}
        <div className="bg-black text-green-400 rounded-lg p-4 font-mono text-sm">
          <ScrollArea className="h-64 mb-3" ref={scrollRef}>
            <div className="space-y-1">
              {history.length === 0 && (
                <div className="text-slate-400">
                  Welcome to Git CTF Terminal! Type 'help' for available commands.
                </div>
              )}
              {history.map((line, index) => (
                <div key={index} className="flex flex-col">
                  <div className="flex items-center gap-2">
                    {line.type === 'command' && (
                      <ChevronRight className="h-3 w-3 text-green-400" />
                    )}
                    <span className={`
                      ${line.type === 'command' ? 'text-green-400' : ''}
                      ${line.type === 'error' ? 'text-red-400' : ''}
                      ${line.type === 'success' ? 'text-yellow-400' : ''}
                      ${line.type === 'output' ? 'text-slate-300' : ''}
                    `}>
                      {line.content}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
          
          {/* Input */}
          <form onSubmit={handleSubmit} className="flex items-center gap-2">
            <ChevronRight className="h-4 w-4 text-green-400" />
            <span className="text-slate-400">{currentPath}$</span>
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              className="flex-1 bg-transparent border-none outline-none text-green-400 font-mono"
              placeholder="Type git command..."
              autoFocus
            />
          </form>
        </div>

        {/* Command Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-semibold">Command Progress</span>
            <span>{solvedCommands.size}/{currentChallenge.commands.length}</span>
          </div>
          <div className="grid grid-cols-1 gap-1">
            {currentChallenge.commands.map((cmd, index) => (
              <div 
                key={cmd.command}
                className={`flex items-center gap-2 p-2 rounded ${
                  solvedCommands.has(cmd.command) 
                    ? 'bg-green-100 dark:bg-green-950' 
                    : 'bg-slate-100 dark:bg-slate-800'
                }`}
              >
                {solvedCommands.has(cmd.command) ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <div className="h-4 w-4 border-2 border-slate-400 rounded-full" />
                )}
                <div className="flex-1">
                  <div className="font-mono text-sm">{cmd.command}</div>
                  <div className="text-xs text-slate-600 dark:text-slate-400">
                    {cmd.description}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default GitTerminal