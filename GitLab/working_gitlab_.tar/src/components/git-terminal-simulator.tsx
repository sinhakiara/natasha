'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Terminal, 
  Play, 
  RotateCcw, 
  HelpCircle, 
  CheckCircle, 
  XCircle,
  ArrowRight,
  Command
} from 'lucide-react'

interface GitCommand {
  command: string
  output: string
  timestamp: Date
  success: boolean
}

interface GitFile {
  name: string
  content: string
  type: 'file' | 'directory'
  modified: boolean
  staged: boolean
}

interface GitCommit {
  hash: string
  message: string
  author: string
  timestamp: Date
  files: string[]
}

interface GitBranch {
  name: string
  current: boolean
  commits: string[]
}

interface GitTerminalSimulatorProps {
  challengeId: string
  onCommandSuccess?: (command: string) => void
  onChallengeComplete?: () => void
}

const GitTerminalSimulator: React.FC<GitTerminalSimulatorProps> = ({
  challengeId,
  onCommandSuccess,
  onChallengeComplete
}) => {
  const [input, setInput] = useState('')
  const [commandHistory, setCommandHistory] = useState<GitCommand[]>([])
  const [currentDirectory, setCurrentDirectory] = useState('/home/user/git-repo')
  const [files, setFiles] = useState<GitFile[]>([])
  const [commits, setCommits] = useState<GitCommit[]>([])
  const [branches, setBranches] = useState<GitBranch[]>([])
  const [currentBranch, setCurrentBranch] = useState('main')
  const [stagedFiles, setStagedFiles] = useState<string[]>([])
  const [showHelp, setShowHelp] = useState(false)
  const terminalRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Initialize challenge-specific environment
  useEffect(() => {
    initializeChallengeEnvironment(challengeId)
  }, [challengeId])

  // Auto-scroll to bottom when new commands are added
  useEffect(() => {
    if (terminalRef.current) {
      const scrollContainer = terminalRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }, [commandHistory])

  const initializeChallengeEnvironment = (id: string) => {
    // Reset state
    setCommandHistory([])
    setInput('')
    setCurrentDirectory('/home/user/git-repo')
    setStagedFiles([])
    
    // Challenge-specific initial states
    switch (id) {
      case 'lost-commit':
        initializeLostCommitChallenge()
        break
      case 'detached-head':
        initializeDetachedHeadChallenge()
        break
      case 'api-key-leak':
        initializeApiKeyLeakChallenge()
        break
      case 'branch-maze':
        initializeBranchMazeChallenge()
        break
      default:
        initializeDefaultChallenge()
    }
  }

  const initializeLostCommitChallenge = () => {
    setFiles([
      { name: 'readme.md', content: '# Project README\nInitial project setup', type: 'file', modified: false, staged: false },
      { name: 'config.py', content: '# Configuration\nAPI_KEY="test_key_123"\nDEBUG=true', type: 'file', modified: false, staged: false },
      { name: 'src/', content: '', type: 'directory', modified: false, staged: false },
      { name: 'src/main.py', content: 'print("Hello World")', type: 'file', modified: false, staged: false }
    ])
    
    setCommits([
      {
        hash: 'a1b2c3d',
        message: 'Initial commit',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 3600000),
        files: ['readme.md']
      },
      {
        hash: 'e4f5g6h',
        message: 'Add config with API key',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 1800000),
        files: ['config.py']
      }
    ])
    
    setBranches([
      { name: 'main', current: true, commits: ['a1b2c3d', 'e4f5g6h'] }
    ])
    
    // Add command history to show the initial state
    setCommandHistory([
      {
        command: 'git init',
        output: 'Initialized empty Git repository in /home/user/git-repo/.git/',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add .',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Initial commit"',
        output: '[main a1b2c3d] Initial commit\n 1 file changed, 1 insertion(+)\n create mode 100644 readme.md',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add config.py',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Add config with API key"',
        output: '[main e4f5g6h] Add config with API key\n 1 file changed, 2 insertions(+)\n create mode 100644 config.py',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git reset --hard HEAD~1',
        output: 'HEAD is now at a1b2c3d Initial commit',
        timestamp: new Date(),
        success: true
      }
    ])
  }

  const initializeDetachedHeadChallenge = () => {
    setFiles([
      { name: 'readme.md', content: '# Project README\nInitial project setup', type: 'file', modified: false, staged: false },
      { name: 'feature.py', content: '# New feature\ndef new_function():\n    pass', type: 'file', modified: false, staged: false }
    ])
    
    setCommits([
      {
        hash: 'a1b2c3d',
        message: 'Initial commit',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 3600000),
        files: ['readme.md']
      },
      {
        hash: 'e4f5g6h',
        message: 'Add feature',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 1800000),
        files: ['feature.py']
      }
    ])
    
    setBranches([
      { name: 'main', current: false, commits: ['a1b2c3d'] },
      { name: 'feature-branch', current: false, commits: ['a1b2c3d', 'e4f5g6h'] }
    ])
    
    setCurrentBranch('e4f5g6h') // Detached HEAD state
    
    setCommandHistory([
      {
        command: 'git checkout feature-branch',
        output: 'Switched to branch \'feature-branch\'',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add feature.py',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Add feature"',
        output: '[feature-branch e4f5g6h] Add feature\n 1 file changed, 3 insertions(+)\n create mode 100644 feature.py',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git checkout e4f5g6h',
        output: 'Note: switching to \'e4f5g6h\'.\n\nYou are in \'detached HEAD\' state. You can look around, make experimental changes and commit them, and you can discard any commits you make in this state without impacting any branches by switching back to a branch.\n\nIf you want to create a new branch to retain commits you create, you may\ndo so (now or later) by using -c with the switch command. Example:\n\n  git switch -c <new-branch-name>\n\nOr undo this operation with:\n\n  git switch -\n\nTurn off this advice by setting config variable advice.detachedHead to false\n\nHEAD is now at e4f5g6h Add feature',
        timestamp: new Date(),
        success: true
      }
    ])
  }

  const initializeApiKeyLeakChallenge = () => {
    setFiles([
      { name: 'readme.md', content: '# Project README\nInitial project setup', type: 'file', modified: false, staged: false },
      { name: '.env.example', content: 'API_KEY="your_api_key_here"\nDATABASE_URL="localhost:5432"', type: 'file', modified: false, staged: false },
      { name: 'src/', content: '', type: 'directory', modified: false, staged: false },
      { name: 'src/app.py', content: 'import os\napi_key = os.getenv("API_KEY")', type: 'file', modified: false, staged: false }
    ])
    
    setCommits([
      {
        hash: 'a1b2c3d',
        message: 'Initial commit',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 3600000),
        files: ['readme.md']
      },
      {
        hash: 'e4f5g6h',
        message: 'Add environment configuration',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 2700000),
        files: ['.env.example']
      },
      {
        hash: 'i7j8k9l',
        message: 'Add application code',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 1800000),
        files: ['src/app.py']
      },
      {
        hash: 'j8k9l0m',
        message: 'Add real API keys (temporary)',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 900000),
        files: ['.env']
      },
      {
        hash: 'k9l0m1n',
        message: 'Remove sensitive keys',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 600000),
        files: ['.env']
      },
      {
        hash: 'l0m1n2o',
        message: 'Final cleanup',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 300000),
        files: ['src/app.py']
      }
    ])
    
    setBranches([
      { name: 'main', current: true, commits: ['a1b2c3d', 'e4f5g6h', 'i7j8k9l', 'j8k9l0m', 'k9l0m1n', 'l0m1n2o'] }
    ])
    
    // The flag is hidden in the commit that was "removed" but still exists in history
    // Add the actual .env file with the flag to the files array (but it's not in the current commit)
    setFiles(prev => [
      ...prev,
      { name: '.env', content: 'API_KEY="FLAG{SECURITY_AUDITOR}"\nDATABASE_URL="localhost:5432"\nDEBUG_MODE=true', type: 'file', modified: false, staged: false }
    ])
    
    setCommandHistory([
      {
        command: 'git init',
        output: 'Initialized empty Git repository in /home/user/git-repo/.git/',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add .',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Initial commit"',
        output: '[main a1b2c3d] Initial commit\n 1 file changed, 1 insertion(+)\n create mode 100644 readme.md',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add .env.example',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Add environment configuration"',
        output: '[main e4f5g6h] Add environment configuration\n 1 file changed, 2 insertions(+)\n create mode 100644 .env.example',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add src/',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Add application code"',
        output: '[main i7j8k9l] Add application code\n 1 file changed, 2 insertions(+)\n create mode 100644 src/app.py',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'echo \'API_KEY="FLAG{SECURITY_AUDITOR}"\nDATABASE_URL="localhost:5432"\nDEBUG_MODE=true\' > .env',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add .env',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Add real API keys (temporary)"',
        output: '[main j8k9l0m] Add real API keys (temporary)\n 1 file changed, 3 insertions(+)\n create mode 100644 .env',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'rm .env',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add .env',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Remove sensitive keys"',
        output: '[main k9l0m1n] Remove sensitive keys\n 1 file changed, 3 deletions(-)\n delete mode 100644 .env',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add src/app.py',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Final cleanup"',
        output: '[main l0m1n2o] Final cleanup\n 1 file changed, 1 insertion(+)\n create mode 100644 src/app.py',
        timestamp: new Date(),
        success: true
      }
    ])
  }

  const initializeBranchMazeChallenge = () => {
    setFiles([
      { name: 'readme.md', content: '# Project README\nInitial project setup', type: 'file', modified: false, staged: false },
      { name: 'flag.txt', content: 'FLAG{BRANCH_ANALYST}', type: 'file', modified: false, staged: false },
      { name: 'decoy.txt', content: 'This is not the flag', type: 'file', modified: false, staged: false }
    ])
    
    setCommits([
      {
        hash: 'a1b2c3d',
        message: 'Initial commit',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 3600000),
        files: ['readme.md']
      }
    ])
    
    setBranches([
      { name: 'main', current: true, commits: ['a1b2c3d'] },
      { name: 'wrong-branch', current: false, commits: ['a1b2c3d'] },
      { name: 'secret-branch', current: false, commits: ['a1b2c3d'] },
      { name: 'hidden-branch', current: false, commits: ['a1b2c3d'] }
    ])
    
    // Flag is only in secret-branch
    const updatedFiles = [...files]
    const flagFileIndex = updatedFiles.findIndex(f => f.name === 'flag.txt')
    if (flagFileIndex !== -1) {
      updatedFiles[flagFileIndex] = { ...updatedFiles[flagFileIndex], content: 'This is not the flag' }
    }
    setFiles(updatedFiles)
    
    setCommandHistory([
      {
        command: 'git init',
        output: 'Initialized empty Git repository in /home/user/git-repo/.git/',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add .',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Initial commit"',
        output: '[main a1b2c3d] Initial commit\n 1 file changed, 1 insertion(+)\n create mode 100644 readme.md',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git branch wrong-branch',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git branch secret-branch',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git branch hidden-branch',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git checkout secret-branch',
        output: 'Switched to branch \'secret-branch\'',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'echo "FLAG{BRANCH_ANALYST}" > flag.txt',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add flag.txt',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Add flag"',
        output: '[secret-branch b2c3d4e] Add flag\n 1 file changed, 1 insertion(+)\n create mode 100644 flag.txt',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git checkout main',
        output: 'Switched to branch \'main\'',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'echo "This is not the flag" > decoy.txt',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add decoy.txt',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Add decoy"',
        output: '[main c3d4e5f] Add decoy\n 1 file changed, 1 insertion(+)\n create mode 100644 decoy.txt',
        timestamp: new Date(),
        success: true
      }
    ])
  }

  const initializeDefaultChallenge = () => {
    setFiles([
      { name: 'readme.md', content: '# Project README\nInitial project setup', type: 'file', modified: false, staged: false }
    ])
    
    setCommits([
      {
        hash: 'a1b2c3d',
        message: 'Initial commit',
        author: 'John Doe <john@example.com>',
        timestamp: new Date(Date.now() - 3600000),
        files: ['readme.md']
      }
    ])
    
    setBranches([
      { name: 'main', current: true, commits: ['a1b2c3d'] }
    ])
    
    setCommandHistory([
      {
        command: 'git init',
        output: 'Initialized empty Git repository in /home/user/git-repo/.git/',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git add .',
        output: '',
        timestamp: new Date(),
        success: true
      },
      {
        command: 'git commit -m "Initial commit"',
        output: '[main a1b2c3d] Initial commit\n 1 file changed, 1 insertion(+)\n create mode 100644 readme.md',
        timestamp: new Date(),
        success: true
      }
    ])
  }

  const executeCommand = (cmd: string) => {
    const trimmedCmd = cmd.trim()
    if (!trimmedCmd) return

    const parts = trimmedCmd.split(' ')
    const command = parts[0]
    const args = parts.slice(1)

    let output = ''
    let success = true

    try {
      switch (command) {
        case 'git':
          const gitResult = executeGitCommand(args, trimmedCmd)
          output = gitResult.output
          success = gitResult.success
          break
        case 'ls':
          output = executeLsCommand(args)
          break
        case 'cat':
          output = executeCatCommand(args)
          break
        case 'echo':
          output = executeEchoCommand(args)
          break
        case 'pwd':
          output = currentDirectory
          break
        case 'clear':
          setCommandHistory([])
          setInput('')
          return
        case 'help':
          output = getHelpText()
          break
        default:
          output = `Command not found: ${command}`
          success = false
      }
    } catch (error) {
      output = `Error: ${error}`
      success = false
    }

    const newCommand: GitCommand = {
      command: trimmedCmd,
      output,
      timestamp: new Date(),
      success
    }

    setCommandHistory(prev => [...prev, newCommand])
    setInput('')
    
    if (success && onCommandSuccess) {
      onCommandSuccess(trimmedCmd)
    }
  }

  const executeGitCommand = (args: string[], fullCommand: string): { output: string; success: boolean } => {
    if (args.length === 0) {
      const output = 'Usage: git <command> [<options>]\n\nThese are common Git commands used in various situations:\n\nstart a working area (see also: git help tutorial)\n   clone      Clone a repository into a new directory\n   init       Create an empty Git repository or reinitialize an existing one\n\nwork on the current change (see also: git help everyday)\n   add        Add file contents to the index\n   mv         Move or rename a file, a directory, or a symlink\n   reset      Reset current HEAD to the specified state\n   rm         Remove files from the working tree and from the index\n\nexamine the history and state (see also: git help revisions)\n   bisect     Use binary search to find the commit that introduced a bug\n   log        Show commit logs\n   show       Show various types of objects\n   status     Show the working tree status\n\ngrow, mark and tweak your common history\n   branch     List, create, or delete branches\n   checkout   Switch branches or restore working tree files\n   commit     Record changes to the repository\n   diff       Show changes between commits, commit and working tree, etc\n   merge      Join two or more development histories together\n   rebase     Reapply commits on top of another base tip\n   tag        Create, list, delete or verify a tag object signed with GPG\n\ncollaborate (see also: git help workflows)\n   fetch      Download objects and refs from another repository\n   pull       Fetch from and integrate with another repository or a local branch\n   push       Update remote refs along with associated objects'
      
      return { output, success: true }
    }

    const subCommand = args[0]
    const subArgs = args.slice(1)

    let output = ''
    let success = true

    try {
      switch (subCommand) {
      case 'status':
        output = executeGitStatus()
        break
      case 'log':
        output = executeGitLog(subArgs)
        break
      case 'add':
        output = executeGitAdd(subArgs)
        break
      case 'commit':
        output = executeGitCommit(subArgs)
        break
      case 'branch':
        output = executeGitBranch(subArgs)
        break
      case 'checkout':
        output = executeGitCheckout(subArgs)
        break
      case 'reset':
        output = executeGitReset(subArgs)
        break
      case 'show':
        output = executeGitShow(subArgs)
        break
      case 'reflog':
        output = executeGitReflog()
        break
      case 'diff':
        output = executeGitDiff(subArgs)
        break
      case 'stash':
        output = executeGitStash(subArgs)
        break
      case 'tag':
        output = executeGitTag(subArgs)
        break
      case 'bisect':
        output = executeGitBisect(subArgs)
        break
      case 'fsck':
        output = executeGitFsck()
        break
      case 'rebase':
        output = executeGitRebase(subArgs)
        break
      case 'cherry-pick':
        output = executeGitCherryPick(subArgs)
        break
      default:
        output = `git: '${subCommand}' is not a git command. See 'git --help'.`
        success = false
    }

    return { output, success }
    } catch (error) {
      return { 
        output: `git: ${error instanceof Error ? error.message : 'Unknown error'}`, 
        success: false 
      }
    }
  }

  const executeGitStatus = () => {
    let output = 'On branch ' + currentBranch + '\n\n'
    
    const modifiedFiles = files.filter(f => f.modified)
    const stagedFiles = files.filter(f => f.staged)
    const untrackedFiles = files.filter(f => !f.staged && !modifiedFiles.includes(f))
    
    if (stagedFiles.length > 0) {
      output += 'Changes to be committed:\n'
      output += '  (use "git restore --staged <file>..." to unstage)\n'
      output += '\n'
      stagedFiles.forEach(file => {
        output += `        modified:   ${file.name}\n`
      })
      output += '\n'
    }
    
    if (modifiedFiles.length > 0) {
      output += 'Changes not staged for commit:\n'
      output += '  (use "git add <file>..." to update what will be committed)\n'
      output += '  (use "git restore <file>..." to discard changes in working directory)\n'
      output += '\n'
      modifiedFiles.forEach(file => {
        output += `        modified:   ${file.name}\n`
      })
      output += '\n'
    }
    
    if (untrackedFiles.length > 0) {
      output += 'Untracked files:\n'
      output += '  (use "git add <file>..." to include in what will be committed)\n'
      output += '\n'
      untrackedFiles.forEach(file => {
        output += `        ${file.name}\n`
      })
    }
    
    if (stagedFiles.length === 0 && modifiedFiles.length === 0 && untrackedFiles.length === 0) {
      output += 'nothing to commit, working tree clean\n'
    }
    
    return output
  }

  const executeGitLog = (args: string[]) => {
    if (commits.length === 0) {
      return 'fatal: your current branch \'main\' does not have any commits yet'
    }
    
    let output = ''
    commits.forEach(commit => {
      output += `commit ${commit.hash}\n`
      output += `Author: ${commit.author}\n`
      output += `Date: ${commit.timestamp.toISOString()}\n`
      output += `\n    ${commit.message}\n\n`
    })
    
    return output
  }

  const executeGitAdd = (args: string[]) => {
    if (args.length === 0) {
      return 'Nothing specified, nothing added.\nHint: Maybe you wanted to say \'git add .\'?'
    }
    
    const updatedFiles = [...files]
    let filesAdded = false
    
    args.forEach(arg => {
      if (arg === '.') {
        updatedFiles.forEach(file => {
          if (file.type === 'file') {
            file.staged = true
            filesAdded = true
          }
        })
      } else {
        const fileIndex = updatedFiles.findIndex(f => f.name === arg)
        if (fileIndex !== -1) {
          updatedFiles[fileIndex].staged = true
          filesAdded = true
        }
      }
    })
    
    setFiles(updatedFiles)
    
    return filesAdded ? '' : `fatal: pathspec '${args[0]}' did not match any files`
  }

  const executeGitCommit = (args: string[]) => {
    const stagedFiles = files.filter(f => f.staged)
    if (stagedFiles.length === 0) {
      return 'nothing to commit, working tree clean'
    }
    
    const messageIndex = args.findIndex(arg => arg === '-m')
    if (messageIndex === -1 || messageIndex + 1 >= args.length) {
      return 'error: commit message is required'
    }
    
    const message = args[messageIndex + 1].replace(/['"]/g, '')
    const newHash = Math.random().toString(36).substring(2, 9)
    
    const newCommit: GitCommit = {
      hash: newHash,
      message,
      author: 'User <user@example.com>',
      timestamp: new Date(),
      files: stagedFiles.map(f => f.name)
    }
    
    setCommits(prev => [newCommit, ...prev])
    
    // Update files - remove staged status and clear modified status
    const updatedFiles = files.map(file => ({
      ...file,
      staged: false,
      modified: false
    }))
    setFiles(updatedFiles)
    
    // Update current branch if it's a branch name (not detached HEAD)
    if (currentBranch !== 'HEAD' && branches.find(b => b.name === currentBranch)) {
      const updatedBranches = branches.map(branch => {
        if (branch.name === currentBranch) {
          return {
            ...branch,
            commits: [newHash, ...branch.commits]
          }
        }
        return branch
      })
      setBranches(updatedBranches)
    }
    
    return `[${currentBranch} ${newHash}] ${message}\n  ${stagedFiles.length} file${stagedFiles.length > 1 ? 's' : ''} changed`
  }

  const executeGitBranch = (args: string[]) => {
    if (args.length === 0) {
      // List branches
      let output = ''
      branches.forEach(branch => {
        const prefix = branch.current ? '* ' : '  '
        output += `${prefix}${branch.name}\n`
      })
      return output
    }
    
    // Create new branch
    const branchName = args[0]
    if (branches.find(b => b.name === branchName)) {
      return `fatal: A branch named '${branchName}' already exists.`
    }
    
    const currentBranchCommits = branches.find(b => b.name === currentBranch)?.commits || []
    const newBranch: GitBranch = {
      name: branchName,
      current: false,
      commits: [...currentBranchCommits]
    }
    
    setBranches(prev => [...prev, newBranch])
    return ''
  }

  const executeGitCheckout = (args: string[]) => {
    if (args.length === 0) {
      return 'fatal: you must specify a path to checkout'
    }
    
    const target = args[0]
    
    // Check if it's a branch
    const branch = branches.find(b => b.name === target)
    if (branch) {
      setCurrentBranch(target)
      
      // Update current status for all branches
      const updatedBranches = branches.map(b => ({
        ...b,
        current: b.name === target
      }))
      setBranches(updatedBranches)
      
      return `Switched to branch '${target}'`
    }
    
    // Check if it's a commit hash
    const commit = commits.find(c => c.hash === target)
    if (commit) {
      setCurrentBranch('HEAD')
      return `Note: switching to '${target}'.\n\nYou are in 'detached HEAD' state. You can look around, make experimental changes and commit them, and you can discard any commits you make in this state without impacting any branches by switching back to a branch.\n\nIf you want to create a new branch to retain commits you create, you may\ndo so (now or later) by using -c with the switch command. Example:\n\n  git switch -c <new-branch-name>\n\nOr undo this operation with:\n\n  git switch -\n\nTurn off this advice by setting config variable advice.detachedHead to false\n\nHEAD is now at ${target} ${commit.message}`
    }
    
    return `fatal: '${target}' did not match any file(s) known to git`
  }

  const executeGitReset = (args: string[]) => {
    if (args.length === 0) {
      return 'fatal: Not a valid object name: HEAD'
    }
    
    const target = args[0]
    
    if (target === '--hard') {
      if (args.length < 2) {
        return 'fatal: Not a valid object name: HEAD'
      }
      const commitHash = args[1]
      const commitIndex = commits.findIndex(c => c.hash === commitHash)
      
      if (commitIndex === -1) {
        return `fatal: ambiguous argument '${commitHash}': unknown revision or path not in the working tree.`
      }
      
      // Remove commits after the target commit
      setCommits(prev => prev.slice(commitIndex))
      
      // Update branch commits
      const updatedBranches = branches.map(branch => {
        if (branch.name === currentBranch) {
          return {
            ...branch,
            commits: prev.slice(commitIndex).map(c => c.hash)
          }
        }
        return branch
      })
      setBranches(updatedBranches)
      
      return `HEAD is now at ${commitHash} ${commits[commitIndex].message}`
    }
    
    // Soft reset
    const commitIndex = commits.findIndex(c => c.hash === target)
    if (commitIndex === -1) {
      return `fatal: ambiguous argument '${target}': unknown revision or path not in the working tree.`
    }
    
    setCommits(prev => prev.slice(commitIndex))
    
    // Update branch commits
    const updatedBranches = branches.map(branch => {
      if (branch.name === currentBranch) {
        return {
          ...branch,
          commits: commits.slice(commitIndex).map(c => c.hash)
        }
      }
      return branch
    })
    setBranches(updatedBranches)
    
    return ''
  }

  const executeGitShow = (args: string[]) => {
    if (args.length === 0) {
      return 'fatal: you must specify a commit or commit range'
    }
    
    const commitHash = args[0]
    const commit = commits.find(c => c.hash === commitHash)
    
    if (!commit) {
      return `fatal: ambiguous argument '${commitHash}': unknown revision or path not in the working tree.`
    }
    
    let output = `commit ${commit.hash}\n`
    output += `Author: ${commit.author}\n`
    output += `Date: ${commit.timestamp.toISOString()}\n`
    output += `\n    ${commit.message}\n`
    output += `\n`
    
    // Show file changes with actual content
    commit.files.forEach(fileName => {
      const file = files.find(f => f.name === fileName)
      if (file && file.type === 'file') {
        output += `diff --git a/${fileName} b/${fileName}\n`
        output += `new file mode 100644\n`
        output += `index 0000000..e69de29\n`
        output += `--- /dev/null\n`
        output += `+++ b/${fileName}\n`
        output += `@@ -0,0 +1,${file.content.split('\n').length} @@\n`
        // Add each line of the file content with proper diff format
        file.content.split('\n').forEach((line, index) => {
          if (index === 0 && line.trim() === '') {
            output += `+\\ No newline at end of file\n`
          } else {
            output += `+${line}\n`
          }
        })
      }
    })
    
    return output
  }

  const executeGitReflog = () => {
    let output = ''
    commandHistory.forEach((cmd, index) => {
      const timeAgo = Math.floor((Date.now() - cmd.timestamp.getTime()) / 1000)
      const timeStr = timeAgo < 60 ? `${timeAgo}s ago` : `${Math.floor(timeAgo / 60)}m ago`
      output += `${index} ${cmd.command} HEAD@{${index}}: ${cmd.success ? 'commit' : 'error'}: ${cmd.command}\n`
    })
    return output
  }

  const executeGitDiff = (args: string[]) => {
    const modifiedFiles = files.filter(f => f.modified)
    if (modifiedFiles.length === 0) {
      return ''
    }
    
    let output = ''
    modifiedFiles.forEach(file => {
      output += `diff --git a/${file.name} b/${file.name}\n`
      output += `index 1234567..89abcde 100644\n`
      output += `--- a/${file.name}\n`
      output += `+++ b/${file.name}\n`
      output += `@@ -1 +1 @@\n`
      output += `-${file.content}\n`
      output += `+${file.content}\n`
    })
    
    return output
  }

  const executeGitStash = (args: string[]) => {
    if (args.length === 0) {
      return 'usage: git stash list [<options>]\n   or: git stash show [<options>] [<stash>]\n   or: git stash drop [-q|--quiet] [<stash>]\n   or: git stash ( pop | apply ) [-q|--quiet] [<stash>]\n   or: git stash branch <branchname> [<stash>]\n   or: git stash clear\n   or: git stash create [<message>]\n   or: git stash store [-m|--message <message>] [-q|--quiet] <commit>\n   or: git stash push [-p|--patch] [-S|--staged] [-k|--keep-index] [-q|--quiet] [-u|--include-untracked] [-a|--all] [-m|--message <message>] [--pathspec-from-file=<file> [--pathspec-file-nul]] [--] [<pathspec>...]]\n   or: git stash save [-p|--patch] [-S|--staged] [-k|--keep-index] [-q|--quiet] [-u|--include-untracked] [-a|--all] [-m|--message <message>] [--pathspec-from-file=<file> [--pathspec-file-nul]] [--] [<pathspec>...]]'
    }
    
    const subCommand = args[0]
    
    switch (subCommand) {
      case 'list':
        return 'stash@{0}: On main: WIP on feature-branch'
      case 'save':
        return 'Saved working directory and index state WIP on main: HEAD'
      case 'pop':
        return 'On branch main\nYour branch is up to date with \'origin/main\'.\n\nChanges not staged for commit:\n  (use "git add <file>..." to update what will be committed)\n  (use "git restore <file>..." to discard changes in working directory)\n\n\tmodified:   file.txt\n\nno changes added to commit (use "git add" and/or "git commit -a")\nDropped refs/stash@{0} (abc1234)'
      default:
        return `git stash '${subCommand}' is not a git command. See 'git stash --help'.`
    }
  }

  const executeGitTag = (args: string[]) => {
    if (args.length === 0) {
      return 'v1.0.0'
    }
    
    const tagName = args[0]
    return `Added tag '${tagName}'`
  }

  const executeGitBisect = (args: string[]) => {
    if (args.length === 0) {
      return 'usage: git bisect [<subcommand>]\n\nThese are common git bisect commands:\n   start         start bisect session\n   bad           mark revision as bad\n   good          mark revision as good\n   reset         finish bisect session\n   visualize     show bisect status in gitk\n   view          show bisect status in gitk\n   replay        replay bisect log\n   log           show bisect log\n   run           bisect run\n   terms         define bisect terms'
    }
    
    const subCommand = args[0]
    
    switch (subCommand) {
      case 'start':
        return 'Bisecting: 12 revisions left to test after this (roughly 4 steps)\n[a1b2c3d] Initial commit'
      case 'bad':
        return 'Bisecting: 6 revisions left to test after this (roughly 3 steps)\n[e4f5g6h] Add feature'
      case 'good':
        return 'Bisecting: 3 revisions left to test after this (roughly 2 steps)\n[i7j8k9l] Fix bug'
      case 'reset':
        return 'Bisect reset'
      default:
        return `git bisect '${subCommand}' is not a git command. See 'git bisect --help'.`
    }
  }

  const executeGitFsck = () => {
    return 'Checking object directories: 100% (256/256), done.\nChecking objects: 100% (512/512), done.\ndangling commit e4f5g6h Add config with API key'
  }

  const executeGitRebase = (args: string[]) => {
    if (args.length === 0) {
      return 'Current branch main is up to date.'
    }
    
    const targetBranch = args[0]
    return `Successfully rebased and updated refs/heads/main.`
  }

  const executeGitCherryPick = (args: string[]) => {
    if (args.length === 0) {
      return 'usage: git cherry-pick [<options>] <commit-ish>...'
    }
    
    const commitHash = args[0]
    const commit = commits.find(c => c.hash === commitHash)
    
    if (!commit) {
      return `fatal: bad object ${commitHash}`
    }
    
    const newHash = Math.random().toString(36).substring(2, 9)
    const newCommit: GitCommit = {
      hash: newHash,
      message: commit.message,
      author: 'User <user@example.com>',
      timestamp: new Date(),
      files: commit.files
    }
    
    setCommits(prev => [newCommit, ...prev])
    
    return `[${currentBranch} ${newHash}] ${commit.message}`
  }

  const executeLsCommand = (args: string[]) => {
    const targetDir = args[0] || '.'
    let output = ''
    
    files.forEach(file => {
      if (file.type === 'directory') {
        output += `${file.name}/\n`
      } else {
        output += `${file.name}\n`
      }
    })
    
    return output
  }

  const executeCatCommand = (args: string[]) => {
    if (args.length === 0) {
      return 'cat: missing operand'
    }
    
    const fileName = args[0]
    const file = files.find(f => f.name === fileName)
    
    if (!file) {
      return `cat: ${fileName}: No such file or directory`
    }
    
    if (file.type === 'directory') {
      return `cat: ${fileName}: Is a directory`
    }
    
    return file.content
  }

  const executeEchoCommand = (args: string[]) => {
    return args.join(' ')
  }

  const getHelpText = () => {
    return 'Available commands:\n' +
           '  git status     - Show working tree status\n' +
           '  git log        - Show commit history\n' +
           '  git add        - Add files to staging area\n' +
           '  git commit     - Commit staged changes\n' +
           '  git branch     - List/create branches\n' +
           '  git checkout   - Switch branches/commits\n' +
           '  git reset      - Reset HEAD to specified state\n' +
           '  git show       - Show commit details\n' +
           '  git reflog     - Show reference log\n' +
           '  git diff       - Show changes\n' +
           '  git stash     - Stash changes\n' +
           '  git tag        - Tag commits\n' +
           '  git bisect     - Binary search for bugs\n' +
           '  git fsck       - Check repository integrity\n' +
           '  git rebase     - Reapply commits\n' +
           '  git cherry-pick - Apply commits from other branches\n' +
           '  ls            - List directory contents\n' +
           '  cat           - Show file contents\n' +
           '  echo          - Echo text\n' +
           '  pwd           - Show current directory\n' +
           '  clear         - Clear terminal\n' +
           '  help          - Show this help'
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    executeCommand(input)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      // Navigate command history up
      const previousCommands = commandHistory.map(cmd => cmd.command).reverse()
      const currentIndex = previousCommands.indexOf(input)
      const newIndex = currentIndex < 0 ? 0 : Math.min(currentIndex + 1, previousCommands.length - 1)
      setInput(previousCommands[newIndex] || '')
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      // Navigate command history down
      const previousCommands = commandHistory.map(cmd => cmd.command)
      const currentIndex = previousCommands.indexOf(input)
      const newIndex = currentIndex <= 0 ? -1 : currentIndex - 1
      setInput(newIndex >= 0 ? previousCommands[newIndex] : '')
    }
  }

  // Focus input when terminal is clicked
  const handleTerminalClick = () => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Terminal className="h-5 w-5" />
          Git Terminal Simulator
          <Badge variant="outline" className="ml-auto">
            {currentBranch}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Terminal Header */}
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <span>💡 Type Git commands to solve the challenge</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowHelp(!showHelp)}
              className="ml-auto"
            >
              <HelpCircle className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => initializeChallengeEnvironment(challengeId)}
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>

          {/* Help Panel */}
          <AnimatePresence>
            {showHelp && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  <h4 className="font-semibold mb-2">Quick Commands:</h4>
                  <div className="text-sm text-slate-600 dark:text-slate-300 font-mono">
                    <div>git status - Check repository status</div>
                    <div>git log - View commit history</div>
                    <div>git add . - Stage all changes</div>
                    <div>git commit -m "message" - Commit changes</div>
                    <div>git branch - List branches</div>
                    <div>git checkout branch - Switch branches</div>
                    <div>git reset --hard HEAD~1 - Reset to previous commit</div>
                    <div>git show commit_hash - Show commit details</div>
                    <div>git reflog - Show reference log</div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Terminal Window */}
          <div 
            className="bg-slate-900 text-slate-100 rounded-lg overflow-hidden flex flex-col border border-slate-700 h-96"
            onClick={handleTerminalClick}
          >
            {/* Output Area - Scrollable */}
            <div className="flex-1 overflow-hidden">
              <ScrollArea className="h-full" ref={terminalRef}>
                <div className="p-4 space-y-2">
                  {commandHistory.map((cmd, index) => (
                    <div key={index} className="space-y-1">
                      {/* Command Input (in output history) */}
                      <div className="flex items-start gap-2">
                        <span className="text-green-400 mt-0.5 flex-shrink-0">$</span>
                        <div className="flex-1 min-w-0">
                          <span className="text-slate-300 break-all">{cmd.command}</span>
                          {cmd.success ? (
                            <CheckCircle className="h-3 w-3 text-green-400 inline ml-2 flex-shrink-0" />
                          ) : (
                            <XCircle className="h-3 w-3 text-red-400 inline ml-2 flex-shrink-0" />
                          )}
                        </div>
                      </div>
                      {/* Command Output */}
                      {cmd.output && (
                        <div className="text-slate-400 whitespace-pre-wrap ml-6 text-xs leading-relaxed">
                          {cmd.output}
                        </div>
                      )}
                    </div>
                  ))}
                  {commandHistory.length === 0 && (
                    <div className="text-slate-500 text-center py-8">
                      <div className="mb-2 text-2xl">🖥️</div>
                      <div className="text-base">Git Terminal Ready</div>
                      <div className="text-xs mt-1 text-slate-600">Type 'help' for available commands</div>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>
            
            {/* Input Area - Fixed at bottom */}
            <div className="border-t-2 border-slate-700 bg-slate-800 px-4 py-3">
              <form onSubmit={handleSubmit} className="flex items-center gap-3">
                <span className="text-green-400 font-semibold flex-shrink-0">$</span>
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="flex-1 bg-slate-900 border border-slate-600 rounded-lg px-4 py-2.5 text-slate-300 placeholder-slate-500 outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition-all text-sm"
                  placeholder="Type Git commands here..."
                  autoFocus
                />
                <Button 
                  type="submit" 
                  size="sm" 
                  className="bg-green-600 hover:bg-green-700 text-white flex-shrink-0 px-3"
                >
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button 
                  type="button" 
                  size="sm" 
                  variant="outline" 
                  className="border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700 flex-shrink-0 px-3"
                  onClick={() => {
                    setCommandHistory([])
                    setInput('')
                    if (inputRef.current) {
                      inputRef.current.focus()
                    }
                  }}
                  title="Clear terminal"
                >
                  Clear
                </Button>
              </form>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 text-sm">
            <span className="text-slate-600">Quick actions:</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setInput('git status')}
            >
              Status
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setInput('git log')}
            >
              Log
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setInput('git add .')}
            >
              Add All
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setInput('git commit -m "Update"')}
            >
              Commit
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setInput('git branch')}
            >
              Branches
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default GitTerminalSimulator