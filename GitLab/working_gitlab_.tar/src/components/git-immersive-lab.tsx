'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { 
  CheckCircle, 
  AlertCircle, 
  Trophy, 
  Target, 
  Play, 
  RotateCcw,
  Lightbulb,
  Terminal,
  FileText,
  GitMerge,
  GitPullRequest,
  Zap,
  ArrowRight,
  XCircle,
  Clock,
  Sparkles,
  BookOpen,
  User,
  Award,
  TrendingUp,
  ChevronRight,
  ChevronDown,
  Plus,
  Minus,
  Maximize2,
  Minimize2,
  Settings,
  Shield,
  Wrench,
  Lock,
  GraduationCap
} from 'lucide-react'

interface VirtualFile {
  name: string
  content: string
  hasSecret: boolean
  status: 'modified' | 'staged' | 'untracked' | 'deleted' | 'normal'
}

interface VirtualCommit {
  id: string
  message: string
  hash: string
  files: string[]
  hasSecret: boolean
  timestamp: number
  isDeleted: boolean
  author: string
  branch: string
}

interface GitCommand {
  command: string
  output: string[]
  error: string | null
  timestamp: number
  success: boolean
}

interface ChallengeStep {
  id: number
  title: string
  description: string
  instruction: string
  expectedCommand?: string
  objective: string
  hint: string
  validation: (state: LabState) => boolean
  tutorial?: {
    title: string
    steps: string[]
    codeExample?: string
  }
}

interface Challenge {
  id: number
  title: string
  description: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  estimatedTime: number
  category: 'basics' | 'safety' | 'recovery' | 'advanced'
  prerequisites: number[]
  steps: ChallengeStep[]
  initialFiles: VirtualFile[]
  initialCommits: VirtualCommit[]
  learningGoals: string[]
  realWorldScenario: string
}

interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  unlocked: boolean
  unlockedAt?: number
}

interface UserProgress {
  level: number
  experience: number
  totalChallenges: number
  completedChallenges: number
  streak: number
  lastPlayed: number
  achievements: Achievement[]
  skillLevels: {
    basics: number
    safety: number
    recovery: number
    advanced: number
  }
}

interface LabState {
  currentChallenge: Challenge | null
  currentStep: number
  files: VirtualFile[]
  commits: VirtualCommit[]
  commandHistory: GitCommand[]
  isCompleted: boolean
  startTime: number | null
  elapsedTime: number
  hintsUsed: number
  score: number
  showTutorial: boolean
  currentCommand: string
  output: string[]
  error: string | null
  showHint: boolean
  userProgress: UserProgress
  activeTutorial: {
    step: number
    totalSteps: number
    content: string
  } | null
  terminalExpanded: boolean
  showGitGraph: boolean
  autoSuggestions: string[]
}

const GitImmersiveLab = () => {
  const [state, setState] = useState<LabState>({
    currentChallenge: null,
    currentStep: 0,
    files: [],
    commits: [],
    commandHistory: [],
    isCompleted: false,
    startTime: null,
    elapsedTime: 0,
    hintsUsed: 0,
    score: 0,
    showTutorial: false,
    currentCommand: '',
    output: [],
    error: null,
    showHint: false,
    userProgress: {
      level: 1,
      experience: 0,
      totalChallenges: 0,
      completedChallenges: 0,
      streak: 0,
      lastPlayed: Date.now(),
      achievements: [
        {
          id: 'first-commit',
          title: 'First Commit',
          description: 'Make your first Git commit',
          icon: '🎯',
          unlocked: false
        },
        {
          id: 'safety-first',
          title: 'Safety First',
          description: 'Complete all safety challenges',
          icon: '🛡️',
          unlocked: false
        },
        {
          id: 'recovery-expert',
          title: 'Recovery Expert',
          description: 'Master Git recovery techniques',
          icon: '🔧',
          unlocked: false
        },
        {
          id: 'git-master',
          title: 'Git Master',
          description: 'Complete all challenges',
          icon: '🏆',
          unlocked: false
        }
      ],
      skillLevels: {
        basics: 0,
        safety: 0,
        recovery: 0,
        advanced: 0
      }
    },
    activeTutorial: null,
    terminalExpanded: false,
    showGitGraph: true,
    autoSuggestions: []
  })

  const [activeChallenge, setActiveChallenge] = useState<number | null>(null)
  const [timer, setTimer] = useState<NodeJS.Timeout | null>(null)
  const terminalRef = useRef<HTMLDivElement>(null)

  const challenges: Challenge[] = [
    {
      id: 1,
      title: "The Secret Hunter",
      description: "Find and identify sensitive information in commit history",
      difficulty: "beginner",
      estimatedTime: 300,
      category: "basics",
      prerequisites: [],
      initialFiles: [
        { name: "README.md", content: "# Project Documentation\n\nThis project is a demo for Git learning.", hasSecret: false, status: "normal" },
        { name: "config.py", content: "# Configuration\nAPI_KEY = \"supersecret123\"\nDB_HOST = \"localhost\"\nDEBUG = True", hasSecret: true, status: "modified" },
        { name: "app.py", content: "print('Hello, World!')", hasSecret: false, status: "normal" }
      ],
      initialCommits: [
        { id: "1", message: "Initial project setup", hash: "a1b2c3d", files: ["README.md"], hasSecret: false, timestamp: Date.now() - 60000, isDeleted: false, author: "You", branch: "main" },
        { id: "2", message: "Add configuration file", hash: "e4f5g6h", files: ["config.py"], hasSecret: true, timestamp: Date.now() - 30000, isDeleted: false, author: "You", branch: "main" },
        { id: "3", message: "Add main application", hash: "i7j8k9l", files: ["app.py"], hasSecret: false, timestamp: Date.now() - 15000, isDeleted: false, author: "You", branch: "main" }
      ],
      learningGoals: [
        "Understand Git commit history",
        "Identify sensitive data in commits",
        "Use git log and git show effectively"
      ],
      realWorldScenario: "You discover that sensitive API keys have been accidentally committed to the repository. You need to find and identify which commits contain this sensitive information before removing them.",
      steps: [
        {
          id: 1,
          title: "Examine Commit History",
          description: "Look at the commit history to understand the project timeline",
          instruction: "Use git log to view all commits in the repository",
          expectedCommand: "git log --oneline",
          objective: "View the complete commit history",
          hint: "Use --oneline for a compact view of commits",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("git log")),
          tutorial: {
            title: "Understanding Git Log",
            steps: [
              "git log shows the complete commit history",
              "Each commit has a unique hash and message",
              "--oneline gives a compact, readable format",
              "The most recent commits appear first"
            ],
            codeExample: "git log --oneline\ngit log --oneline --graph\ngit log --oneline -5"
          }
        },
        {
          id: 2,
          title: "Inspect Suspicious Commits",
          description: "Look for commits that might contain sensitive information",
          instruction: "Use git show to inspect the commit that added config.py",
          expectedCommand: "git show e4f5g6h",
          objective: "Inspect the configuration commit for sensitive data",
          hint: "Look for the commit that added the config.py file",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("git show") && cmd.command.includes("e4f5g6h")),
          tutorial: {
            title: "Inspecting Commits",
            steps: [
              "git show displays detailed information about a specific commit",
              "It shows the commit message, author, and file changes",
              "You can see the exact content that was added or modified",
              "This is essential for security audits"
            ]
          }
        },
        {
          id: 3,
          title: "Identify the Secret",
          description: "Confirm you've found the sensitive information",
          instruction: "Look for the API key in the commit output",
          objective: "Successfully identify the sensitive API key",
          hint: "Look for 'supersecret123' in the output",
          validation: (state) => state.output.some(out => out.includes("supersecret123"))
        }
      ]
    },
    {
      id: 2,
      title: "Soft Reset Rescue Mission",
      description: "Safely undo commits while preserving changes",
      difficulty: "intermediate",
      estimatedTime: 600,
      category: "safety",
      prerequisites: [1],
      initialFiles: [
        { name: "index.js", content: "console.log('Hello World');", hasSecret: false, status: "normal" },
        { name: "config.json", content: "{\n  \"debug\": true,\n  \"apiKey\": \"secret-key-123\"\n}", hasSecret: true, status: "staged" },
        { name: "utils.js", content: "function helper() {\n  return 'help';\n}", hasSecret: false, status: "normal" }
      ],
      initialCommits: [
        { id: "1", message: "Initial setup", hash: "abc1234", files: ["index.js"], hasSecret: false, timestamp: Date.now() - 120000, isDeleted: false, author: "You", branch: "main" },
        { id: "2", message: "Add utility functions", hash: "def5678", files: ["utils.js"], hasSecret: false, timestamp: Date.now() - 90000, isDeleted: false, author: "You", branch: "main" },
        { id: "3", message: "Add debug configuration", hash: "ghi9012", files: ["config.json"], hasSecret: true, timestamp: Date.now() - 60000, isDeleted: false, author: "You", branch: "main" },
        { id: "4", message: "Update main application", hash: "jkl3456", files: ["index.js"], hasSecret: false, timestamp: Date.now() - 30000, isDeleted: false, author: "You", branch: "main" }
      ],
      learningGoals: [
        "Understand the difference between soft and hard reset",
        "Safely undo commits while preserving changes",
        "Verify file status after reset operations"
      ],
      realWorldScenario: "You accidentally committed sensitive configuration data, but you need to keep the changes for further modification. Use soft reset to undo the commit while keeping the changes in your working directory.",
      steps: [
        {
          id: 1,
          title: "Assess Current State",
          description: "Examine the current commit and file status",
          instruction: "Check the current commit history and file status",
          expectedCommand: "git log --oneline",
          objective: "Understand the current repository state",
          hint: "Use git log to see the commit history",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("git log"))
        },
        {
          id: 2,
          title: "Perform Soft Reset",
          description: "Undo the last commit but keep the changes",
          instruction: "Use git reset --soft to undo the last commit safely",
          expectedCommand: "git reset --soft HEAD~1",
          objective: "Undo the last commit while preserving changes",
          hint: "HEAD~1 refers to the commit before the current one",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("git reset --soft"))
        },
        {
          id: 3,
          title: "Verify Changes Preserved",
          description: "Confirm that the sensitive file still exists with its content",
          instruction: "Check that the files still exist with their content intact",
          objective: "Verify that changes are preserved in working directory",
          hint: "Use ls to see files and cat to view file contents",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("ls")) && 
                          state.commandHistory.some(cmd => cmd.command.includes("cat"))
        }
      ]
    },
    {
      id: 3,
      title: "Hard Reset Cleanup",
      description: "Completely remove problematic commits and their changes",
      difficulty: "advanced",
      estimatedTime: 900,
      category: "recovery",
      prerequisites: [1, 2],
      initialFiles: [
        { name: "main.py", content: "print('Hello World')", hasSecret: false, status: "normal" },
        { name: "secrets.txt", content: "PASSWORD=my-secret-password\nAPI_KEY=12345\nDATABASE_URL=local-db", hasSecret: true, status: "staged" },
        { name: "utils.py", content: "def helper():\n    return 'help'", hasSecret: false, status: "normal" },
        { name: "README.md", content: "# My Project\nA simple Python project", hasSecret: false, status: "normal" }
      ],
      initialCommits: [
        { id: "1", message: "Initial commit", hash: "start123", files: ["main.py"], hasSecret: false, timestamp: Date.now() - 180000, isDeleted: false, author: "You", branch: "main" },
        { id: "2", message: "Add utility functions", hash: "utils456", files: ["utils.py"], hasSecret: false, timestamp: Date.now() - 150000, isDeleted: false, author: "You", branch: "main" },
        { id: "3", message: "Add secrets file", hash: "secret789", files: ["secrets.txt"], hasSecret: true, timestamp: Date.now() - 120000, isDeleted: false, author: "You", branch: "main" },
        { id: "4", message: "Update main application", hash: "update012", files: ["main.py"], hasSecret: false, timestamp: Date.now() - 90000, isDeleted: false, author: "You", branch: "main" },
        { id: "5", message: "Add documentation", hash: "docs345", files: ["README.md"], hasSecret: false, timestamp: Date.now() - 60000, isDeleted: false, author: "You", branch: "main" },
        { id: "6", message: "Final changes", hash: "final678", files: ["main.py"], hasSecret: false, timestamp: Date.now() - 30000, isDeleted: false, author: "You", branch: "main" }
      ],
      learningGoals: [
        "Perform hard reset operations safely",
        "Understand permanent data removal",
        "Use reflog for recovery operations",
        "Clean up repository history effectively"
      ],
      realWorldScenario: "Critical security vulnerability! Sensitive credentials have been committed and need to be completely removed from the repository history. You must perform a hard reset to eliminate all traces of the sensitive data.",
      steps: [
        {
          id: 1,
          title: "Security Assessment",
          description: "Identify all commits containing sensitive information",
          instruction: "Examine the commit history to find all problematic commits",
          expectedCommand: "git log --oneline",
          objective: "Identify commits with sensitive data",
          hint: "Look for commits that added files containing sensitive data",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("git log"))
        },
        {
          id: 2,
          title: "Emergency Reset",
          description: "Reset to a safe point before the sensitive data was added",
          instruction: "Use git reset --hard to remove all commits after the safe point",
          expectedCommand: "git reset --hard utils456",
          objective: "Reset to a safe commit before secrets were added",
          hint: "Find the hash of the last safe commit before secrets were added",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("git reset --hard"))
        },
        {
          id: 3,
          title: "Verify Cleanup",
          description: "Confirm that all sensitive data has been removed",
          instruction: "Check that secrets.txt no longer exists and verify the commit history",
          objective: "Verify complete removal of sensitive data",
          hint: "Use ls to check files and git log to verify history",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("ls")) &&
                          !state.files.some(f => f.name === "secrets.txt")
        },
        {
          id: 4,
          title: "Recovery Check",
          description: "Verify that you can still see the deleted commits in reflog",
          instruction: "Use git reflog to see the reset operation and deleted commits",
          expectedCommand: "git reflog",
          objective: "Understand how reflog tracks all operations",
          hint: "Reflog shows all Git operations, even deleted commits",
          validation: (state) => state.commandHistory.some(cmd => cmd.command.includes("git reflog"))
        }
      ]
    }
  ]

  useEffect(() => {
    if (state.startTime && !state.isCompleted) {
      setTimer(setInterval(() => {
        setState(prev => ({
          ...prev,
          elapsedTime: Math.floor((Date.now() - prev.startTime!) / 1000)
        }))
      }, 1000))
    }

    return () => {
      if (timer) clearInterval(timer)
    }
  }, [state.startTime, state.isCompleted])

  useEffect(() => {
    // Auto-scroll terminal to bottom
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight
    }
  }, [state.output, state.commandHistory])

  const startChallenge = (challenge: Challenge) => {
    setState(prev => ({
      ...prev,
      currentChallenge: challenge,
      currentStep: 0,
      files: [...challenge.initialFiles],
      commits: [...challenge.initialCommits],
      commandHistory: [],
      isCompleted: false,
      startTime: Date.now(),
      elapsedTime: 0,
      hintsUsed: 0,
      score: 0,
      showTutorial: prev.userProgress.level === 1, // Show tutorial for beginners
      currentCommand: '',
      output: [],
      error: null,
      showHint: false,
      activeTutorial: prev.userProgress.level === 1 ? {
        step: 1,
        totalSteps: 3,
        content: "Welcome to Git Lab! This is your terminal where you'll type Git commands. Let's start with the basics."
      } : null,
      autoSuggestions: []
    }))
    setActiveChallenge(challenge.id)
  }

  const executeCommand = (command: string) => {
    if (!state.currentChallenge) return

    const newCommandHistory = [...state.commandHistory, {
      command,
      output: [],
      error: null,
      timestamp: Date.now(),
      success: false
    }]
    
    let newOutput = [...state.output]
    let newError: string | null = null
    let newFiles = [...state.files]
    let newCommits = [...state.commits]
    let newScore = state.score
    let newAutoSuggestions: string[] = []

    // Simulate Git command execution
    const cmd = command.trim().toLowerCase()
    
    if (cmd === 'git log' || cmd === 'git log --oneline') {
      newOutput.push('Commit history:')
      state.commits.forEach(commit => {
        if (!commit.isDeleted) {
          newOutput.push(`${commit.hash} ${commit.message}`)
        }
      })
      newScore += 10
      newCommandHistory[newCommandHistory.length - 1].success = true
    } else if (cmd.startsWith('git show')) {
      const hash = cmd.split(' ')[2]
      const commit = state.commits.find(c => c.hash === hash)
      if (commit) {
        newOutput.push(`Commit ${commit.hash}`)
        newOutput.push(`Author: ${commit.author}`)
        newOutput.push(`Date: ${new Date(commit.timestamp).toLocaleString()}`)
        newOutput.push(``)
        newOutput.push(`    ${commit.message}`)
        newOutput.push(``)
        commit.files.forEach(file => {
          const fileContent = state.files.find(f => f.name === file)
          if (fileContent) {
            newOutput.push(`diff --git a/${file} b/${file}`)
            newOutput.push(`new file mode 100644`)
            newOutput.push(`index 0000000..1234567`)
            newOutput.push(`--- /dev/null`)
            newOutput.push(`+++ b/${file}`)
            newOutput.push(`@@ -0,0 +1 @@`)
            fileContent.content.split('\n').forEach(line => {
              newOutput.push(`+${line}`)
            })
          }
        })
        newScore += 15
        newCommandHistory[newCommandHistory.length - 1].success = true
      } else {
        newError = `fatal: bad revision '${hash}'`
        newCommandHistory[newCommandHistory.length - 1].success = false
      }
    } else if (cmd === 'git reset --soft head~1' || cmd === 'git reset --soft head~1') {
      if (state.commits.length > 1) {
        const lastCommit = state.commits[state.commits.length - 1]
        newCommits = state.commits.map(commit => 
          commit.id === lastCommit.id ? { ...commit, isDeleted: true } : commit
        )
        newOutput.push('Commit undone but files preserved (soft reset)')
        newScore += 20
        newCommandHistory[newCommandHistory.length - 1].success = true
      } else {
        newError = 'fatal: invalid upstream \'HEAD~1\''
        newCommandHistory[newCommandHistory.length - 1].success = false
      }
    } else if (cmd.startsWith('git reset --hard')) {
      const targetHash = cmd.split(' ')[3]
      if (targetHash) {
        const targetIndex = state.commits.findIndex(c => c.hash === targetHash)
        if (targetIndex !== -1) {
          // Remove commits after the target
          newCommits = state.commits.slice(0, targetIndex + 1)
          
          // Remove files that were added in deleted commits
          const validFiles = new Set<string>()
          newCommits.forEach(commit => {
            commit.files.forEach(file => validFiles.add(file))
          })
          newFiles = state.files.filter(file => validFiles.has(file.name))
          
          newOutput.push(`HEAD is now at ${targetHash}`)
          newScore += 25
          newCommandHistory[newCommandHistory.length - 1].success = true
        } else {
          newError = `fatal: bad revision '${targetHash}'`
          newCommandHistory[newCommandHistory.length - 1].success = false
        }
      } else {
        newError = 'fatal: You must specify a commit to reset to'
        newCommandHistory[newCommandHistory.length - 1].success = false
      }
    } else if (cmd === 'ls') {
      newOutput.push('Files in working directory:')
      state.files.forEach(file => {
        newOutput.push(file.name)
      })
      newScore += 5
      newCommandHistory[newCommandHistory.length - 1].success = true
    } else if (cmd.startsWith('cat ')) {
      const fileName = cmd.substring(4)
      const file = state.files.find(f => f.name === fileName)
      if (file) {
        newOutput.push(`Contents of ${fileName}:`)
        file.content.split('\n').forEach(line => {
          newOutput.push(line)
        })
        newScore += 10
        newCommandHistory[newCommandHistory.length - 1].success = true
      } else {
        newError = `cat: ${fileName}: No such file or directory`
        newCommandHistory[newCommandHistory.length - 1].success = false
      }
    } else if (cmd === 'git reflog') {
      newOutput.push('Reflog history:')
      state.commits.forEach(commit => {
        const action = commit.isDeleted ? 'reset: moving to' : 'commit: ' + commit.message
        newOutput.push(`${commit.hash} HEAD@{${commit.id}}: ${action}`)
      })
      newScore += 15
      newCommandHistory[newCommandHistory.length - 1].success = true
    } else if (cmd === 'git status') {
      newOutput.push('On branch main')
      newOutput.push('')
      const modifiedFiles = state.files.filter(f => f.status === 'modified')
      const stagedFiles = state.files.filter(f => f.status === 'staged')
      const untrackedFiles = state.files.filter(f => f.status === 'untracked')
      
      if (stagedFiles.length > 0) {
        newOutput.push('Changes to be committed:')
        newOutput.push('  (use "git restore --staged <file>..." to unstage)')
        newOutput.push('')
        stagedFiles.forEach(file => {
          newOutput.push(`\tnew file:   ${file.name}`)
        })
        newOutput.push('')
      }
      
      if (modifiedFiles.length > 0) {
        newOutput.push('Changes not staged for commit:')
        newOutput.push('  (use "git add <file>..." to update what will be committed)')
        newOutput.push('  (use "git restore <file>..." to discard changes in working directory)')
        newOutput.push('')
        modifiedFiles.forEach(file => {
          newOutput.push(`\tmodified:   ${file.name}`)
        })
        newOutput.push('')
      }
      
      if (untrackedFiles.length > 0) {
        newOutput.push('Untracked files:')
        newOutput.push('  (use "git add <file>..." to include in what will be committed)')
        newOutput.push('')
        untrackedFiles.forEach(file => {
          newOutput.push(`\t${file.name}`)
        })
      }
      
      if (modifiedFiles.length === 0 && stagedFiles.length === 0 && untrackedFiles.length === 0) {
        newOutput.push('nothing to commit, working tree clean')
      }
      
      newScore += 8
      newCommandHistory[newCommandHistory.length - 1].success = true
    } else if (cmd === 'clear') {
      newOutput = []
      newCommandHistory[newCommandHistory.length - 1].success = true
    } else if (cmd === 'help' || cmd === '--help') {
      newOutput.push('Available Git commands:')
      newOutput.push('  git log [--oneline]     - Show commit history')
      newOutput.push('  git show <commit>       - Show commit details')
      newOutput.push('  git reset --soft <ref>  - Soft reset to reference')
      newOutput.push('  git reset --hard <ref>  - Hard reset to reference')
      newOutput.push('  git reflog             - Show reflog history')
      newOutput.push('  git status             - Show working tree status')
      newOutput.push('  ls                     - List files')
      newOutput.push('  cat <file>             - Show file contents')
      newOutput.push('  clear                  - Clear terminal')
      newOutput.push('  help                   - Show this help')
      newCommandHistory[newCommandHistory.length - 1].success = true
    } else {
      newError = `git: '${command.split(' ')[0]}' is not a git command`
      newCommandHistory[newCommandHistory.length - 1].success = false
    }

    // Generate auto-suggestions based on current state
    if (cmd.startsWith('git show') && !cmd.includes(' ')) {
      newAutoSuggestions = state.commits.map(c => c.hash)
    } else if (cmd.startsWith('git reset') && !cmd.includes(' ')) {
      newAutoSuggestions = ['--soft', '--hard']
    }

    setState(prev => ({
      ...prev,
      commandHistory: newCommandHistory,
      output: newOutput,
      error: newError,
      files: newFiles,
      commits: newCommits,
      score: newScore,
      currentCommand: '',
      autoSuggestions: newAutoSuggestions
    }))

    // Check if current step is completed
    const currentStep = state.currentChallenge?.steps[state.currentStep]
    if (currentStep && currentStep.validation({
      ...state,
      commandHistory: newCommandHistory,
      output: newOutput,
      files: newFiles,
      commits: newCommits
    })) {
      setTimeout(() => {
        completeStep()
      }, 1000)
    }
  }

  const completeStep = () => {
    if (!state.currentChallenge) return

    const nextStepIndex = state.currentStep + 1
    const stepBonus = Math.max(50 - state.hintsUsed * 10, 20)
    
    if (nextStepIndex >= state.currentChallenge.steps.length) {
      // Challenge completed
      const challenge = state.currentChallenge
      const newExperience = state.userProgress.experience + 100
      const newLevel = Math.floor(newExperience / 500) + 1
      
      // Update skill levels
      const newSkillLevels = { ...state.userProgress.skillLevels }
      newSkillLevels[challenge.category] = Math.min(100, newSkillLevels[challenge.category] + 25)
      
      // Check achievements
      const newAchievements = [...state.userProgress.achievements]
      if (state.userProgress.completedChallenges === 0) {
        const firstAchievement = newAchievements.find(a => a.id === 'first-commit')
        if (firstAchievement) {
          firstAchievement.unlocked = true
          firstAchievement.unlockedAt = Date.now()
        }
      }
      
      setState(prev => ({
        ...prev,
        isCompleted: true,
        score: prev.score + 100 + stepBonus,
        userProgress: {
          ...prev.userProgress,
          level: newLevel,
          experience: newExperience,
          completedChallenges: prev.userProgress.completedChallenges + 1,
          streak: prev.userProgress.streak + 1,
          lastPlayed: Date.now(),
          achievements: newAchievements,
          skillLevels: newSkillLevels
        }
      }))
      
      if (timer) clearInterval(timer)
    } else {
      setState(prev => ({
        ...prev,
        currentStep: nextStepIndex,
        score: prev.score + stepBonus,
        showHint: false,
        activeTutorial: null
      }))
    }
  }

  const useHint = () => {
    setState(prev => ({
      ...prev,
      hintsUsed: prev.hintsUsed + 1,
      showHint: true,
      score: Math.max(0, prev.score - 5)
    }))
  }

  const resetChallenge = () => {
    if (state.currentChallenge) {
      startChallenge(state.currentChallenge)
    }
  }

  const exitChallenge = () => {
    setState(prev => ({
      ...prev,
      currentChallenge: null,
      currentStep: 0,
      files: [],
      commits: [],
      commandHistory: [],
      isCompleted: false,
      startTime: null,
      elapsedTime: 0,
      hintsUsed: 0,
      score: 0,
      showTutorial: false,
      currentCommand: '',
      output: [],
      error: null,
      showHint: false,
      activeTutorial: null,
      autoSuggestions: []
    }))
    setActiveChallenge(null)
    if (timer) clearInterval(timer)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800 border-green-200'
      case 'intermediate': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'advanced': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'basics': return <BookOpen className="h-4 w-4" />
      case 'safety': return <Shield className="h-4 w-4" />
      case 'recovery': return <Wrench className="h-4 w-4" />
      case 'advanced': return <Zap className="h-4 w-4" />
      default: return <Target className="h-4 w-4" />
    }
  }

  if (state.currentChallenge) {
    const currentStep = state.currentChallenge.steps[state.currentStep]
    const progress = ((state.currentStep + 1) / state.currentChallenge.steps.length) * 100

    return (
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Challenge Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <CardTitle className="flex items-center gap-2">
                    {getCategoryIcon(state.currentChallenge.category)}
                    {state.currentChallenge.title}
                  </CardTitle>
                  <Badge className={getDifficultyColor(state.currentChallenge.difficulty)}>
                    {state.currentChallenge.difficulty}
                  </Badge>
                </div>
                <CardDescription className="text-base">
                  {state.currentChallenge.description}
                </CardDescription>
                <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <div className="text-sm text-blue-700 dark:text-blue-300">
                      <strong>Real World Scenario:</strong> {state.currentChallenge.realWorldScenario}
                    </div>
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={exitChallenge}>
                <XCircle className="h-4 w-4 mr-2" />
                Exit
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-500">{state.currentStep + 1}/{state.currentChallenge.steps.length}</div>
                <div className="text-sm text-slate-500">Steps</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-500">{state.score}</div>
                <div className="text-sm text-slate-500">Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-500">{formatTime(state.elapsedTime)}</div>
                <div className="text-sm text-slate-500">Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-500">{state.hintsUsed}</div>
                <div className="text-sm text-slate-500">Hints</div>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="w-full" />
              <div className="text-sm text-slate-500 mt-1">{Math.round(progress)}% Complete</div>
            </div>
          </CardContent>
        </Card>

        {/* Tutorial Overlay */}
        <AnimatePresence>
          {state.activeTutorial && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            >
              <Card className="w-full max-w-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="h-5 w-5" />
                    Interactive Tutorial
                  </CardTitle>
                  <CardDescription>
                    Step {state.activeTutorial.step} of {state.activeTutorial.totalSteps}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-slate-600 dark:text-slate-300">
                    {state.activeTutorial.content}
                  </p>
                  <div className="flex justify-end gap-2">
                    <Button 
                      variant="outline" 
                      onClick={() => setState(prev => ({ ...prev, activeTutorial: null, showTutorial: false }))}
                    >
                      Skip Tutorial
                    </Button>
                    <Button onClick={() => {
                      if (state.activeTutorial!.step < state.activeTutorial!.totalSteps) {
                        setState(prev => ({
                          ...prev,
                          activeTutorial: {
                            ...prev.activeTutorial!,
                            step: prev.activeTutorial!.step + 1,
                            content: prev.activeTutorial!.step === 1 ? 
                              "Type 'git log --oneline' in the terminal below and press Enter to see your commit history." :
                              "Great! Now try 'git show <hash>' to inspect a specific commit. Replace <hash> with an actual commit hash."
                          }
                        }))
                      } else {
                        setState(prev => ({ ...prev, activeTutorial: null, showTutorial: false }))
                      }
                    }}>
                      {state.activeTutorial.step === state.activeTutorial.totalSteps ? 'Start Challenge' : 'Next'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel - Instructions */}
          <div className="lg:col-span-1 space-y-4">
            {/* Current Step */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {state.currentStep + 1}
                  </div>
                  {currentStep.title}
                </CardTitle>
                <CardDescription>
                  {currentStep.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Objective:</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-300">
                    {currentStep.objective}
                  </p>
                </div>

                {currentStep.expectedCommand && (
                  <div>
                    <h4 className="font-medium mb-2">Expected Command:</h4>
                    <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-lg font-mono text-sm">
                      {currentStep.expectedCommand}
                    </div>
                  </div>
                )}

                {/* Tutorial Section */}
                {currentStep.tutorial && (
                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <BookOpen className="h-4 w-4" />
                      Learning Guide
                    </h4>
                    <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
                      <h5 className="font-medium text-blue-800 dark:text-blue-200 mb-2">
                        {currentStep.tutorial.title}
                      </h5>
                      <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                        {currentStep.tutorial.steps.map((step, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <ChevronRight className="h-3 w-3 mt-0.5 flex-shrink-0" />
                            {step}
                          </li>
                        ))}
                      </ul>
                      {currentStep.tutorial.codeExample && (
                        <div className="mt-2 p-2 bg-blue-100 dark:bg-blue-900 rounded font-mono text-xs">
                          {currentStep.tutorial.codeExample}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button onClick={useHint} variant="outline" className="flex-1">
                    <Lightbulb className="h-4 w-4 mr-2" />
                    Use Hint (-5 pts)
                  </Button>
                  <Button onClick={resetChallenge} variant="outline">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset
                  </Button>
                </div>

                <AnimatePresence>
                  {state.showHint && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                    >
                      <Alert>
                        <Lightbulb className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Hint:</strong> {currentStep.hint}
                        </AlertDescription>
                      </Alert>
                    </motion.div>
                  )}
                </AnimatePresence>

                {state.error && (
                  <Alert variant="destructive">
                    <XCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Error:</strong> {state.error}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Learning Goals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Learning Goals
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-slate-600 dark:text-slate-300 space-y-2">
                  {state.currentChallenge.learningGoals.map((goal, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      {goal}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Terminal & Git Graph */}
          <div className="lg:col-span-2 space-y-4">
            {/* Git Graph */}
            {state.showGitGraph && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <GitPullRequest className="h-5 w-5" />
                      Git Repository Graph
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setState(prev => ({ ...prev, showGitGraph: false }))}
                    >
                      <Minimize2 className="h-4 w-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-slate-300 dark:bg-slate-600"></div>
                    <div className="space-y-4">
                      {state.commits.filter(c => !c.isDeleted).map((commit, index) => (
                        <div key={commit.id} className="relative flex items-center gap-4">
                          <div className="relative z-10">
                            <div className={`w-4 h-4 rounded-full ${
                              commit.hasSecret ? 'bg-red-500 animate-pulse' : 'bg-green-500'
                            }`}></div>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-sm text-slate-600 dark:text-slate-300">
                                {commit.hash}
                              </span>
                              {commit.hasSecret && (
                                <Badge variant="destructive" className="text-xs">
                                  Secret
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm font-medium">{commit.message}</p>
                            <div className="text-xs text-slate-500">
                              {commit.author} • {new Date(commit.timestamp).toLocaleTimeString()}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Terminal */}
            <Card className={state.terminalExpanded ? 'fixed inset-4 z-40' : ''}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Terminal className="h-5 w-5" />
                    Git Terminal
                  </div>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setState(prev => ({ ...prev, showGitGraph: !prev.showGitGraph }))}
                    >
                      <GitPullRequest className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setState(prev => ({ ...prev, terminalExpanded: !prev.terminalExpanded }))}
                    >
                      {state.terminalExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                    </Button>
                  </div>
                </CardTitle>
                <CardDescription>
                  Type Git commands to interact with the repository. Type 'help' for available commands.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* File Status */}
                <div>
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Working Directory
                  </h4>
                  <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg text-sm">
                    {state.files.map(file => (
                      <div key={file.name} className="flex items-center gap-2">
                        <span className={file.hasSecret ? 'text-red-500' : 'text-green-500'}>
                          {file.hasSecret ? '🔴' : '🟢'}
                        </span>
                        <span className={file.status === 'modified' ? 'text-yellow-600' : 
                                      file.status === 'staged' ? 'text-blue-600' : 
                                      file.status === 'untracked' ? 'text-purple-600' : 'text-slate-600'}>
                          {file.name}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {file.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Command Input */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-medium">Command Input</h4>
                    <Badge variant="outline" className="text-xs">
                      Auto-complete available
                    </Badge>
                  </div>
                  <div className="relative">
                    <div className="flex items-center gap-2">
                      <span className="text-green-500 font-mono">$</span>
                      <input
                        type="text"
                        value={state.currentCommand}
                        onChange={(e) => setState(prev => ({ 
                          ...prev, 
                          currentCommand: e.target.value,
                          autoSuggestions: [] 
                        }))}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && state.currentCommand.trim()) {
                            executeCommand(state.currentCommand)
                          }
                        }}
                        placeholder="Type Git command..."
                        className="flex-1 px-3 py-2 bg-slate-900 text-green-400 border border-slate-700 rounded-lg font-mono text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                        autoFocus
                      />
                      <Button onClick={() => executeCommand(state.currentCommand)} disabled={!state.currentCommand.trim()}>
                        <Play className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    {/* Auto-suggestions */}
                    {state.autoSuggestions.length > 0 && (
                      <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-slate-700 rounded-lg shadow-lg z-10">
                        {state.autoSuggestions.map((suggestion, index) => (
                          <div
                            key={index}
                            className="px-3 py-2 text-sm text-slate-300 hover:bg-slate-700 cursor-pointer font-mono"
                            onClick={() => setState(prev => ({ 
                              ...prev, 
                              currentCommand: state.currentCommand.split(' ')[0] + ' ' + suggestion,
                              autoSuggestions: [] 
                            }))}
                          >
                            {suggestion}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Terminal Output */}
                <div>
                  <h4 className="font-medium mb-2">Output</h4>
                  <ScrollArea 
                    ref={terminalRef}
                    className="h-64 bg-slate-900 text-green-400 p-3 rounded-lg font-mono text-sm"
                  >
                    {state.output.map((line, index) => (
                      <div key={index}>{line}</div>
                    ))}
                    {state.output.length === 0 && (
                      <div className="text-slate-500">Welcome to Git Lab! Type 'help' to see available commands.</div>
                    )}
                  </ScrollArea>
                </div>

                {/* Command History */}
                <div>
                  <h4 className="font-medium mb-2">Recent Commands</h4>
                  <ScrollArea className="h-24 bg-slate-50 dark:bg-slate-800 p-3 rounded-lg font-mono text-sm">
                    {state.commandHistory.slice(-5).map((cmd, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <span className={cmd.success ? 'text-green-600' : 'text-red-600'}>
                          {cmd.success ? '✓' : '✗'}
                        </span>
                        <span className="text-slate-600 dark:text-slate-300">$ {cmd.command}</span>
                      </div>
                    ))}
                    {state.commandHistory.length === 0 && (
                      <div className="text-slate-500">No commands executed yet.</div>
                    )}
                  </ScrollArea>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Completion Modal */}
        <AnimatePresence>
          {state.isCompleted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            >
              <Card className="w-full max-w-lg">
                <CardHeader className="text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Trophy className="h-10 w-10 text-white" />
                  </div>
                  <CardTitle>Challenge Completed!</CardTitle>
                  <CardDescription>
                    Excellent work! You've mastered this Git concept.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-3xl font-bold text-blue-500">{state.score}</div>
                      <div className="text-sm text-slate-500">Final Score</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-green-500">{formatTime(state.elapsedTime)}</div>
                      <div className="text-sm text-slate-500">Time Taken</div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h4 className="font-medium mb-2">Experience Gained</h4>
                    <div className="flex items-center gap-2">
                      <Progress value={(state.userProgress.experience % 500) / 500 * 100} className="flex-1" />
                      <span className="text-sm text-slate-500">
                        Level {state.userProgress.level}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button onClick={resetChallenge} variant="outline" className="flex-1">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Try Again
                    </Button>
                    <Button onClick={exitChallenge} className="flex-1">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      Continue
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-2">
          <Sparkles className="h-6 w-6 text-yellow-500" />
          <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
            Git Immersive Lab
          </h2>
          <Sparkles className="h-6 w-6 text-yellow-500" />
        </div>
        <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
          Master Git operations through interactive, real-world scenarios. Learn by doing in a safe, guided environment.
        </p>
        
        {/* User Progress */}
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span className="text-sm font-medium">Level {state.userProgress.level}</span>
              </div>
              <span className="text-sm text-slate-500">
                {state.userProgress.experience % 500}/500 XP
              </span>
            </div>
            <Progress value={(state.userProgress.experience % 500) / 500 * 100} className="w-full" />
            <div className="flex items-center justify-between mt-2 text-xs text-slate-500">
              <span>{state.userProgress.completedChallenges} challenges completed</span>
              <span>{state.userProgress.streak} day streak</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Challenge Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {['basics', 'safety', 'recovery', 'advanced'].map((category) => {
          const categoryChallenges = challenges.filter(c => c.category === category)
          const completedInCategory = categoryChallenges.filter(c => 
            state.userProgress.completedChallenges >= c.id
          ).length
          const skillLevel = state.userProgress.skillLevels[category as keyof typeof state.userProgress.skillLevels]
          
          return (
            <Card key={category} className="text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-3">
                  {getCategoryIcon(category)}
                </div>
                <h3 className="font-semibold capitalize mb-1">{category}</h3>
                <p className="text-sm text-slate-500 mb-3">
                  {completedInCategory}/{categoryChallenges.length} completed
                </p>
                <Progress value={skillLevel} className="w-full mb-2" />
                <div className="text-xs text-slate-500">
                  Skill Level: {skillLevel}%
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Challenges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {challenges.map((challenge) => {
          const isUnlocked = challenge.prerequisites.length === 0 || 
                           challenge.prerequisites.every(pre => state.userProgress.completedChallenges >= pre)
          const isCompleted = state.userProgress.completedChallenges >= challenge.id
          
          return (
            <motion.div
              key={challenge.id}
              whileHover={{ scale: isUnlocked ? 1.01 : 1 }}
              whileTap={{ scale: isUnlocked ? 0.99 : 1 }}
            >
              <Card className={`transition-all ${
                activeChallenge === challenge.id ? 'ring-2 ring-blue-500' : ''
              } ${!isUnlocked ? 'opacity-50' : ''}`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      {getCategoryIcon(challenge.category)}
                      {challenge.title}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      {isCompleted && (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      )}
                      <Badge className={getDifficultyColor(challenge.difficulty)}>
                        {challenge.difficulty}
                      </Badge>
                    </div>
                  </div>
                  <CardDescription>
                    {challenge.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Learning Objectives:</h4>
                    <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                      {challenge.learningGoals.slice(0, 2).map((goal, index) => (
                        <li key={index}>{goal}</li>
                      ))}
                      {challenge.learningGoals.length > 2 && (
                        <li className="text-slate-400">+{challenge.learningGoals.length - 2} more</li>
                      )}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between text-sm text-slate-500">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {Math.floor(challenge.estimatedTime / 60)}m
                    </div>
                    <div className="flex items-center gap-1">
                      <GitMerge className="h-4 w-4" />
                      {challenge.steps.length} steps
                    </div>
                  </div>

                  {!isUnlocked && challenge.prerequisites.length > 0 && (
                    <Alert>
                      <Lock className="h-4 w-4" />
                      <AlertDescription>
                        Complete challenge {challenge.prerequisites[0]} to unlock
                      </AlertDescription>
                    </Alert>
                  )}

                  <Button 
                    onClick={() => startChallenge(challenge)}
                    className="w-full"
                    disabled={!isUnlocked || activeChallenge !== null}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Completed
                      </>
                    ) : activeChallenge === challenge.id ? (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        In Progress
                      </>
                    ) : !isUnlocked ? (
                      <>
                        <Lock className="h-4 w-4 mr-2" />
                        Locked
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Start Challenge
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            Achievements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {state.userProgress.achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-4 rounded-lg border text-center ${
                  achievement.unlocked 
                    ? 'bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800' 
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="text-2xl mb-2">{achievement.icon}</div>
                <h4 className="font-medium text-sm">{achievement.title}</h4>
                <p className="text-xs text-slate-500 mt-1">{achievement.description}</p>
                {achievement.unlocked && achievement.unlockedAt && (
                  <div className="text-xs text-green-600 mt-2">
                    Unlocked {new Date(achievement.unlockedAt).toLocaleDateString()}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default GitImmersiveLab