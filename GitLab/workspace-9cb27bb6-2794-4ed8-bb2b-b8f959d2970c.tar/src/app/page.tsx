'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import GitAnimatedNode from '@/components/git-animated-node'
import GitOperationCard from '@/components/git-operation-card'
import GitSimpleLab from '@/components/git-simple-lab'
import GitGuideAvatar from '@/components/git-guide-avatar'
import { 
  GitBranch, 
  GitMerge, 
  GitPullRequest, 
  RotateCcw, 
  Trash2, 
  Eye, 
  Play, 
  CheckCircle, 
  AlertCircle,
  Trophy,
  BookOpen,
  Terminal,
  Sparkles,
  Target,
  Zap
} from 'lucide-react'

interface GitCommit {
  id: string
  message: string
  hash: string
  files: string[]
  hasSecret: boolean
  timestamp: number
  isDeleted: boolean
}

interface GitOperation {
  type: 'soft-reset' | 'hard-reset' | 'reflog' | 'show' | 'checkout'
  description: string
  command: string
}

const GitLearningLab = () => {
  const [commits, setCommits] = useState<GitCommit[]>([
    {
      id: '1',
      message: 'Initial commit',
      hash: 'def5678',
      files: ['readme.md'],
      hasSecret: false,
      timestamp: Date.now() - 10000,
      isDeleted: false
    },
    {
      id: '2',
      message: 'Add config with API key',
      hash: 'abc1234',
      files: ['config.py'],
      hasSecret: true,
      timestamp: Date.now(),
      isDeleted: false
    }
  ])
  
  const [currentStep, setCurrentStep] = useState(0)
  const [selectedCommit, setSelectedCommit] = useState<string | null>(null)
  const [reflogVisible, setReflogVisible] = useState(false)
  const [showAnimation, setShowAnimation] = useState(false)
  const [progress, setProgress] = useState(0)
  const [completedOperations, setCompletedOperations] = useState<Set<string>>(new Set())
  const [showCelebration, setShowCelebration] = useState(false)
  
  const operations: GitOperation[] = [
    {
      type: 'soft-reset',
      description: 'Undoes commit but keeps files in working directory',
      command: 'git reset --soft HEAD^1'
    },
    {
      type: 'hard-reset',
      description: 'Undoes commit and deletes files from working directory',
      command: 'git reset --hard HEAD^1'
    },
    {
      type: 'reflog',
      description: 'Shows history of all Git actions including deleted commits',
      command: 'git reflog'
    },
    {
      type: 'show',
      description: 'Shows details of a specific commit',
      command: 'git show <commit-hash>'
    },
    {
      type: 'checkout',
      description: 'Switches to a specific commit state',
      command: 'git checkout <commit-hash>'
    }
  ]

  const handleOperation = (operation: GitOperation) => {
    setShowAnimation(true)
    
    setTimeout(() => {
      let newProgress = progress
      let newCompleted = new Set(completedOperations)
      
      switch (operation.type) {
        case 'soft-reset':
          if (commits.length > 1) {
            const lastCommit = commits[commits.length - 1]
            setCommits(prev => prev.map(commit => 
              commit.id === lastCommit.id 
                ? { ...commit, isDeleted: true }
                : commit
            ))
            newCompleted.add('soft-reset')
            newProgress = Math.min(progress + 20, 100)
          }
          break
        case 'hard-reset':
          if (commits.length > 1) {
            setCommits(prev => prev.slice(0, -1))
            newCompleted.add('hard-reset')
            newProgress = Math.min(progress + 25, 100)
          }
          break
        case 'reflog':
          setReflogVisible(true)
          newCompleted.add('reflog')
          newProgress = Math.min(progress + 15, 100)
          break
        case 'show':
          if (selectedCommit) {
            newCompleted.add('show')
            newProgress = Math.min(progress + 10, 100)
          }
          break
        case 'checkout':
          newCompleted.add('checkout')
          newProgress = Math.min(progress + 10, 100)
          break
        default:
          break
      }
      
      setCompletedOperations(newCompleted)
      setProgress(newProgress)
      setShowAnimation(false)
      
      // Celebration effect when reaching milestones
      if (newProgress >= 100) {
        setShowCelebration(true)
        setTimeout(() => setShowCelebration(false), 3000)
      } else if (newProgress % 50 === 0 && newProgress > 0) {
        setShowCelebration(true)
        setTimeout(() => setShowCelebration(false), 1500)
      }
    }, 1000)
  }

  const addCommit = () => {
    const newCommit: GitCommit = {
      id: (commits.length + 1).toString(),
      message: `Commit ${commits.length + 1}`,
      hash: Math.random().toString(36).substring(2, 8),
      files: [`file${commits.length + 1}.txt`],
      hasSecret: Math.random() > 0.7,
      timestamp: Date.now(),
      isDeleted: false
    }
    setCommits([...commits, newCommit])
  }

  const resetLab = () => {
    setCommits([
      {
        id: '1',
        message: 'Initial commit',
        hash: 'def5678',
        files: ['readme.md'],
        hasSecret: false,
        timestamp: Date.now() - 10000,
        isDeleted: false
      },
      {
        id: '2',
        message: 'Add config with API key',
        hash: 'abc1234',
        files: ['config.py'],
        hasSecret: true,
        timestamp: Date.now(),
        isDeleted: false
      }
    ])
    setProgress(0)
    setReflogVisible(false)
    setSelectedCommit(null)
    setCompletedOperations(new Set())
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4">
      {/* Celebration Effect */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            className="fixed inset-0 flex items-center justify-center pointer-events-none z-50"
          >
            <div className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
              🎉 Awesome! 🎉
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Animated Header */}
        <motion.div 
          className="text-center space-y-2"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.h1 
            className="text-4xl font-bold text-slate-800 dark:text-slate-100"
            animate={{ 
              background: [
                'linear-gradient(45deg, #1e293b, #475569)',
                'linear-gradient(45deg, #3b82f6, #8b5cf6)',
                'linear-gradient(45deg, #1e293b, #475569)'
              ]
            }}
            transition={{ duration: 5, repeat: Infinity }}
            style={{ WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}
          >
            Git Rollback & Commit Deletion Lab
          </motion.h1>
          <motion.p 
            className="text-lg text-slate-600 dark:text-slate-300"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Interactive learning environment for mastering Git operations
          </motion.p>
          <motion.div 
            className="flex justify-center items-center gap-2"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
          >
            <Progress value={progress} className="w-64" />
            <motion.span 
              className="text-sm text-slate-500"
              animate={{ scale: progress >= 100 ? [1, 1.2, 1] : 1 }}
              transition={{ duration: 0.5 }}
            >
              {progress}% Complete
            </motion.span>
          </motion.div>
        </motion.div>

        <Tabs defaultValue="workflow" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="workflow" className="flex items-center gap-2">
                <GitBranch className="h-4 w-4" />
                Workflow
              </TabsTrigger>
              <TabsTrigger value="operations" className="flex items-center gap-2">
                <Terminal className="h-4 w-4" />
                Operations
              </TabsTrigger>
              <TabsTrigger value="challenges" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Challenges
              </TabsTrigger>
              <TabsTrigger value="guide" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Guide
              </TabsTrigger>
            </TabsList>
          </motion.div>

          {/* Workflow Visualization */}
          <TabsContent value="workflow" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GitBranch className="h-5 w-5" />
                    Git Commit Timeline
                  </CardTitle>
                  <CardDescription>
                    Visual representation of your Git commit history
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    {/* Timeline */}
                    <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-slate-300 dark:bg-slate-600"></div>
                    
                    {/* Animated Commits */}
                    <div className="space-y-6">
                      {commits.map((commit, index) => (
                        <GitAnimatedNode
                          key={commit.id}
                          commit={commit}
                          isSelected={selectedCommit === commit.id}
                          onClick={() => setSelectedCommit(commit.id)}
                          index={index}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-6">
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button onClick={addCommit} variant="outline">
                        <GitBranch className="h-4 w-4 mr-2" />
                        Add Commit
                      </Button>
                    </motion.div>
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button onClick={resetLab} variant="outline">
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Reset Lab
                      </Button>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Reflog Panel */}
            <AnimatePresence>
              {reflogVisible && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="h-5 w-5" />
                        Git Reflog
                      </CardTitle>
                      <CardDescription>
                        History of all Git operations including deleted commits
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-48">
                        <div className="space-y-2 font-mono text-sm">
                          {commits.map((commit) => (
                            <motion.div
                              key={commit.id}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: commit.id === '1' ? 0.1 : 0.2 }}
                              className="p-2 bg-slate-50 dark:bg-slate-800 rounded"
                            >
                              <div className="text-slate-600 dark:text-slate-300">
                                {commit.hash} HEAD@{commit.id}: {commit.isDeleted ? 'reset: deleted' : 'commit: ' + commit.message}
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </TabsContent>

          {/* Operations Panel */}
          <TabsContent value="operations" className="space-y-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
            >
              {operations.map((operation, index) => (
                <motion.div
                  key={operation.type}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                >
                  <GitOperationCard
                    operation={operation}
                    onExecute={() => handleOperation(operation)}
                    isExecuting={showAnimation}
                    completed={completedOperations.has(operation.type)}
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          {/* Challenges */}
          <TabsContent value="challenges" className="space-y-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <GitSimpleLab />
            </motion.div>
          </TabsContent>

          {/* Guide */}
          <TabsContent value="guide" className="space-y-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-6"
            >
              {/* Avatar Guide */}
              <motion.div
                initial={{ x: -20 }}
                animate={{ x: 0 }}
                transition={{ delay: 0.3 }}
              >
                <GitGuideAvatar 
                  currentStep={currentStep} 
                  onTipRequest={() => {}}
                />
              </motion.div>

              {/* Learning Content */}
              <motion.div
                initial={{ x: 20 }}
                animate={{ x: 0 }}
                transition={{ delay: 0.4 }}
                className="lg:col-span-2"
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5" />
                      Git Rollback & Deletion Guide
                    </CardTitle>
                    <CardDescription>
                      Master the art of undoing Git commits safely
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-4">
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.5 }}
                        >
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            <RotateCcw className="h-4 w-4 text-blue-500" />
                            Soft Reset
                          </h3>
                          <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                            Use <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">git reset --soft</code> when you want to:
                          </p>
                          <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                            <li>Undo a commit but keep your changes</li>
                            <li>Modify the commit message</li>
                            <li>Split a large commit into smaller ones</li>
                          </ul>
                        </motion.div>
                        
                        <Separator />
                        
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.6 }}
                        >
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            <Trash2 className="h-4 w-4 text-red-500" />
                            Hard Reset
                          </h3>
                          <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                            Use <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">git reset --hard</code> when you want to:
                          </p>
                          <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                            <li>Completely remove commits and changes</li>
                            <li>Start fresh from a previous commit</li>
                            <li>Remove sensitive data accidentally committed</li>
                          </ul>
                          <Alert className="mt-2">
                            <AlertCircle className="h-4 w-4" />
                            <AlertDescription>
                              <strong>Warning:</strong> Hard reset permanently deletes changes. Use with caution!
                            </AlertDescription>
                          </Alert>
                        </motion.div>
                        
                        <Separator />
                        
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.7 }}
                        >
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            <Eye className="h-4 w-4 text-purple-500" />
                            Reflog
                          </h3>
                          <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                            Use <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">git reflog</code> to:
                          </p>
                          <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                            <li>Recover accidentally deleted commits</li>
                            <li>Track all Git operations history</li>
                            <li>Find lost work after reset operations</li>
                          </ul>
                        </motion.div>
                        
                        <Separator />
                        
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.8 }}
                        >
                          <h3 className="font-semibold mb-2 flex items-center gap-2">
                            <Zap className="h-4 w-4 text-yellow-500" />
                            Best Practices
                          </h3>
                          <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                            <li>Always check <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">git status</code> before operations</li>
                            <li>Use soft reset when unsure about hard reset</li>
                            <li>Never force push to shared repositories</li>
                            <li>Keep sensitive data out of version control</li>
                            <li>Practice in a safe environment like this lab</li>
                          </ul>
                        </motion.div>
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default GitLearningLab