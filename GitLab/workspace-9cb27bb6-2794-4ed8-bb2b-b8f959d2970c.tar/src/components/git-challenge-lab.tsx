'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { 
  CheckCircle, 
  AlertCircle, 
  Trophy, 
  Target, 
  Play, 
  RotateCcw,
  Lightbulb,
  Terminal,
  FileText,
  GitCommit,
  GitBranch,
  Eye,
  Trash2,
  Zap,
  Star,
  ArrowRight,
  ArrowLeft,
  HelpCircle,
  XCircle,
  Clock
} from 'lucide-react'

interface VirtualFile {
  name: string
  content: string
  hasSecret: boolean
}

interface VirtualCommit {
  id: string
  message: string
  hash: string
  files: string[]
  hasSecret: boolean
  timestamp: number
  isDeleted: boolean
}

interface ChallengeStep {
  id: number
  title: string
  description: string
  instruction: string
  command: string
  expectedState: string
  hint: string
  validation: (currentState: ChallengeState) => boolean
}

interface Challenge {
  id: number
  title: string
  description: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  timeLimit?: number
  steps: ChallengeStep[]
  initialFiles: VirtualFile[]
  initialCommits: VirtualCommit[]
  learningObjectives: string[]
}

interface ChallengeState {
  currentChallenge: Challenge | null
  currentStep: number
  files: VirtualFile[]
  commits: VirtualCommit[]
  commandHistory: string[]
  isCompleted: boolean
  startTime: number | null
  elapsedTime: number
  hintsUsed: number
  score: number
  showHint: boolean
  currentCommand: string
  output: string[]
  error: string | null
}

const GitChallengeLab = () => {
  const [state, setState] = useState<ChallengeState>({
    currentChallenge: null,
    currentStep: 0,
    files: [],
    commits: [],
    commandHistory: [],
    isCompleted: false,
    startTime: null,
    elapsedTime: 0,
    hintsUsed: 0,
    score: 0,
    showHint: false,
    currentCommand: '',
    output: [],
    error: null
  })

  const [activeChallenge, setActiveChallenge] = useState<number | null>(null)
  const [timer, setTimer] = useState<NodeJS.Timeout | null>(null)

  const challenges: Challenge[] = [
    {
      id: 1,
      title: "Find the Secret Commit",
      description: "Identify and inspect a commit that contains sensitive information",
      difficulty: "beginner",
      timeLimit: 300,
      initialFiles: [
        { name: "readme.md", content: "# Project README\n\nThis is a safe file.", hasSecret: false },
        { name: "config.py", content: "API_KEY=\"supersecret123\"\nDB_HOST=\"localhost\"", hasSecret: true }
      ],
      initialCommits: [
        { id: "1", message: "Initial commit", hash: "a1b2c3d", files: ["readme.md"], hasSecret: false, timestamp: Date.now() - 20000, isDeleted: false },
        { id: "2", message: "Add configuration file", hash: "e4f5g6h", files: ["config.py"], hasSecret: true, timestamp: Date.now() - 10000, isDeleted: false },
        { id: "3", message: "Update documentation", hash: "i7j8k9l", files: ["readme.md"], hasSecret: false, timestamp: Date.now(), isDeleted: false }
      ],
      learningObjectives: [
        "Use git log to view commit history",
        "Identify commits with sensitive data",
        "Use git show to inspect commit contents"
      ],
      steps: [
        {
          id: 1,
          title: "View Commit History",
          description: "Examine the commit history to identify all commits",
          instruction: "Use git log to see all commits in the repository",
          command: "git log --oneline",
          expectedState: "log_viewed",
          hint: "The --oneline flag shows each commit in a single, compact line",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("git log"))
        },
        {
          id: 2,
          title: "Inspect Suspicious Commit",
          description: "Look for commits that might contain sensitive information",
          instruction: "Use git show to inspect the commit that added config.py",
          command: "git show e4f5g6h",
          expectedState: "commit_inspected",
          hint: "Look for the commit with message 'Add configuration file'",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("git show") && cmd.includes("e4f5g6h"))
        },
        {
          id: 3,
          title: "Identify the Secret",
          description: "Confirm you found the sensitive information",
          instruction: "Check the output for the API key in the config.py file",
          command: "",
          expectedState: "secret_found",
          hint: "Look for 'supersecret123' in the commit output",
          validation: (state) => state.output.some(out => out.includes("supersecret123"))
        }
      ]
    },
    {
      id: 2,
      title: "Soft Reset Rescue",
      description: "Safely undo a commit while keeping the changes",
      difficulty: "intermediate",
      timeLimit: 600,
      initialFiles: [
        { name: "app.js", content: "console.log('Hello World');", hasSecret: false },
        { name: "config.json", content: "{\n  \"debug\": true,\n  \"apiKey\": \"secret-key-123\"\n}", hasSecret: true }
      ],
      initialCommits: [
        { id: "1", message: "Initial setup", hash: "abc1234", files: ["app.js"], hasSecret: false, timestamp: Date.now() - 30000, isDeleted: false },
        { id: "2", message: "Add debug configuration", hash: "def5678", files: ["config.json"], hasSecret: true, timestamp: Date.now() - 20000, isDeleted: false },
        { id: "3", message: "Fix typo in app", hash: "ghi9012", files: ["app.js"], hasSecret: false, timestamp: Date.now() - 10000, isDeleted: false },
        { id: "4", message: "Add feature", hash: "jkl3456", files: ["app.js"], hasSecret: false, timestamp: Date.now(), isDeleted: false }
      ],
      learningObjectives: [
        "Understand soft reset vs hard reset",
        "Safely undo commits while preserving changes",
        "Verify file contents after reset"
      ],
      steps: [
        {
          id: 1,
          title: "Check Current State",
          description: "Examine the current commit and file status",
          instruction: "View the current commit history and check file contents",
          command: "git log --oneline",
          expectedState: "state_checked",
          hint: "Use git log to see the commit history",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("git log"))
        },
        {
          id: 2,
          title: "Perform Soft Reset",
          description: "Undo the last commit but keep the changes",
          instruction: "Use git reset --soft to undo the last commit",
          command: "git reset --soft HEAD~1",
          expectedState: "soft_reset_complete",
          hint: "HEAD~1 refers to the commit before the current one",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("git reset --soft"))
        },
        {
          id: 3,
          title: "Verify Changes",
          description: "Confirm that files still contain the changes",
          instruction: "Check that the files still exist with their content",
          command: "ls && cat app.js",
          expectedState: "changes_verified",
          hint: "The files should still exist with their content intact",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("ls")) && 
                          state.commandHistory.some(cmd => cmd.includes("cat"))
        }
      ]
    },
    {
      id: 3,
      title: "Hard Reset Cleanup",
      description: "Completely remove commits and their changes",
      difficulty: "advanced",
      timeLimit: 900,
      initialFiles: [
        { name: "main.py", content: "print('Hello World')", hasSecret: false },
        { name: "secrets.txt", content: "PASSWORD=my-secret-password\nAPI_KEY=12345", hasSecret: true },
        { name: "utils.py", content: "def helper():\n    pass", hasSecret: false }
      ],
      initialCommits: [
        { id: "1", message: "Initial commit", hash: "start123", files: ["main.py"], hasSecret: false, timestamp: Date.now() - 40000, isDeleted: false },
        { id: "2", message: "Add utils", hash: "utils456", files: ["utils.py"], hasSecret: false, timestamp: Date.now() - 30000, isDeleted: false },
        { id: "3", message: "Add secrets file", hash: "secret789", files: ["secrets.txt"], hasSecret: true, timestamp: Date.now() - 20000, isDeleted: false },
        { id: "4", message: "Update main", hash: "update012", files: ["main.py"], hasSecret: false, timestamp: Date.now() - 10000, isDeleted: false },
        { id: "5", message: "Final changes", hash: "final345", files: ["main.py"], hasSecret: false, timestamp: Date.now(), isDeleted: false }
      ],
      learningObjectives: [
        "Perform hard reset operations safely",
        "Understand permanent data removal",
        "Use reflog for recovery if needed"
      ],
      steps: [
        {
          id: 1,
          title: "Assess the Damage",
          description: "Identify which commits contain sensitive information",
          instruction: "Examine the commit history to find the problematic commit",
          command: "git log --oneline",
          expectedState: "damage_assessed",
          hint: "Look for commits that added files containing sensitive data",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("git log"))
        },
        {
          id: 2,
          title: "Hard Reset to Safe Point",
          description: "Reset to a commit before the sensitive data was added",
          instruction: "Use git reset --hard to remove the problematic commits",
          command: "git reset --hard utils456",
          expectedState: "hard_reset_complete",
          hint: "Find the hash of the commit before the secrets were added",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("git reset --hard"))
        },
        {
          id: 3,
          title: "Verify Cleanup",
          description: "Confirm that sensitive files are completely removed",
          instruction: "Check that secrets.txt no longer exists",
          command: "ls && git log --oneline",
          expectedState: "cleanup_verified",
          hint: "The secrets file should be gone and the commit history should be shorter",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("ls")) &&
                          !state.files.some(f => f.name === "secrets.txt")
        },
        {
          id: 4,
          title: "Check Reflog",
          description: "Verify that the deleted commits can still be found in reflog",
          instruction: "Use git reflog to see the reset operation",
          command: "git reflog",
          expectedState: "reflog_checked",
          hint: "Reflog shows all operations, even deleted commits",
          validation: (state) => state.commandHistory.some(cmd => cmd.includes("git reflog"))
        }
      ]
    }
  ]

  useEffect(() => {
    if (state.startTime && !state.isCompleted) {
      setTimer(setInterval(() => {
        setState(prev => ({
          ...prev,
          elapsedTime: Math.floor((Date.now() - prev.startTime!) / 1000)
        }))
      }, 1000))
    }

    return () => {
      if (timer) clearInterval(timer)
    }
  }, [state.startTime, state.isCompleted])

  const startChallenge = (challenge: Challenge) => {
    setState({
      currentChallenge: challenge,
      currentStep: 0,
      files: [...challenge.initialFiles],
      commits: [...challenge.initialCommits],
      commandHistory: [],
      isCompleted: false,
      startTime: Date.now(),
      elapsedTime: 0,
      hintsUsed: 0,
      score: 0,
      showHint: false,
      currentCommand: '',
      output: [],
      error: null
    })
    setActiveChallenge(challenge.id)
  }

  const executeCommand = (command: string) => {
    if (!state.currentChallenge) return

    const newCommandHistory = [...state.commandHistory, command]
    let newOutput = [...state.output]
    let newError: string | null = null
    let newFiles = [...state.files]
    let newCommits = [...state.commits]
    let newScore = state.score

    // Simulate Git command execution
    const cmd = command.trim().toLowerCase()
    
    if (cmd === 'git log' || cmd === 'git log --oneline') {
      newOutput.push('Commit history:')
      state.commits.forEach(commit => {
        if (!commit.isDeleted) {
          newOutput.push(`${commit.hash} ${commit.message}`)
        }
      })
      newScore += 10
    } else if (cmd.startsWith('git show')) {
      const hash = cmd.split(' ')[2]
      const commit = state.commits.find(c => c.hash === hash)
      if (commit) {
        newOutput.push(`Commit ${commit.hash}`)
        newOutput.push(`Author: Git Lab <git@lab.com>`)
        newOutput.push(`Date: ${new Date(commit.timestamp).toLocaleString()}`)
        newOutput.push(``)
        newOutput.push(`    ${commit.message}`)
        newOutput.push(``)
        commit.files.forEach(file => {
          const fileContent = state.files.find(f => f.name === file)
          if (fileContent) {
            newOutput.push(`diff --git a/${file} b/${file}`)
            newOutput.push(`new file mode 100644`)
            newOutput.push(`index 0000000..1234567`)
            newOutput.push(`--- /dev/null`)
            newOutput.push(`+++ b/${file}`)
            newOutput.push(`@@ -0,0 +1 @@`)
            fileContent.content.split('\n').forEach(line => {
              newOutput.push(`+${line}`)
            })
          }
        })
        newScore += 15
      } else {
        newError = `Commit ${hash} not found`
      }
    } else if (cmd === 'git reset --soft head~1' || cmd === 'git reset --soft head~1') {
      if (state.commits.length > 1) {
        const lastCommit = state.commits[state.commits.length - 1]
        newCommits = state.commits.map(commit => 
          commit.id === lastCommit.id ? { ...commit, isDeleted: true } : commit
        )
        newOutput.push('Commit undone but files preserved (soft reset)')
        newScore += 20
      } else {
        newError = 'No commits to reset'
      }
    } else if (cmd.startsWith('git reset --hard')) {
      const targetHash = cmd.split(' ')[3]
      if (targetHash) {
        const targetIndex = state.commits.findIndex(c => c.hash === targetHash)
        if (targetIndex !== -1) {
          // Remove commits after the target
          newCommits = state.commits.slice(0, targetIndex + 1)
          
          // Remove files that were added in deleted commits
          const validFiles = new Set<string>()
          newCommits.forEach(commit => {
            commit.files.forEach(file => validFiles.add(file))
          })
          newFiles = state.files.filter(file => validFiles.has(file.name))
          
          newOutput.push(`Hard reset to commit ${targetHash}`)
          newScore += 25
        } else {
          newError = `Commit ${targetHash} not found`
        }
      } else {
        newError = 'Please specify a target commit hash'
      }
    } else if (cmd === 'ls') {
      newOutput.push('Files in working directory:')
      state.files.forEach(file => {
        newOutput.push(file.name)
      })
      newScore += 5
    } else if (cmd.startsWith('cat ')) {
      const fileName = cmd.substring(4)
      const file = state.files.find(f => f.name === fileName)
      if (file) {
        newOutput.push(`Contents of ${fileName}:`)
        file.content.split('\n').forEach(line => {
          newOutput.push(line)
        })
        newScore += 10
      } else {
        newError = `File ${fileName} not found`
      }
    } else if (cmd === 'git reflog') {
      newOutput.push('Reflog history:')
      state.commits.forEach(commit => {
        newOutput.push(`${commit.hash} HEAD@{${commit.id}}: ${commit.isDeleted ? 'reset: moving to' : 'commit: ' + commit.message}`)
      })
      newScore += 15
    } else {
      newError = `Command not recognized: ${command}`
    }

    setState(prev => ({
      ...prev,
      commandHistory: newCommandHistory,
      output: newOutput,
      error: newError,
      files: newFiles,
      commits: newCommits,
      score: newScore,
      currentCommand: ''
    }))

    // Check if current step is completed
    const currentStep = state.currentChallenge?.steps[state.currentStep]
    if (currentStep && currentStep.validation({
      ...state,
      commandHistory: newCommandHistory,
      output: newOutput,
      files: newFiles,
      commits: newCommits
    })) {
      setTimeout(() => {
        nextStep()
      }, 1000)
    }
  }

  const nextStep = () => {
    if (!state.currentChallenge) return

    const nextStepIndex = state.currentStep + 1
    if (nextStepIndex >= state.currentChallenge.steps.length) {
      // Challenge completed
      setState(prev => ({
        ...prev,
        isCompleted: true,
        score: prev.score + 100 // Bonus for completion
      }))
      if (timer) clearInterval(timer)
    } else {
      setState(prev => ({
        ...prev,
        currentStep: nextStepIndex,
        showHint: false
      }))
    }
  }

  const useHint = () => {
    setState(prev => ({
      ...prev,
      hintsUsed: prev.hintsUsed + 1,
      showHint: true,
      score: Math.max(0, prev.score - 5) // Small penalty for using hint
    }))
  }

  const resetChallenge = () => {
    if (state.currentChallenge) {
      startChallenge(state.currentChallenge)
    }
  }

  const exitChallenge = () => {
    setState({
      currentChallenge: null,
      currentStep: 0,
      files: [],
      commits: [],
      commandHistory: [],
      isCompleted: false,
      startTime: null,
      elapsedTime: 0,
      hintsUsed: 0,
      score: 0,
      showHint: false,
      currentCommand: '',
      output: [],
      error: null
    })
    setActiveChallenge(null)
    if (timer) clearInterval(timer)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800'
      case 'intermediate': return 'bg-yellow-100 text-yellow-800'
      case 'advanced': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (state.currentChallenge) {
    const currentStep = state.currentChallenge.steps[state.currentStep]
    const progress = ((state.currentStep + 1) / state.currentChallenge.steps.length) * 100

    return (
      <div className="space-y-6">
        {/* Challenge Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  {state.currentChallenge.title}
                </CardTitle>
                <CardDescription>
                  {state.currentChallenge.description}
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={getDifficultyColor(state.currentChallenge.difficulty)}>
                  {state.currentChallenge.difficulty}
                </Badge>
                <Button variant="outline" size="sm" onClick={exitChallenge}>
                  <XCircle className="h-4 w-4 mr-2" />
                  Exit
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-500">{state.currentStep + 1}/{state.currentChallenge.steps.length}</div>
                <div className="text-sm text-slate-500">Steps</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-500">{state.score}</div>
                <div className="text-sm text-slate-500">Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-500">{formatTime(state.elapsedTime)}</div>
                <div className="text-sm text-slate-500">Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-500">{state.hintsUsed}</div>
                <div className="text-sm text-slate-500">Hints Used</div>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="w-full" />
              <div className="text-sm text-slate-500 mt-1">{Math.round(progress)}% Complete</div>
            </div>
          </CardContent>
        </Card>

        {/* Challenge Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Panel - Instructions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {state.currentStep + 1}
                </div>
                {currentStep.title}
              </CardTitle>
              <CardDescription>
                {currentStep.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Instruction:</h4>
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  {currentStep.instruction}
                </p>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Expected Command:</h4>
                <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-lg font-mono text-sm">
                  {currentStep.command || "No specific command required"}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Learning Objectives:</h4>
                <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                  {state.currentChallenge.learningObjectives.map((obj, index) => (
                    <li key={index}>{obj}</li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-2">
                <Button onClick={useHint} variant="outline" className="flex-1">
                  <Lightbulb className="h-4 w-4 mr-2" />
                  Use Hint (-5 points)
                </Button>
                <Button onClick={resetChallenge} variant="outline">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset
                </Button>
              </div>

              <AnimatePresence>
                {state.showHint && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                  >
                    <Alert>
                      <Lightbulb className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Hint:</strong> {currentStep.hint}
                      </AlertDescription>
                    </Alert>
                  </motion.div>
                )}
              </AnimatePresence>

              {state.error && (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Error:</strong> {state.error}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Right Panel - Terminal */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5" />
                Git Terminal
              </CardTitle>
              <CardDescription>
                Execute Git commands to complete the challenge
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* File System Status */}
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Current Files
                </h4>
                <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg text-sm">
                  {state.files.map(file => (
                    <div key={file.name} className="flex items-center gap-2">
                      <span className={file.hasSecret ? 'text-red-500' : 'text-green-500'}>
                        {file.hasSecret ? '🔴' : '🟢'}
                      </span>
                      {file.name}
                    </div>
                  ))}
                </div>
              </div>

              {/* Commit Status */}
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <GitCommit className="h-4 w-4" />
                  Current Commits
                </h4>
                <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg text-sm font-mono max-h-32 overflow-y-auto">
                  {state.commits.filter(c => !c.isDeleted).map(commit => (
                    <div key={commit.id} className="flex items-center gap-2">
                      <span className={commit.hasSecret ? 'text-red-500' : 'text-green-500'}>
                        {commit.hasSecret ? '⚠️' : '✓'}
                      </span>
                      <span>{commit.hash}</span>
                      <span>{commit.message}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Terminal Input */}
              <div>
                <h4 className="font-medium mb-2">Command Input</h4>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={state.currentCommand}
                    onChange={(e) => setState(prev => ({ ...prev, currentCommand: e.target.value }))}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && state.currentCommand.trim()) {
                        executeCommand(state.currentCommand)
                      }
                    }}
                    placeholder="Enter Git command..."
                    className="flex-1 px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <Button onClick={() => executeCommand(state.currentCommand)} disabled={!state.currentCommand.trim()}>
                    <Play className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Command Output */}
              <div>
                <h4 className="font-medium mb-2">Output</h4>
                <ScrollArea className="h-48 bg-slate-900 text-green-400 p-3 rounded-lg font-mono text-sm">
                  {state.output.map((line, index) => (
                    <div key={index}>{line}</div>
                  ))}
                  {state.output.length === 0 && (
                    <div className="text-slate-500">No output yet. Execute a command to see results.</div>
                  )}
                </ScrollArea>
              </div>

              {/* Command History */}
              <div>
                <h4 className="font-medium mb-2">Command History</h4>
                <ScrollArea className="h-24 bg-slate-50 dark:bg-slate-800 p-3 rounded-lg font-mono text-sm">
                  {state.commandHistory.map((cmd, index) => (
                    <div key={index} className="text-slate-600 dark:text-slate-300">
                      $ {cmd}
                    </div>
                  ))}
                  {state.commandHistory.length === 0 && (
                    <div className="text-slate-500">No commands executed yet.</div>
                  )}
                </ScrollArea>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Completion Modal */}
        <AnimatePresence>
          {state.isCompleted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            >
              <Card className="w-full max-w-md">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Trophy className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle>Challenge Completed!</CardTitle>
                  <CardDescription>
                    Congratulations! You've successfully completed the challenge.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-blue-500">{state.score}</div>
                      <div className="text-sm text-slate-500">Final Score</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-500">{formatTime(state.elapsedTime)}</div>
                      <div className="text-sm text-slate-500">Time Taken</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={resetChallenge} variant="outline" className="flex-1">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Try Again
                    </Button>
                    <Button onClick={exitChallenge} className="flex-1">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      Next Challenge
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
          Git Challenge Lab
        </h2>
        <p className="text-lg text-slate-600 dark:text-slate-300">
          Master Git operations through hands-on interactive challenges
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {challenges.map((challenge) => (
          <motion.div
            key={challenge.id}
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
          >
            <Card className={`cursor-pointer transition-all ${
              activeChallenge === challenge.id ? 'ring-2 ring-blue-500' : ''
            }`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    {challenge.title}
                  </CardTitle>
                  <Badge className={getDifficultyColor(challenge.difficulty)}>
                    {challenge.difficulty}
                  </Badge>
                </div>
                <CardDescription>
                  {challenge.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Learning Objectives:</h4>
                  <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                    {challenge.learningObjectives.slice(0, 3).map((obj, index) => (
                      <li key={index}>{obj}</li>
                    ))}
                    {challenge.learningObjectives.length > 3 && (
                      <li className="text-slate-400">+{challenge.learningObjectives.length - 3} more</li>
                    )}
                  </ul>
                </div>

                <div className="flex items-center justify-between text-sm text-slate-500">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {Math.floor((challenge.timeLimit || 0) / 60)}m
                  </div>
                  <div className="flex items-center gap-1">
                    <GitCommit className="h-4 w-4" />
                    {challenge.steps.length} steps
                  </div>
                </div>

                <Button 
                  onClick={() => startChallenge(challenge)}
                  className="w-full"
                  disabled={activeChallenge !== null}
                >
                  <Play className="h-4 w-4 mr-2" />
                  {activeChallenge === challenge.id ? 'In Progress' : 'Start Challenge'}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default GitChallengeLab