'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Input } from '@/components/ui/input'
import { Alert, AlertDescription } from '@/components/ui/alert'
import GitTerminalSimulator from '@/components/git-terminal-simulator'
import { 
  ArrowLeft, 
  Flag, 
  Eye, 
  EyeOff, 
  CheckCircle, 
  XCircle, 
  Hourglass,
  Trophy,
  Target,
  Shield,
  Search,
  Clock,
  Zap,
  GitBranch,
  Award,
  Terminal
} from 'lucide-react'

interface Challenge {
  id: string
  title: string
  category: 'forensic' | 'recovery' | 'security' | 'advanced' | 'intermediate'
  difficulty: 'easy' | 'medium' | 'hard' | 'expert'
  description: string
  points: number
  hints: string[]
  flag: string
  completed: boolean
  timeLimit?: number
  requirements?: string[]
  story?: string
}

const ChallengePage = () => {
  const params = useParams()
  const router = useRouter()
  const challengeId = params.id as string
  
  const [challenge, setChallenge] = useState<Challenge | null>(null)
  const [flagInput, setFlagInput] = useState('')
  const [showHint, setShowHint] = useState(false)
  const [currentHintIndex, setCurrentHintIndex] = useState(0)
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null)
  const [showSuccess, setShowSuccess] = useState(false)
  const [showFailure, setShowFailure] = useState(false)
  const [loading, setLoading] = useState(true)

  // Mock challenges data - in a real app, this would come from an API
  const challenges: Challenge[] = [
    {
      id: 'lost-commit',
      title: 'The Lost Commit',
      category: 'forensic',
      difficulty: 'medium',
      description: 'A critical commit containing the secret configuration was accidentally deleted. Use Git forensic tools to recover the lost commit and extract the flag.',
      points: 150,
      hints: [
        'Check git reflog for deleted commits',
        'Look for commits with sensitive information',
        'Use git show to examine commit contents'
      ],
      flag: 'FLAG{LOST_COMMIT_RECOVERED_2024}',
      completed: false,
      story: 'The development team accidentally deleted a commit containing crucial API keys. Your mission is to recover this commit before the system goes down.'
    },
    {
      id: 'secret-message',
      title: 'The Secret Message',
      category: 'forensic',
      difficulty: 'hard',
      description: 'A secret message is hidden within the commit history using steganography techniques. Find and decode the hidden flag.',
      points: 250,
      hints: [
        'Examine commit messages for patterns',
        'Look for unusual whitespace or characters',
        'Check file contents for hidden data'
      ],
      flag: 'FLAG{STEGANOGRAPHY_MASTER}',
      completed: false,
      story: 'A rogue developer hid a backdoor in the codebase using steganography. Find the hidden message before it\'s too late.'
    },
    {
      id: 'broken-repo',
      title: 'The Broken Repository',
      category: 'recovery',
      difficulty: 'medium',
      description: 'The repository is corrupted and won\'t function properly. Diagnose the issues and restore the repository to working order.',
      points: 200,
      hints: [
        'Check git status for corruption indicators',
        'Use git fsck to find broken objects',
        'Restore from backup if available'
      ],
      flag: 'FLAG{RECOVERY_MASTER_2024}',
      completed: false,
      story: 'A failed merge operation has left the repository in an unusable state. Fix the corruption and restore normal functionality.'
    },
    {
      id: 'detached-head',
      title: 'Detached Head Nightmare',
      category: 'recovery',
      difficulty: 'easy',
      description: 'You\'re in a detached HEAD state and need to find your way back to the main branch while preserving your work.',
      points: 100,
      hints: [
        'Use git status to understand your situation',
        'Create a new branch to save your work',
        'Merge back to the main branch'
      ],
      flag: 'FLAG{DETACHED_HEAD_SURVIVOR}',
      completed: false,
      story: 'You accidentally checked out a specific commit and now you\'re lost in Git history. Find your way back to safety.'
    },
    {
      id: 'api-key-leak',
      title: 'API Key Leak',
      category: 'security',
      difficulty: 'medium',
      description: 'Find the API key that was accidentally committed to the repository and identify the commit that introduced it.',
      points: 175,
      hints: [
        'Search for common API key patterns',
        'Use git log -p to examine commit changes',
        'Look for environment files or configuration'
      ],
      flag: 'FLAG{SECURITY_AUDITOR}',
      completed: false,
      story: 'An API key was accidentally pushed to the repository. Find it and determine which commit introduced the vulnerability.'
    },
    {
      id: 'malicious-commit',
      title: 'The Malicious Commit',
      category: 'security',
      difficulty: 'hard',
      description: 'A malicious commit introduced a backdoor into the codebase. Find the commit, identify the vulnerability, and extract the attacker\'s flag.',
      points: 300,
      hints: [
        'Look for unusual code patterns',
        'Check for obfuscated or suspicious code',
        'Examine commit author information'
      ],
      flag: 'FLAG{BACKDOOR_HUNTER}',
      completed: false,
      story: 'An attacker gained commit access and introduced a backdoor. Find the malicious code and prevent further damage.'
    },
    {
      id: 'rebase-maze',
      title: 'The Rebase Maze',
      category: 'advanced',
      difficulty: 'expert',
      description: 'Navigate a complex rebase scenario with multiple branches and conflicts to reach the target state.',
      points: 400,
      hints: [
        'Plan your rebase strategy carefully',
        'Resolve conflicts systematically',
        'Use git reflog to track your progress'
      ],
      flag: 'FLAG{REBASE_MASTER}',
      completed: false,
      timeLimit: 1800,
      story: 'You\'re trapped in a complex rebase scenario with multiple conflicting branches. Navigate the maze to reach the solution.'
    },
    {
      id: 'cherry-pick-puzzle',
      title: 'Cherry Pick Puzzle',
      category: 'advanced',
      difficulty: 'hard',
      description: 'Selectively apply specific commits from one branch to another to reconstruct the correct codebase state.',
      points: 350,
      hints: [
        'Identify which commits need to be cherry-picked',
        'Handle merge conflicts properly',
        'Maintain commit order and integrity'
      ],
      flag: 'FLAG{CHERRY_PICK_EXPERT}',
      completed: false,
      story: 'Important commits were made to the wrong branch. Carefully select and apply them to reconstruct the correct history.'
    },
    {
      id: 'time-traveler',
      title: 'The Time Traveler',
      category: 'advanced',
      difficulty: 'expert',
      description: 'Reconstruct the historical timeline of the repository by analyzing commit patterns and restoring lost history.',
      points: 450,
      hints: [
        'Use git log with various formatting options',
        'Analyze commit timestamps and patterns',
        'Reconstruct the timeline using reflog'
      ],
      flag: 'FLAG{TIME_TRAVELER}',
      completed: false,
      story: 'The repository history has been tampered with. Restore the correct timeline and uncover the truth.'
    },
    {
      id: 'imposter',
      title: 'The Imposter',
      category: 'forensic',
      difficulty: 'hard',
      description: 'An imposter has been making commits in the repository. Identify the suspicious commits and find the hidden flag.',
      points: 275,
      hints: [
        'Look for unusual commit patterns',
        'Check commit author information',
        'Analyze commit timestamps for anomalies'
      ],
      flag: 'FLAG{IMPOSTER_DETECTED}',
      completed: false,
      story: 'Someone has been making unauthorized commits. Find the imposter and expose their activities.'
    },
    {
      id: 'the-vault',
      title: 'The Vault',
      category: 'advanced',
      difficulty: 'expert',
      description: 'A multi-step challenge requiring you to solve several Git puzzles to unlock the final vault containing the ultimate flag.',
      points: 500,
      hints: [
        'This is a multi-step challenge',
        'Each step reveals part of the final solution',
        'Use all your Git skills to progress'
      ],
      flag: 'FLAG{VAULT_MASTER_2024}',
      completed: false,
      timeLimit: 3600,
      story: 'The ultimate Git challenge awaits. Solve multiple complex puzzles to unlock the vault and claim your prize.'
    },
    {
      id: 'branch-maze',
      title: 'Branch Analysis Maze',
      category: 'forensic',
      difficulty: 'medium',
      description: 'Navigate through a complex branch structure to identify the correct branch containing the hidden flag.',
      points: 180,
      hints: [
        'Use git branch -a to see all branches',
        'Look for branch names that seem unusual',
        'Check the commit history of suspicious branches'
      ],
      flag: 'FLAG{BRANCH_ANALYST}',
      completed: false,
      story: 'A developer created a maze of branches to hide important code. Navigate the branch structure to find the correct path.'
    },
    {
      id: 'ghost-branches',
      title: 'Ghost Branches',
      category: 'forensic',
      difficulty: 'hard',
      description: 'Find deleted branches that still exist in the repository\'s reflog and recover the hidden flag.',
      points: 220,
      hints: [
        'Check git reflog for branch operations',
        'Look for deleted branch references',
        'Use git fsck to find dangling commits'
      ],
      flag: 'FLAG{GHOST_HUNTER}',
      completed: false,
      story: 'Branches were deleted but their traces remain. Find the ghost branches and recover the secrets they hold.'
    },
    {
      id: 'merge-conflict-puzzle',
      title: 'Merge Conflict Puzzle',
      category: 'recovery',
      difficulty: 'medium',
      description: 'Resolve a complex merge conflict scenario where the correct solution reveals the hidden flag.',
      points: 190,
      hints: [
        'Analyze the conflict markers carefully',
        'Look for patterns in the conflicting code',
        'The flag might be hidden in the correct merge resolution'
      ],
      flag: 'FLAG{MERGE_MASTER}',
      completed: false,
      story: 'A failed merge left the repository in a conflicted state. Resolve the conflicts properly to uncover the hidden flag.'
    },
    {
      id: 'commit-jigsaw',
      title: 'Commit Jigsaw',
      category: 'recovery',
      difficulty: 'hard',
      description: 'Reconstruct the correct commit order from a scrambled history to reveal the hidden message.',
      points: 240,
      hints: [
        'Look at commit timestamps for clues',
        'Check commit dependencies and relationships',
        'Use git rebase -i to reorder commits'
      ],
      flag: 'FLAG{COMMIT_RECONSTRUCTOR}',
      completed: false,
      story: 'Someone scrambled the commit history to hide important information. Put the pieces back in the correct order.'
    },
    {
      id: 'bisect-hunt',
      title: 'Git Bisect Hunt',
      category: 'intermediate',
      difficulty: 'medium',
      description: 'Use git bisect to efficiently find the commit that introduced a specific bug and extract the hidden flag.',
      points: 160,
      hints: [
        'Start git bisect with good and bad commits',
        'Test each commit systematically',
        'The flag is hidden in the commit that introduced the bug'
      ],
      flag: 'FLAG{BISECT_EXPERT}',
      completed: false,
      story: 'A bug was introduced somewhere in the commit history. Use git bisect to find the exact commit and claim your reward.'
    },
    {
      id: 'stash-investigation',
      title: 'Stash Investigation',
      category: 'intermediate',
      difficulty: 'medium',
      description: 'Recover and analyze stashed changes that contain hidden clues to find the final flag.',
      points: 170,
      hints: [
        'Check git stash list for hidden stashes',
        'Examine stashed changes carefully',
        'Look for encoded messages in the stashed content'
      ],
      flag: 'FLAG{STASH_DETECTIVE}',
      completed: false,
      story: 'A developer stashed important changes and forgot about them. Recover the stashed work and find the hidden flag.'
    },
    {
      id: 'tag-treasure',
      title: 'Tag Treasure Hunt',
      category: 'intermediate',
      difficulty: 'easy',
      description: 'Find and decode hidden messages in Git tags to uncover the treasure flag.',
      points: 140,
      hints: [
        'List all tags including lightweight ones',
        'Check tag messages for hidden clues',
        'Some tags might contain encoded information'
      ],
      flag: 'FLAG{TAG_EXPLORER}',
      completed: false,
      story: 'Previous developers hid clues in Git tags. Follow the tag trail to find the hidden treasure.'
    },
    {
      id: 'patch-analysis',
      title: 'Patch Analysis',
      category: 'intermediate',
      difficulty: 'medium',
      description: 'Analyze patch files and apply them correctly to reveal the hidden flag in the resulting code.',
      points: 185,
      hints: [
        'Examine patch files for hidden patterns',
        'Apply patches in the correct order',
        'The flag appears after successful patch application'
      ],
      flag: 'FLAG{PATCH_ANALYST}',
      completed: false,
      story: 'Patch files contain the key to unlocking the repository. Apply them correctly to reveal the hidden flag.'
    }
  ]

  useEffect(() => {
    // Find the challenge by ID
    const foundChallenge = challenges.find(c => c.id === challengeId)
    setChallenge(foundChallenge || null)
    
    if (foundChallenge && foundChallenge.timeLimit) {
      setTimeRemaining(foundChallenge.timeLimit)
    }
    
    setLoading(false)
  }, [challengeId])

  const handleFlagSubmit = () => {
    if (!challenge || !flagInput) return

    if (flagInput.trim() === challenge.flag) {
      setShowSuccess(true)
      setTimeout(() => {
        setShowSuccess(false)
        // In a real app, you would update the challenge status in the backend
        router.push('/')
      }, 3000)
    } else {
      setShowFailure(true)
      setTimeout(() => setShowFailure(false), 2000)
    }
  }

  const getNextHint = () => {
    if (challenge && currentHintIndex < challenge.hints.length - 1) {
      setCurrentHintIndex(currentHintIndex + 1)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-500'
      case 'medium': return 'bg-yellow-500'
      case 'hard': return 'bg-orange-500'
      case 'expert': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'forensic': return <Search className="h-5 w-5" />
      case 'recovery': return <Clock className="h-5 w-5" />
      case 'security': return <Shield className="h-5 w-5" />
      case 'advanced': return <Zap className="h-5 w-5" />
      case 'intermediate': return <GitBranch className="h-5 w-5" />
      default: return <Target className="h-5 w-5" />
    }
  }

  // Timer effect
  useEffect(() => {
    if (timeRemaining !== null && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev && prev > 0) {
            return prev - 1
          }
          clearInterval(timer)
          return 0
        })
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [timeRemaining])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-slate-600 dark:text-slate-300">Loading challenge...</p>
        </div>
      </div>
    )
  }

  if (!challenge) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Challenge Not Found</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-slate-600 dark:text-slate-300 mb-4">
              The challenge you're looking for doesn't exist.
            </p>
            <Button onClick={() => router.push('/')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Challenges
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4">
      {/* Success/Failure Notifications */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-4 right-4 z-50"
          >
            <Alert className="bg-green-100 border-green-500 text-green-800">
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Challenge completed! +{challenge.points} points
              </AlertDescription>
            </Alert>
          </motion.div>
        )}
        {showFailure && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-4 right-4 z-50"
          >
            <Alert className="bg-red-100 border-red-500 text-red-800">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                Incorrect flag. Try again!
              </AlertDescription>
            </Alert>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          className="flex items-center gap-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Button 
            onClick={() => router.push('/')}
            variant="outline"
            size="sm"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Challenges
          </Button>
          
          <div className="flex items-center gap-2">
            {getCategoryIcon(challenge.category)}
            <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
              {challenge.title}
            </h1>
          </div>
        </motion.div>

        {/* Challenge Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Badge className={getDifficultyColor(challenge.difficulty)}>
                    {challenge.difficulty}
                  </Badge>
                  <Badge variant="outline">
                    {challenge.category}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Award className="h-4 w-4 text-blue-500" />
                    <span className="font-semibold">{challenge.points} pts</span>
                  </div>
                </div>
                {challenge.timeLimit && (
                  <div className="flex items-center gap-2 text-orange-600 dark:text-orange-400">
                    <Hourglass className="h-4 w-4" />
                    <span className="font-semibold">
                      {Math.floor(timeRemaining! / 60)}:{(timeRemaining! % 60).toString().padStart(2, '0')}
                    </span>
                  </div>
                )}
              </div>
              <CardTitle className="text-xl">Challenge Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {challenge.story && (
                <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  <h3 className="font-semibold mb-2 text-slate-800 dark:text-slate-200">Story</h3>
                  <p className="text-slate-600 dark:text-slate-300">
                    {challenge.story}
                  </p>
                </div>
              )}
              
              <div>
                <h3 className="font-semibold mb-2 text-slate-800 dark:text-slate-200">Description</h3>
                <p className="text-slate-600 dark:text-slate-300">
                  {challenge.description}
                </p>
              </div>

              {challenge.requirements && (
                <div>
                  <h3 className="font-semibold mb-2 text-slate-800 dark:text-slate-200">Requirements</h3>
                  <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 space-y-1">
                    {challenge.requirements.map((req, index) => (
                      <li key={index}>{req}</li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Challenge Workspace */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5" />
                Challenge Workspace
              </CardTitle>
              <CardDescription>
                Use Git commands to solve the challenge. Type 'help' for available commands.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Git Terminal */}
              {gitEnvironment && (
                <GitTerminal
                  onCommandExecute={handleGitCommand}
                  challengeId={challengeId}
                  welcomeMessage={`Git Terminal - ${challenge?.title || 'Challenge'}\nType 'help' to see available commands`}
                />
              )}

              {/* Hints Section */}
              {showHint && (
                <div className="p-4 bg-blue-100 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-semibold mb-2 text-blue-800 dark:text-blue-200">Hint</h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    {challenge.hints[currentHintIndex]}
                  </p>
                  {currentHintIndex < challenge.hints.length - 1 && (
                    <Button 
                      onClick={getNextHint} 
                      variant="outline" 
                      size="sm" 
                      className="mt-2"
                    >
                      Next Hint
                    </Button>
                  )}
                </div>
              )}

              {/* Flag Submission */}
              <div className="space-y-4">
                <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  <h4 className="font-semibold mb-2 text-slate-800 dark:text-slate-200">Submit Flag</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-300 mb-3">
                    Once you've solved the challenge using Git commands, enter the flag here.
                  </p>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter flag here..."
                      value={flagInput}
                      onChange={(e) => setFlagInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleFlagSubmit()}
                      className="flex-1"
                    />
                    <Button onClick={handleFlagSubmit}>
                      Submit
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={() => setShowHint(!showHint)} 
                    variant="outline" 
                    className="flex-1"
                  >
                    {showHint ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
                    {showHint ? 'Hide Hint' : 'Show Hint'}
                  </Button>
                  <Button 
                    onClick={() => router.push('/')}
                    variant="outline"
                  >
                    Exit Challenge
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

export default ChallengePage