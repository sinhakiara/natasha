'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  BookOpen, 
  MessageCircle, 
  Lightbulb, 
  Star, 
  Zap,
  Shield,
  Trophy,
  ArrowRight,
  Sparkles
} from 'lucide-react'

interface GitGuideAvatarProps {
  currentStep: number
  onTipRequest: () => void
}

const GitGuideAvatar = ({ currentStep, onTipRequest }: GitGuideAvatarProps) => {
  const [isHovered, setIsHovered] = useState(false)
  const [showMessage, setShowMessage] = useState(false)
  const [currentTip, setCurrentTip] = useState(0)
  const [isSpeaking, setIsSpeaking] = useState(false)

  const tips = [
    "🎯 Remember: Git is your time machine! Use it wisely to travel through your code history.",
    "🔍 Always check `git status` before making any changes to understand your current state.",
    "💡 Soft reset keeps your changes but removes the commit - perfect for fixing commit messages!",
    "⚠️ Hard reset is permanent! Use it only when you're absolutely sure.",
    "🔑 Reflog is your safety net - it can recover commits you thought were lost forever.",
    "📚 Practice makes perfect! Try each operation in this safe environment first.",
    "🛡️ Never commit sensitive data like API keys or passwords to version control.",
    "🎉 Mastering Git rollback operations will make you a more confident developer!"
  ]

  const lessons = [
    {
      icon: <BookOpen className="h-5 w-5" />,
      title: "Learn the Basics",
      description: "Understand commits, hashes, and Git history",
      completed: true
    },
    {
      icon: <Shield className="h-5 w-5" />,
      title: "Safe Operations",
      description: "Master soft reset and safe Git practices",
      completed: currentStep >= 1
    },
    {
      icon: <Zap className="h-5 w-5" />,
      title: "Advanced Techniques",
      description: "Learn hard reset and reflog recovery",
      completed: currentStep >= 2
    },
    {
      icon: <Trophy className="h-5 w-5" />,
      title: "Git Mastery",
      description: "Complete all challenges and become a Git expert",
      completed: currentStep >= 3
    }
  ]

  useEffect(() => {
    const tipInterval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % tips.length)
    }, 5000)

    return () => clearInterval(tipInterval)
  }, [])

  const avatarVariants = {
    idle: { 
      scale: 1,
      rotate: 0,
    },
    hover: { 
      scale: 1.02,
      rotate: [0, -3, 3, 0],
      transition: { duration: 0.5 }
    },
    speaking: {
      scale: [1, 1.01, 1],
      transition: { duration: 0.5, repeat: Infinity }
    }
  }

  const messageVariants = {
    hidden: { 
      opacity: 0, 
      scale: 0.8,
      y: 10
    },
    visible: { 
      opacity: 1, 
      scale: 1,
      y: 0,
      transition: { duration: 0.3 }
    },
    exit: { 
      opacity: 0, 
      scale: 0.8,
      y: 10
    }
  }

  return (
    <Card className="relative overflow-hidden">
      {/* Animated background */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5"
        animate={{
          background: [
            'linear-gradient(45deg, rgba(59, 130, 246, 0.05), rgba(147, 51, 234, 0.05))',
            'linear-gradient(45deg, rgba(147, 51, 234, 0.05), rgba(236, 72, 153, 0.05))',
            'linear-gradient(45deg, rgba(236, 72, 153, 0.05), rgba(59, 130, 246, 0.05))'
          ]
        }}
        transition={{ duration: 10, repeat: Infinity }}
      />
      
      <CardHeader className="relative z-10">
        <CardTitle className="flex items-center gap-2">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          >
            <Sparkles className="h-5 w-5 text-yellow-500" />
          </motion.div>
          Your Git Guide
        </CardTitle>
      </CardHeader>
      
      <CardContent className="relative z-10 space-y-6">
        {/* Avatar */}
        <motion.div
          className="flex flex-col items-center space-y-4"
          variants={avatarVariants}
          animate={isSpeaking ? "speaking" : (isHovered ? "hover" : "idle")}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <motion.div
            className="relative"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Avatar className="w-24 h-24 ring-4 ring-blue-500/20">
              <AvatarImage src="/api/placeholder/96/96" alt="Git Guide" />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white text-xl font-bold">
                GG
              </AvatarFallback>
            </Avatar>
            
            {/* Floating elements */}
            <motion.div
              className="absolute -top-2 -right-2 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center"
              animate={{ 
                y: [0, -5, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Star className="h-3 w-3 text-white" />
            </motion.div>
            
            <motion.div
              className="absolute -bottom-2 -left-2 w-6 h-6 bg-green-400 rounded-full flex items-center justify-center"
              animate={{ 
                y: [0, 5, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ duration: 2, repeat: Infinity, delay: 1 }}
            >
              <Zap className="h-3 w-3 text-white" />
            </motion.div>
          </motion.div>
          
          <div className="text-center">
            <h3 className="font-semibold text-lg">Git Guru</h3>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Level {Math.floor(currentStep) + 1} Guide
            </p>
          </div>
        </motion.div>
        
        {/* Interactive tip */}
        <div className="space-y-3">
          <Button
            onClick={() => {
              setShowMessage(true)
              setIsSpeaking(true)
              setTimeout(() => {
                setIsSpeaking(false)
                setTimeout(() => setShowMessage(false), 3000)
              }, 2000)
            }}
            className="w-full relative overflow-hidden"
            variant="outline"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10"
              animate={{ x: ['-100%', '100%'] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <Lightbulb className="h-4 w-4 mr-2" />
            Get Tip
          </Button>
          
          <AnimatePresence>
            {showMessage && (
              <motion.div
                variants={messageVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg"
              >
                <div className="flex items-start gap-2">
                  <MessageCircle className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    {tips[currentTip]}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {/* Learning progress */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm flex items-center gap-2">
            <Trophy className="h-4 w-4" />
            Learning Path
          </h4>
          
          <div className="space-y-2">
            {lessons.map((lesson, index) => (
              <motion.div
                key={index}
                className={`flex items-center gap-3 p-2 rounded-lg transition-colors ${
                  lesson.completed 
                    ? 'bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800' 
                    : 'bg-slate-50 dark:bg-slate-800'
                }`}
                whileHover={{ scale: 1.02 }}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <motion.div
                  className={`p-1 rounded-lg ${
                    lesson.completed 
                      ? 'bg-green-500 text-white' 
                      : 'bg-slate-300 dark:bg-slate-600 text-slate-500'
                  }`}
                  animate={lesson.completed ? { 
                    rotate: [0, 360], 
                    scale: [1, 1.1, 1] 
                  } : {}}
                  transition={{ duration: 0.5 }}
                >
                  {lesson.icon}
                </motion.div>
                
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium ${
                    lesson.completed 
                      ? 'text-green-700 dark:text-green-300' 
                      : 'text-slate-700 dark:text-slate-300'
                  }`}>
                    {lesson.title}
                  </p>
                  <p className="text-xs text-slate-500 truncate">
                    {lesson.description}
                  </p>
                </div>
                
                {lesson.completed ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Complete
                    </Badge>
                  </motion.div>
                ) : (
                  <ArrowRight className="h-4 w-4 text-slate-400" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200 dark:border-slate-700">
          <div className="text-center p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <div className="text-lg font-bold text-blue-500">{currentStep + 1}</div>
            <div className="text-xs text-slate-500">Current Level</div>
          </div>
          <div className="text-center p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <div className="text-lg font-bold text-green-500">{tips.length}</div>
            <div className="text-xs text-slate-500">Tips Available</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default GitGuideAvatar