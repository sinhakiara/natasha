'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { 
  CheckCircle, 
  AlertCircle, 
  Trophy, 
  Target, 
  Play, 
  RotateCcw,
  Lightbulb,
  Terminal,
  FileText,
  GitBranch,
  Eye,
  Trash2,
  Zap,
  ArrowRight,
  ArrowLeft,
  XCircle,
  Clock,
  Sparkles,
  BookOpen,
  User,
  Award,
  TrendingUp,
  ChevronRight,
  ChevronDown,
  Plus,
  Minus,
  Maximize2,
  Settings,
  Shield,
  Wrench,
  Lock,
  GraduationCap,
  X,
  Home,
  Info,
  ThumbsUp,
  Star
} from 'lucide-react'

interface SimpleFile {
  name: string
  content: string
  hasSecret: boolean
  status: 'normal' | 'modified'
}

interface SimpleCommit {
  id: string
  message: string
  hash: string
  files: string[]
  hasSecret: boolean
  timestamp: number
  isDeleted: boolean
}

interface SimpleStep {
  id: number
  title: string
  description: string
  instruction: string
  command: string
  hint: string
  successMessage: string
}

interface SimpleChallenge {
  id: number
  title: string
  description: string
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  timeLimit: number
  steps: SimpleStep[]
  initialFiles: SimpleFile[]
  initialCommits: SimpleCommit[]
  whatYoullLearn: string[]
}

interface SimpleLabState {
  currentChallenge: SimpleChallenge | null
  currentStep: number
  files: SimpleFile[]
  commits: SimpleCommit[]
  commandHistory: string[]
  isCompleted: boolean
  startTime: number | null
  elapsedTime: number
  hintsUsed: number
  score: number
  showHint: boolean
  currentCommand: string
  output: string[]
  error: string | null
  showSuccess: boolean
  completedChallenges: number[]
  userLevel: number
}

const GitSimpleLab = () => {
  const [state, setState] = useState<SimpleLabState>({
    currentChallenge: null,
    currentStep: 0,
    files: [],
    commits: [],
    commandHistory: [],
    isCompleted: false,
    startTime: null,
    elapsedTime: 0,
    hintsUsed: 0,
    score: 0,
    showHint: false,
    currentCommand: '',
    output: [],
    error: null,
    showSuccess: false,
    completedChallenges: [],
    userLevel: 1
  })

  const [activeChallenge, setActiveChallenge] = useState<number | null>(null)
  const [timer, setTimer] = useState<NodeJS.Timeout | null>(null)
  const terminalRef = useRef<HTMLDivElement>(null)

  const challenges: SimpleChallenge[] = [
    {
      id: 1,
      title: "Find the Secret",
      description: "Learn to inspect Git commits and find sensitive information",
      difficulty: "beginner",
      timeLimit: 300,
      initialFiles: [
        { name: "README.md", content: "# My Project\n\nThis is a simple project.", hasSecret: false, status: "normal" },
        { name: "config.py", content: "# Configuration\nAPI_KEY = \"secret123\"\nDEBUG = True", hasSecret: true, status: "modified" },
        { name: "app.py", content: "print('Hello World')", hasSecret: false, status: "normal" }
      ],
      initialCommits: [
        { id: "1", message: "Initial commit", hash: "a1b2c3d", files: ["README.md"], hasSecret: false, timestamp: Date.now() - 60000, isDeleted: false },
        { id: "2", message: "Add config", hash: "e4f5g6h", files: ["config.py"], hasSecret: true, timestamp: Date.now() - 30000, isDeleted: false },
        { id: "3", message: "Add app", hash: "i7j8k9l", files: ["app.py"], hasSecret: false, timestamp: Date.now() - 15000, isDeleted: false }
      ],
      whatYoullLearn: [
        "View Git commit history",
        "Inspect individual commits",
        "Identify sensitive data in commits"
      ],
      steps: [
        {
          id: 1,
          title: "View Commit History",
          description: "First, let's see all the commits in your project",
          instruction: "Type 'git log --oneline' to see a simple list of commits",
          command: "git log --oneline",
          hint: "Type exactly: git log --oneline",
          successMessage: "Great! You can see all your commits. Notice that each commit has a unique hash and message."
        },
        {
          id: 2,
          title: "Inspect the Config Commit",
          description: "Now let's look at the commit that added the config file",
          instruction: "Type 'git show e4f5g6h' to inspect the commit with the config",
          command: "git show e4f5g6h",
          hint: "Use the hash from the config commit: e4f5g6h",
          successMessage: "Excellent! You can see the contents of the config.py file. Notice the API_KEY that was added."
        },
        {
          id: 3,
          title: "Find the Secret",
          description: "Look for the sensitive information in the commit",
          instruction: "The secret is in the output above. Can you spot it?",
          command: "",
          hint: "Look for 'secret123' in the commit output",
          successMessage: "Perfect! You found the secret API key. This is why it's dangerous to commit sensitive information!"
        }
      ]
    },
    {
      id: 2,
      title: "Soft Reset Practice",
      description: "Learn how to safely undo commits while keeping your changes",
      difficulty: "intermediate",
      timeLimit: 600,
      initialFiles: [
        { name: "index.js", content: "console.log('Hello');", hasSecret: false, status: "normal" },
        { name: "config.json", content: "{\n  \"debug\": true\n}", hasSecret: false, status: "modified" },
        { name: "utils.js", content: "function help() { return 'help'; }", hasSecret: false, status: "normal" }
      ],
      initialCommits: [
        { id: "1", message: "Initial setup", hash: "abc1234", files: ["index.js"], hasSecret: false, timestamp: Date.now() - 90000, isDeleted: false },
        { id: "2", message: "Add utils", hash: "def5678", files: ["utils.js"], hasSecret: false, timestamp: Date.now() - 60000, isDeleted: false },
        { id: "3", message: "Add config", hash: "ghi9012", files: ["config.json"], hasSecret: false, timestamp: Date.now() - 30000, isDeleted: false },
        { id: "4", message: "Update index", hash: "jkl3456", files: ["index.js"], hasSecret: false, timestamp: Date.now() - 15000, isDeleted: false }
      ],
      whatYoullLearn: [
        "Safely undo commits",
        "Keep your changes in working directory",
        "Understand soft vs hard reset"
      ],
      steps: [
        {
          id: 1,
          title: "Check Current State",
          description: "Let's see what commits we have right now",
          instruction: "Type 'git log --oneline' to see all commits",
          command: "git log --oneline",
          hint: "Type: git log --oneline",
          successMessage: "Good! You can see you have 4 commits. The most recent is 'Update index'."
        },
        {
          id: 2,
          title: "Perform Soft Reset",
          description: "Now we'll undo the last commit but keep the changes",
          instruction: "Type 'git reset --soft HEAD~1' to undo the last commit",
          command: "git reset --soft HEAD~1",
          hint: "Type exactly: git reset --soft HEAD~1",
          successMessage: "Excellent! You've undone the last commit but your files are still there. This is the power of soft reset!"
        },
        {
          id: 3,
          title: "Verify Changes",
          description: "Let's check that your files are still there",
          instruction: "Type 'ls' to see your files",
          command: "ls",
          hint: "Type: ls",
          successMessage: "Perfect! All your files are still there. Soft reset keeps your changes but removes the commit."
        }
      ]
    },
    {
      id: 3,
      title: "Hard Reset Cleanup",
      description: "Learn how to completely remove commits and their changes",
      difficulty: "advanced",
      timeLimit: 900,
      initialFiles: [
        { name: "main.py", content: "print('Hello')", hasSecret: false, status: "normal" },
        { name: "secrets.txt", content: "PASSWORD=my-secret", hasSecret: true, status: "modified" },
        { name: "utils.py", content: "def helper(): pass", hasSecret: false, status: "normal" }
      ],
      initialCommits: [
        { id: "1", message: "Initial commit", hash: "start123", files: ["main.py"], hasSecret: false, timestamp: Date.now() - 120000, isDeleted: false },
        { id: "2", message: "Add utils", hash: "utils456", files: ["utils.py"], hasSecret: false, timestamp: Date.now() - 90000, isDeleted: false },
        { id: "3", message: "Add secrets", hash: "secret789", files: ["secrets.txt"], hasSecret: true, timestamp: Date.now() - 60000, isDeleted: false },
        { id: "4", message: "Update main", hash: "update012", files: ["main.py"], hasSecret: false, timestamp: Date.now() - 30000, isDeleted: false }
      ],
      whatYoullLearn: [
        "Completely remove commits",
        "Remove files from working directory",
        "Understand when to use hard reset"
      ],
      steps: [
        {
          id: 1,
          title: "Assess the Situation",
          description: "Let's see our current commit history",
          instruction: "Type 'git log --oneline' to see all commits",
          command: "git log --oneline",
          hint: "Type: git log --oneline",
          successMessage: "You can see you have 4 commits, including one with secrets that needs to be removed."
        },
        {
          id: 2,
          title: "Hard Reset to Safe Point",
          description: "We'll reset to before the secrets were added",
          instruction: "Type 'git reset --hard utils456' to remove the secrets commit",
          command: "git reset --hard utils456",
          hint: "Type: git reset --hard utils456",
          successMessage: "Great! You've performed a hard reset. The secrets commit and its files are completely gone."
        },
        {
          id: 3,
          title: "Verify Cleanup",
          description: "Let's make sure the secrets are gone",
          instruction: "Type 'ls' to see what files remain",
          command: "ls",
          hint: "Type: ls",
          successMessage: "Perfect! The secrets.txt file is gone. Hard reset completely removes both commits and files."
        }
      ]
    }
  ]

  useEffect(() => {
    if (state.startTime && !state.isCompleted) {
      setTimer(setInterval(() => {
        setState(prev => ({
          ...prev,
          elapsedTime: Math.floor((Date.now() - prev.startTime!) / 1000)
        }))
      }, 1000))
    }

    return () => {
      if (timer) clearInterval(timer)
    }
  }, [state.startTime, state.isCompleted])

  useEffect(() => {
    // Auto-scroll terminal to bottom
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight
    }
  }, [state.output, state.commandHistory])

  const startChallenge = (challenge: SimpleChallenge) => {
    setState(prev => ({
      ...prev,
      currentChallenge: challenge,
      currentStep: 0,
      files: [...challenge.initialFiles],
      commits: [...challenge.initialCommits],
      commandHistory: [],
      isCompleted: false,
      startTime: Date.now(),
      elapsedTime: 0,
      hintsUsed: 0,
      score: 0,
      showHint: false,
      currentCommand: '',
      output: [],
      error: null,
      showSuccess: false
    }))
    setActiveChallenge(challenge.id)
  }

  const executeCommand = (command: string) => {
    if (!state.currentChallenge) return

    const newCommandHistory = [...state.commandHistory, command]
    let newOutput = [...state.output]
    let newError: string | null = null
    let newFiles = [...state.files]
    let newCommits = [...state.commits]
    let newScore = state.score

    // Simulate Git command execution
    const cmd = command.trim().toLowerCase()
    
    if (cmd === 'git log' || cmd === 'git log --oneline') {
      newOutput.push('Commit history:')
      state.commits.forEach(commit => {
        if (!commit.isDeleted) {
          newOutput.push(`${commit.hash} ${commit.message}`)
        }
      })
      newScore += 10
    } else if (cmd.startsWith('git show')) {
      const hash = cmd.split(' ')[2]
      const commit = state.commits.find(c => c.hash === hash)
      if (commit) {
        newOutput.push(`Commit ${commit.hash}`)
        newOutput.push(`Author: You <you@example.com>`)
        newOutput.push(`Date: ${new Date(commit.timestamp).toLocaleString()}`)
        newOutput.push(``)
        newOutput.push(`    ${commit.message}`)
        newOutput.push(``)
        commit.files.forEach(file => {
          const fileContent = state.files.find(f => f.name === file)
          if (fileContent) {
            newOutput.push(`diff --git a/${file} b/${file}`)
            newOutput.push(`new file mode 100644`)
            newOutput.push(`index 0000000..1234567`)
            newOutput.push(`--- /dev/null`)
            newOutput.push(`+++ b/${file}`)
            newOutput.push(`@@ -0,0 +1 @@`)
            fileContent.content.split('\n').forEach(line => {
              newOutput.push(`+${line}`)
            })
          }
        })
        newScore += 15
      } else {
        newError = `Commit '${hash}' not found`
      }
    } else if (cmd === 'git reset --soft head~1') {
      if (state.commits.length > 1) {
        const lastCommit = state.commits[state.commits.length - 1]
        newCommits = state.commits.map(commit => 
          commit.id === lastCommit.id ? { ...commit, isDeleted: true } : commit
        )
        newOutput.push('Commit undone but files preserved (soft reset)')
        newScore += 20
      } else {
        newError = 'No commits to reset'
      }
    } else if (cmd.startsWith('git reset --hard')) {
      const targetHash = cmd.split(' ')[3]
      if (targetHash) {
        const targetIndex = state.commits.findIndex(c => c.hash === targetHash)
        if (targetIndex !== -1) {
          // Remove commits after the target
          newCommits = state.commits.slice(0, targetIndex + 1)
          
          // Remove files that were added in deleted commits
          const validFiles = new Set<string>()
          newCommits.forEach(commit => {
            commit.files.forEach(file => validFiles.add(file))
          })
          newFiles = state.files.filter(file => validFiles.has(file.name))
          
          newOutput.push(`HEAD is now at ${targetHash}`)
          newScore += 25
        } else {
          newError = `Commit '${targetHash}' not found`
        }
      } else {
        newError = 'Please specify a target commit'
      }
    } else if (cmd === 'ls') {
      newOutput.push('Files:')
      state.files.forEach(file => {
        newOutput.push(`  ${file.name}`)
      })
      newScore += 5
    } else if (cmd.startsWith('cat ')) {
      const fileName = cmd.substring(4)
      const file = state.files.find(f => f.name === fileName)
      if (file) {
        newOutput.push(`Contents of ${fileName}:`)
        file.content.split('\n').forEach(line => {
          newOutput.push(line)
        })
        newScore += 10
      } else {
        newError = `File '${fileName}' not found`
      }
    } else if (cmd === 'clear') {
      newOutput = []
    } else if (cmd === 'help') {
      newOutput.push('Available commands:')
      newOutput.push('  git log --oneline  - Show commit history')
      newOutput.push('  git show <hash>    - Show commit details')
      newOutput.push('  git reset --soft HEAD~1  - Soft reset')
      newOutput.push('  git reset --hard <hash>  - Hard reset')
      newOutput.push('  ls                 - List files')
      newOutput.push('  cat <file>         - Show file contents')
      newOutput.push('  clear              - Clear terminal')
      newOutput.push('  help               - Show this help')
    } else {
      newError = `Command not found: ${command.split(' ')[0]}. Type 'help' for available commands.`
    }

    setState(prev => ({
      ...prev,
      commandHistory: newCommandHistory,
      output: newOutput,
      error: newError,
      files: newFiles,
      commits: newCommits,
      score: newScore,
      currentCommand: '',
      showHint: false
    }))

    // Check if current step is completed
    const currentStep = state.currentChallenge?.steps[state.currentStep]
    if (currentStep && cmd === currentStep.command) {
      setTimeout(() => {
        setState(prev => ({
          ...prev,
          showSuccess: true
        }))
        
        setTimeout(() => {
          nextStep()
        }, 3000)
      }, 1000)
    }
  }

  const nextStep = () => {
    if (!state.currentChallenge) return

    const nextStepIndex = state.currentStep + 1
    if (nextStepIndex >= state.currentChallenge.steps.length) {
      // Challenge completed
      const newCompletedChallenges = [...state.completedChallenges, state.currentChallenge.id]
      const newUserLevel = Math.floor(newCompletedChallenges.length / 1) + 1 // Level up after each challenge
      
      setState(prev => ({
        ...prev,
        isCompleted: true,
        showSuccess: false,
        completedChallenges: newCompletedChallenges,
        userLevel: newUserLevel
      }))
      
      if (timer) clearInterval(timer)
    } else {
      setState(prev => ({
        ...prev,
        currentStep: nextStepIndex,
        showSuccess: false,
        showHint: false
      }))
    }
  }

  const useHint = () => {
    setState(prev => ({
      ...prev,
      hintsUsed: prev.hintsUsed + 1,
      showHint: true,
      score: Math.max(0, prev.score - 5)
    }))
  }

  const resetChallenge = () => {
    if (state.currentChallenge) {
      startChallenge(state.currentChallenge)
    }
  }

  const exitChallenge = () => {
    setState(prev => ({
      ...prev,
      currentChallenge: null,
      currentStep: 0,
      files: [],
      commits: [],
      commandHistory: [],
      isCompleted: false,
      startTime: null,
      elapsedTime: 0,
      hintsUsed: 0,
      score: 0,
      showHint: false,
      currentCommand: '',
      output: [],
      error: null,
      showSuccess: false
    }))
    setActiveChallenge(null)
    if (timer) clearInterval(timer)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800'
      case 'intermediate': return 'bg-yellow-100 text-yellow-800'
      case 'advanced': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (state.currentChallenge) {
    const currentStep = state.currentChallenge.steps[state.currentStep]
    const progress = ((state.currentStep + 1) / state.currentChallenge.steps.length) * 100

    return (
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Challenge Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  {state.currentChallenge.title}
                </CardTitle>
                <CardDescription>
                  {state.currentChallenge.description}
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={getDifficultyColor(state.currentChallenge.difficulty)}>
                  {state.currentChallenge.difficulty}
                </Badge>
                <Button variant="outline" size="sm" onClick={exitChallenge}>
                  <X className="h-4 w-4 mr-2" />
                  Exit
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-xl font-bold text-blue-500">{state.currentStep + 1}/{state.currentChallenge.steps.length}</div>
                <div className="text-sm text-slate-500">Step</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-green-500">{state.score}</div>
                <div className="text-sm text-slate-500">Score</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-yellow-500">{formatTime(state.elapsedTime)}</div>
                <div className="text-sm text-slate-500">Time</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-purple-500">{state.hintsUsed}</div>
                <div className="text-sm text-slate-500">Hints</div>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="w-full" />
              <div className="text-sm text-slate-500 mt-1">{Math.round(progress)}% Complete</div>
            </div>
          </CardContent>
        </Card>

        {/* Success Message */}
        <AnimatePresence>
          {state.showSuccess && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <AlertDescription className="text-green-700">
                  <strong>Step Complete!</strong> {currentStep.successMessage}
                </AlertDescription>
              </Alert>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Panel - Instructions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {state.currentStep + 1}
                </div>
                {currentStep.title}
              </CardTitle>
              <CardDescription>
                {currentStep.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">What to do:</h4>
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  {currentStep.instruction}
                </p>
              </div>

              <div>
                <h4 className="font-medium mb-2">Command to type:</h4>
                <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-lg font-mono text-sm">
                  {currentStep.command || "No command needed"}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">You'll learn:</h4>
                <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                  {state.currentChallenge.whatYoullLearn.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="flex gap-2">
                <Button onClick={useHint} variant="outline" className="flex-1">
                  <Lightbulb className="h-4 w-4 mr-2" />
                  Need Hint?
                </Button>
                <Button onClick={resetChallenge} variant="outline">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Restart
                </Button>
              </div>

              <AnimatePresence>
                {state.showHint && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                  >
                    <Alert>
                      <Lightbulb className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Hint:</strong> {currentStep.hint}
                      </AlertDescription>
                    </Alert>
                  </motion.div>
                )}
              </AnimatePresence>

              {state.error && (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Error:</strong> {state.error}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Right Panel - Terminal */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5" />
                Git Terminal
              </CardTitle>
              <CardDescription>
                Type the command exactly as shown and press Enter
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Current Files */}
              <div>
                <h4 className="font-medium mb-2">Current Files:</h4>
                <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg text-sm">
                  {state.files.map(file => (
                    <div key={file.name} className="flex items-center gap-2">
                      <span className={file.hasSecret ? 'text-red-500' : 'text-green-500'}>
                        {file.hasSecret ? '🔴' : '🟢'}
                      </span>
                      {file.name}
                    </div>
                  ))}
                </div>
              </div>

              {/* Command Input */}
              <div>
                <h4 className="font-medium mb-2">Type your command:</h4>
                <div className="flex gap-2">
                  <span className="text-green-500 font-mono">$</span>
                  <input
                    type="text"
                    value={state.currentCommand}
                    onChange={(e) => setState(prev => ({ ...prev, currentCommand: e.target.value }))}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && state.currentCommand.trim()) {
                        executeCommand(state.currentCommand)
                      }
                    }}
                    placeholder="Type Git command here..."
                    className="flex-1 px-3 py-2 bg-slate-900 text-green-400 border border-slate-700 rounded-lg font-mono text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                    autoFocus
                  />
                  <Button onClick={() => executeCommand(state.currentCommand)} disabled={!state.currentCommand.trim()}>
                    <Play className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Terminal Output */}
              <div>
                <h4 className="font-medium mb-2">Output:</h4>
                <ScrollArea 
                  ref={terminalRef}
                  className="h-48 bg-slate-900 text-green-400 p-3 rounded-lg font-mono text-sm"
                >
                  {state.output.map((line, index) => (
                    <div key={index}>{line}</div>
                  ))}
                  {state.output.length === 0 && (
                    <div className="text-slate-500">Welcome! Type 'help' to see available commands.</div>
                  )}
                </ScrollArea>
              </div>

              {/* Quick Help */}
              <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg">
                <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-1">Quick Help:</h4>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Type the command exactly as shown in the instructions. If you get stuck, click "Need Hint?" for help.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Completion Modal */}
        <AnimatePresence>
          {state.isCompleted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            >
              <Card className="w-full max-w-md">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Trophy className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle>Challenge Complete!</CardTitle>
                  <CardDescription>
                    Congratulations! You've mastered this challenge.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-blue-500">{state.score}</div>
                      <div className="text-sm text-slate-500">Score</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-500">{formatTime(state.elapsedTime)}</div>
                      <div className="text-sm text-slate-500">Time</div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-lg font-semibold text-purple-500">
                      Level Up! You are now level {state.userLevel}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button onClick={resetChallenge} variant="outline" className="flex-1">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Try Again
                    </Button>
                    <Button onClick={exitChallenge} className="flex-1">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      Next Challenge
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    )
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-2">
          <Sparkles className="h-6 w-6 text-yellow-500" />
          <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
            Git Learning Lab
          </h2>
          <Sparkles className="h-6 w-6 text-yellow-500" />
        </div>
        <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
          Learn Git commands step-by-step with interactive challenges. Perfect for beginners!
        </p>
        
        {/* User Level */}
        <Card className="max-w-sm mx-auto">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span className="text-sm font-medium">Level {state.userLevel}</span>
              </div>
              <span className="text-sm text-slate-500">
                {state.completedChallenges.length} challenges completed
              </span>
            </div>
            <Progress value={(state.completedChallenges.length % 3) / 3 * 100} className="w-full" />
          </CardContent>
        </Card>
      </div>

      {/* Challenges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {challenges.map((challenge) => {
          const isCompleted = state.completedChallenges.includes(challenge.id)
          const isNextChallenge = !isCompleted && 
            (state.completedChallenges.length === challenge.id - 1 || state.completedChallenges.length === 0)
          
          return (
            <motion.div
              key={challenge.id}
              whileHover={{ scale: isNextChallenge ? 1.02 : 1 }}
              whileTap={{ scale: isNextChallenge ? 0.98 : 1 }}
            >
              <Card className={`transition-all ${
                activeChallenge === challenge.id ? 'ring-2 ring-blue-500' : ''
              } ${!isNextChallenge && !isCompleted ? 'opacity-60' : ''}`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      {isCompleted ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : isNextChallenge ? (
                        <Target className="h-5 w-5 text-blue-500" />
                      ) : (
                        <Lock className="h-5 w-5 text-slate-400" />
                      )}
                      {challenge.title}
                    </CardTitle>
                    <Badge className={getDifficultyColor(challenge.difficulty)}>
                      {challenge.difficulty}
                    </Badge>
                  </div>
                  <CardDescription className="text-base">
                    {challenge.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">You'll learn:</h4>
                    <ul className="text-sm text-slate-600 dark:text-slate-300 list-disc list-inside space-y-1">
                      {challenge.whatYoullLearn.map((item, index) => (
                        <li key={index}>{item}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between text-sm text-slate-500">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {Math.floor(challenge.timeLimit / 60)}m
                    </div>
                    <div className="flex items-center gap-1">
                      <BookOpen className="h-4 w-4" />
                      {challenge.steps.length} steps
                    </div>
                  </div>

                  <Button 
                    onClick={() => startChallenge(challenge)}
                    className="w-full"
                    disabled={!isNextChallenge && !isCompleted}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Completed
                      </>
                    ) : activeChallenge === challenge.id ? (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        In Progress
                      </>
                    ) : !isNextChallenge ? (
                      <>
                        <Lock className="h-4 w-4 mr-2" />
                        Locked
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Start Challenge
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Your Learning Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
              <div className="text-2xl font-bold text-green-500">{state.completedChallenges.length}</div>
              <div className="text-sm text-green-700 dark:text-green-300">Challenges Completed</div>
            </div>
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
              <div className="text-2xl font-bold text-blue-500">{state.userLevel}</div>
              <div className="text-sm text-blue-700 dark:text-blue-300">Current Level</div>
            </div>
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
              <div className="text-2xl font-bold text-purple-500">
                {challenges.length - state.completedChallenges.length}
              </div>
              <div className="text-sm text-purple-700 dark:text-purple-300">Challenges Remaining</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default GitSimpleLab