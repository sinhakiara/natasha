// API service for Linux Practice Lab

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || ''

interface User {
  id: string
  name: string
  email: string
  points: number
  level: number
  role: 'STUDENT' | 'ADMIN'
  createdAt: string
  updatedAt: string
}

interface LoginResponse {
  user: User
  token: string
  message: string
}

interface Level {
  id: number
  title: string
  description: string
  difficulty: string
  points: number
  tasks: Task[]
  progress?: {
    completedTasks: number
    totalTasks: number
    percentage: number
    isUnlocked: boolean
  }
}

interface Task {
  id: number
  title: string
  description: string
  command: string
  expectedOutput?: string
  hint?: string
  order: number
  points: number
  completed?: boolean
  attempts?: number
  score?: number
}

interface VerificationResponse {
  isCorrect: boolean
  output: string
  attempt: {
    id: string
    isCorrect: boolean
    timeTaken: number
    hintUsed: boolean
  }
  progress: any
  user: User
  levelCompleted: boolean
}

interface LeaderboardEntry {
  rank: number
  id: string
  name: string
  email: string
  points: number
  level: number
  completedTasks: number
  joinDate: string
}

interface LeaderboardResponse {
  leaderboard: LeaderboardEntry[]
  pagination: {
    total: number
    limit: number
    offset: number
    hasMore: boolean
  }
}

// Admin interfaces
interface AdminStudent {
  id: string
  name: string
  email: string
  points: number
  level: number
  completedTasks: number
  totalAttempts: number
  joinDate: string
  lastActive: string
}

interface AdminStudentResponse {
  students: AdminStudent[]
  pagination: {
    total: number
    page: number
    limit: number
    totalPages: number
  }
  levelStats: Array<{
    levelId: number
    totalStudents: number
    totalScore: number
  }>
}

interface AdminStudentDetails {
  student: {
    id: string
    name: string
    email: string
    points: number
    level: number
    joinDate: string
    lastActive: string
  }
  statistics: {
    totalTasks: number
    completedTasks: number
    completionRate: number
    accuracy: number
    totalTimeSpent: number
    averageScore: number
    totalAttempts: number
  }
  progressByLevel: Array<{
    level: any
    completedTasks: number
    totalTasks: number
    completionRate: number
    totalScore: number
  }>
  recentAttempts: Array<{
    id: string
    taskId: number
    command: string
    isCorrect: boolean
    timeTaken: number
    hintUsed: boolean
    timestamp: string
  }>
}

interface AdminProgressOverview {
  overview: {
    totalStudents: number
    totalLevels: number
    totalTasks: number
    totalCompletions: number
    overallCompletionRate: number
  }
  levelStats: Array<{
    levelId: number
    title: string
    difficulty: string
    totalTasks: number
    completions: number
    completionRate: number
    totalAttempts: number
    averageAttemptsPerTask: number
  }>
  topStudents: Array<{
    id: string
    name: string
    email: string
    points: number
    level: number
    completedTasks: number
  }>
  taskAnalysis: Array<{
    taskId: number
    title: string
    levelId: number
    totalAttempts: number
    correctAttempts: number
    completions: number
    successRate: number
    averageAttempts: number
  }>
  recentActivity: Array<{
    date: string
    attempts: number
  }>
}

class APIService {
  private token: string | null = null

  constructor() {
    // Load token from localStorage on client side
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem('auth_token')
    }
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${API_BASE_URL}/api${endpoint}`
    
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...(this.token && { Authorization: `Bearer ${this.token}` }),
        ...options.headers,
      },
      ...options,
    }

    try {
      const response = await fetch(url, config)
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error('API request failed:', error)
      throw error
    }
  }

  // Authentication methods
  async login(email: string, password: string): Promise<LoginResponse> {
    const response = await this.request<LoginResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    })
    
    this.token = response.token
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', response.token)
    }
    
    return response
  }

  async signup(name: string, email: string, password: string, role?: 'STUDENT' | 'ADMIN'): Promise<LoginResponse> {
    const response = await this.request<LoginResponse>('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ name, email, password, role }),
    })
    
    this.token = response.token
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', response.token)
    }
    
    return response
  }

  async logout(): Promise<void> {
    if (this.token) {
      try {
        await this.request('/auth/logout', {
          method: 'POST',
        })
      } catch (error) {
        console.error('Logout request failed:', error)
      }
    }
    
    this.token = null
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token')
    }
  }

  async getCurrentUser(): Promise<{ user: User }> {
    return this.request('/auth/me')
  }

  // Levels and tasks methods
  async getLevels(userId?: string): Promise<{ levels: Level[] }> {
    const params = userId ? `?userId=${userId}` : ''
    return this.request(`/levels${params}`)
  }

  // Simulation methods
  async verifyCommand(
    taskId: number,
    command: string,
    timeTaken: number = 0,
    hintUsed: boolean = false
  ): Promise<VerificationResponse> {
    return this.request('/simulation/verify', {
      method: 'POST',
      body: JSON.stringify({ taskId, command, timeTaken, hintUsed }),
    })
  }

  // Leaderboard methods
  async getLeaderboard(limit: number = 10, offset: number = 0): Promise<LeaderboardResponse> {
    return this.request(`/leaderboard?limit=${limit}&offset=${offset}`)
  }

  // Admin methods
  async getStudents(page: number = 1, limit: number = 10, search?: string, level?: string): Promise<AdminStudentResponse> {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString()
    })
    
    if (search) params.append('search', search)
    if (level) params.append('level', level)
    
    return this.request(`/admin/students?${params.toString()}`)
  }

  async getStudentDetails(studentId: string): Promise<AdminStudentDetails> {
    return this.request(`/admin/students/${studentId}`)
  }

  async getProgressOverview(): Promise<AdminProgressOverview> {
    return this.request('/admin/progress')
  }

  // Utility methods
  isAuthenticated(): boolean {
    return !!this.token
  }

  getToken(): string | null {
    return this.token
  }

  setToken(token: string): void {
    this.token = token
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', token)
    }
  }

  clearToken(): void {
    this.token = null
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token')
    }
  }

  isAdmin(): boolean {
    try {
      if (this.token) {
        const payload = JSON.parse(atob(this.token.split('.')[1]))
        return payload.role === 'ADMIN'
      }
    } catch (error) {
      console.error('Error checking admin status:', error)
    }
    return false
  }
}

// Create and export singleton instance
export const apiService = new APIService()

// Export types for use in components
export type {
  User,
  Level,
  Task,
  LeaderboardEntry,
  LoginResponse,
  VerificationResponse,
  LeaderboardResponse,
  AdminStudent,
  AdminStudentResponse,
  AdminStudentDetails,
  AdminProgressOverview,
}