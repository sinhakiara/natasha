import { db } from './db'
import { UserRole } from '@prisma/client'
import bcrypt from 'bcryptjs'

const levelsData = [
  {
    id: -1,
    title: "Getting Started",
    description: "Learn the absolute basics of Linux commands",
    difficulty: "beginner",
    points: 100,
    tasks: [
      {
        id: 1,
        title: "Print Working Directory",
        description: "Display the current working directory",
        command: "pwd",
        expectedOutput: "/home/user",
        hint: "Use the 'pwd' command to show your current location",
        order: 1,
        points: 50
      },
      {
        id: 2,
        title: "List Directory Contents",
        description: "List all files and folders in the current directory",
        command: "ls",
        expectedOutput: "documents downloads pictures",
        hint: "Use the 'ls' command to list directory contents",
        order: 2,
        points: 50
      }
    ]
  },
  {
    id: 0,
    title: "Basic File Operations",
    description: "Learn fundamental file manipulation commands",
    difficulty: "beginner",
    points: 150,
    tasks: [
      {
        id: 3,
        title: "Create a File",
        description: "Create an empty file named 'test.txt'",
        command: "touch test.txt",
        expectedOutput: "",
        hint: "Use the 'touch' command to create an empty file",
        order: 1,
        points: 75
      },
      {
        id: 4,
        title: "Copy a File",
        description: "Copy 'test.txt' to 'backup.txt'",
        command: "cp test.txt backup.txt",
        expectedOutput: "",
        hint: "Use the 'cp' command to copy files",
        order: 2,
        points: 75
      }
    ]
  },
  {
    id: 1,
    title: "File Management",
    description: "Master file copying, moving, and deletion",
    difficulty: "beginner",
    points: 200,
    tasks: [
      {
        id: 5,
        title: "Copy Files",
        description: "Copy file1.txt to file2.txt",
        command: "cp file1.txt file2.txt",
        expectedOutput: "",
        hint: "Use 'cp' command: cp source destination",
        order: 1,
        points: 60
      },
      {
        id: 6,
        title: "Move Files",
        description: "Move file1.txt to /tmp/",
        command: "mv file1.txt /tmp/",
        expectedOutput: "",
        hint: "Use 'mv' command to move files",
        order: 2,
        points: 70
      },
      {
        id: 7,
        title: "Remove Files",
        description: "Delete file2.txt",
        command: "rm file2.txt",
        expectedOutput: "",
        hint: "Use 'rm' command to remove files",
        order: 3,
        points: 70
      }
    ]
  },
  {
    id: 2,
    title: "File Content Operations",
    description: "Learn to view and manipulate file contents",
    difficulty: "intermediate",
    points: 250,
    tasks: [
      {
        id: 8,
        title: "View File Content",
        description: "Display contents of file.txt",
        command: "cat file.txt",
        expectedOutput: "Hello World!",
        hint: "Use 'cat' to display file contents",
        order: 1,
        points: 80
      },
      {
        id: 9,
        title: "Redirect Output",
        description: "Save 'Hello World' to greeting.txt",
        command: "echo 'Hello World' > greeting.txt",
        expectedOutput: "",
        hint: "Use '>' to redirect output to a file",
        order: 2,
        points: 85
      },
      {
        id: 10,
        title: "Append to File",
        description: "Append 'Goodbye' to greeting.txt",
        command: "echo 'Goodbye' >> greeting.txt",
        expectedOutput: "",
        hint: "Use '>>' to append content to a file",
        order: 3,
        points: 85
      }
    ]
  },
  {
    id: 3,
    title: "User Management Basics",
    description: "Learn essential user and group management",
    difficulty: "intermediate",
    points: 300,
    tasks: [
      {
        id: 11,
        title: "Create User",
        description: "Create a new user named 'student'",
        command: "sudo useradd student",
        expectedOutput: "",
        hint: "Use 'useradd' command with sudo privileges",
        order: 1,
        points: 100
      },
      {
        id: 12,
        title: "Set Password",
        description: "Set password for user 'student'",
        command: "sudo passwd student",
        expectedOutput: "",
        hint: "Use 'passwd' command to set user password",
        order: 2,
        points: 100
      },
      {
        id: 13,
        title: "Create Group",
        description: "Create a new group named 'developers'",
        command: "sudo groupadd developers",
        expectedOutput: "",
        hint: "Use 'groupadd' command to create groups",
        order: 3,
        points: 100
      }
    ]
  },
  {
    id: 4,
    title: "Advanced File Operations",
    description: "Master advanced file manipulation techniques",
    difficulty: "intermediate",
    points: 350,
    tasks: [
      {
        id: 14,
        title: "View File Head",
        description: "Display first 10 lines of logfile.txt",
        command: "head logfile.txt",
        expectedOutput: "Line 1\nLine 2\nLine 3\nLine 4\nLine 5\nLine 6\nLine 7\nLine 8\nLine 9\nLine 10",
        hint: "Use 'head' command to show first lines",
        order: 1,
        points: 110
      },
      {
        id: 15,
        title: "View File Tail",
        description: "Display last 5 lines of logfile.txt",
        command: "tail -n 5 logfile.txt",
        expectedOutput: "Line 96\nLine 97\nLine 98\nLine 99\nLine 100",
        hint: "Use 'tail -n' to show last N lines",
        order: 2,
        points: 120
      },
      {
        id: 16,
        title: "Text Editor",
        description: "Open file.txt in nano editor",
        command: "nano file.txt",
        expectedOutput: "",
        hint: "Use 'nano' command to open text editor",
        order: 3,
        points: 120
      }
    ]
  },
  {
    id: 5,
    title: "Environment and Aliases",
    description: "Learn environment variables and command aliases",
    difficulty: "advanced",
    points: 400,
    tasks: [
      {
        id: 17,
        title: "Set Environment Variable",
        description: "Set MY_VAR to 'hello'",
        command: "export MY_VAR='hello'",
        expectedOutput: "",
        hint: "Use 'export' to set environment variables",
        order: 1,
        points: 130
      },
      {
        id: 18,
        title: "Create Alias",
        description: "Create alias 'll' for 'ls -la'",
        command: "alias ll='ls -la'",
        expectedOutput: "",
        hint: "Use 'alias' to create command shortcuts",
        order: 2,
        points: 130
      },
      {
        id: 19,
        title: "Edit Bashrc",
        description: "Open .bashrc file for editing",
        command: "nano ~/.bashrc",
        expectedOutput: "",
        hint: "Use nano to edit your bash configuration file",
        order: 3,
        points: 140
      }
    ]
  }
]

export async function seedDatabase() {
  try {
    console.log('Seeding database...')
    
    // Clear existing data
    await db.userAttempt.deleteMany()
    await db.userProgress.deleteMany()
    await db.task.deleteMany()
    await db.level.deleteMany()
    await db.session.deleteMany()
    await db.user.deleteMany()
    
    console.log('Cleared existing data')

    // Create admin user
    const adminPassword = await bcrypt.hash('admin123', 12)
    const admin = await db.user.create({
      data: {
        name: 'Admin User',
        email: 'admin@linuxlab.com',
        password: adminPassword,
        role: UserRole.ADMIN,
        points: 0,
        level: -1
      }
    })
    console.log('Created admin user: admin@linuxlab.com / admin123')

    // Create some sample students
    const studentPassword = await bcrypt.hash('student123', 12)
    const sampleStudents = [
      { name: 'Alex Johnson', email: 'alex@example.com' },
      { name: 'Sarah Chen', email: 'sarah@example.com' },
      { name: 'Mike Wilson', email: 'mike@example.com' },
      { name: 'Emma Davis', email: 'emma@example.com' },
      { name: 'John Smith', email: 'john@example.com' }
    ]

    for (const student of sampleStudents) {
      await db.user.create({
        data: {
          name: student.name,
          email: student.email,
          password: studentPassword,
          role: UserRole.STUDENT,
          points: Math.floor(Math.random() * 1000),
          level: Math.floor(Math.random() * 4)
        }
      })
    }
    console.log('Created sample students')

    // Seed levels and tasks
    for (const levelData of levelsData) {
      const { tasks, ...level } = levelData
      
      const createdLevel = await db.level.create({
        data: level
      })

      for (const taskData of tasks) {
        await db.task.create({
          data: {
            ...taskData,
            levelId: createdLevel.id
          }
        })
      }
    }

    console.log(`Database seeded successfully with ${levelsData.length} levels and ${levelsData.reduce((acc, level) => acc + level.tasks.length, 0)} tasks`)
    console.log('Admin credentials: admin@linuxlab.com / admin123')
    console.log('Student credentials: Any student email / student123')
    
  } catch (error) {
    console.error('Seed error:', error)
    throw error
  }
}

// Run if called directly
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log('Seed completed successfully')
      process.exit(0)
    })
    .catch((error) => {
      console.error('Seed failed:', error)
      process.exit(1)
    })
}