'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Terminal, Trophy, User, BookOpen, Target, Loader2, Settings } from 'lucide-react'
import { apiService, type User, type Level, type Task, type LeaderboardEntry } from '@/lib/api'
import { useRouter } from 'next/navigation'

export default function LinuxPracticeLab() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [currentLevel, setCurrentLevel] = useState<number | null>(null)
  const [currentTask, setCurrentTask] = useState<number>(0)
  const [commandInput, setCommandInput] = useState('')
  const [terminalOutput, setTerminalOutput] = useState<string[]>([])
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null)
  const [showHint, setShowHint] = useState(false)
  const [timeElapsed, setTimeElapsed] = useState(0)
  const [levels, setLevels] = useState<Level[]>([])
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loginForm, setLoginForm] = useState({ email: '', password: '' })
  const [signupForm, setSignupForm] = useState({ name: '', email: '', password: '' })

  // Check authentication on mount
  useEffect(() => {
    checkAuth()
  }, [])

  // Load levels and leaderboard when authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === 'ADMIN') {
        router.push('/admin')
      } else {
        loadLevels()
        loadLeaderboard()
      }
    }
  }, [isAuthenticated, user, router])

  const checkAuth = async () => {
    try {
      if (apiService.isAuthenticated()) {
        const response = await apiService.getCurrentUser()
        setUser(response.user)
        setIsAuthenticated(true)
        setTerminalOutput(["Welcome to Linux Practice Lab!", "Type 'help' for available commands."])
      }
    } catch (error) {
      console.error('Auth check failed:', error)
      apiService.clearToken()
    }
  }

  const loadLevels = async () => {
    try {
      setLoading(true)
      const response = await apiService.getLevels(user?.id)
      setLevels(response.levels)
    } catch (error) {
      console.error('Failed to load levels:', error)
      setError('Failed to load levels')
    } finally {
      setLoading(false)
    }
  }

  const loadLeaderboard = async () => {
    try {
      const response = await apiService.getLeaderboard(10)
      setLeaderboard(response.leaderboard)
    } catch (error) {
      console.error('Failed to load leaderboard:', error)
    }
  }

  const handleLogin = async (email: string, password: string) => {
    try {
      setLoading(true)
      setError(null)
      const response = await apiService.login(email, password)
      setUser(response.user)
      setIsAuthenticated(true)
      setTerminalOutput(["Welcome to Linux Practice Lab!", "Type 'help' for available commands."])
    } catch (error) {
      setError('Login failed. Please check your credentials.')
    } finally {
      setLoading(false)
    }
  }

  const handleSignup = async (name: string, email: string, password: string) => {
    try {
      setLoading(true)
      setError(null)
      const response = await apiService.signup(name, email, password)
      setUser(response.user)
      setIsAuthenticated(true)
      setTerminalOutput(["Welcome to Linux Practice Lab!", "Account created successfully!", "Type 'help' for available commands."])
    } catch (error) {
      setError('Signup failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const executeCommand = async () => {
    if (!commandInput.trim() || !user || currentLevel === null) return

    const newOutput = [...terminalOutput, `$ ${commandInput}`]
    
    // Find current task
    const level = levels.find(l => l.id === currentLevel)
    if (!level || currentTask >= level.tasks.length) return

    const task = level.tasks[currentTask]
    
    try {
      const response = await apiService.verifyCommand(
        task.id,
        commandInput,
        timeElapsed,
        showHint
      )

      newOutput.push(response.output)
      
      if (response.isCorrect) {
        newOutput.push("✓ Correct! Well done!")
        setIsCorrect(true)
        setUser(response.user)
        
        // Move to next task or level
        setTimeout(() => {
          if (currentTask < level.tasks.length - 1) {
            setCurrentTask(currentTask + 1)
          } else {
            // Level completed
            setCurrentLevel(null)
            setCurrentTask(0)
            newOutput.push(`🎉 Level ${currentLevel + 1} completed! +${level.points} points`)
            loadLevels() // Refresh levels to update progress
          }
          setIsCorrect(null)
          setShowHint(false)
          setTimeElapsed(0)
        }, 1500)
      } else {
        newOutput.push("✗ Incorrect. Try again!")
        setIsCorrect(false)
      }
    } catch (error) {
      newOutput.push("✗ Error verifying command. Please try again.")
      setIsCorrect(false)
    }
    
    setTerminalOutput(newOutput)
    setCommandInput("")
  }

  const startLevel = (levelId: number) => {
    const level = levels.find(l => l.id === levelId)
    if (!level) return
    
    setCurrentLevel(levelId)
    setCurrentTask(0)
    setIsCorrect(null)
    setShowHint(false)
    setTimeElapsed(0)
    setTerminalOutput([`Starting Level ${levelId + 1}: ${level.title}`, level.description])
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-500"
      case "intermediate": return "bg-yellow-500"
      case "advanced": return "bg-red-500"
      default: return "bg-gray-500"
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Terminal className="h-12 w-12 text-blue-400" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Linux Practice Lab</h1>
            <p className="text-slate-300">Master Linux commands through interactive challenges</p>
          </div>
          
          <Card className="bg-slate-800 border-slate-700">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-slate-700">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="p-6">
                <div className="space-y-4">
                  {error && (
                    <Alert className="bg-red-900 border-red-700">
                      <AlertDescription className="text-red-200">{error}</AlertDescription>
                    </Alert>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="Enter your email" 
                      className="bg-slate-700 border-slate-600"
                      value={loginForm.email}
                      onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input 
                      id="password" 
                      type="password" 
                      placeholder="Enter your password" 
                      className="bg-slate-700 border-slate-600"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                    />
                  </div>
                  <Button 
                    onClick={() => handleLogin(loginForm.email, loginForm.password)}
                    disabled={loading}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Login
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="signup" className="p-6">
                <div className="space-y-4">
                  {error && (
                    <Alert className="bg-red-900 border-red-700">
                      <AlertDescription className="text-red-200">{error}</AlertDescription>
                    </Alert>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input 
                      id="name" 
                      type="text" 
                      placeholder="Enter your full name" 
                      className="bg-slate-700 border-slate-600"
                      value={signupForm.name}
                      onChange={(e) => setSignupForm({...signupForm, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Email</Label>
                    <Input 
                      id="signup-email" 
                      type="email" 
                      placeholder="Enter your email" 
                      className="bg-slate-700 border-slate-600"
                      value={signupForm.email}
                      onChange={(e) => setSignupForm({...signupForm, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <Input 
                      id="signup-password" 
                      type="password" 
                      placeholder="Create a password" 
                      className="bg-slate-700 border-slate-600"
                      value={signupForm.password}
                      onChange={(e) => setSignupForm({...signupForm, password: e.target.value})}
                    />
                  </div>
                  <Button 
                    onClick={() => handleSignup(signupForm.name, signupForm.email, signupForm.password)}
                    disabled={loading}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Sign Up
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </div>
    )
  }

  const activeLevel = levels.find(l => l.id === currentLevel)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Terminal className="h-8 w-8 text-blue-400" />
            <h1 className="text-2xl font-bold">Linux Practice Lab</h1>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Trophy className="h-5 w-5 text-yellow-400" />
              <span className="font-semibold">{user?.points} pts</span>
            </div>
            <div className="flex items-center space-x-2">
              <Target className="h-5 w-5 text-green-400" />
              <span className="font-semibold">Level {user?.level ? user.level + 1 : 1}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="font-medium">{user?.name}</span>
              {user?.role === 'ADMIN' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => router.push('/admin')}
                  className="border-slate-600 hover:bg-slate-700"
                >
                  <Settings className="h-4 w-4 mr-1" />
                  Admin
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Level Selection */}
            {currentLevel === null && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BookOpen className="h-5 w-5" />
                    <span>Choose Your Level</span>
                  </CardTitle>
                  <CardDescription>Select a level to start practicing Linux commands</CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {levels.map((level) => (
                        <Card 
                          key={level.id} 
                          className={`bg-slate-700 border-slate-600 cursor-pointer hover:bg-slate-600 transition-colors ${
                            !level.progress?.isUnlocked ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                          onClick={() => level.progress?.isUnlocked && startLevel(level.id)}
                        >
                          <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-lg">Level {level.id + 1}</CardTitle>
                              <Badge className={`${getDifficultyColor(level.difficulty)} text-white`}>
                                {level.difficulty}
                              </Badge>
                            </div>
                            <CardDescription>{level.description}</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                  <Trophy className="h-4 w-4 text-yellow-400" />
                                  <span className="text-sm">{level.points} points</span>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Target className="h-4 w-4 text-blue-400" />
                                  <span className="text-sm">{level.tasks.length} tasks</span>
                                </div>
                              </div>
                              
                              {level.progress && (
                                <div className="space-y-2">
                                  <div className="flex items-center justify-between text-xs">
                                    <span>Progress</span>
                                    <span>{level.progress.completedTasks}/{level.progress.totalTasks}</span>
                                  </div>
                                  <Progress value={level.progress.percentage} className="h-2" />
                                </div>
                              )}
                              
                              {level.progress?.isUnlocked && (
                                <Button className="w-full mt-3 bg-blue-600 hover:bg-blue-700">
                                  {level.progress?.completedTasks === level.progress?.totalTasks 
                                    ? 'Review Level' 
                                    : level.progress?.completedTasks > 0 
                                      ? 'Continue Level' 
                                      : 'Start Level'
                                  }
                                </Button>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Active Level */}
            {currentLevel !== null && activeLevel && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center space-x-2">
                        <Target className="h-5 w-5" />
                        <span>Level {currentLevel + 1}: {activeLevel.title}</span>
                      </CardTitle>
                      <CardDescription>{activeLevel.description}</CardDescription>
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => setCurrentLevel(null)}
                      className="border-slate-600 hover:bg-slate-700"
                    >
                      Back to Levels
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Progress */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Progress</span>
                        <span className="text-sm text-slate-400">
                          Task {currentTask + 1} of {activeLevel.tasks.length}
                        </span>
                      </div>
                      <Progress 
                        value={((currentTask + 1) / activeLevel.tasks.length) * 100} 
                        className="h-2"
                      />
                    </div>

                    {/* Current Task */}
                    <Card className="bg-slate-700 border-slate-600">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">
                          {activeLevel.tasks[currentTask]?.title}
                        </CardTitle>
                        <CardDescription>
                          {activeLevel.tasks[currentTask]?.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {showHint && activeLevel.tasks[currentTask]?.hint && (
                            <Alert className="bg-blue-900 border-blue-700">
                              <AlertDescription className="text-blue-200">
                                💡 Hint: {activeLevel.tasks[currentTask]?.hint}
                              </AlertDescription>
                            </Alert>
                          )}
                          
                          <div className="flex space-x-2">
                            <Button 
                              variant="outline" 
                              onClick={() => setShowHint(!showHint)}
                              className="border-slate-600 hover:bg-slate-600"
                            >
                              {showHint ? "Hide Hint" : "Show Hint"}
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Terminal */}
                    <Card className="bg-slate-900 border-slate-700">
                      <CardHeader className="pb-3">
                        <CardTitle className="flex items-center space-x-2">
                          <Terminal className="h-4 w-4" />
                          <span>Terminal</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="bg-black p-4 rounded-lg font-mono text-sm h-64 overflow-y-auto">
                            {terminalOutput.map((line, index) => (
                              <div key={index} className="mb-1">
                                {line.startsWith('$') ? (
                                  <span className="text-green-400">{line}</span>
                                ) : line.includes('✓') ? (
                                  <span className="text-green-400">{line}</span>
                                ) : line.includes('✗') ? (
                                  <span className="text-red-400">{line}</span>
                                ) : line.includes('🎉') ? (
                                  <span className="text-yellow-400">{line}</span>
                                ) : (
                                  <span className="text-gray-300">{line}</span>
                                )}
                              </div>
                            ))}
                          </div>
                          
                          <div className="flex space-x-2">
                            <Input
                              value={commandInput}
                              onChange={(e) => setCommandInput(e.target.value)}
                              onKeyPress={(e) => e.key === 'Enter' && executeCommand()}
                              placeholder="Enter your command..."
                              className="bg-slate-800 border-slate-600 text-white font-mono"
                            />
                            <Button onClick={executeCommand} className="bg-blue-600 hover:bg-blue-700">
                              Execute
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Leaderboard */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="h-5 w-5 text-yellow-400" />
                  <span>Leaderboard</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {leaderboard.map((entry) => (
                    <div key={entry.rank} className="flex items-center justify-between p-3 rounded-lg bg-slate-700">
                      <div className="flex items-center space-x-3">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          entry.rank === 1 ? 'bg-yellow-500' : 
                          entry.rank === 2 ? 'bg-gray-400' : 
                          entry.rank === 3 ? 'bg-orange-600' : 'bg-slate-600'
                        }`}>
                          {entry.rank}
                        </div>
                        <div>
                          <div className="font-medium">{entry.name}</div>
                          <div className="text-xs text-slate-400">Level {entry.level + 1}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{entry.points}</div>
                        <div className="text-xs text-slate-400">points</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* User Stats */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="h-5 w-5" />
                  <span>Your Progress</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Total Points</span>
                    <span className="font-semibold text-yellow-400">{user?.points}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Current Level</span>
                    <span className="font-semibold text-green-400">{user?.level ? user.level + 1 : 1}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Tasks Completed</span>
                    <span className="font-semibold text-blue-400">
                      {levels.reduce((acc, level) => acc + (level.progress?.completedTasks || 0), 0)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Accuracy</span>
                    <span className="font-semibold text-purple-400">85%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5" />
                  <span>Quick Tips</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-slate-300">
                  <p>• Use <code className="bg-slate-700 px-1 rounded">help</code> command in terminal</p>
                  <p>• Each level has increasing difficulty</p>
                  <p>• Points are awarded per level completion</p>
                  <p>• Use hints when you're stuck</p>
                  <p>• Practice regularly to improve accuracy</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}