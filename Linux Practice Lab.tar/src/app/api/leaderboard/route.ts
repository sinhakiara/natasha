import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '10')
    const offset = parseInt(searchParams.get('offset') || '0')

    // Get top users by points
    const users = await db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        points: true,
        level: true,
        createdAt: true,
        _count: {
          select: {
            progress: {
              where: { completed: true }
            }
          }
        }
      },
      orderBy: [
        { points: 'desc' },
        { level: 'desc' },
        { createdAt: 'asc' }
      ],
      take: limit,
      skip: offset
    })

    // Get total count for pagination
    const totalUsers = await db.user.count()

    // Format leaderboard entries
    const leaderboard = users.map((user, index) => ({
      rank: offset + index + 1,
      id: user.id,
      name: user.name || 'Anonymous',
      email: user.email,
      points: user.points,
      level: user.level,
      completedTasks: user._count.progress,
      joinDate: user.createdAt
    }))

    return NextResponse.json({
      leaderboard,
      pagination: {
        total: totalUsers,
        limit,
        offset,
        hasMore: offset + limit < totalUsers
      }
    })

  } catch (error) {
    console.error('Get leaderboard error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}