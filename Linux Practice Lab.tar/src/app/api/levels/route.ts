import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    const levels = await db.level.findMany({
      where: { isActive: true },
      include: {
        tasks: {
          where: { isActive: true },
          orderBy: { order: 'asc' }
        }
      },
      orderBy: { id: 'asc' }
    })

    // If userId is provided, include user progress
    if (userId) {
      const userProgress = await db.userProgress.findMany({
        where: { userId },
        include: {
          task: true
        }
      })

      // Add progress information to levels and tasks
      const levelsWithProgress = levels.map(level => {
        const levelTasks = level.tasks.map(task => {
          const progress = userProgress.find(p => p.taskId === task.id)
          return {
            ...task,
            completed: progress?.completed || false,
            attempts: progress?.attempts || 0,
            score: progress?.score || 0
          }
        })

        const completedTasks = levelTasks.filter(t => t.completed).length
        const totalTasks = levelTasks.length

        return {
          ...level,
          tasks: levelTasks,
          progress: {
            completedTasks,
            totalTasks,
            percentage: totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0,
            isUnlocked: level.id <= -1 || completedTasks > 0 // First level is always unlocked
          }
        }
      })

      return NextResponse.json({ levels: levelsWithProgress })
    }

    return NextResponse.json({ levels })

  } catch (error) {
    console.error('Get levels error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}