import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TaskStatus } from '@prisma/client'

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    }

    const token = authHeader.substring(7)
    const { taskId, command, timeTaken, hintUsed } = await request.json()

    if (!taskId || !command) {
      return NextResponse.json(
        { error: 'Task ID and command are required' },
        { status: 400 }
      )
    }

    // Find session and user
    const session = await db.session.findFirst({
      where: {
        token,
        expiresAt: {
          gt: new Date()
        }
      },
      include: {
        user: true
      }
    })

    if (!session) {
      return NextResponse.json(
        { error: 'Invalid or expired token' },
        { status: 401 }
      )
    }

    // Find the task
    const task = await db.task.findUnique({
      where: { id: taskId },
      include: {
        level: true
      }
    })

    if (!task) {
      return NextResponse.json(
        { error: 'Task not found' },
        { status: 404 }
      )
    }

    // Verify command (simple string matching for now)
    const isCorrect = command.trim() === task.command.trim()
    
    // Mock output based on command
    let output = ''
    if (isCorrect) {
      output = task.expectedOutput || 'Command executed successfully'
    } else {
      output = 'Command not found or incorrect syntax'
    }

    // Record attempt
    const attempt = await db.userAttempt.create({
      data: {
        userId: session.user.id,
        taskId: task.id,
        command,
        output,
        isCorrect,
        timeTaken: timeTaken || 0,
        hintUsed: hintUsed || false
      }
    })

    // Update or create user progress
    let userProgress = await db.userProgress.findUnique({
      where: {
        userId_taskId: {
          userId: session.user.id,
          taskId: task.id
        }
      }
    })

    if (isCorrect) {
      const progressData = {
        status: TaskStatus.COMPLETED as TaskStatus,
        completed: true,
        attempts: (userProgress?.attempts || 0) + 1,
        timeSpent: (userProgress?.timeSpent || 0) + (timeTaken || 0),
        score: calculateScore(task.points, (userProgress?.attempts || 0) + 1, hintUsed || false),
        completedAt: new Date()
      }

      if (userProgress) {
        // Update existing progress
        userProgress = await db.userProgress.update({
          where: { id: userProgress.id },
          data: progressData
        })
      } else {
        // Create new progress
        userProgress = await db.userProgress.create({
          data: {
            userId: session.user.id,
            levelId: task.levelId,
            taskId: task.id,
            startedAt: new Date(),
            ...progressData
          }
        })
      }

      // Check if level is completed
      const totalTasksInLevel = await db.task.count({
        where: { levelId: task.levelId }
      })

      const completedTasksInLevel = await db.userProgress.count({
        where: {
          userId: session.user.id,
          levelId: task.levelId,
          completed: true
        }
      })

      const levelCompleted = completedTasksInLevel === totalTasksInLevel

      if (levelCompleted) {
        // Update user level and points
        await db.user.update({
          where: { id: session.user.id },
          data: {
            level: task.levelId,
            points: {
              increment: task.level.points
            }
          }
        })
      }
    } else {
      // Update attempts for incorrect answer
      const progressData = {
        status: userProgress?.status === TaskStatus.COMPLETED ? TaskStatus.COMPLETED : TaskStatus.IN_PROGRESS,
        attempts: (userProgress?.attempts || 0) + 1,
        timeSpent: (userProgress?.timeSpent || 0) + (timeTaken || 0),
        startedAt: userProgress?.startedAt || new Date()
      }

      if (userProgress) {
        userProgress = await db.userProgress.update({
          where: { id: userProgress.id },
          data: progressData
        })
      } else {
        // Create new progress for incorrect attempt
        userProgress = await db.userProgress.create({
          data: {
            userId: session.user.id,
            levelId: task.levelId,
            taskId: task.id,
            status: TaskStatus.IN_PROGRESS,
            startedAt: new Date(),
            completed: false,
            attempts: 1,
            timeSpent: timeTaken || 0,
            score: 0
          }
        })
      }
    }

    // Get updated user data
    const updatedUser = await db.user.findUnique({
      where: { id: session.user.id },
      select: {
        id: true,
        name: true,
        email: true,
        points: true,
        level: true,
        role: true,
        createdAt: true,
        updatedAt: true
      }
    })

    return NextResponse.json({
      isCorrect,
      output,
      attempt: {
        id: attempt.id,
        isCorrect: attempt.isCorrect,
        timeTaken: attempt.timeTaken,
        hintUsed: attempt.hintUsed
      },
      progress: userProgress,
      user: updatedUser,
      levelCompleted: isCorrect && completedTasksInLevel === totalTasksInLevel
    })

  } catch (error) {
    console.error('Verification error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

function calculateScore(basePoints: number, attempts: number, hintUsed: boolean): number {
  let score = basePoints
  
  // Deduct points for multiple attempts
  if (attempts > 1) {
    score = Math.max(0, score - (attempts - 1) * 10)
  }
  
  // Deduct points for using hints
  if (hintUsed) {
    score = Math.max(0, score - 5)
  }
  
  return score
}