import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'
import { UserRole } from '@prisma/client'

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, role = UserRole.STUDENT } = await request.json()

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: 'Name, email, and password are required' },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters long' },
        { status: 400 }
      )
    }

    // Only allow admin role creation if it's the first user or if requester is admin
    if (role === UserRole.ADMIN) {
      const userCount = await db.user.count()
      if (userCount > 0) {
        const authHeader = request.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
          return NextResponse.json(
            { error: 'Admin authorization required to create admin users' },
            { status: 401 }
          )
        }
        
        const token = authHeader.substring(7)
        const session = await db.session.findFirst({
          where: {
            token,
            expiresAt: { gt: new Date() }
          },
          include: { user: true }
        })
        
        if (!session || session.user.role !== UserRole.ADMIN) {
          return NextResponse.json(
            { error: 'Only admins can create admin users' },
            { status: 403 }
          )
        }
      }
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 409 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const user = await db.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        points: 0,
        level: -1,
        role
      }
    })

    // Create session
    const session = await db.session.create({
      data: {
        userId: user.id,
        token: bcrypt.hashSync(user.id + Date.now().toString(), 8),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
      }
    })

    // Return user data without password
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      user: userWithoutPassword,
      token: session.token,
      message: 'User created successfully'
    })

  } catch (error) {
    console.error('Signup error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}