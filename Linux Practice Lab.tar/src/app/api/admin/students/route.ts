import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { UserRole } from '@prisma/client'

// Middleware to check admin access
async function isAdmin(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return false
  }

  const token = authHeader.substring(7)
  
  const session = await db.session.findFirst({
    where: {
      token,
      expiresAt: {
        gt: new Date()
      }
    },
    include: {
      user: true
    }
  })

  return session && session.user.role === UserRole.ADMIN
}

export async function GET(request: NextRequest) {
  try {
    // Check admin access
    const adminCheck = await isAdmin(request)
    if (!adminCheck) {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const search = searchParams.get('search') || ''
    const level = searchParams.get('level')

    const offset = (page - 1) * limit

    // Build where clause
    const where: any = {
      role: UserRole.STUDENT,
      isActive: true
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } }
      ]
    }

    if (level && level !== '') {
      where.level = parseInt(level)
    }

    // Get students with progress info
    const students = await db.user.findMany({
      where,
      select: {
        id: true,
        name: true,
        email: true,
        points: true,
        level: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            progress: {
              where: { completed: true }
            },
            attempts: true
          }
        }
      },
      orderBy: [
        { points: 'desc' },
        { level: 'desc' },
        { createdAt: 'asc' }
      ],
      take: limit,
      skip: offset
    })

    // Get total count for pagination
    const total = await db.user.count({ where })

    // Get level statistics
    const levelStats = await db.userProgress.groupBy({
      by: ['levelId'],
      where: {
        user: {
          role: UserRole.STUDENT,
          isActive: true
        }
      },
      _count: {
        id: true
      },
      _sum: {
        score: true
      }
    })

    return NextResponse.json({
      students: students.map(student => ({
        id: student.id,
        name: student.name,
        email: student.email,
        points: student.points,
        level: student.level,
        completedTasks: student._count.progress,
        totalAttempts: student._count.attempts,
        joinDate: student.createdAt,
        lastActive: student.updatedAt
      })),
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      },
      levelStats: levelStats.map(stat => ({
        levelId: stat.levelId,
        totalStudents: stat._count.id,
        totalScore: stat._sum.score || 0
      }))
    })

  } catch (error) {
    console.error('Get students error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}