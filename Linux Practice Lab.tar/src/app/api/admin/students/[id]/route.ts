import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { UserRole } from '@prisma/client'

// Middleware to check admin access
async function isAdmin(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return false
  }

  const token = authHeader.substring(7)
  
  const session = await db.session.findFirst({
    where: {
      token,
      expiresAt: {
        gt: new Date()
      }
    },
    include: {
      user: true
    }
  })

  return session && session.user.role === UserRole.ADMIN
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check admin access
    const adminCheck = await isAdmin(request)
    if (!adminCheck) {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    const studentId = params.id

    // Get student details
    const student = await db.user.findUnique({
      where: { 
        id: studentId,
        role: UserRole.STUDENT,
        isActive: true
      },
      select: {
        id: true,
        name: true,
        email: true,
        points: true,
        level: true,
        createdAt: true,
        updatedAt: true,
        progress: {
          include: {
            task: {
              include: {
                level: true
              }
            }
          }
        },
        attempts: {
          orderBy: { createdAt: 'desc' },
          take: 50
        }
      }
    })

    if (!student) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      )
    }

    // Calculate statistics
    const totalTasks = await db.task.count()
    const completedTasks = student.progress.filter(p => p.completed).length
    const accuracy = student.attempts.length > 0 
      ? (student.attempts.filter(a => a.isCorrect).length / student.attempts.length) * 100 
      : 0

    const totalTimeSpent = student.progress.reduce((acc, p) => acc + p.timeSpent, 0)
    const averageScore = student.progress.length > 0
      ? student.progress.reduce((acc, p) => acc + p.score, 0) / student.progress.length
      : 0

    // Group progress by level
    const progressByLevel = student.progress.reduce((acc, progress) => {
      const levelId = progress.task.levelId
      if (!acc[levelId]) {
        acc[levelId] = {
          level: progress.task.level,
          tasks: [],
          completedTasks: 0,
          totalScore: 0
        }
      }
      acc[levelId].tasks.push(progress)
      if (progress.completed) {
        acc[levelId].completedTasks++
      }
      acc[levelId].totalScore += progress.score
      return acc
    }, {} as any)

    return NextResponse.json({
      student: {
        id: student.id,
        name: student.name,
        email: student.email,
        points: student.points,
        level: student.level,
        joinDate: student.createdAt,
        lastActive: student.updatedAt
      },
      statistics: {
        totalTasks,
        completedTasks,
        completionRate: totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0,
        accuracy: Math.round(accuracy * 100) / 100,
        totalTimeSpent,
        averageScore: Math.round(averageScore * 100) / 100,
        totalAttempts: student.attempts.length
      },
      progressByLevel: Object.values(progressByLevel).map((levelData: any) => ({
        level: levelData.level,
        completedTasks: levelData.completedTasks,
        totalTasks: levelData.tasks.length,
        completionRate: levelData.tasks.length > 0 
          ? (levelData.completedTasks / levelData.tasks.length) * 100 
          : 0,
        totalScore: levelData.totalScore
      })),
      recentAttempts: student.attempts.slice(0, 10).map(attempt => ({
        id: attempt.id,
        taskId: attempt.taskId,
        command: attempt.command,
        isCorrect: attempt.isCorrect,
        timeTaken: attempt.timeTaken,
        hintUsed: attempt.hintUsed,
        timestamp: attempt.createdAt
      }))
    })

  } catch (error) {
    console.error('Get student details error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}