import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { UserRole } from '@prisma/client'

// Middleware to check admin access
async function isAdmin(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return false
  }

  const token = authHeader.substring(7)
  
  const session = await db.session.findFirst({
    where: {
      token,
      expiresAt: {
        gt: new Date()
      }
    },
    include: {
      user: true
    }
  })

  return session && session.user.role === UserRole.ADMIN
}

export async function GET(request: NextRequest) {
  try {
    // Check admin access
    const adminCheck = await isAdmin(request)
    if (!adminCheck) {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    // Get overall statistics
    const totalStudents = await db.user.count({
      where: {
        role: UserRole.STUDENT,
        isActive: true
      }
    })

    const totalLevels = await db.level.count({
      where: { isActive: true }
    })

    const totalTasks = await db.task.count({
      where: { isActive: true }
    })

    // Get completion statistics
    const totalCompletions = await db.userProgress.count({
      where: {
        user: {
          role: UserRole.STUDENT,
          isActive: true
        },
        completed: true
      }
    })

    // Get level-wise progress
    const levelProgress = await db.level.findMany({
      where: { isActive: true },
      include: {
        tasks: {
          include: {
            progress: {
              where: {
                user: {
                  role: UserRole.STUDENT,
                  isActive: true
                }
              }
            }
          }
        }
      },
      orderBy: { id: 'asc' }
    })

    const levelStats = levelProgress.map(level => {
      const totalTasksInLevel = level.tasks.length
      const completions = level.tasks.reduce((acc, task) => 
        acc + task.progress.filter(p => p.completed).length, 0
      )
      const totalAttempts = level.tasks.reduce((acc, task) => 
        acc + task.progress.length, 0
      )
      const correctAttempts = level.tasks.reduce((acc, task) => 
        acc + task.progress.filter(p => {
          // Get attempts for this task
          return true // This would need to be calculated differently
        }).length, 0
      )

      return {
        levelId: level.id,
        title: level.title,
        difficulty: level.difficulty,
        totalTasks: totalTasksInLevel,
        completions,
        completionRate: totalTasksInLevel > 0 ? (completions / totalTasksInLevel) * 100 : 0,
        totalAttempts,
        averageAttemptsPerTask: totalTasksInLevel > 0 ? totalAttempts / totalTasksInLevel : 0
      }
    })

    // Get student activity (last 7 days)
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    const recentActivity = await db.userAttempt.groupBy({
      by: ['createdAt'],
      where: {
        createdAt: {
          gte: sevenDaysAgo
        },
        user: {
          role: UserRole.STUDENT,
          isActive: true
        }
      },
      _count: {
        id: true
      },
      orderBy: {
        createdAt: 'asc'
      }
    })

    // Get top performing students
    const topStudents = await db.user.findMany({
      where: {
        role: UserRole.STUDENT,
        isActive: true
      },
      select: {
        id: true,
        name: true,
        email: true,
        points: true,
        level: true,
        _count: {
          select: {
            progress: {
              where: { completed: true }
            }
          }
        }
      },
      orderBy: [
        { points: 'desc' },
        { level: 'desc' }
      ],
      take: 10
    })

    // Get task difficulty analysis
    const taskStats = await db.task.findMany({
      where: { isActive: true },
      include: {
        attempts: {
          where: {
            user: {
              role: UserRole.STUDENT,
              isActive: true
            }
          }
        },
        progress: {
          where: {
            user: {
              role: UserRole.STUDENT,
              isActive: true
            }
          }
        }
      },
      orderBy: { id: 'asc' }
    })

    const taskAnalysis = taskStats.map(task => {
      const totalAttempts = task.attempts.length
      const correctAttempts = task.attempts.filter(a => a.isCorrect).length
      const completions = task.progress.filter(p => p.completed).length
      const averageAttempts = completions > 0 ? totalAttempts / completions : 0
      const successRate = totalAttempts > 0 ? (correctAttempts / totalAttempts) * 100 : 0

      return {
        taskId: task.id,
        title: task.title,
        levelId: task.levelId,
        totalAttempts,
        correctAttempts,
        completions,
        successRate: Math.round(successRate * 100) / 100,
        averageAttempts: Math.round(averageAttempts * 100) / 100
      }
    })

    return NextResponse.json({
      overview: {
        totalStudents,
        totalLevels,
        totalTasks,
        totalCompletions,
        overallCompletionRate: totalTasks > 0 && totalStudents > 0 
          ? (totalCompletions / (totalTasks * totalStudents)) * 100 
          : 0
      },
      levelStats,
      topStudents: topStudents.map(student => ({
        id: student.id,
        name: student.name,
        email: student.email,
        points: student.points,
        level: student.level,
        completedTasks: student._count.progress
      })),
      taskAnalysis,
      recentActivity: recentActivity.map(activity => ({
        date: activity.createdAt,
        attempts: activity._count.id
      }))
    })

  } catch (error) {
    console.error('Get admin progress error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}