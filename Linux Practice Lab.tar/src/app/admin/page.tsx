'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Users, 
  Trophy, 
  Target, 
  TrendingUp, 
  Search, 
  Eye, 
  Loader2,
  BarChart3,
  Clock,
  CheckCircle,
  XCircle
} from 'lucide-react'
import { apiService, type AdminStudent, type AdminProgressOverview, type AdminStudentDetails } from '@/lib/api'

export default function AdminDashboard() {
  const [user, setUser] = useState<any>(null)
  const [students, setStudents] = useState<AdminStudent[]>([])
  const [overview, setOverview] = useState<AdminProgressOverview | null>(null)
  const [selectedStudent, setSelectedStudent] = useState<AdminStudentDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [levelFilter, setLevelFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  useEffect(() => {
    checkAuth()
  }, [])

  useEffect(() => {
    if (user) {
      loadStudents()
      loadOverview()
    }
  }, [user, currentPage, searchTerm, levelFilter])

  const checkAuth = async () => {
    try {
      const response = await apiService.getCurrentUser()
      setUser(response.user)
      
      if (response.user.role !== 'ADMIN') {
        setError('Access denied. Admin privileges required.')
        return
      }
    } catch (error) {
      console.error('Auth check failed:', error)
      setError('Authentication failed')
    } finally {
      setLoading(false)
    }
  }

  const loadStudents = async () => {
    try {
      setLoading(true)
      const response = await apiService.getStudents(currentPage, 10, searchTerm, levelFilter)
      setStudents(response.students)
      setTotalPages(response.pagination.totalPages)
    } catch (error) {
      console.error('Failed to load students:', error)
      setError('Failed to load students')
    } finally {
      setLoading(false)
    }
  }

  const loadOverview = async () => {
    try {
      const response = await apiService.getProgressOverview()
      setOverview(response)
    } catch (error) {
      console.error('Failed to load overview:', error)
    }
  }

  const viewStudentDetails = async (studentId: string) => {
    try {
      const response = await apiService.getStudentDetails(studentId)
      setSelectedStudent(response)
    } catch (error) {
      console.error('Failed to load student details:', error)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-500"
      case "intermediate": return "bg-yellow-500"
      case "advanced": return "bg-red-500"
      default: return "bg-gray-500"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
        <Card className="bg-slate-800 border-slate-700 max-w-md">
          <CardHeader>
            <CardTitle className="text-red-400">Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="bg-red-900 border-red-700">
              <AlertDescription className="text-red-200">{error}</AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <BarChart3 className="h-8 w-8 text-blue-400" />
            <div>
              <h1 className="text-2xl font-bold">Admin Dashboard</h1>
              <p className="text-slate-400 text-sm">Linux Practice Lab Management</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Badge className="bg-purple-600">ADMIN</Badge>
            <div className="flex items-center space-x-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="font-medium">{user?.name}</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-slate-800 border-slate-700">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="students">Students</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {overview && (
              <>
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card className="bg-slate-800 border-slate-700">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Students</CardTitle>
                      <Users className="h-4 w-4 text-blue-400" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{overview.overview.totalStudents}</div>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-800 border-slate-700">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Levels</CardTitle>
                      <Target className="h-4 w-4 text-green-400" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{overview.overview.totalLevels}</div>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-800 border-slate-700">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Completions</CardTitle>
                      <CheckCircle className="h-4 w-4 text-yellow-400" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{overview.overview.totalCompletions}</div>
                      <p className="text-xs text-slate-400">
                        {overview.overview.overallCompletionRate.toFixed(1)}% completion rate
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-800 border-slate-700">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Tasks</CardTitle>
                      <TrendingUp className="h-4 w-4 text-purple-400" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{overview.overview.totalTasks}</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Top Students */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Trophy className="h-5 w-5 text-yellow-400" />
                      <span>Top Performing Students</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {overview.topStudents.slice(0, 5).map((student, index) => (
                        <div key={student.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-700">
                          <div className="flex items-center space-x-3">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                              index === 0 ? 'bg-yellow-500' : 
                              index === 1 ? 'bg-gray-400' : 
                              index === 2 ? 'bg-orange-600' : 'bg-slate-600'
                            }`}>
                              {index + 1}
                            </div>
                            <div>
                              <div className="font-medium">{student.name}</div>
                              <div className="text-xs text-slate-400">{student.email}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{student.points} pts</div>
                            <div className="text-xs text-slate-400">Level {student.level + 1}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Level Progress */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle>Level Progress Overview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {overview.levelStats.map((level) => (
                        <div key={level.levelId} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Badge className={`${getDifficultyColor(level.difficulty)} text-white`}>
                                {level.difficulty}
                              </Badge>
                              <span className="font-medium">{level.title}</span>
                            </div>
                            <span className="text-sm text-slate-400">
                              {level.completions} completions
                            </span>
                          </div>
                          <Progress value={level.completionRate} className="h-2" />
                          <div className="flex items-center justify-between text-xs text-slate-400">
                            <span>{level.completionRate.toFixed(1)}% completion rate</span>
                            <span>{level.averageAttemptsPerTask.toFixed(1)} avg attempts</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>

          {/* Students Tab */}
          <TabsContent value="students" className="space-y-6">
            {/* Filters */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle>Student Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4">
                  <div className="flex-1">
                    <Label htmlFor="search">Search Students</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <Input
                        id="search"
                        placeholder="Search by name or email..."
                        className="bg-slate-700 border-slate-600 pl-10"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="w-32">
                    <Label htmlFor="level">Filter by Level</Label>
                    <Select value={levelFilter} onValueChange={setLevelFilter}>
                      <SelectTrigger className="bg-slate-700 border-slate-600">
                        <SelectValue placeholder="All levels" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All levels</SelectItem>
                        <SelectItem value="-1">Getting Started</SelectItem>
                        <SelectItem value="0">Basic File Ops</SelectItem>
                        <SelectItem value="1">File Management</SelectItem>
                        <SelectItem value="2">Content Ops</SelectItem>
                        <SelectItem value="3">User Management</SelectItem>
                        <SelectItem value="4">Advanced Ops</SelectItem>
                        <SelectItem value="5">Environment</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Students Table */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle>Registered Students</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Level</TableHead>
                      <TableHead>Points</TableHead>
                      <TableHead>Completed Tasks</TableHead>
                      <TableHead>Total Attempts</TableHead>
                      <TableHead>Last Active</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {students.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{student.name}</div>
                              <div className="text-sm text-slate-400">{student.email}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">Level {student.level + 1}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <Trophy className="h-4 w-4 text-yellow-400" />
                            <span>{student.points}</span>
                          </div>
                        </TableCell>
                        <TableCell>{student.completedTasks}</TableCell>
                        <TableCell>{student.totalAttempts}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4 text-slate-400" />
                            <span className="text-sm">
                              {new Date(student.lastActive).toLocaleDateString()}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => viewStudentDetails(student.id)}
                            className="border-slate-600 hover:bg-slate-700"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {/* Pagination */}
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-slate-400">
                    Page {currentPage} of {totalPages}
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                      className="border-slate-600 hover:bg-slate-700"
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages}
                      className="border-slate-600 hover:bg-slate-700"
                    >
                      Next
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {overview && (
              <>
                {/* Task Analysis */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle>Task Difficulty Analysis</CardTitle>
                    <CardDescription>Success rates and completion statistics for each task</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Task</TableHead>
                          <TableHead>Level</TableHead>
                          <TableHead>Total Attempts</TableHead>
                          <TableHead>Success Rate</TableHead>
                          <TableHead>Avg Attempts</TableHead>
                          <TableHead>Completions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {overview.taskAnalysis.map((task) => (
                          <TableRow key={task.taskId}>
                            <TableCell className="font-medium">{task.title}</TableCell>
                            <TableCell>
                              <Badge variant="outline">Level {task.levelId + 1}</Badge>
                            </TableCell>
                            <TableCell>{task.totalAttempts}</TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                <Progress value={task.successRate} className="h-2 w-16" />
                                <span className="text-sm">{task.successRate}%</span>
                              </div>
                            </TableCell>
                            <TableCell>{task.averageAttempts}</TableCell>
                            <TableCell>{task.completions}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                {/* Recent Activity */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle>Recent Activity (Last 7 Days)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {overview.recentActivity.map((activity, index) => (
                        <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-slate-700">
                          <span className="text-sm">
                            {new Date(activity.date).toLocaleDateString()}
                          </span>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-medium">{activity.attempts}</span>
                            <span className="text-xs text-slate-400">attempts</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Student Details Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="bg-slate-800 border-slate-700 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Student Details: {selectedStudent.student.name}</CardTitle>
                  <CardDescription>{selectedStudent.student.email}</CardDescription>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setSelectedStudent(null)}
                  className="border-slate-600 hover:bg-slate-700"
                >
                  Close
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Statistics */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Performance Statistics</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-700 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-blue-400">
                        {selectedStudent.statistics.completedTasks}
                      </div>
                      <div className="text-sm text-slate-400">Completed Tasks</div>
                    </div>
                    <div className="bg-slate-700 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-green-400">
                        {selectedStudent.statistics.completionRate.toFixed(1)}%
                      </div>
                      <div className="text-sm text-slate-400">Completion Rate</div>
                    </div>
                    <div className="bg-slate-700 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-400">
                        {selectedStudent.statistics.accuracy}%
                      </div>
                      <div className="text-sm text-slate-400">Accuracy</div>
                    </div>
                    <div className="bg-slate-700 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-purple-400">
                        {Math.round(selectedStudent.statistics.totalTimeSpent / 60)}m
                      </div>
                      <div className="text-sm text-slate-400">Time Spent</div>
                    </div>
                  </div>
                </div>

                {/* Progress by Level */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Progress by Level</h3>
                  <div className="space-y-3">
                    {selectedStudent.progressByLevel.map((levelProgress) => (
                      <div key={levelProgress.level.id} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{levelProgress.level.title}</span>
                          <span className="text-sm text-slate-400">
                            {levelProgress.completedTasks}/{levelProgress.totalTasks}
                          </span>
                        </div>
                        <Progress value={levelProgress.completionRate} className="h-2" />
                        <div className="text-xs text-slate-400">
                          {levelProgress.completionRate.toFixed(1)}% complete • {levelProgress.totalScore} pts
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recent Attempts */}
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-4">Recent Attempts</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Command</TableHead>
                      <TableHead>Result</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Hint Used</TableHead>
                      <TableHead>Timestamp</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedStudent.recentAttempts.map((attempt) => (
                      <TableRow key={attempt.id}>
                        <TableCell className="font-mono text-sm">{attempt.command}</TableCell>
                        <TableCell>
                          {attempt.isCorrect ? (
                            <CheckCircle className="h-4 w-4 text-green-400" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-400" />
                          )}
                        </TableCell>
                        <TableCell>{attempt.timeTaken}s</TableCell>
                        <TableCell>{attempt.hintUsed ? 'Yes' : 'No'}</TableCell>
                        <TableCell>
                          {new Date(attempt.timestamp).toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}