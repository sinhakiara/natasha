import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Mark the alert as read (resolved)
    const alert = await db.alert.update({
      where: { id },
      data: { isRead: true }
    })

    if (!alert) {
      return NextResponse.json({ error: 'Threat not found' }, { status: 404 })
    }

    return NextResponse.json({ 
      success: true,
      message: 'Threat resolved successfully',
      alert 
    })
  } catch (error) {
    console.error('Error resolving threat:', error)
    return NextResponse.json({ error: 'Failed to resolve threat' }, { status: 500 })
  }
}