import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : undefined
    const unreadOnly = searchParams.get('unreadOnly') === 'true'

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const where: any = { userId }
    if (unreadOnly) {
      where.isRead = false
    }

    const alerts = await db.alert.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json({ alerts })
  } catch (error) {
    console.error('Error fetching alerts:', error)
    return NextResponse.json({ error: 'Failed to fetch alerts' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, message, type, severity, sourceId, sourceType, userId, monitorId, leakId } = body

    if (!userId || !title || !message || !type || !severity) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const alert = await db.alert.create({
      data: {
        title,
        message,
        type,
        severity,
        sourceId,
        sourceType,
        userId,
        monitorId,
        leakId,
      },
    })

    // Emit real-time alert via WebSocket
    const { setupSocket } = await import('@/lib/socket')
    const io = setupSocket()
    
    io.emit('new_alert', {
      id: alert.id,
      title: alert.title,
      message: alert.message,
      type: alert.type,
      severity: alert.severity,
      sourceId: alert.sourceId,
      sourceType: alert.sourceType,
      timestamp: alert.createdAt.toISOString(),
      isRead: alert.isRead,
    })

    return NextResponse.json({ alert })
  } catch (error) {
    console.error('Error creating alert:', error)
    return NextResponse.json({ error: 'Failed to create alert' }, { status: 500 })
  }
}