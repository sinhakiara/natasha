import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; memberId: string }> }
) {
  try {
    const { id, memberId } = await params
    const organizationId = id

    // Check if member exists and belongs to the organization
    const member = await db.organizationMember.findUnique({
      where: {
        id: memberId,
        organizationId
      }
    })

    if (!member) {
      return NextResponse.json({ error: 'Member not found' }, { status: 404 })
    }

    // Don't allow removing the last admin
    const adminCount = await db.organizationMember.count({
      where: {
        organizationId,
        role: 'ADMIN'
      }
    })

    if (member.role === 'ADMIN' && adminCount === 1) {
      return NextResponse.json({ error: 'Cannot remove the last admin' }, { status: 400 })
    }

    // Remove the member
    await db.organizationMember.delete({
      where: { id: memberId }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error removing organization member:', error)
    return NextResponse.json({ error: 'Failed to remove organization member' }, { status: 500 })
  }
}