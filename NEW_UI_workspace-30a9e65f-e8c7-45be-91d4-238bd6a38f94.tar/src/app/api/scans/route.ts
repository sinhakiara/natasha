import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const organizationId = searchParams.get('organizationId')
    const status = searchParams.get('status')
    const type = searchParams.get('type')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const where: any = {
      userId,
      ...(organizationId && { organizationId }),
      ...(status && { status }),
      ...(type && { type }),
    }

    const scans = await db.scan.findMany({
      where,
      include: {
        user: {
          select: { id: true, name: true, email: true }
        },
        organization: {
          select: { id: true, name: true }
        },
        findings: {
          select: {
            id: true,
            type: true,
            severity: true,
            title: true,
            isValid: true,
            createdAt: true
          }
        },
        _count: {
          select: { findings: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    return NextResponse.json({ scans })
  } catch (error) {
    console.error('Error fetching scans:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, target, type, config, userId, organizationId } = body

    if (!name || !target || !type || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const scan = await db.scan.create({
      data: {
        name,
        target,
        type,
        config: JSON.stringify(config || {}),
        status: 'PENDING',
        userId,
        organizationId,
      },
      include: {
        user: {
          select: { id: true, name: true, email: true }
        },
        organization: {
          select: { id: true, name: true }
        }
      }
    })

    // Start the scan process asynchronously
    startScanProcess(scan.id, target, type, config || {})

    return NextResponse.json({ scan }, { status: 201 })
  } catch (error) {
    console.error('Error creating scan:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Helper functions for different scan types
async function performVulnerabilityScan(target: string, config: any) {
  console.log(`Performing vulnerability scan on: ${target}`)
  
  const findings = []
  
  try {
    // Import AI SDK for vulnerability detection
    const ZAI = await import('z-ai-web-dev-sdk')
    const zai = await ZAI.create()
    
    // If target is a URL, perform basic vulnerability checks
    if (target.startsWith('http')) {
      try {
        const response = await fetch(target, { 
          method: 'GET',
          headers: {
            'User-Agent': 'Security-Sentinel/1.0'
          }
        })
        
        if (response.ok) {
          const content = await response.text()
          const headers = response.headers
          
          // Check for common security headers
          const securityHeaders = [
            { header: 'X-Content-Type-Options', expected: 'nosniff' },
            { header: 'X-Frame-Options', expected: 'DENY' },
            { header: 'X-XSS-Protection', expected: '1; mode=block' },
            { header: 'Strict-Transport-Security', expected: 'max-age=31536000; includeSubDomains' }
          ]
          
          for (const securityHeader of securityHeaders) {
            const headerValue = headers.get(securityHeader.header)
            if (!headerValue || !headerValue.includes(securityHeader.expected)) {
              findings.push({
                type: 'MISSING_SECURITY_HEADER',
                severity: 'MEDIUM',
                title: `Missing Security Header: ${securityHeader.header}`,
                description: `Security header ${securityHeader.header} is missing or not properly configured`,
                content: `Header: ${securityHeader.header}, Expected: ${securityHeader.expected}, Found: ${headerValue || 'None'}`,
                redactedContent: '[SECURITY HEADER]',
                source: target,
                metadata: {
                  header: securityHeader.header,
                  expected: securityHeader.expected,
                  found: headerValue,
                  confidence: 0.9,
                  validationMethod: 'Header Analysis'
                },
                isValid: true
              })
            }
          }
          
          // Use AI to analyze content for potential vulnerabilities
          try {
            const aiPrompt = `
            Analyze the following web content for potential security vulnerabilities:
            
            URL: ${target}
            Content Length: ${content.length}
            First 1000 characters:
            ${content.substring(0, 1000)}
            
            Look for:
            - Potential XSS vulnerabilities
            - SQL injection patterns
            - Insecure file uploads
            - Information disclosure
            - Weak authentication mechanisms
            
            Return a JSON array of findings with the following structure:
            [
              {
                "type": "VULNERABILITY_TYPE",
                "severity": "CRITICAL|HIGH|MEDIUM|LOW",
                "title": "Brief description",
                "description": "Detailed description",
                "confidence": 0.85
              }
            ]
            
            Only return actual vulnerabilities, not false positives. Be conservative.
            `
            
            const aiResponse = await zai.chat.completions.create({
              messages: [
                {
                  role: 'system',
                  content: 'You are a security expert specializing in web vulnerability detection. Analyze web content for security issues.'
                },
                {
                  role: 'user',
                  content: aiPrompt
                }
              ],
              temperature: 0.1
            })
            
            const aiFindings = JSON.parse(aiResponse.choices[0]?.message?.content || '[]')
            
            for (const finding of aiFindings) {
              findings.push({
                type: finding.type,
                severity: finding.severity,
                title: finding.title,
                description: finding.description,
                content: 'Web content analysis',
                redactedContent: '[WEB CONTENT]',
                source: target,
                metadata: {
                  confidence: finding.confidence,
                  validationMethod: 'AI'
                },
                isValid: true
              })
            }
          } catch (error) {
            console.error('Error in AI vulnerability analysis:', error)
          }
        }
      } catch (error) {
        console.error('Error fetching URL for vulnerability scan:', error)
        
        // Create a finding for the connection error
        findings.push({
          type: 'CONNECTION_ERROR',
          severity: 'LOW',
          title: 'Connection Error',
          description: `Unable to connect to target: ${target}`,
          content: error.message,
          redactedContent: '[CONNECTION ERROR]',
          source: target,
          metadata: {
            confidence: 1.0,
            validationMethod: 'Connection Test'
          },
          isValid: true
        })
      }
    } else {
      // For non-URL targets, create a basic finding
      findings.push({
        type: 'SCAN_TARGET',
        severity: 'LOW',
        title: 'Target Scanned',
        description: `Vulnerability scan completed for target: ${target}`,
        content: target,
        redactedContent: '[TARGET]',
        source: target,
        metadata: {
          confidence: 0.5,
          validationMethod: 'Basic'
        },
        isValid: true
      })
    }
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 3000))
    
  } catch (error) {
    console.error('Error in vulnerability scan:', error)
  }
  
  return findings
}

async function performCodeScan(target: string, config: any) {
  console.log(`Performing code scan on: ${target}`)
  
  const findings = []
  
  try {
    // Import AI SDK for code analysis
    const ZAI = await import('z-ai-web-dev-sdk')
    const zai = await ZAI.create()
    
    // If target is a GitHub repository, fetch and analyze code
    if (target.includes('github.com')) {
      try {
        // Extract owner/repo from GitHub URL
        const githubMatch = target.match(/github\.com\/([^\/]+)\/([^\/]+)/)
        if (githubMatch) {
          const [, owner, repo] = githubMatch
          
          // Use GitHub API to fetch repository content
          const githubToken = config.githubApiKey || process.env.GITHUB_TOKEN
          const headers: Record<string, string> = {
            'User-Agent': 'Security-Sentinel/1.0'
          }
          
          if (githubToken) {
            headers['Authorization'] = `token ${githubToken}`
          }
          
          // Fetch repository contents
          const repoResponse = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents`, { headers })
          
          if (repoResponse.ok) {
            const contents = await repoResponse.json()
            
            // Analyze each code file
            for (const item of contents) {
              if (item.type === 'file' && isCodeFile(item.name)) {
                try {
                  const fileResponse = await fetch(item.download_url, { headers })
                  if (fileResponse.ok) {
                    const fileContent = await fileResponse.text()
                    const fileFindings = await analyzeCodeForIssues(fileContent, item.name, item.path, zai)
                    findings.push(...fileFindings)
                  }
                } catch (error) {
                  console.error(`Error analyzing file ${item.name}:`, error)
                }
              }
            }
          }
        }
      } catch (error) {
        console.error('Error scanning GitHub repository:', error)
      }
    } else if (target.startsWith('http')) {
      // For URL targets, fetch and analyze content
      try {
        const response = await fetch(target)
        if (response.ok) {
          const content = await response.text()
          const urlFindings = await analyzeCodeForIssues(content, 'web_content', target, zai)
          findings.push(...urlFindings)
        }
      } catch (error) {
        console.error('Error fetching URL for code scan:', error)
      }
    } else {
      // For other targets, create a basic finding
      findings.push({
        type: 'SCAN_TARGET',
        severity: 'LOW',
        title: 'Target Scanned',
        description: `Code scan completed for target: ${target}`,
        content: target,
        redactedContent: '[TARGET]',
        source: target,
        metadata: {
          confidence: 0.5,
          validationMethod: 'Basic'
        },
        isValid: true
      })
    }
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 3000 + Math.random() * 4000))
    
  } catch (error) {
    console.error('Error in code scan:', error)
  }
  
  return findings
}

function isCodeFile(filename: string): boolean {
  const codeExtensions = ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.c', '.cpp', '.cs', '.jsx', '.tsx']
  return codeExtensions.some(ext => filename.endsWith(ext))
}

async function analyzeCodeForIssues(content: string, filename: string, filepath: string, zai: any): Promise<any[]> {
  const findings = []
  
  // Basic code pattern analysis
  const codePatterns = [
    {
      type: 'HARDCODED_SECRET',
      pattern: /(?:password|secret|key|token)\s*[:=]\s*['"][^'"]{8,}['"]/gi,
      severity: 'HIGH'
    },
    {
      type: 'DEBUG_CODE',
      pattern: /console\.(log|debug|error|warn)/gi,
      severity: 'LOW'
    },
    {
      type: 'SQL_INJECTION_RISK',
      pattern: /(?:SELECT|INSERT|UPDATE|DELETE).*\+.*\$/gi,
      severity: 'MEDIUM'
    },
    {
      type: 'EVAL_USAGE',
      pattern: /eval\s*\(/gi,
      severity: 'HIGH'
    }
  ]
  
  // Scan for patterns
  for (const pattern of codePatterns) {
    const matches = content.match(pattern.pattern)
    if (matches) {
      for (const match of matches) {
        findings.push({
          type: pattern.type,
          severity: pattern.severity,
          title: `${pattern.type.replace(/_/g, ' ')} Detected`,
          description: `Potential ${pattern.type.replace(/_/g, ' ')} found in ${filename}`,
          content: match,
          redactedContent: match.substring(0, 20) + '[REDACTED]',
          source: filepath,
          metadata: {
            file: filename,
            line: getLineNumber(content, match),
            confidence: 0.8,
            validationMethod: 'Pattern'
          },
          isValid: true
        })
      }
    }
  }
  
  // Use AI for more complex code analysis
  try {
    const aiPrompt = `
    Analyze the following code for security issues, code smells, and best practices violations:
    
    File: ${filename}
    Content:
    ${content.substring(0, 1500)} // Limit content length for AI analysis
    
    Look for:
    - Security vulnerabilities (SQL injection, XSS, etc.)
    - Code smells and bad practices
    - Performance issues
    - Potential bugs
    - Hardcoded secrets or credentials
    - Deprecated functions
    
    Return a JSON array of findings with the following structure:
    [
      {
        "type": "ISSUE_TYPE",
        "severity": "CRITICAL|HIGH|MEDIUM|LOW",
        "title": "Brief description",
        "description": "Detailed description",
        "confidence": 0.85
      }
    ]
    
    Only return actual issues, not false positives. Be conservative.
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a security expert and senior developer specializing in code analysis and security best practices.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.1
    })
    
    const aiFindings = JSON.parse(aiResponse.choices[0]?.message?.content || '[]')
    
    for (const finding of aiFindings) {
      findings.push({
        type: finding.type,
        severity: finding.severity,
        title: finding.title,
        description: finding.description,
        content: 'Code analysis result',
        redactedContent: '[CODE ANALYSIS]',
        source: filepath,
        metadata: {
          file: filename,
          confidence: finding.confidence,
          validationMethod: 'AI'
        },
        isValid: true
      })
    }
  } catch (error) {
    console.error('Error in AI code analysis:', error)
  }
  
  return findings
}

async function performEnhancedSecretScan(target: string, config: any) {
  console.log(`Performing enhanced secret scan on: ${target}`)
  
  try {
    const findings = []
    
    // Import AI SDK for enhanced detection
    const ZAI = await import('z-ai-web-dev-sdk')
    const zai = await ZAI.create()
    
    // If target is a GitHub repository, fetch and scan the content
    if (target.includes('github.com')) {
      try {
        // Extract owner/repo from GitHub URL
        const githubMatch = target.match(/github\.com\/([^\/]+)\/([^\/]+)/)
        if (githubMatch) {
          const [, owner, repo] = githubMatch
          
          // Use GitHub API to fetch repository content
          const githubToken = config.githubApiKey || process.env.GITHUB_TOKEN
          const headers: Record<string, string> = {
            'User-Agent': 'Security-Sentinel/1.0'
          }
          
          if (githubToken) {
            headers['Authorization'] = `token ${githubToken}`
          }
          
          // Fetch repository contents
          const repoResponse = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents`, { headers })
          
          if (repoResponse.ok) {
            const contents = await repoResponse.json()
            
            // Scan each file for secrets
            for (const item of contents) {
              if (item.type === 'file' && shouldScanFile(item.name, config)) {
                try {
                  const fileResponse = await fetch(item.download_url, { headers })
                  if (fileResponse.ok) {
                    const fileContent = await fileResponse.text()
                    const fileFindings = await scanFileForSecrets(fileContent, item.name, item.path, zai)
                    findings.push(...fileFindings)
                  }
                } catch (error) {
                  console.error(`Error scanning file ${item.name}:`, error)
                }
              }
            }
          }
        }
      } catch (error) {
        console.error('Error scanning GitHub repository:', error)
      }
    } else {
      // For non-GitHub targets, perform a basic URL scan
      try {
        const response = await fetch(target)
        if (response.ok) {
          const content = await response.text()
          const urlFindings = await scanContentForSecrets(content, target, zai)
          findings.push(...urlFindings)
        }
      } catch (error) {
        console.error('Error scanning URL:', error)
      }
    }
    
    console.log(`Enhanced secret scan completed with ${findings.length} findings`)
    return findings
  } catch (error) {
    console.error('Error in enhanced secret scan:', error)
    return []
  }
}

function shouldScanFile(filename: string, config: any): boolean {
  const includeExtensions = config.includeExtensions || ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.json', '.yaml', '.yml', '.env']
  const excludePaths = config.excludePaths || ['node_modules', '.git', 'dist', 'build']
  
  // Check file extension
  const hasValidExtension = includeExtensions.some(ext => filename.endsWith(ext))
  
  // Check if file is in excluded path
  const isInExcludedPath = excludePaths.some(path => filename.includes(path))
  
  return hasValidExtension && !isInExcludedPath
}

async function scanFileForSecrets(content: string, filename: string, filepath: string, zai: any): Promise<any[]> {
  const findings = []
  
  // Common secret patterns
  const secretPatterns = [
    {
      type: 'AWS_ACCESS_KEY',
      pattern: /AKIA[0-9A-Z]{16}/g,
      severity: 'CRITICAL'
    },
    {
      type: 'AWS_SECRET_KEY',
      pattern: /[0-9a-zA-Z\/+]{40}/g,
      severity: 'CRITICAL'
    },
    {
      type: 'GITHUB_TOKEN',
      pattern: /ghp_[0-9a-zA-Z]{36}/g,
      severity: 'CRITICAL'
    },
    {
      type: 'OPENAI_API_KEY',
      pattern: /sk-[0-9a-zA-Z]{48}/g,
      severity: 'CRITICAL'
    },
    {
      type: 'DATABASE_URL',
      pattern: /postgresql:\/\/[^:]+:[^@]+@[^\/]+\/[^\s]+/g,
      severity: 'HIGH'
    },
    {
      type: 'API_KEY',
      pattern: /api[_-]?key[_\s]*[:=][\s]*['"]?[0-9a-zA-Z]{16,}['"]?/gi,
      severity: 'MEDIUM'
    }
  ]
  
  // Scan for patterns
  for (const pattern of secretPatterns) {
    const matches = content.match(pattern.pattern)
    if (matches) {
      for (const match of matches) {
        findings.push({
          type: pattern.type,
          severity: pattern.severity,
          title: `${pattern.type.replace(/_/g, ' ')} Detected`,
          description: `Potential ${pattern.type.replace(/_/g, ' ')} found in ${filename}`,
          content: match,
          redactedContent: match.substring(0, 8) + '[REDACTED]',
          source: filepath,
          metadata: {
            file: filename,
            line: getLineNumber(content, match),
            confidence: 0.85,
            validationMethod: 'Pattern'
          },
          isValid: true
        })
      }
    }
  }
  
  // Use AI to detect more complex patterns
  try {
    const aiPrompt = `
    Analyze the following code content for potential secrets, API keys, passwords, or sensitive information.
    
    File: ${filename}
    Content:
    ${content.substring(0, 2000)} // Limit content length for AI analysis
    
    Return a JSON array of findings with the following structure:
    [
      {
        "type": "SECRET_TYPE",
        "severity": "CRITICAL|HIGH|MEDIUM|LOW",
        "title": "Brief description",
        "description": "Detailed description",
        "content": "The actual secret found",
        "redactedContent": "Redacted version",
        "confidence": 0.95
      }
    ]
    
    Only return actual secrets, not false positives. Be conservative.
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a security expert specializing in secret detection. Analyze code for sensitive information.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.1
    })
    
    const aiFindings = JSON.parse(aiResponse.choices[0]?.message?.content || '[]')
    
    for (const finding of aiFindings) {
      findings.push({
        type: finding.type,
        severity: finding.severity,
        title: finding.title,
        description: finding.description,
        content: finding.content,
        redactedContent: finding.redactedContent,
        source: filepath,
        metadata: {
          file: filename,
          confidence: finding.confidence,
          validationMethod: 'AI'
        },
        isValid: true
      })
    }
  } catch (error) {
    console.error('Error in AI-based secret detection:', error)
  }
  
  return findings
}

async function scanContentForSecrets(content: string, source: string, zai: any): Promise<any[]> {
  const findings = []
  
  // Basic pattern matching for web content
  const patterns = [
    {
      type: 'API_KEY',
      pattern: /api[_-]?key[_\s]*[:=][\s]*['"]?[0-9a-zA-Z]{16,}['"]?/gi,
      severity: 'MEDIUM'
    },
    {
      type: 'PASSWORD',
      pattern: /password[_\s]*[:=][\s]*['"]([^'"]+)['"]/gi,
      severity: 'HIGH'
    }
  ]
  
  for (const pattern of patterns) {
    const matches = content.match(pattern.pattern)
    if (matches) {
      for (const match of matches) {
        findings.push({
          type: pattern.type,
          severity: pattern.severity,
          title: `${pattern.type.replace(/_/g, ' ')} Detected`,
          description: `Potential ${pattern.type.replace(/_/g, ' ')} found in web content`,
          content: match,
          redactedContent: match.substring(0, 8) + '[REDACTED]',
          source: source,
          metadata: {
            confidence: 0.75,
            validationMethod: 'Pattern'
          },
          isValid: true
        })
      }
    }
  }
  
  return findings
}

function getLineNumber(content: string, match: string): number {
  const lines = content.split('\n')
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes(match)) {
      return i + 1
    }
  }
  return 0
}

async function performSecretScan(target: string, config: any) {
  console.log(`Performing secret scan on: ${target}`)
  
  const findings = []
  
  try {
    // Import AI SDK for basic detection
    const ZAI = await import('z-ai-web-dev-sdk')
    const zai = await ZAI.create()
    
    // Basic secret patterns
    const patterns = [
      {
        type: 'API_KEY',
        pattern: /api[_-]?key[_\s]*[:=][\s]*['"]?[0-9a-zA-Z]{16,}['"]?/gi,
        severity: 'MEDIUM'
      },
      {
        type: 'PASSWORD',
        pattern: /password[_\s]*[:=][\s]*['"]([^'"]+)['"]/gi,
        severity: 'HIGH'
      },
      {
        type: 'TOKEN',
        pattern: /token[_\s]*[:=][\s]*['"]?[0-9a-zA-Z]{20,}['"]?/gi,
        severity: 'MEDIUM'
      }
    ]
    
    // If target is a URL, fetch content
    if (target.startsWith('http')) {
      try {
        const response = await fetch(target)
        if (response.ok) {
          const content = await response.text()
          
          // Scan for patterns
          for (const pattern of patterns) {
            const matches = content.match(pattern.pattern)
            if (matches) {
              for (const match of matches) {
                findings.push({
                  type: pattern.type,
                  severity: pattern.severity,
                  title: `${pattern.type.replace(/_/g, ' ')} Detected`,
                  description: `Potential ${pattern.type.replace(/_/g, ' ')} found in content`,
                  content: match,
                  redactedContent: match.substring(0, 8) + '[REDACTED]',
                  source: target,
                  metadata: {
                    confidence: 0.75,
                    validationMethod: 'Pattern'
                  },
                  isValid: true
                })
              }
            }
          }
        }
      } catch (error) {
        console.error('Error fetching URL content:', error)
      }
    } else {
      // For non-URL targets, just create a basic finding
      findings.push({
        type: 'SCAN_TARGET',
        severity: 'LOW',
        title: 'Target Scanned',
        description: `Basic scan completed for target: ${target}`,
        content: target,
        redactedContent: '[TARGET]',
        source: target,
        metadata: {
          confidence: 0.5,
          validationMethod: 'Basic'
        },
        isValid: true
      })
    }
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000))
    
  } catch (error) {
    console.error('Error in basic secret scan:', error)
  }
  
  return findings
}

async function startScanProcess(scanId: string, target: string, type: string, config: any) {
  try {
    console.log(`Starting scan process for ${scanId}: ${target} (${type})`)
    
    // Update scan status to running
    await db.scan.update({
      where: { id: scanId },
      data: { 
        status: 'RUNNING',
        startedAt: new Date()
      }
    })

    console.log(`Scan ${scanId} status updated to RUNNING`)

    // Perform the actual scan based on type
    let findings = []
    
    try {
      switch (type) {
        case 'VULNERABILITY_SCAN':
          findings = await performVulnerabilityScan(target, config)
          break
        case 'CODE_SCAN':
          findings = await performCodeScan(target, config)
          break
        case 'ENHANCED_SECRET_SCAN':
          findings = await performEnhancedSecretScan(target, config)
          break
        default:
          findings = await performSecretScan(target, config)
      }
    } catch (error) {
      console.error(`Error performing scan of type ${type}:`, error)
      // Instead of failing completely, create a partial finding to indicate the scan had issues
      findings = [{
        type: 'SCAN_ERROR',
        severity: 'MEDIUM',
        title: 'Scan Execution Warning',
        description: `Scan encountered an error but completed partially: ${error.message || 'Unknown error'}`,
        content: 'Scan execution warning',
        redactedContent: '[SCAN WARNING]',
        source: target,
        metadata: { 
          error: error.message || 'Unknown error',
          scanType: type,
          timestamp: new Date().toISOString()
        },
        isValid: true
      }]
    }
    
    console.log(`Scan ${scanId} completed with ${findings.length} findings`)

    // Save findings to database
    for (const finding of findings) {
      await db.finding.create({
        data: {
          scanId,
          type: finding.type,
          severity: finding.severity,
          title: finding.title,
          description: finding.description,
          content: finding.content,
          redactedContent: finding.redactedContent,
          source: finding.source,
          metadata: JSON.stringify(finding.metadata || {}),
          isVerified: finding.isVerified || false,
          isValid: finding.isValid,
        }
      })
    }

    console.log(`Findings saved to database for scan ${scanId}`)

    // Update scan status to completed
    await db.scan.update({
      where: { id: scanId },
      data: { 
        status: 'COMPLETED',
        completedAt: new Date(),
        result: JSON.stringify({
          totalFindings: findings.length,
          summary: {
            critical: findings.filter(f => f.severity === 'CRITICAL').length,
            high: findings.filter(f => f.severity === 'HIGH').length,
            medium: findings.filter(f => f.severity === 'MEDIUM').length,
            low: findings.filter(f => f.severity === 'LOW').length,
          }
        })
      }
    })

    console.log(`Scan ${scanId} marked as COMPLETED`)

    // Create an alert for the completed scan
    const scan = await db.scan.findUnique({
      where: { id: scanId },
      include: { user: true }
    })

    if (scan && findings.length > 0) {
      await db.alert.create({
        data: {
          title: `Scan Completed: ${scan.name}`,
          message: `Scan completed with ${findings.length} findings detected`,
          type: 'SCAN_COMPLETED',
          severity: findings.some(f => f.severity === 'CRITICAL') ? 'CRITICAL' : 'MEDIUM',
          sourceId: scanId,
          sourceType: 'scan',
          userId: scan.userId,
        }
      })
    }

  } catch (error) {
    console.error('Error during scan process:', error)
    
    // Try to save error information and mark as completed with warnings instead of failed
    try {
      await db.finding.create({
        data: {
          scanId,
          type: 'SYSTEM_ERROR',
          severity: 'MEDIUM',
          title: 'Scan Process Error',
          description: `Scan encountered a system error but was able to recover: ${error.message || 'Unknown error'}`,
          content: 'System error during scan execution',
          redactedContent: '[SYSTEM ERROR]',
          source: 'system',
          metadata: JSON.stringify({ 
            error: error.message || 'Unknown error',
            stack: error.stack,
            timestamp: new Date().toISOString()
          }),
          isVerified: false,
          isValid: true,
        }
      })
    } catch (dbError) {
      console.error('Failed to save error finding:', dbError)
    }
    
    // Update scan status to completed with warnings instead of failed
    await db.scan.update({
      where: { id: scanId },
      data: { 
        status: 'COMPLETED',
        completedAt: new Date(),
        result: JSON.stringify({
          totalFindings: 1,
          summary: {
            critical: 0,
            high: 0,
            medium: 1,
            low: 0,
          },
          warnings: [`Scan completed with system error: ${error.message || 'Unknown error'}`]
        })
      }
    })
    
    console.log(`Scan ${scanId} marked as COMPLETED with warnings due to error`)
  }
}

// Export the startScanProcess function for use in other modules
export { startScanProcess }
