import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const query = await db.zoomEyeQuery.findUnique({
      where: { id }
    })

    if (!query) {
      return NextResponse.json({ error: 'Query not found' }, { status: 404 })
    }

    return NextResponse.json({ query })
  } catch (error) {
    console.error('Error fetching query:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}