import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : undefined

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const queries = await db.zoomEyeQuery.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json({ queries })
  } catch (error) {
    console.error('Error fetching ZoomEye queries:', error)
    return NextResponse.json({ error: 'Failed to fetch ZoomEye queries' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { query, type, userId, scope } = body

    if (!userId || !query || !type) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const zoomEyeQuery = await db.zoomEyeQuery.create({
      data: {
        query,
        type,
        scope,
        userId,
        status: 'PENDING',
      },
    })

    // Simulate ZoomEye query execution (in real app, this would call ZoomEye API)
    setTimeout(async () => {
      try {
        // Generate mock results based on the query type and content
        const generateMockHostname = (query: string, type: string, scope: string, index: number) => {
          // If scope is provided and looks like a domain, use it
          if (scope && scope.includes('domain:')) {
            const domain = scope.split('domain:')[1]?.split(' ')[0] || scope.split(' ')[0] || 'example.com'
            return `host-${index + 1}.${domain}`
          }
          // If scope is provided and looks like an IP range, use it
          if (scope && scope.match(/\d+\.\d+\.\d+\.\d+/)) {
            const baseIp = scope.match(/\d+\.\d+\.\d+\.\d+/)?.[0] || '192.168.1'
            return `${baseIp}.${index + 1}`
          }
          
          if (type === 'DOMAIN' && query.includes('domain:')) {
            const domain = query.split('domain:')[1]?.split(' ')[0] || query.split(' ')[0] || 'example.com'
            return `host-${index + 1}.${domain}`
          } else if (type === 'HOST' && query.includes('port:')) {
            const port = query.match(/port:(\d+)/)?.[1] || '80'
            return `server-${index + 1}-port${port}.local`
          } else if (type === 'WEB' && query.includes('title:')) {
            const title = query.match(/title:"([^"]+)"/)?.[1] || 'admin'
            return `${title.toLowerCase().replace(/\s+/g, '-')}-${index + 1}.com`
          } else if (type === 'WEB' && query.includes('server:')) {
            const server = query.match(/server:"([^"]+)"/)?.[1] || 'nginx'
            return `${server.toLowerCase()}-${index + 1}.com`
          } else {
            // Generic fallback based on query content - extract domain from user input
            const queryWords = query.toLowerCase().split(/[\s+:]+/)
            const relevantWord = queryWords.find(word => 
              word.length > 2 && !['port', 'app', 'ssl', 'ssh', 'http', 'https'].includes(word)
            )
            
            // Check if there's a domain-like word in the query
            const domainWord = queryWords.find(word => 
              word.includes('.') && word.length > 4
            )
            
            if (domainWord) {
              return `host-${index + 1}.${domainWord}`
            }
            
            const baseWord = relevantWord || 'target'
            return `${baseWord}-${index + 1}.com`
          }
        }

        const mockResults = {
          total: Math.floor(Math.random() * 1000) + 10,
          data: Array.from({ length: Math.min(5, Math.floor(Math.random() * 10) + 1) }, (_, i) => ({
            ip: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 254) + 1}`,
            hostname: generateMockHostname(query, type, scope || '', i),
            port: [80, 443, 22, 21, 25, 53, 110, 143, 993, 995][Math.floor(Math.random() * 10)],
            banner: ['Apache/2.4.41', 'nginx/1.18.0', 'OpenSSH/7.6p1', 'Microsoft-IIS/10.0'][Math.floor(Math.random() * 4)],
            location: {
              country: ['US', 'GB', 'DE', 'JP', 'CN'][Math.floor(Math.random() * 5)],
              city: ['New York', 'London', 'Berlin', 'Tokyo', 'Beijing'][Math.floor(Math.random() * 5)]
            }
          }))
        }

        await db.zoomEyeQuery.update({
          where: { id: zoomEyeQuery.id },
          data: {
            status: 'COMPLETED',
            result: JSON.stringify(mockResults)
          }
        })
      } catch (error) {
        console.error('Error updating ZoomEye query:', error)
        await db.zoomEyeQuery.update({
          where: { id: zoomEyeQuery.id },
          data: {
            status: 'FAILED',
            result: JSON.stringify({ error: 'Query execution failed' })
          }
        })
      }
    }, 3000) // 3 second delay for demo

    return NextResponse.json({ query: zoomEyeQuery })
  } catch (error) {
    console.error('Error creating ZoomEye query:', error)
    return NextResponse.json({ error: 'Failed to create ZoomEye query' }, { status: 500 })
  }
}