import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const organizationId = searchParams.get('organizationId')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const monitors = await db.monitor.findMany({
      where: {
        userId,
        ...(organizationId && { organizationId }),
      },
      include: {
        user: {
          select: { id: true, name: true, email: true }
        },
        organization: {
          select: { id: true, name: true }
        },
        leaks: {
          orderBy: { createdAt: 'desc' },
          take: 5
        },
        _count: {
          select: { leaks: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ monitors })
  } catch (error) {
    console.error('Error fetching monitors:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, type, target, config, userId, organizationId } = body

    if (!name || !type || !target || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const monitor = await db.monitor.create({
      data: {
        name,
        type,
        target,
        config: JSON.stringify(config || {}),
        userId,
        organizationId,
      },
      include: {
        user: {
          select: { id: true, name: true, email: true }
        },
        organization: {
          select: { id: true, name: true }
        },
        _count: {
          select: { leaks: true }
        }
      }
    })

    // TODO: Start actual monitoring process here
    // This would involve setting up GitHub webhook monitoring or polling

    return NextResponse.json({ monitor }, { status: 201 })
  } catch (error) {
    console.error('Error creating monitor:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const monitorId = searchParams.get('id')
    const userId = searchParams.get('userId')

    if (!monitorId) {
      return NextResponse.json({ error: 'Monitor ID is required' }, { status: 400 })
    }

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Verify the monitor belongs to the user
    const monitor = await db.monitor.findFirst({
      where: {
        id: monitorId,
        userId: userId
      }
    })

    if (!monitor) {
      return NextResponse.json({ error: 'Monitor not found or access denied' }, { status: 404 })
    }

    // Delete associated leaks first
    await db.leak.deleteMany({
      where: {
        monitorId: monitorId
      }
    })

    // Delete the monitor
    await db.monitor.delete({
      where: {
        id: monitorId
      }
    })

    return NextResponse.json({ message: 'Monitor deleted successfully' })
  } catch (error) {
    console.error('Error deleting monitor:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}