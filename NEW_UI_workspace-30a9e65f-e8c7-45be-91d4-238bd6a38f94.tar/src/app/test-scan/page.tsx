'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Play, Trash2, AlertTriangle, CheckCircle, Clock, FileText } from 'lucide-react'

interface Scan {
  id: string
  name: string
  target: string
  type: string
  status: string
  startedAt?: string
  completedAt?: string
  createdAt: string
  findings: any[]
  _count: {
    findings: number
  }
}

export default function TestScanPage() {
  const [scans, setScans] = useState<Scan[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [testTarget, setTestTarget] = useState('https://httpbin.org/headers')
  const [testType, setTestType] = useState('SECRET_SCAN')
  const [logs, setLogs] = useState<string[]>([])

  const addLog = (message: string) => {
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  const fetchScans = async () => {
    try {
      setIsLoading(true)
      const response = await fetch('/api/scans/test')
      if (response.ok) {
        const data = await response.json()
        setScans(data.scans || [])
        addLog(`Fetched ${data.scans.length} scans (${data.scansWithFindings} with findings)`)
      }
    } catch (error) {
      addLog(`Error fetching scans: ${error}`)
    } finally {
      setIsLoading(false)
    }
  }

  const createTestScan = async () => {
    try {
      setIsCreating(true)
      addLog(`Creating test scan for: ${testTarget}`)

      const response = await fetch('/api/scans/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          target: testTarget,
          type: testType
        })
      })

      if (response.ok) {
        const data = await response.json()
        addLog(`Test scan created: ${data.scan.id} - ${data.scan.name}`)
        setScans(prev => [data.scan, ...prev])
      } else {
        const error = await response.json()
        addLog(`Error creating scan: ${error.error}`)
      }
    } catch (error) {
      addLog(`Error creating test scan: ${error}`)
    } finally {
      setIsCreating(false)
    }
  }

  const clearScans = async () => {
    try {
      addLog('Clearing all scans...')
      // This would normally be a DELETE request, but for testing we'll just refresh
      await fetchScans()
      addLog('Scans cleared')
    } catch (error) {
      addLog(`Error clearing scans: ${error}`)
    }
  }

  useEffect(() => {
    fetchScans()
    
    // Set up polling for scan updates
    const interval = setInterval(() => {
      fetchScans()
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <Clock className="h-3 w-3 animate-spin" />
      case 'FAILED':
        return <AlertTriangle className="h-3 w-3" />
      case 'PENDING':
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Scan Testing</h1>
        <p className="text-muted-foreground">
          Test the secret scanning functionality
        </p>
      </div>

      {/* Test Controls */}
      <Card>
        <CardHeader>
          <CardTitle>Test Controls</CardTitle>
          <CardDescription>Create and monitor test scans</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium">Target URL</label>
              <Input
                placeholder="https://example.com"
                value={testTarget}
                onChange={(e) => setTestTarget(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Scan Type</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={testType}
                onChange={(e) => setTestType(e.target.value)}
              >
                <option value="SECRET_SCAN">Secret Scan</option>
                <option value="VULNERABILITY_SCAN">Vulnerability Scan</option>
                <option value="CODE_SCAN">Code Scan</option>
              </select>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={createTestScan} 
              disabled={isCreating}
            >
              <Play className="h-4 w-4 mr-2" />
              {isCreating ? 'Creating...' : 'Create Test Scan'}
            </Button>
            
            <Button 
              variant="outline"
              onClick={fetchScans}
            >
              Refresh
            </Button>
            
            <Button 
              variant="outline"
              onClick={clearScans}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Clear
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Logs */}
      <Card>
        <CardHeader>
          <CardTitle>Activity Logs</CardTitle>
          <CardDescription>Real-time scan activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm h-64 overflow-y-auto">
            {logs.length === 0 ? (
              <div className="text-gray-500">No activity yet...</div>
            ) : (
              logs.map((log, index) => (
                <div key={index}>{log}</div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Scans */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Scans</CardTitle>
          <CardDescription>Latest test scan results</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div>Loading...</div>
          ) : scans.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-500">No scans yet. Create a test scan to get started.</div>
            </div>
          ) : (
            <div className="space-y-4">
              {scans.map((scan) => (
                <div key={scan.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-sm font-medium text-gray-900 truncate">
                          {scan.name}
                        </h3>
                        <Badge className={getStatusColor(scan.status)}>
                          {getStatusIcon(scan.status)}
                          {scan.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 truncate">
                        {scan.target}
                      </p>
                      <p className="text-xs text-gray-400">
                        {scan.type} • {new Date(scan.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">Findings:</span>
                      <Badge variant={scan._count.findings > 0 ? 'destructive' : 'secondary'}>
                        {scan._count.findings}
                      </Badge>
                    </div>
                    
                    {scan._count.findings > 0 && (
                      <Button variant="ghost" size="sm">
                        <FileText className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}