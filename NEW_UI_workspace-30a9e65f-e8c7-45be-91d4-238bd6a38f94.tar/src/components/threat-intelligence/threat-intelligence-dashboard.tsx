'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Shield, 
  Eye, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Globe,
  Database,
  Search,
  Bug,
  Key,
  Network,
  FileText,
  TrendingUp,
  TrendingDown,
  Activity,
  Target,
  Lock,
  Unlock,
  Wifi,
  WifiOff,
  RefreshCw,
  Filter,
  Download,
  Share2,
  Settings,
  Users,
  Building,
  MapPin,
  Calendar,
  BarChart3,
  PieChart,
  LineChart
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { useSocket } from '@/hooks/useSocket'

interface Threat {
  id: string
  type: 'data_breach' | 'malware' | 'phishing' | 'vulnerability' | 'dark_web' | 'brand_impersonation'
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  title: string
  description: string
  source: string
  url?: string
  affectedAssets: string[]
  tags: string[]
  confidence: number
  firstSeen: string
  lastSeen: string
  status: 'active' | 'investigating' | 'resolved' | 'false_positive'
  mitigation?: string
  impact: {
    financial?: number
    reputational?: number
    operational?: number
  }
}

interface ThreatIntelligenceMetrics {
  totalThreats: number
  activeThreats: number
  criticalThreats: number
  resolvedThreats: number
  falsePositives: number
  averageResponseTime: number
  threatsByType: Record<string, number>
  threatsBySeverity: Record<string, number>
  trends: {
    daily: Array<{ date: string; count: number }>
    weekly: Array<{ week: string; count: number }>
    monthly: Array<{ month: string; count: number }>
  }
}

interface DarkWebListing {
  id: string
  type: 'data_sale' | 'credential_leak' | 'malware' | 'services' | 'fraud'
  title: string
  description: string
  price?: string
  currency?: string
  seller: string
  marketplace: string
  listingDate: string
  lastSeen: string
  threatLevel: 'critical' | 'high' | 'medium' | 'low'
  dataTypes: string[]
  estimatedRecords?: number
  verified: boolean
}

export function ThreatIntelligenceDashboard() {
  const { data: session } = useSession()
  const [threats, setThreats] = useState<Threat[]>([])
  const [darkWebListings, setDarkWebListings] = useState<DarkWebListing[]>([])
  const [metrics, setMetrics] = useState<ThreatIntelligenceMetrics | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedThreat, setSelectedThreat] = useState<Threat | null>(null)
  const [filters, setFilters] = useState({
    type: '',
    severity: '',
    status: '',
    timeframe: '7d'
  })
  const [darkWebFilters, setDarkWebFilters] = useState({
    keywords: '',
    domains: '',
    ips: ''
  })
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const { toast } = useToast()

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3'

  // Initialize socket connection
  const { 
    socket, 
    isConnected, 
    joinThreatRoom, 
    leaveThreatRoom,
    onThreatUpdate,
    offThreatUpdate
  } = useSocket({ userId, autoConnect: true })

  // Handle real-time threat updates
  useEffect(() => {
    if (isConnected) {
      const handleThreatUpdate = (data: { threat: Threat; action: string }) => {
        console.log('Real-time threat update:', data)
        
        if (data.action === 'new') {
          setThreats(prev => [data.threat, ...prev])
          toast({
            title: "New Threat Detected",
            description: `${data.threat.title} - ${data.threat.severity.toUpperCase()}`,
            variant: "destructive"
          })
        } else if (data.action === 'update') {
          setThreats(prev => 
            prev.map(threat => 
              threat.id === data.threat.id ? data.threat : threat
            )
          )
        } else if (data.action === 'resolve') {
          setThreats(prev => 
            prev.map(threat => 
              threat.id === data.threat.id 
                ? { ...threat, status: 'resolved' as const }
                : threat
            )
          )
        }
        
        setLastUpdate(new Date())
      }

      // Subscribe to threat updates
      onThreatUpdate(handleThreatUpdate)

      return () => {
        offThreatUpdate(handleThreatUpdate)
      }
    }
  }, [isConnected, onThreatUpdate, offThreatUpdate, toast])

  useEffect(() => {
    fetchThreatIntelligence()
  }, [filters, darkWebFilters])

  const fetchThreatIntelligence = async () => {
    try {
      setIsLoading(true)
      
      // Fetch threats
      const threatsResponse = await fetch(`/api/threat-intelligence/threats?userId=${userId}&${new URLSearchParams(filters as any)}`)
      if (threatsResponse.ok) {
        const threatsData = await threatsResponse.json()
        setThreats(threatsData.threats || [])
      }

      // Fetch dark web listings
      const darkWebParams = new URLSearchParams()
      darkWebParams.append('userId', userId)
      if (darkWebFilters.keywords) darkWebParams.append('keywords', darkWebFilters.keywords)
      if (darkWebFilters.domains) darkWebParams.append('domains', darkWebFilters.domains)
      if (darkWebFilters.ips) darkWebParams.append('ips', darkWebFilters.ips)
      
      const darkWebResponse = await fetch(`/api/threat-intelligence/dark-web?${darkWebParams.toString()}`)
      if (darkWebResponse.ok) {
        const darkWebData = await darkWebResponse.json()
        setDarkWebListings(darkWebData.listings || [])
      }

      // Fetch metrics
      const metricsResponse = await fetch(`/api/threat-intelligence/metrics?userId=${userId}`)
      if (metricsResponse.ok) {
        const metricsData = await metricsResponse.json()
        setMetrics(metricsData.metrics)
      }
    } catch (error) {
      console.error('Error fetching threat intelligence:', error)
      toast({
        title: "Error",
        description: "Failed to fetch threat intelligence data",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getThreatTypeIcon = (type: string) => {
    switch (type) {
      case 'data_breach': return <Database className="h-4 w-4" />
      case 'malware': return <Bug className="h-4 w-4" />
      case 'phishing': return <Eye className="h-4 w-4" />
      case 'vulnerability': return <Shield className="h-4 w-4" />
      case 'dark_web': return <Globe className="h-4 w-4" />
      case 'brand_impersonation': return <Building className="h-4 w-4" />
      default: return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-red-100 text-red-800 border-red-200'
      case 'investigating': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'resolved': return 'bg-green-100 text-green-800 border-green-200'
      case 'false_positive': return 'bg-gray-100 text-gray-800 border-gray-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <AlertTriangle className="h-3 w-3" />
      case 'investigating': return <Clock className="h-3 w-3 animate-spin" />
      case 'resolved': return <CheckCircle className="h-3 w-3" />
      case 'false_positive': return <Activity className="h-3 w-3" />
      default: return <Clock className="h-3 w-3" />
    }
  }

  const formatConfidence = (confidence: number) => {
    return `${Math.round(confidence * 100)}%`
  }

  const formatImpact = (impact: any) => {
    if (!impact) return 'N/A'
    const values = Object.values(impact).filter(v => v !== undefined)
    if (values.length === 0) return 'N/A'
    return `$${values.reduce((sum, val) => sum + (val as number), 0).toLocaleString()}`
  }

  const handleInvestigateThreat = (threat: Threat) => {
    setSelectedThreat(threat)
    // In a real implementation, this would open a detailed investigation view
    toast({
      title: "Investigation Started",
      description: `Investigating: ${threat.title}`,
    })
  }

  const handleResolveThreat = async (threatId: string) => {
    try {
      const response = await fetch(`/api/threat-intelligence/threats/${threatId}/resolve`, {
        method: 'POST'
      })

      if (response.ok) {
        setThreats(prev => 
          prev.map(threat => 
            threat.id === threatId 
              ? { ...threat, status: 'resolved' as const }
              : threat
          )
        )
        toast({
          title: "Threat Resolved",
          description: "Threat has been marked as resolved",
        })
      }
    } catch (error) {
      console.error('Error resolving threat:', error)
      toast({
        title: "Error",
        description: "Failed to resolve threat",
        variant: "destructive"
      })
    }
  }

  const getDarkWebThreatIcon = (type: string) => {
    switch (type) {
      case 'data_sale': return <Database className="h-4 w-4" />
      case 'credential_leak': return <Key className="h-4 w-4" />
      case 'malware': return <Bug className="h-4 w-4" />
      case 'services': return <Settings className="h-4 w-4" />
      case 'fraud': return <AlertTriangle className="h-4 w-4" />
      default: return <Globe className="h-4 w-4" />
    }
  }

  return (
    <RBACGuard requiredRoles={['ADMIN', 'MEMBER', 'VIEWER']}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Threat Intelligence Dashboard</h2>
            <p className="text-muted-foreground">
              Real-time threat monitoring and dark web intelligence inspired by CloudSEK XVigil
            </p>
          </div>
          <div className="flex items-center space-x-2">
            {isConnected ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Wifi className="h-3 w-3 mr-1" />
                Live Intelligence
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                <WifiOff className="h-3 w-3 mr-1" />
                Offline
              </Badge>
            )}
            {lastUpdate && (
              <span className="text-xs text-muted-foreground">
                Last update: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={fetchThreatIntelligence}
              disabled={isLoading}
            >
              {isLoading ? (
                <Clock className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Refresh
            </Button>
          </div>
        </div>

        {/* Metrics Overview */}
        {metrics && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Threats</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics.totalThreats}</div>
                <p className="text-xs text-muted-foreground">
                  {metrics.activeThreats} active threats
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Critical Threats</CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{metrics.criticalThreats}</div>
                <p className="text-xs text-muted-foreground">
                  Require immediate attention
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Resolved</CardTitle>
                <CheckCircle className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{metrics.resolvedThreats}</div>
                <p className="text-xs text-muted-foreground">
                  {metrics.averageResponseTime} avg response time
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">False Positives</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics.falsePositives}</div>
                <p className="text-xs text-muted-foreground">
                  Accuracy improving
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content Tabs */}
        <Tabs defaultValue="threats" className="space-y-4">
          <TabsList>
            <TabsTrigger value="threats">Active Threats</TabsTrigger>
            <TabsTrigger value="darkweb">Dark Web Monitoring</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
          </TabsList>

          <TabsContent value="threats" className="space-y-4">
            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Filter className="h-5 w-5" />
                  <span>Filters</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <select
                    className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={filters.type}
                    onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
                  >
                    <option value="">All Types</option>
                    <option value="data_breach">Data Breach</option>
                    <option value="malware">Malware</option>
                    <option value="phishing">Phishing</option>
                    <option value="vulnerability">Vulnerability</option>
                    <option value="dark_web">Dark Web</option>
                    <option value="brand_impersonation">Brand Impersonation</option>
                  </select>
                  <select
                    className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={filters.severity}
                    onChange={(e) => setFilters(prev => ({ ...prev, severity: e.target.value }))}
                  >
                    <option value="">All Severities</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                    <option value="info">Info</option>
                  </select>
                  <select
                    className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={filters.status}
                    onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                  >
                    <option value="">All Statuses</option>
                    <option value="active">Active</option>
                    <option value="investigating">Investigating</option>
                    <option value="resolved">Resolved</option>
                    <option value="false_positive">False Positive</option>
                  </select>
                  <select
                    className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={filters.timeframe}
                    onChange={(e) => setFilters(prev => ({ ...prev, timeframe: e.target.value }))}
                  >
                    <option value="24h">Last 24 Hours</option>
                    <option value="7d">Last 7 Days</option>
                    <option value="30d">Last 30 Days</option>
                    <option value="90d">Last 90 Days</option>
                  </select>
                </div>
              </CardContent>
            </Card>

            {/* Threats List */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Active Threats</CardTitle>
                    <CardDescription>
                      Real-time threat intelligence monitoring
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="animate-pulse">
                        <div className="h-24 bg-gray-200 rounded-lg"></div>
                      </div>
                    ))}
                  </div>
                ) : threats.length === 0 ? (
                  <div className="text-center py-8">
                    <Shield className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Threats</h3>
                    <p className="text-gray-500">Your threat intelligence monitoring is active and will alert you to any threats.</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {threats.map((threat) => (
                      <div key={threat.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3">
                            <div className="p-2 bg-red-100 rounded-lg">
                              {getThreatTypeIcon(threat.type)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="font-medium">{threat.title}</h3>
                                <Badge className={getSeverityColor(threat.severity)}>
                                  {threat.severity.toUpperCase()}
                                </Badge>
                                <Badge className={getStatusColor(threat.status)}>
                                  {getStatusIcon(threat.status)}
                                  <span className="ml-1">{threat.status.replace('_', ' ').toUpperCase()}</span>
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                {threat.description}
                              </p>
                              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                                <span className="flex items-center space-x-1">
                                  <Calendar className="h-3 w-3" />
                                  <span>First seen: {new Date(threat.firstSeen).toLocaleDateString()}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Target className="h-3 w-3" />
                                  <span>Confidence: {formatConfidence(threat.confidence)}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <TrendingUp className="h-3 w-3" />
                                  <span>Impact: {formatImpact(threat.impact)}</span>
                                </span>
                              </div>
                              <div className="flex items-center space-x-2 mt-2">
                                {threat.tags.map((tag, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {threat.status === 'active' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleInvestigateThreat(threat)}
                              >
                                <Search className="h-4 w-4" />
                              </Button>
                            )}
                            {threat.status !== 'resolved' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleResolveThreat(threat.id)}
                              >
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="darkweb" className="space-y-4">
            {/* Dark Web Monitoring Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>Monitoring Controls</span>
                </CardTitle>
                <CardDescription>
                  Configure specific keywords, domains, and IPs to monitor on the dark web
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Keywords</label>
                    <Input
                      placeholder="e.g., company name, brand, products (comma separated)"
                      value={darkWebFilters.keywords}
                      onChange={(e) => setDarkWebFilters(prev => ({ ...prev, keywords: e.target.value }))}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Monitor for specific keywords in dark web listings
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Domains</label>
                    <Input
                      placeholder="e.g., example.com, company.org (comma separated)"
                      value={darkWebFilters.domains}
                      onChange={(e) => setDarkWebFilters(prev => ({ ...prev, domains: e.target.value }))}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Monitor for mentions of specific domains
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">IP Addresses</label>
                    <Input
                      placeholder="e.g., 192.168.1.1, 10.0.0.1 (comma separated)"
                      value={darkWebFilters.ips}
                      onChange={(e) => setDarkWebFilters(prev => ({ ...prev, ips: e.target.value }))}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Monitor for mentions of specific IP addresses
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-gray-600">
                    {darkWebFilters.keywords || darkWebFilters.domains || darkWebFilters.ips ? (
                      <span className="text-green-600">
                        ✓ Active monitoring for {[
                          darkWebFilters.keywords && 'keywords',
                          darkWebFilters.domains && 'domains',
                          darkWebFilters.ips && 'IPs'
                        ].filter(Boolean).join(', ')}
                      </span>
                    ) : (
                      <span className="text-gray-500">
                        No specific monitoring targets set - showing all activity
                      </span>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setDarkWebFilters({ keywords: '', domains: '', ips: '' })
                      toast({
                        title: "Filters Cleared",
                        description: "Dark web monitoring filters have been reset",
                      })
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Dark Web Monitoring</CardTitle>
                <CardDescription>
                  Real-time monitoring of dark web marketplaces and forums
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="animate-pulse">
                        <div className="h-24 bg-gray-200 rounded-lg"></div>
                      </div>
                    ))}
                  </div>
                ) : darkWebListings.length === 0 ? (
                  <div className="text-center py-8">
                    <Globe className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Dark Web Activity</h3>
                    <p className="text-gray-500">Dark web monitoring is active and will alert you to any suspicious activity.</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {darkWebListings.map((listing) => (
                      <div key={listing.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3">
                            <div className="p-2 bg-purple-100 rounded-lg">
                              {getDarkWebThreatIcon(listing.type)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="font-medium">{listing.title}</h3>
                                <Badge className={getSeverityColor(listing.threatLevel)}>
                                  {listing.threatLevel.toUpperCase()}
                                </Badge>
                                {listing.verified && (
                                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                    Verified
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                {listing.description}
                              </p>
                              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                                <span className="flex items-center space-x-1">
                                  <Building className="h-3 w-3" />
                                  <span>Marketplace: {listing.marketplace}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Users className="h-3 w-3" />
                                  <span>Seller: {listing.seller}</span>
                                </span>
                                {listing.price && (
                                  <span className="flex items-center space-x-1">
                                    <TrendingUp className="h-3 w-3" />
                                    <span>Price: {listing.price} {listing.currency}</span>
                                  </span>
                                )}
                                {listing.estimatedRecords && (
                                  <span className="flex items-center space-x-1">
                                    <Database className="h-3 w-3" />
                                    <span>Records: {listing.estimatedRecords.toLocaleString()}</span>
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center space-x-2 mt-2">
                                {listing.dataTypes.map((dataType, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {dataType}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                toast({
                                  title: "Investigation Started",
                                  description: `Investigating dark web listing: ${listing.title}`,
                                })
                              }}
                            >
                              <Search className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <PieChart className="h-5 w-5" />
                    <span>Threats by Type</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {metrics?.threatsByType && Object.entries(metrics.threatsByType).map(([type, count]) => (
                      <div key={type} className="flex items-center justify-between">
                        <span className="text-sm capitalize">{type.replace('_', ' ')}</span>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5" />
                    <span>Threats by Severity</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {metrics?.threatsBySeverity && Object.entries(metrics.threatsBySeverity).map(([severity, count]) => (
                      <div key={severity} className="flex items-center justify-between">
                        <span className="text-sm capitalize">{severity}</span>
                        <Badge className={getSeverityColor(severity)}>{count}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="trends" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <LineChart className="h-5 w-5" />
                  <span>Threat Trends</span>
                </CardTitle>
                <CardDescription>
                  Historical threat data and trend analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <LineChart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Trend Analysis</h3>
                  <p className="text-gray-500">Trend charts and analytics will be displayed here.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </RBACGuard>
  )
}