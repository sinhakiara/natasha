'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Search, 
  Plus, 
  Play, 
  Pause, 
  Trash2, 
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield,
  Key,
  Eye,
  ExternalLink,
  Copy,
  Wifi,
  WifiOff,
  GitBranch,
  Database,
  FileText,
  Code,
  Bug,
  RefreshCw,
  Filter,
  Download,
  Share2,
  Zap,
  Target,
  TrendingUp,
  TrendingDown,
  Activity,
  Lock,
  Unlock,
  Globe,
  Cloud,
  Server,
  Terminal
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { useSocket } from '@/hooks/useSocket'
import { prepareReportDataFromScans, downloadReport } from '@/lib/report-generator'

interface EnhancedSecretFinding {
  id: string
  type: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  title: string
  description: string
  secret: string
  redactedSecret: string
  file: string
  line: number
  commit?: string
  author?: string
  date?: string
  repository: string
  branch: string
  provider: 'github' | 'gitlab' | 'bitbucket' | 'local'
  confidence: number
  isValid: boolean
  status: 'active' | 'resolved' | 'false_positive' | 'ignored'
  tags: string[]
  remediation: {
    steps: string[]
    priority: 'immediate' | 'high' | 'medium' | 'low'
    estimatedTime: string
  }
  impact: {
    financial?: number
    reputational?: number
    compliance?: string[]
  }
  firstSeen: string
  lastSeen: string
}

interface EnhancedSecretScan {
  id: string
  name: string
  target: string
  type: 'ENHANCED_SECRET_SCAN'
  status: string
  config: EnhancedSecretScanConfig
  startedAt?: string
  completedAt?: string
  createdAt: string
  findings: EnhancedSecretFinding[]
  _count: {
    findings: number
    critical: number
    high: number
    medium: number
    low: number
  }
  statistics: {
    filesScanned: number
    secretsFound: number
    falsePositives: number
    scanDuration: number
    averageConfidence: number
  }
}

interface EnhancedSecretScanConfig {
  maxFileSize: number
  includeExtensions: string[]
  excludePaths: string[]
  deepScan: boolean
  historicalScan: boolean
  entropyThreshold: number
  regexPatterns: string[]
  customPatterns: string[]
  ignoreKnownFalsePositives: boolean
  validateSecrets: boolean
  checkPublicRepositories: boolean
  includeCommits: boolean
  maxCommitHistory: number
  providers: string[]
  githubApiKey?: string
  enableEntropyDetection: boolean
  enableBase64Detection: boolean
  enableHexDetection: boolean
  enableCustomPatternDetection: boolean
  enableAdvancedValidation: boolean
  validationConfidence: number
  severityThreshold: 'critical' | 'high' | 'medium' | 'low' | 'info'
}

const SECRET_PATTERNS = [
  {
    name: 'AWS Access Key',
    pattern: 'AKIA[0-9A-Z]{16}',
    type: 'aws_access_key',
    severity: 'critical'
  },
  {
    name: 'AWS Secret Key',
    pattern: '[0-9a-zA-Z/+]{40}',
    type: 'aws_secret_key',
    severity: 'critical'
  },
  {
    name: 'GitHub Personal Access Token',
    pattern: 'ghp_[0-9a-zA-Z]{36}',
    type: 'github_pat',
    severity: 'critical'
  },
  {
    name: 'GitHub OAuth Token',
    pattern: 'gho_[0-9a-zA-Z]{36}',
    type: 'github_oauth',
    severity: 'critical'
  },
  {
    name: 'GitHub App Token',
    pattern: 'ghu_[0-9a-zA-Z]{36}',
    type: 'github_app',
    severity: 'critical'
  },
  {
    name: 'GitHub Refresh Token',
    pattern: 'ghr_[0-9a-zA-Z]{76}',
    type: 'github_refresh',
    severity: 'critical'
  },
  {
    name: 'Google API Key',
    pattern: 'AIza[0-9A-Za-z\\-_]{35}',
    type: 'google_api_key',
    severity: 'high'
  },
  {
    name: 'Google OAuth ID',
    pattern: '[0-9]+-[0-9A-Za-z_]{32}\\.apps\\.googleusercontent\\.com',
    type: 'google_oauth_id',
    severity: 'medium'
  },
  {
    name: 'Google OAuth Secret',
    pattern: 'GOCSPX-[0-9A-Za-z\\-_]{28}',
    type: 'google_oauth_secret',
    severity: 'high'
  },
  {
    name: 'Azure Storage Key',
    pattern: 'DefaultEndpointsProtocol=https;AccountName=[a-z0-9]{3,24};AccountKey=[a-zA-Z0-9+/=]{88}',
    type: 'azure_storage_key',
    severity: 'critical'
  },
  {
    name: 'Azure Service Bus',
    pattern: 'Endpoint=sb://[a-z0-9-]+\\.servicebus\\.windows\\.net/;SharedAccessKeyName=[a-zA-Z0-9]+;SharedAccessKey=[a-zA-Z0-9+/=]{43}',
    type: 'azure_service_bus',
    severity: 'high'
  },
  {
    name: 'Slack Webhook',
    pattern: 'https://hooks\\.slack\\.com/services/[A-Z0-9]{9}/[A-Z0-9]{9}/[a-zA-Z0-9]{24}',
    type: 'slack_webhook',
    severity: 'medium'
  },
  {
    name: 'Slack Token',
    pattern: 'xox[baprs]-[0-9]{12}-[0-9]{12}-[0-9]{12}-[a-z0-9]{32}',
    type: 'slack_token',
    severity: 'high'
  },
  {
    name: 'Stripe API Key',
    pattern: 'sk_live_[0-9a-zA-Z]{24}',
    type: 'stripe_api_key',
    severity: 'critical'
  },
  {
    name: 'Stripe Publishable Key',
    pattern: 'pk_live_[0-9a-zA-Z]{24}',
    type: 'stripe_publishable_key',
    severity: 'medium'
  },
  {
    name: 'Twilio Account SID',
    pattern: 'AC[a-z0-9]{32}',
    type: 'twilio_account_sid',
    severity: 'high'
  },
  {
    name: 'Twilio Auth Token',
    pattern: '[0-9a-f]{32}',
    type: 'twilio_auth_token',
    severity: 'high'
  },
  {
    name: 'Heroku API Key',
    pattern: '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
    type: 'heroku_api_key',
    severity: 'high'
  },
  {
    name: 'Mailgun API Key',
    pattern: 'key-[0-9a-f]{32}',
    type: 'mailgun_api_key',
    severity: 'high'
  },
  {
    name: 'SendGrid API Key',
    pattern: 'SG\\.[a-zA-Z0-9\\-_]{22}\\.[a-zA-Z0-9\\-_]{43}',
    type: 'sendgrid_api_key',
    severity: 'high'
  },
  {
    name: 'PostgreSQL URI',
    pattern: 'postgresql://[a-zA-Z0-9:_-]+@[a-zA-Z0-9.-]+/[a-zA-Z0-9_-]+',
    type: 'postgresql_uri',
    severity: 'high'
  },
  {
    name: 'MySQL URI',
    pattern: 'mysql://[a-zA-Z0-9:_-]+@[a-zA-Z0-9.-]+/[a-zA-Z0-9_-]+',
    type: 'mysql_uri',
    severity: 'high'
  },
  {
    name: 'MongoDB URI',
    pattern: 'mongodb://[a-zA-Z0-9:_-]+@[a-zA-Z0-9.-]+/[a-zA-Z0-9_-]+',
    type: 'mongodb_uri',
    severity: 'high'
  },
  {
    name: 'Redis URI',
    pattern: 'redis://[a-zA-Z0-9:_-]+@[a-zA-Z0-9.-]+:[0-9]+',
    type: 'redis_uri',
    severity: 'medium'
  },
  {
    name: 'SSH Private Key',
    pattern: '-----BEGIN [A-Z]+ PRIVATE KEY-----',
    type: 'ssh_private_key',
    severity: 'critical'
  },
  {
    name: 'SSH Public Key',
    pattern: 'ssh-rsa [a-zA-Z0-9+/=]+ [a-zA-Z0-9@._-]+',
    type: 'ssh_public_key',
    severity: 'medium'
  },
  {
    name: 'JWT Token',
    pattern: 'eyJ[0-9a-zA-Z_-]*\\.[0-9a-zA-Z_-]*\\.[0-9a-zA-Z_-]*',
    type: 'jwt_token',
    severity: 'high'
  },
  {
    name: 'Generic API Key',
    pattern: '[a-zA-Z0-9]{32}',
    type: 'generic_api_key',
    severity: 'medium'
  },
  {
    name: 'Generic Secret',
    pattern: '[a-zA-Z0-9/_-]{16,}',
    type: 'generic_secret',
    severity: 'low'
  },
  {
    name: 'OpenAI API Key',
    pattern: 'sk-[a-zA-Z0-9]{48}',
    type: 'openai_api_key',
    severity: 'critical',
    validation: 'openai'
  },
  {
    name: 'Anthropic API Key',
    pattern: 'sk-ant-api03-[a-zA-Z0-9-_]{95}',
    type: 'anthropic_api_key',
    severity: 'critical',
    validation: 'anthropic'
  },
  {
    name: 'HuggingFace Token',
    pattern: 'hf_[a-zA-Z0-9]{34}',
    type: 'huggingface_token',
    severity: 'high',
    validation: 'huggingface'
  },
  {
    name: 'DigitalOcean Token',
    pattern: 'doo_v1_[a-f0-9]{64}',
    type: 'digitalocean_token',
    severity: 'high',
    validation: 'digitalocean'
  },
  {
    name: 'Shopify Token',
    pattern: 'shpat_[a-zA-Z0-9]{32}',
    type: 'shopify_token',
    severity: 'high',
    validation: 'shopify'
  }
]

// Enhanced secret detection with advanced pattern matching
function detectSecretsAdvanced(content: string, patterns: any[]): any[] {
  const findings = []
  
  for (const pattern of patterns) {
    const regex = new RegExp(pattern.pattern, 'gi')
    let match
    
    while ((match = regex.exec(content)) !== null) {
      const secret = match[0]
      const context = content.substring(Math.max(0, match.index - 50), match.index + secret.length + 50)
      
      // Advanced validation with heuristics
      let isValid = true
      let confidence = 0.8
      let reasoning = `Matched ${pattern.name} pattern`
      let validationMethod = 'Pattern'
      
      // Apply additional validation rules
      if (pattern.validation) {
        // Entropy calculation for better validation
        const entropy = calculateEntropy(secret)
        confidence = Math.min(0.95, Math.max(0.5, entropy / 5))
        
        // Length validation
        if (secret.length < 8) {
          isValid = false
          confidence = Math.min(confidence, 0.3)
          reasoning += ' - Too short for a valid secret'
        }
        
        // Character diversity validation
        const hasUppercase = /[A-Z]/.test(secret)
        const hasLowercase = /[a-z]/.test(secret)
        const hasNumbers = /[0-9]/.test(secret)
        const hasSpecial = /[^A-Za-z0-9]/.test(secret)
        
        const diversityScore = [hasUppercase, hasLowercase, hasNumbers, hasSpecial].filter(Boolean).length
        if (diversityScore < 2) {
          confidence *= 0.7
          reasoning += ' - Low character diversity'
        }
        
        // Common false positive patterns
        const falsePositivePatterns = [
          /example/i,
          /test/i,
          /demo/i,
          /sample/i,
          /placeholder/i,
          /fake/i,
          /dummy/i
        ]
        
        if (falsePositivePatterns.some(fp => fp.test(context))) {
          isValid = false
          confidence = Math.min(confidence, 0.2)
          reasoning += ' - Matches false positive pattern'
          validationMethod = 'Heuristic'
        }
        
        // Format-specific validation
        if (pattern.type === 'aws_access_key' && !secret.startsWith('AKIA')) {
          isValid = false
          confidence = Math.min(confidence, 0.3)
          reasoning += ' - Invalid AWS Access Key format'
        }
        
        if (pattern.type === 'github_pat' && !secret.startsWith('ghp_')) {
          isValid = false
          confidence = Math.min(confidence, 0.3)
          reasoning += ' - Invalid GitHub PAT format'
        }
        
        if (pattern.type === 'openai_api_key' && !secret.startsWith('sk-')) {
          isValid = false
          confidence = Math.min(confidence, 0.3)
          reasoning += ' - Invalid OpenAI API Key format'
        }
        
        validationMethod = 'Advanced Heuristic'
      }
      
      findings.push({
        type: pattern.type.toUpperCase(),
        severity: pattern.severity.toUpperCase(),
        title: `${pattern.name} Detected`,
        description: pattern.description || `${pattern.name} found in code`,
        secret: secret,
        redactedSecret: secret.substring(0, Math.min(8, secret.length)) + '[REDACTED]' + secret.substring(Math.max(0, secret.length - 4)),
        confidence: confidence,
        isValid: isValid,
        reasoning: reasoning,
        context: context,
        pattern: pattern.name,
        validationMethod: validationMethod,
        entropy: calculateEntropy(secret)
      })
    }
  }
  
  return findings
}

// Calculate Shannon entropy for secret validation
function calculateEntropy(str: string): number {
  const freq: { [key: string]: number } = {}
  for (let i = 0; i < str.length; i++) {
    const char = str[i]
    freq[char] = (freq[char] || 0) + 1
  }
  
  let entropy = 0
  for (const char in freq) {
    const p = freq[char] / str.length
    entropy -= p * Math.log2(p)
  }
  
  return entropy
}

export function EnhancedSecretScanner() {
  const { toast } = useToast()
  const { data: session } = useSession()
  const router = useRouter()
  const [scans, setScans] = useState<EnhancedSecretScan[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [newScan, setNewScan] = useState({
    name: '',
    target: '',
    config: {
      maxFileSize: 10 * 1024 * 1024,
      includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.json', '.yaml', '.yml', '.env', '.xml', '.html', '.css', '.sql', '.sh', '.md', '.txt'],
      excludePaths: ['node_modules', '.git', 'dist', 'build', 'vendor', '.next', '.out', '.cache'],
      deepScan: true,
      historicalScan: true,
      entropyThreshold: 4.5,
      regexPatterns: SECRET_PATTERNS.map(p => p.pattern),
      customPatterns: [],
      ignoreKnownFalsePositives: true,
      validateSecrets: true,
      checkPublicRepositories: true,
      includeCommits: true,
      maxCommitHistory: 100,
      providers: ['github', 'gitlab', 'bitbucket'],
      githubApiKey: '',
      enableEntropyDetection: true,
      enableBase64Detection: true,
      enableHexDetection: true,
      enableCustomPatternDetection: true,
      enableAdvancedValidation: true, // Advanced heuristic validation
      severityThreshold: 'medium',
      validationConfidence: 0.7 // Minimum confidence threshold for validation
    } as EnhancedSecretScanConfig
  })
  const [validationError, setValidationError] = useState('')
  const [activeScanId, setActiveScanId] = useState<string | null>(null)
  const [scanProgress, setScanProgress] = useState(0)
  const [selectedScanFindings, setSelectedScanFindings] = useState<EnhancedSecretFinding[]>([])
  const [selectedScan, setSelectedScan] = useState<EnhancedSecretScan | null>(null)
  const [visibleSecrets, setVisibleSecrets] = useState<Set<string>>(new Set())
  const [showConfig, setShowConfig] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [filters, setFilters] = useState({
    severity: '',
    type: '',
    status: '',
    provider: '',
    timeframe: '7d'
  })
  const hasActiveScansRef = useRef(false)

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3'

  // Initialize socket connection
  const { 
    socket, 
    isConnected, 
    joinScanRoom, 
    leaveScanRoom, 
    onScanProgress, 
    offScanProgress,
    onMonitoringEvent,
    offMonitoringEvent
  } = useSocket({ userId, autoConnect: true })

  // Handle real-time scan updates
  useEffect(() => {
    if (isConnected) {
      const handleScanProgress = (data: { scanId: string; progress: number; status: string }) => {
        console.log('Real-time enhanced secret scan progress update:', data)
        
        setScanProgress(data.progress)
        
        setScans(prevScans => 
          prevScans.map(scan => 
            scan.id === data.scanId 
              ? { ...scan, status: data.status }
              : scan
          )
        )
        
        if (data.status === 'COMPLETED') {
          toast({
            title: "Enhanced Secret Scan Completed",
            description: `Enhanced secret scan has completed successfully`,
          })
          setScanProgress(0)
        } else if (data.status === 'FAILED') {
          toast({
            title: "Enhanced Secret Scan Failed",
            description: `Enhanced secret scan has failed`,
            variant: "destructive"
          })
          setScanProgress(0)
        }
        
        setLastUpdate(new Date())
      }

      const handleMonitoringEvent = (event: { type: string; data: any; userId: string }) => {
        if (event.userId === userId) {
          console.log('Monitoring event:', event)
          
          if (event.type === 'scan_started') {
            setScans(prevScans => 
              prevScans.map(scan => 
                scan.id === event.data.scanId 
                  ? { ...scan, status: 'RUNNING', startedAt: new Date().toISOString() }
                  : scan
              )
            )
          } else if (event.type === 'scan_updated') {
            fetchScans(true)
          }
        }
      }

      onScanProgress(handleScanProgress)
      onMonitoringEvent(handleMonitoringEvent)

      return () => {
        offScanProgress(handleScanProgress)
        offMonitoringEvent(handleMonitoringEvent)
      }
    }
  }, [isConnected, userId, onScanProgress, offScanProgress, onMonitoringEvent, offMonitoringEvent, toast])

  // Join scan rooms for active scans
  useEffect(() => {
    if (isConnected) {
      const activeScans = scans.filter(scan => scan.status === 'RUNNING')
      activeScans.forEach(scan => {
        joinScanRoom(scan.id)
      })

      return () => {
        activeScans.forEach(scan => {
          leaveScanRoom(scan.id)
        })
      }
    }
  }, [scans, isConnected, joinScanRoom, leaveScanRoom])

  useEffect(() => {
    fetchScans()
  }, [])

  useEffect(() => {
    hasActiveScansRef.current = scans.some(scan => scan.status === 'RUNNING')
  }, [scans])

  useEffect(() => {
    const interval = setInterval(() => {
      if (hasActiveScansRef.current && !isConnected) {
        console.log('Polling for enhanced secret scan updates (WebSocket not connected)...')
        fetchScans(true)
      }
    }, 10000)

    return () => clearInterval(interval)
  }, [hasActiveScansRef.current, isConnected])

  useEffect(() => {
    const activeScans = scans.filter(scan => scan.status === 'RUNNING')
    if (activeScans.length > 0) {
      const progressInterval = setInterval(() => {
        setScanProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval)
            return 95
          }
          return prev + Math.random() * 5
        })
      }, 2000)

      return () => clearInterval(progressInterval)
    } else {
      setScanProgress(0)
    }
  }, [scans.filter(scan => scan.status === 'RUNNING').length])

  const fetchScans = async (isPolling = false) => {
    try {
      if (!isPolling) {
        setIsLoading(true)
      }
      
      const response = await fetch(`/api/scans?userId=${userId}&type=ENHANCED_SECRET_SCAN`)
      if (response.ok) {
        const data = await response.json()
        setScans(data.scans || [])
        
        const runningScans = data.scans?.filter((scan: EnhancedSecretScan) => scan.status === 'RUNNING') || []
        if (runningScans.length > 0) {
          console.log(`Found ${runningScans.length} running enhanced secret scans:`, runningScans.map((s: EnhancedSecretScan) => s.name))
        }
      }
    } catch (error) {
      console.error('Error fetching enhanced secret scans:', error)
      if (!isPolling) {
        toast({
          title: "Error",
          description: "Failed to fetch enhanced secret scans",
          variant: "destructive"
        })
      }
    } finally {
      if (!isPolling) {
        setIsLoading(false)
      }
    }
  }

  const validateForm = (): boolean => {
    if (!newScan.name.trim()) {
      setValidationError('Scan name is required')
      return false
    }

    if (!newScan.target.trim()) {
      setValidationError('Target is required')
      return false
    }

    if (!newScan.target.includes('github.com') && !newScan.target.startsWith('/')) {
      setValidationError('Target must be a GitHub repository or file path')
      return false
    }

    setValidationError('')
    return true
  }

  const handleCreateScan = async () => {
    if (!validateForm()) return

    try {
      setIsCreating(true)
      
      const response = await fetch('/api/scans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: newScan.name,
          target: newScan.target,
          type: 'ENHANCED_SECRET_SCAN',
          config: newScan.config,
          userId
        })
      })

      if (response.ok) {
        const data = await response.json()
        setScans(prev => [data.scan, ...prev])
        setNewScan({
          name: '',
          target: '',
          config: {
            maxFileSize: 10 * 1024 * 1024,
            includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.json', '.yaml', '.yml', '.env', '.xml', '.html', '.css', '.sql', '.sh', '.md', '.txt'],
            excludePaths: ['node_modules', '.git', 'dist', 'build', 'vendor', '.next', '.out', '.cache'],
            deepScan: true,
            historicalScan: true,
            entropyThreshold: 4.5,
            regexPatterns: SECRET_PATTERNS.map(p => p.pattern),
            customPatterns: [],
            ignoreKnownFalsePositives: true,
            validateSecrets: true,
            checkPublicRepositories: true,
            includeCommits: true,
            maxCommitHistory: 100,
            providers: ['github', 'gitlab', 'bitbucket'],
            githubApiKey: '',
            enableEntropyDetection: true,
            enableBase64Detection: true,
            enableHexDetection: true,
            enableCustomPatternDetection: true,
            enableAdvancedValidation: true,
            severityThreshold: 'medium',
            validationConfidence: 0.7
          }
        })
        toast({
          title: "Success",
          description: "Enhanced secret scan started successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to create enhanced secret scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error creating enhanced secret scan:', error)
      toast({
        title: "Error",
        description: "Failed to create enhanced secret scan",
        variant: "destructive"
      })
    } finally {
      setIsCreating(false)
    }
  }

  const handleStopScan = async (scanId: string) => {
    try {
      setScans(prev => prev.map(scan => 
        scan.id === scanId ? { ...scan, status: 'FAILED' } : scan
      ))
      
      toast({
        title: "Success",
        description: "Enhanced secret scan stopped successfully",
      })
    } catch (error) {
      console.error('Error stopping enhanced secret scan:', error)
      toast({
        title: "Error",
        description: "Failed to stop enhanced secret scan",
        variant: "destructive"
      })
    }
  }

  const handleDeleteScan = async (scanId: string) => {
    if (!confirm('Are you sure you want to delete this enhanced secret scan and all its findings? This action cannot be undone.')) {
      return
    }

    try {
      const response = await fetch(`/api/scans/${scanId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setScans(prev => prev.filter(scan => scan.id !== scanId))
        toast({
          title: "Success",
          description: "Enhanced secret scan deleted successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to delete enhanced secret scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error deleting enhanced secret scan:', error)
      toast({
        title: "Error",
        description: "Failed to delete enhanced secret scan",
        variant: "destructive"
      })
    }
  }

  const handleViewFindings = async (scanId: string) => {
    router.push(`/enhanced-secret-scanner/${scanId}`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <Clock className="h-3 w-3 animate-spin" />
      case 'FAILED':
        return <AlertTriangle className="h-3 w-3" />
      case 'PENDING':
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getProviderIcon = (provider: string) => {
    switch (provider) {
      case 'github': return <GitBranch className="h-4 w-4" />
      case 'gitlab': return <GitBranch className="h-4 w-4" />
      case 'bitbucket': return <GitBranch className="h-4 w-4" />
      case 'local': return <Server className="h-4 w-4" />
      default: return <Globe className="h-4 w-4" />
    }
  }

  const getFindingTypeIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'aws_access_key':
      case 'aws_secret_key': return <Cloud className="h-4 w-4" />
      case 'github_pat':
      case 'github_oauth':
      case 'github_app':
      case 'github_refresh': return <GitBranch className="h-4 w-4" />
      case 'google_api_key':
      case 'google_oauth_id':
      case 'google_oauth_secret': return <Cloud className="h-4 w-4" />
      case 'azure_storage_key':
      case 'azure_service_bus': return <Cloud className="h-4 w-4" />
      case 'slack_webhook':
      case 'slack_token': return <Zap className="h-4 w-4" />
      case 'stripe_api_key':
      case 'stripe_publishable_key': return <Terminal className="h-4 w-4" />
      case 'ssh_private_key':
      case 'ssh_public_key': return <Lock className="h-4 w-4" />
      case 'jwt_token': return <Key className="h-4 w-4" />
      case 'postgresql_uri':
      case 'mysql_uri':
      case 'mongodb_uri':
      case 'redis_uri': return <Database className="h-4 w-4" />
      default: return <Key className="h-4 w-4" />
    }
  }

  const maskSecret = (secret: string) => {
    if (secret.length <= 8) return '*'.repeat(secret.length)
    return secret.substring(0, 4) + '*'.repeat(secret.length - 8) + secret.substring(secret.length - 4)
  }

  const toggleSecretVisibility = (findingId: string) => {
    setVisibleSecrets(prev => {
      const newSet = new Set(prev)
      if (newSet.has(findingId)) {
        newSet.delete(findingId)
      } else {
        newSet.add(findingId)
      }
      return newSet
    })
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: "Text copied to clipboard",
    })
  }

  const formatTarget = (target: string) => {
    if (target.length > 50) {
      return target.substring(0, 50) + '...'
    }
    return target
  }

  const formatNumber = (num: number) => {
    return num.toLocaleString()
  }

  const handleGenerateReport = (format: 'html' | 'pdf' = 'html') => {
    const completedScans = scans.filter(scan => scan.status === 'COMPLETED')
    if (completedScans.length === 0) {
      toast({
        title: "No Data",
        description: "No completed scans available for report generation",
        variant: "destructive"
      })
      return
    }

    try {
      const reportData = prepareReportDataFromScans(completedScans, 'Enhanced Secret Security')
      downloadReport(reportData, format)
      toast({
        title: "Report Generated",
        description: `Enhanced Secret Security Scan report has been generated in ${format.toUpperCase()} format`,
      })
    } catch (error) {
      console.error('Error generating report:', error)
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive"
      })
    }
  }

  return (
    <RBACGuard requiredRoles={['ADMIN', 'MEMBER']}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Enhanced Secret Scanner</h2>
            <p className="text-muted-foreground">
              Advanced secret detection inspired by GitGuardian and TruffleHog with AI-powered analysis
            </p>
          </div>
          <div className="flex items-center space-x-2">
            {isConnected ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Wifi className="h-3 w-3 mr-1" />
                Live Scanning
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                <WifiOff className="h-3 w-3 mr-1" />
                Offline
              </Badge>
            )}
            {lastUpdate && (
              <span className="text-xs text-muted-foreground">
                Last update: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>

        {/* Create New Scan Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-5 w-5" />
              <span>Create New Enhanced Secret Scan</span>
            </CardTitle>
            <CardDescription>
              Configure advanced secret detection with 25+ pattern types and AI validation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Scan Name</label>
                <Input
                  placeholder="Enter scan name"
                  value={newScan.name}
                  onChange={(e) => setNewScan(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Target Repository</label>
                <Input
                  placeholder="GitHub repository URL"
                  value={newScan.target}
                  onChange={(e) => setNewScan(prev => ({ ...prev, target: e.target.value }))}
                />
              </div>
            </div>

            {validationError && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{validationError}</AlertDescription>
              </Alert>
            )}

            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={() => setShowConfig(!showConfig)}
              >
                <Settings className="h-4 w-4 mr-2" />
                {showConfig ? 'Hide' : 'Show'} Advanced Configuration
              </Button>
              <Button
                onClick={handleCreateScan}
                disabled={isCreating}
              >
                {isCreating ? (
                  <>
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Start Scan
                  </>
                )}
              </Button>
            </div>

            {showConfig && (
              <div className="border rounded-lg p-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Detection Methods</h4>
                    <div className="space-y-2">
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.enableEntropyDetection}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, enableEntropyDetection: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Entropy Detection</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.enableBase64Detection}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, enableBase64Detection: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Base64 Detection</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.enableHexDetection}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, enableHexDetection: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Hex Detection</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.enableCustomPatternDetection}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, enableCustomPatternDetection: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Custom Pattern Detection</span>
                      </label>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Scan Options</h4>
                    <div className="space-y-2">
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.deepScan}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, deepScan: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Deep Scan</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.historicalScan}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, historicalScan: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Historical Scan</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.validateSecrets}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, validateSecrets: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Validate Secrets</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newScan.config.ignoreKnownFalsePositives}
                          onChange={(e) => setNewScan(prev => ({
                            ...prev,
                            config: { ...prev.config!, ignoreKnownFalsePositives: e.target.checked }
                          }))}
                          className="rounded"
                        />
                        <span className="text-sm">Ignore False Positives</span>
                      </label>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Severity Threshold</h4>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={newScan.config.severityThreshold}
                    onChange={(e) => setNewScan(prev => ({
                      ...prev,
                      config: { ...prev.config!, severityThreshold: e.target.value as any }
                    }))}
                  >
                    <option value="critical">Critical Only</option>
                    <option value="high">High and Critical</option>
                    <option value="medium">Medium and Above</option>
                    <option value="low">Low and Above</option>
                    <option value="info">All Severities</option>
                  </select>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Scans Progress */}
        {scans.filter(scan => scan.status === 'RUNNING').length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5 animate-spin" />
                <span>Active Scans</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scans.filter(scan => scan.status === 'RUNNING').map(scan => (
                  <div key={scan.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{scan.name}</span>
                      <Badge className={getStatusColor(scan.status)}>
                        {getStatusIcon(scan.status)}
                        <span className="ml-1">{scan.status}</span>
                      </Badge>
                    </div>
                    <Progress value={scanProgress} className="h-2" />
                    <div className="text-xs text-muted-foreground">
                      {Math.round(scanProgress)}% complete
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Scans */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Enhanced Secret Scans</CardTitle>
                <CardDescription>
                  Advanced secret detection with 25+ patterns and AI validation
                </CardDescription>
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerateReport('html')}
                  disabled={scans.filter(s => s.status === 'COMPLETED').length === 0}
                >
                  <Download className="h-4 w-4 mr-2" />
                  HTML Report
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerateReport('pdf')}
                  disabled={scans.filter(s => s.status === 'COMPLETED').length === 0}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  PDF Report
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fetchScans()}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4 mr-2" />
                  )}
                  Refresh
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="animate-pulse">
                    <div className="h-24 bg-gray-200 rounded-lg"></div>
                  </div>
                ))}
              </div>
            ) : scans.length === 0 ? (
              <div className="text-center py-8">
                <Key className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Enhanced Secret Scans</h3>
                <p className="text-gray-500">Create your first enhanced secret scan to detect secrets with advanced patterns.</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {scans.map((scan) => (
                  <div key={scan.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className="p-2 bg-purple-100 rounded-lg">
                          <Search className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{scan.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {formatTarget(scan.target)}
                          </p>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge className={getStatusColor(scan.status)}>
                              {getStatusIcon(scan.status)}
                              <span className="ml-1">{scan.status}</span>
                            </Badge>
                            <Badge variant="outline">
                              {scan._count?.findings || 0} findings
                            </Badge>
                            {scan._count?.critical && (
                              <Badge className="bg-red-100 text-red-800">
                                {scan._count.critical} critical
                              </Badge>
                            )}
                            {scan._count?.high && (
                              <Badge className="bg-orange-100 text-orange-800">
                                {scan._count.high} high
                              </Badge>
                            )}
                          </div>
                          {scan.statistics && (
                            <div className="text-xs text-muted-foreground mt-2">
                              {formatNumber(scan.statistics.filesScanned)} files scanned • 
                              {scan.statistics.averageConfidence.toFixed(1)}% avg confidence • 
                              {Math.round(scan.statistics.scanDuration / 1000)}s duration
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {scan.status === 'RUNNING' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleStopScan(scan.id)}
                          >
                            <Pause className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewFindings(scan.id)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteScan(scan.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </RBACGuard>
  )
}