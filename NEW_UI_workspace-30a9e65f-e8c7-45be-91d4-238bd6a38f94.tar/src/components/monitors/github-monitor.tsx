'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Github, 
  Plus, 
  Play, 
  Pause, 
  Trash2, 
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { parseGitHubUrl, isValidGitHubRepo } from '@/lib/utils/github'

interface Monitor {
  id: string
  name: string
  type: string
  target: string
  isActive: boolean
  createdAt: string
  leaks: any[]
  _count?: {
    leaks: number
  }
}

interface NewMonitorForm {
  name: string
  type: string
  target: string
  githubToken?: string
}

export function GitHubMonitor() {
  const [monitors, setMonitors] = useState<Monitor[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [newMonitor, setNewMonitor] = useState<NewMonitorForm>({
    name: '',
    type: 'GITHUB_REPO',
    target: '',
    githubToken: ''
  })
  const [validationError, setValidationError] = useState('')
  const [isValidatingKey, setIsValidatingKey] = useState(false)
  const [isKeyValid, setIsKeyValid] = useState<boolean | null>(null)
  const { toast } = useToast()

  const { data: session } = useSession()
  
  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3' // Admin user ID as fallback

  useEffect(() => {
    fetchMonitors()
  }, [])

  // Reset validation state when GitHub token changes
  useEffect(() => {
    if (newMonitor.githubToken) {
      setIsKeyValid(null)
    }
  }, [newMonitor.githubToken])

  const fetchMonitors = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/monitors?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setMonitors(data.monitors || [])
      }
    } catch (error) {
      console.error('Error fetching monitors:', error)
      toast({
        title: "Error",
        description: "Failed to fetch monitors",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const validateForm = (): boolean => {
    if (!newMonitor.name.trim()) {
      setValidationError('Monitor name is required')
      return false
    }

    if (!newMonitor.target.trim()) {
      setValidationError('Target URL is required')
      return false
    }

    if (newMonitor.type === 'GITHUB_REPO') {
      const repoInfo = parseGitHubUrl(newMonitor.target)
      if (!repoInfo.isValid) {
        setValidationError('Invalid GitHub repository URL')
        return false
      }
    }

    // Validate GitHub API key if provided
    if (newMonitor.githubToken && !isKeyValid) {
      setValidationError('Please validate the GitHub API key first')
      return false
    }

    setValidationError('')
    return true
  }

  const validateGitHubKey = async (token: string): Promise<boolean> => {
    if (!token.trim()) {
      setIsKeyValid(null)
      return false
    }

    setIsValidatingKey(true)
    try {
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `token ${token.trim()}`,
          'User-Agent': 'Security-Sentinel/1.0'
        }
      })

      if (response.ok) {
        const userData = await response.json()
        console.log('GitHub API key validated for user:', userData.login)
        setIsKeyValid(true)
        toast({
          title: "Success",
          description: `GitHub API key validated successfully for user: ${userData.login}`,
        })
        return true
      } else {
        setIsKeyValid(false)
        const errorData = await response.json()
        console.error('GitHub API key validation failed:', errorData)
        toast({
          title: "Validation Failed",
          description: `Invalid GitHub API key: ${errorData.message || 'Unauthorized'}`,
          variant: "destructive"
        })
        return false
      }
    } catch (error) {
      setIsKeyValid(false)
      console.error('Error validating GitHub API key:', error)
      toast({
        title: "Validation Error",
        description: "Failed to validate GitHub API key. Please check your internet connection.",
        variant: "destructive"
      })
      return false
    } finally {
      setIsValidatingKey(false)
    }
  }

  const handleCreateMonitor = async () => {
    if (!validateForm()) return

    try {
      setIsCreating(true)
      
      const response = await fetch('/api/monitors', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newMonitor,
          userId,
          config: {
            githubToken: newMonitor.githubToken,
            includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.json', '.yaml', '.yml', '.env'],
            excludePaths: ['node_modules', '.git', 'dist', 'build'],
            checkCommits: true,
            checkPullRequests: true
          }
        })
      })

      if (response.ok) {
        const data = await response.json()
        setMonitors(prev => [data.monitor, ...prev])
        setNewMonitor({ name: '', type: 'GITHUB_REPO', target: '', githubToken: '' })
        setIsKeyValid(null) // Reset validation state
        toast({
          title: "Success",
          description: "Monitor created successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to create monitor",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error creating monitor:', error)
      toast({
        title: "Error",
        description: "Failed to create monitor",
        variant: "destructive"
      })
    } finally {
      setIsCreating(false)
    }
  }

  const handleToggleMonitor = async (monitorId: string, isActive: boolean) => {
    try {
      // In a real implementation, this would call an API to toggle the monitor
      setMonitors(prev => prev.map(m => 
        m.id === monitorId ? { ...m, isActive } : m
      ))
      
      toast({
        title: "Success",
        description: `Monitor ${isActive ? 'started' : 'stopped'} successfully`,
      })
    } catch (error) {
      console.error('Error toggling monitor:', error)
      toast({
        title: "Error",
        description: "Failed to toggle monitor",
        variant: "destructive"
      })
    }
  }

  const handleDeleteMonitor = async (monitorId: string) => {
    try {
      const response = await fetch(`/api/monitors?id=${monitorId}&userId=${userId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setMonitors(prev => prev.filter(m => m.id !== monitorId))
        toast({
          title: "Success",
          description: "Monitor deleted successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to delete monitor",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error deleting monitor:', error)
      toast({
        title: "Error",
        description: "Failed to delete monitor",
        variant: "destructive"
      })
    }
  }

  const getSeverityColor = (count: number) => {
    if (count === 0) return 'bg-green-100 text-green-800'
    if (count <= 3) return 'bg-yellow-100 text-yellow-800'
    return 'bg-red-100 text-red-800'
  }

  const formatTarget = (target: string, type: string) => {
    if (type === 'GITHUB_REPO') {
      const repoInfo = parseGitHubUrl(target)
      return repoInfo.isValid ? `${repoInfo.owner}/${repoInfo.repo}` : target
    }
    return target
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">GitHub Monitor</h2>
          <p className="text-muted-foreground">
            Real-time monitoring of GitHub repositories for leaked secrets and credentials
          </p>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">GitHub Monitor</h2>
        <p className="text-muted-foreground">
          Real-time monitoring of GitHub repositories for leaked secrets and credentials
        </p>
      </div>

      {/* Create New Monitor */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Create New Monitor
          </CardTitle>
          <CardDescription>Set up monitoring for GitHub repositories or organizations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {validationError && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{validationError}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium">Monitor Name</label>
              <Input
                placeholder="e.g., Acme Corp Repos"
                value={newMonitor.name}
                onChange={(e) => setNewMonitor(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Target Type</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={newMonitor.type}
                onChange={(e) => setNewMonitor(prev => ({ ...prev, type: e.target.value }))}
              >
                <option value="GITHUB_REPO">GitHub Repository</option>
                <option value="GITHUB_ORG">GitHub Organization</option>
                <option value="DOMAIN">Domain</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">Target URL/Name</label>
            <Input
              placeholder="e.g., https://github.com/acme/corp-repo"
              value={newMonitor.target}
              onChange={(e) => setNewMonitor(prev => ({ ...prev, target: e.target.value }))}
            />
          </div>
          
          {newMonitor.type === 'GITHUB_REPO' && (
            <div>
              <label className="text-sm font-medium">GitHub Token (Optional - for private repos)</label>
              <div className="flex space-x-2">
                <Input
                  type="password"
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                  value={newMonitor.githubToken}
                  onChange={(e) => setNewMonitor(prev => ({ ...prev, githubToken: e.target.value }))}
                  className={isKeyValid === false ? 'border-red-500' : isKeyValid === true ? 'border-green-500' : ''}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => validateGitHubKey(newMonitor.githubToken)}
                  disabled={isValidatingKey || !newMonitor.githubToken.trim()}
                  className="whitespace-nowrap"
                >
                  {isValidatingKey ? 'Validating...' : 'Validate'}
                </Button>
              </div>
              {isKeyValid === true && (
                <p className="text-sm text-green-600 mt-1">✓ GitHub API key is valid</p>
              )}
              {isKeyValid === false && (
                <p className="text-sm text-red-600 mt-1">✗ GitHub API key is invalid</p>
              )}
              {isValidatingKey && (
                <p className="text-sm text-blue-600 mt-1">Validating GitHub API key...</p>
              )}
            </div>
          )}
          
          <Button 
            onClick={handleCreateMonitor} 
            disabled={isCreating}
            className="w-full"
          >
            {isCreating ? 'Creating...' : 'Start Monitoring'}
          </Button>
        </CardContent>
      </Card>

      {/* Active Monitors */}
      <Card>
        <CardHeader>
          <CardTitle>Active Monitors</CardTitle>
          <CardDescription>Your currently running GitHub monitors</CardDescription>
        </CardHeader>
        <CardContent>
          {monitors.length === 0 ? (
            <div className="text-center py-8">
              <Github className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No monitors yet</h3>
              <p className="text-gray-500">Create your first monitor to start detecting leaks</p>
            </div>
          ) : (
            <div className="space-y-4">
              {monitors.map((monitor) => (
                <div key={monitor.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <Github className="h-6 w-6 text-gray-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-sm font-medium text-gray-900 truncate">
                          {monitor.name}
                        </h3>
                        {monitor.isActive ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            <Clock className="h-3 w-3 mr-1" />
                            Paused
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-500 truncate">
                        {formatTarget(monitor.target, monitor.type)}
                      </p>
                      <p className="text-xs text-gray-400">
                        Created {new Date(monitor.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">Leaks:</span>
                      <Badge className={getSeverityColor(monitor._count?.leaks || 0)}>
                        {monitor._count?.leaks || 0}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggleMonitor(monitor.id, !monitor.isActive)}
                      >
                        {monitor.isActive ? (
                          <Pause className="h-4 w-4" />
                        ) : (
                          <Play className="h-4 w-4" />
                        )}
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteMonitor(monitor.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}