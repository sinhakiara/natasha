'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Code, 
  Plus, 
  Play, 
  Pause, 
  Trash2, 
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield,
  FileText,
  Database,
  Lock,
  Eye,
  ExternalLink,
  Copy,
  Wifi,
  WifiOff,
  GitBranch,
  Bug,
  Search,
  Key,
  RefreshCw,
  Download
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { useSocket } from '@/hooks/useSocket'
import { prepareReportDataFromScans, downloadReport } from '@/lib/report-generator'

interface CodeScan {
  id: string
  name: string
  target: string
  type: 'CODE_SCAN'
  scanType: string
  status: string
  config: string
  startedAt?: string
  completedAt?: string
  createdAt: string
  findings: any[]
  _count: {
    findings: number
  }
  owaspStandards: string[]
  languages: string[]
}

interface NewCodeScanForm {
  name: string
  target: string
  scanType: string
  config?: {
    maxFileSize?: number
    includeExtensions?: string[]
    excludePaths?: string[]
    deepScan?: boolean
    owaspStandards?: string[]
    languages?: string[]
    qualityGates?: string[]
    securityRules?: string[]
  }
}

const OWASP_CODE_SCAN_STANDARDS = [
  { id: 'ASVS_L1', name: 'ASVS Level 1', description: 'Basic security verification' },
  { id: 'ASVS_L2', name: 'ASVS Level 2', description: 'Standard security verification' },
  { id: 'ASVS_L3', name: 'ASVS Level 3', description: 'Advanced security verification' },
  { id: 'MASVS', name: 'MASVS', description: 'Mobile Application Security Verification Standard' },
  { id: 'CWE_TOP25', name: 'CWE Top 25', description: 'Most dangerous software errors' },
  { id: 'SANS_TOP25', name: 'SANS Top 25', description: 'Most dangerous software errors' },
  { id: 'OWASP_TOP10', name: 'OWASP Top 10', description: 'Top 10 web application security risks' },
  { id: 'PCI_DSS', name: 'PCI DSS', description: 'Payment Card Industry Data Security Standard' }
]

const SUPPORTED_LANGUAGES = [
  { id: 'javascript', name: 'JavaScript', extensions: ['.js', '.jsx', '.ts', '.tsx'] },
  { id: 'python', name: 'Python', extensions: ['.py'] },
  { id: 'java', name: 'Java', extensions: ['.java'] },
  { id: 'csharp', name: 'C#', extensions: ['.cs'] },
  { id: 'php', name: 'PHP', extensions: ['.php'] },
  { id: 'ruby', name: 'Ruby', extensions: ['.rb'] },
  { id: 'go', name: 'Go', extensions: ['.go'] },
  { id: 'rust', name: 'Rust', extensions: ['.rs'] },
  { id: 'cpp', name: 'C++', extensions: ['.cpp', '.cc', '.cxx', '.c++'] },
  { id: 'c', name: 'C', extensions: ['.c', '.h'] }
]

const SCAN_TYPES = [
  { id: 'security', name: 'Security Scan', description: 'Focus on security vulnerabilities' },
  { id: 'quality', name: 'Quality Scan', description: 'Code quality and best practices' },
  { id: 'compliance', name: 'Compliance Scan', description: 'Standards compliance checking' },
  { id: 'comprehensive', name: 'Comprehensive Scan', description: 'Complete analysis including security, quality, and compliance' }
]

export function CodeScanner() {
  const { toast } = useToast()
  const { data: session } = useSession()
  const router = useRouter()
  const [scans, setScans] = useState<CodeScan[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [newScan, setNewScan] = useState<NewCodeScanForm>({
    name: '',
    target: '',
    scanType: 'comprehensive',
    config: {
      maxFileSize: 10 * 1024 * 1024,
      includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.cpp', '.c'],
      excludePaths: ['node_modules', '.git', 'dist', 'build', 'vendor'],
      deepScan: true,
      owaspStandards: ['ASVS_L2', 'OWASP_TOP10'],
      languages: ['javascript', 'python', 'java'],
      qualityGates: ['code_coverage', 'complexity', 'duplication'],
      securityRules: ['injection', 'xss', 'auth', 'crypto']
    }
  })
  const [validationError, setValidationError] = useState('')
  const [activeScanId, setActiveScanId] = useState<string | null>(null)
  const [scanProgress, setScanProgress] = useState(0)
  const [selectedScanFindings, setSelectedScanFindings] = useState<any[]>([])
  const [selectedScan, setSelectedScan] = useState<CodeScan | null>(null)
  const [showConfig, setShowConfig] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const hasActiveScansRef = useRef(false)

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3'

  // Initialize socket connection
  const { 
    socket, 
    isConnected, 
    joinScanRoom, 
    leaveScanRoom, 
    onScanProgress, 
    offScanProgress,
    onMonitoringEvent,
    offMonitoringEvent
  } = useSocket({ userId, autoConnect: true })

  // Handle real-time scan updates
  useEffect(() => {
    if (isConnected) {
      const handleScanProgress = (data: { scanId: string; progress: number; status: string }) => {
        console.log('Real-time code scan progress update:', data)
        
        // Update scan progress
        setScanProgress(data.progress)
        
        // Update scans list with new status
        setScans(prevScans => 
          prevScans.map(scan => 
            scan.id === data.scanId 
              ? { ...scan, status: data.status }
              : scan
          )
        )
        
        // Show notification for status changes
        if (data.status === 'COMPLETED') {
          toast({
            title: "Code Scan Completed",
            description: `Code scan has completed successfully`,
          })
          setScanProgress(0)
        } else if (data.status === 'FAILED') {
          toast({
            title: "Code Scan Failed",
            description: `Code scan has failed`,
            variant: "destructive"
          })
          setScanProgress(0)
        }
        
        setLastUpdate(new Date())
      }

      const handleMonitoringEvent = (event: { type: string; data: any; userId: string }) => {
        if (event.userId === userId) {
          console.log('Monitoring event:', event)
          
          if (event.type === 'scan_started') {
            setScans(prevScans => 
              prevScans.map(scan => 
                scan.id === event.data.scanId 
                  ? { ...scan, status: 'RUNNING', startedAt: new Date().toISOString() }
                  : scan
              )
            )
          } else if (event.type === 'scan_updated') {
            fetchScans(true) // Refresh scans list
          }
        }
      }

      // Subscribe to scan progress events
      onScanProgress(handleScanProgress)
      onMonitoringEvent(handleMonitoringEvent)

      return () => {
        offScanProgress(handleScanProgress)
        offMonitoringEvent(handleMonitoringEvent)
      }
    }
  }, [isConnected, userId, onScanProgress, offScanProgress, onMonitoringEvent, offMonitoringEvent, toast])

  // Join scan rooms for active scans
  useEffect(() => {
    if (isConnected) {
      const activeScans = scans.filter(scan => scan.status === 'RUNNING')
      activeScans.forEach(scan => {
        joinScanRoom(scan.id)
      })

      return () => {
        activeScans.forEach(scan => {
          leaveScanRoom(scan.id)
        })
      }
    }
  }, [scans, isConnected, joinScanRoom, leaveScanRoom])

  useEffect(() => {
    fetchScans()
  }, [])

  useEffect(() => {
    // Update the ref when scans change
    hasActiveScansRef.current = scans.some(scan => scan.status === 'RUNNING')
  }, [scans])

  useEffect(() => {
    // Set up polling for active scans (fallback mechanism)
    const interval = setInterval(() => {
      if (hasActiveScansRef.current && !isConnected) {
        console.log('Polling for code scan updates (WebSocket not connected)...')
        fetchScans(true) // Pass true to indicate this is a polling request
      }
    }, 10000) // Poll every 10 seconds as fallback

    return () => clearInterval(interval)
  }, [hasActiveScansRef.current, isConnected])

  useEffect(() => {
    // Simulate scan progress for active scans
    const activeScans = scans.filter(scan => scan.status === 'RUNNING')
    if (activeScans.length > 0) {
      const progressInterval = setInterval(() => {
        setScanProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval)
            return 95
          }
          return prev + Math.random() * 6
        })
      }, 2000)

      return () => clearInterval(progressInterval)
    } else {
      setScanProgress(0)
    }
  }, [scans.filter(scan => scan.status === 'RUNNING').length])

  const fetchScans = async (isPolling = false) => {
    try {
      if (!isPolling) {
        setIsLoading(true)
      }
      
      const response = await fetch(`/api/scans?userId=${userId}&type=CODE_SCAN`)
      if (response.ok) {
        const data = await response.json()
        setScans(data.scans || [])
        
        const runningScans = data.scans?.filter((scan: CodeScan) => scan.status === 'RUNNING') || []
        if (runningScans.length > 0) {
          console.log(`Found ${runningScans.length} running code scans:`, runningScans.map((s: CodeScan) => s.name))
        }
      }
    } catch (error) {
      console.error('Error fetching code scans:', error)
      if (!isPolling) {
        toast({
          title: "Error",
          description: "Failed to fetch code scans",
          variant: "destructive"
        })
      }
    } finally {
      if (!isPolling) {
        setIsLoading(false)
      }
    }
  }

  const validateForm = (): boolean => {
    if (!newScan.name.trim()) {
      setValidationError('Scan name is required')
      return false
    }

    if (!newScan.target.trim()) {
      setValidationError('Target is required')
      return false
    }

    // Validate target - should be a repository path or directory
    if (!newScan.target.includes('github.com') && !newScan.target.startsWith('/') && !newScan.target.includes('gitlab.com')) {
      setValidationError('Target must be a valid repository URL or file path')
      return false
    }

    setValidationError('')
    return true
  }

  const handleCreateScan = async () => {
    if (!validateForm()) return

    try {
      setIsCreating(true)
      
      const response = await fetch('/api/scans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newScan,
          type: 'CODE_SCAN',
          userId
        })
      })

      if (response.ok) {
        const data = await response.json()
        setScans(prev => [data.scan, ...prev])
        setNewScan({
          name: '',
          target: '',
          scanType: 'comprehensive',
          config: {
            maxFileSize: 10 * 1024 * 1024,
            includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.cpp', '.c'],
            excludePaths: ['node_modules', '.git', 'dist', 'build', 'vendor'],
            deepScan: true,
            owaspStandards: ['ASVS_L2', 'OWASP_TOP10'],
            languages: ['javascript', 'python', 'java'],
            qualityGates: ['code_coverage', 'complexity', 'duplication'],
            securityRules: ['injection', 'xss', 'auth', 'crypto']
          }
        })
        toast({
          title: "Success",
          description: "Code scan started successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to create code scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error creating code scan:', error)
      toast({
        title: "Error",
        description: "Failed to create code scan",
        variant: "destructive"
      })
    } finally {
      setIsCreating(false)
    }
  }

  const handleStopScan = async (scanId: string) => {
    try {
      setScans(prev => prev.map(scan => 
        scan.id === scanId ? { ...scan, status: 'FAILED' } : scan
      ))
      
      toast({
        title: "Success",
        description: "Code scan stopped successfully",
      })
    } catch (error) {
      console.error('Error stopping code scan:', error)
      toast({
        title: "Error",
        description: "Failed to stop code scan",
        variant: "destructive"
      })
    }
  }

  const handleDeleteScan = async (scanId: string) => {
    if (!confirm('Are you sure you want to delete this code scan and all its findings? This action cannot be undone.')) {
      return
    }

    try {
      const response = await fetch(`/api/scans/${scanId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setScans(prev => prev.filter(scan => scan.id !== scanId))
        toast({
          title: "Success",
          description: "Code scan deleted successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to delete code scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error deleting code scan:', error)
      toast({
        title: "Error",
        description: "Failed to delete code scan",
        variant: "destructive"
      })
    }
  }

  const handleViewFindings = async (scanId: string) => {
    router.push(`/code-scanner/${scanId}`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <Clock className="h-3 w-3 animate-spin" />
      case 'FAILED':
        return <AlertTriangle className="h-3 w-3" />
      case 'PENDING':
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getScanTypeIcon = (type: string) => {
    switch (type) {
      case 'security':
        return <Shield className="h-5 w-5" />
      case 'quality':
        return <FileText className="h-5 w-5" />
      case 'compliance':
        return <Database className="h-5 w-5" />
      case 'comprehensive':
        return <Code className="h-5 w-5" />
      default:
        return <Search className="h-5 w-5" />
    }
  }

  const getScanTypeName = (type: string) => {
    const scanType = SCAN_TYPES.find(t => t.id === type)
    return scanType ? scanType.name : type
  }

  const getSeverityColor = (count: number) => {
    if (count === 0) return 'bg-green-100 text-green-800'
    if (count <= 3) return 'bg-yellow-100 text-yellow-800'
    if (count <= 10) return 'bg-orange-100 text-orange-800'
    return 'bg-red-100 text-red-800'
  }

  const formatTarget = (target: string) => {
    if (target.length > 50) {
      return target.substring(0, 50) + '...'
    }
    return target
  }

  const getFindingSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getFindingIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'security': return <Shield className="h-4 w-4" />
      case 'quality': return <FileText className="h-4 w-4" />
      case 'compliance': return <Database className="h-4 w-4" />
      case 'code_smell': return <Bug className="h-4 w-4" />
      case 'vulnerability': return <AlertTriangle className="h-4 w-4" />
      default: return <Code className="h-4 w-4" />
    }
  }

  const getOWASPStandardName = (standardId: string) => {
    const standard = OWASP_CODE_SCAN_STANDARDS.find(std => std.id === standardId)
    return standard ? standard.name : standardId
  }

  const getLanguageName = (languageId: string) => {
    const language = SUPPORTED_LANGUAGES.find(lang => lang.id === languageId)
    return language ? language.name : languageId
  }

  const handleGenerateReport = (format: 'html' | 'pdf' = 'html') => {
    const completedScans = scans.filter(scan => scan.status === 'COMPLETED')
    if (completedScans.length === 0) {
      toast({
        title: "No Data",
        description: "No completed scans available for report generation",
        variant: "destructive"
      })
      return
    }

    try {
      const reportData = prepareReportDataFromScans(completedScans, 'Code Security')
      downloadReport(reportData, format)
      toast({
        title: "Report Generated",
        description: `Code Security Scan report has been generated in ${format.toUpperCase()} format`,
      })
    } catch (error) {
      console.error('Error generating report:', error)
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive"
      })
    }
  }

  return (
    <RBACGuard requiredRoles={['ADMIN', 'MEMBER']}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Code Scanner</h2>
            <p className="text-muted-foreground">
              OWASP standards compliant code analysis for security, quality, and compliance
            </p>
          </div>
          <div className="flex items-center space-x-2">
            {isConnected ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Wifi className="h-3 w-3 mr-1" />
                Live
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                <WifiOff className="h-3 w-3 mr-1" />
                Offline
              </Badge>
            )}
            {lastUpdate && (
              <span className="text-xs text-muted-foreground">
                Last update: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>

        {/* Create New Scan Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-5 w-5" />
              <span>Create New Code Scan</span>
            </CardTitle>
            <CardDescription>
              Configure OWASP standards compliant code analysis
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Scan Name</label>
                <Input
                  placeholder="Enter scan name"
                  value={newScan.name}
                  onChange={(e) => setNewScan(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Target Repository</label>
                <Input
                  placeholder="GitHub repository or local path"
                  value={newScan.target}
                  onChange={(e) => setNewScan(prev => ({ ...prev, target: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Scan Type</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={newScan.scanType}
                  onChange={(e) => setNewScan(prev => ({ ...prev, scanType: e.target.value }))}
                >
                  {SCAN_TYPES.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {validationError && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{validationError}</AlertDescription>
              </Alert>
            )}

            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={() => setShowConfig(!showConfig)}
              >
                <Settings className="h-4 w-4 mr-2" />
                {showConfig ? 'Hide' : 'Show'} Advanced Configuration
              </Button>
              <Button
                onClick={handleCreateScan}
                disabled={isCreating}
              >
                {isCreating ? (
                  <>
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Start Scan
                  </>
                )}
              </Button>
            </div>

            {showConfig && (
              <div className="border rounded-lg p-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">OWASP Standards</h4>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {OWASP_CODE_SCAN_STANDARDS.map(standard => (
                        <label key={standard.id} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={newScan.config?.owaspStandards?.includes(standard.id) || false}
                            onChange={(e) => {
                              const standards = newScan.config?.owaspStandards || []
                              if (e.target.checked) {
                                setNewScan(prev => ({
                                  ...prev,
                                  config: {
                                    ...prev.config!,
                                    owaspStandards: [...standards, standard.id]
                                  }
                                }))
                              } else {
                                setNewScan(prev => ({
                                  ...prev,
                                  config: {
                                    ...prev.config!,
                                    owaspStandards: standards.filter(id => id !== standard.id)
                                  }
                                }))
                              }
                            }}
                            className="rounded"
                          />
                          <span className="text-sm">
                            <strong>{standard.id}:</strong> {standard.name}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Programming Languages</h4>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {SUPPORTED_LANGUAGES.map(language => (
                        <label key={language.id} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={newScan.config?.languages?.includes(language.id) || false}
                            onChange={(e) => {
                              const languages = newScan.config?.languages || []
                              if (e.target.checked) {
                                setNewScan(prev => ({
                                  ...prev,
                                  config: {
                                    ...prev.config!,
                                    languages: [...languages, language.id]
                                  }
                                }))
                              } else {
                                setNewScan(prev => ({
                                  ...prev,
                                  config: {
                                    ...prev.config!,
                                    languages: languages.filter(id => id !== language.id)
                                  }
                                }))
                              }
                            }}
                            className="rounded"
                          />
                          <span className="text-sm">{language.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Scans Progress */}
        {scans.filter(scan => scan.status === 'RUNNING').length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5 animate-spin" />
                <span>Active Scans</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scans.filter(scan => scan.status === 'RUNNING').map(scan => (
                  <div key={scan.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{scan.name}</span>
                      <Badge className={getStatusColor(scan.status)}>
                        {getStatusIcon(scan.status)}
                        <span className="ml-1">{scan.status}</span>
                      </Badge>
                    </div>
                    <Progress value={scanProgress} className="h-2" />
                    <div className="text-xs text-muted-foreground">
                      {Math.round(scanProgress)}% complete
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Scans */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Code Scans</CardTitle>
                <CardDescription>
                  OWASP standards compliant code analysis results
                </CardDescription>
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerateReport('html')}
                  disabled={scans.filter(s => s.status === 'COMPLETED').length === 0}
                >
                  <Download className="h-4 w-4 mr-2" />
                  HTML Report
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerateReport('pdf')}
                  disabled={scans.filter(s => s.status === 'COMPLETED').length === 0}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  PDF Report
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fetchScans()}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4 mr-2" />
                  )}
                  Refresh
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="animate-pulse">
                    <div className="h-20 bg-gray-200 rounded-lg"></div>
                  </div>
                ))}
              </div>
            ) : scans.length === 0 ? (
              <div className="text-center py-8">
                <Code className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Code Scans</h3>
                <p className="text-gray-500">Create your first OWASP standards compliant code scan to get started.</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {scans.map((scan) => (
                  <div key={scan.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className="p-2 bg-green-100 rounded-lg">
                          {getScanTypeIcon(scan.scanType)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{scan.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {getScanTypeName(scan.scanType)} • {formatTarget(scan.target)}
                          </p>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge className={getStatusColor(scan.status)}>
                              {getStatusIcon(scan.status)}
                              <span className="ml-1">{scan.status}</span>
                            </Badge>
                            <Badge variant="outline">
                              {scan._count?.findings || 0} findings
                            </Badge>
                            {scan.owaspStandards && scan.owaspStandards.length > 0 && (
                              <Badge variant="outline">
                                {scan.owaspStandards.length} standards
                              </Badge>
                            )}
                            {scan.languages && scan.languages.length > 0 && (
                              <Badge variant="outline">
                                {scan.languages.length} languages
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {scan.status === 'RUNNING' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleStopScan(scan.id)}
                          >
                            <Pause className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewFindings(scan.id)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteScan(scan.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </RBACGuard>
  )
}