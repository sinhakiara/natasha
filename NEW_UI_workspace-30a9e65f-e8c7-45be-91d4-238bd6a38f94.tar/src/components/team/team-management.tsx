'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Users, 
  Building, 
  Plus, 
  Mail, 
  UserPlus, 
  Settings, 
  Shield,
  Crown,
  User,
  Trash2,
  Edit,
  Globe,
  Calendar,
  Activity,
  AlertTriangle
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Organization {
  id: string
  name: string
  description?: string
  createdAt: string
  _count: {
    members: number
    domains: number
    monitors: number
    scans: number
  }
}

interface OrganizationMember {
  id: string
  userId: string
  organizationId: string
  role: 'ADMIN' | 'MEMBER' | 'VIEWER'
  createdAt: string
  user: {
    id: string
    email: string
    name?: string
    createdAt: string
  }
}

interface Domain {
  id: string
  domain: string
  organizationId: string
  isActive: boolean
  createdAt: string
}

interface NewOrganizationForm {
  name: string
  description: string
}

interface NewMemberForm {
  email: string
  role: 'ADMIN' | 'MEMBER' | 'VIEWER'
}

interface NewDomainForm {
  domain: string
}

export function TeamManagement() {
  const { data: session } = useSession()
  const [organizations, setOrganizations] = useState<Organization[]>([])
  const [members, setMembers] = useState<OrganizationMember[]>([])
  const [domains, setDomains] = useState<Domain[]>([])
  const [selectedOrganization, setSelectedOrganization] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isCreatingOrg, setIsCreatingOrg] = useState(false)
  const [isAddingMember, setIsAddingMember] = useState(false)
  const [isAddingDomain, setIsAddingDomain] = useState(false)
  const [newOrganization, setNewOrganization] = useState<NewOrganizationForm>({
    name: '',
    description: ''
  })
  const [newMember, setNewMember] = useState<NewMemberForm>({
    email: '',
    role: 'MEMBER'
  })
  const [newDomain, setNewDomain] = useState<NewDomainForm>({
    domain: ''
  })
  const [validationError, setValidationError] = useState('')
  const { toast } = useToast()

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3' // Admin user ID as fallback

  useEffect(() => {
    fetchOrganizations()
  }, [])

  useEffect(() => {
    if (selectedOrganization) {
      fetchOrganizationDetails()
    }
  }, [selectedOrganization])

  const fetchOrganizations = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/organizations?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setOrganizations(data.organizations || [])
        if (data.organizations?.length > 0 && !selectedOrganization) {
          setSelectedOrganization(data.organizations[0].id)
        }
      }
    } catch (error) {
      console.error('Error fetching organizations:', error)
      toast({
        title: "Error",
        description: "Failed to fetch organizations",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const fetchOrganizationDetails = async () => {
    if (!selectedOrganization) return

    try {
      const [membersResponse, domainsResponse] = await Promise.all([
        fetch(`/api/organizations/${selectedOrganization}/members`),
        fetch(`/api/organizations/${selectedOrganization}/domains`)
      ])

      if (membersResponse.ok) {
        const membersData = await membersResponse.json()
        setMembers(membersData.members || [])
      }

      if (domainsResponse.ok) {
        const domainsData = await domainsResponse.json()
        setDomains(domainsData.domains || [])
      }
    } catch (error) {
      console.error('Error fetching organization details:', error)
      toast({
        title: "Error",
        description: "Failed to fetch organization details",
        variant: "destructive"
      })
    }
  }

  const validateOrganizationForm = (): boolean => {
    if (!newOrganization.name.trim()) {
      setValidationError('Organization name is required')
      return false
    }

    if (newOrganization.name.length < 3) {
      setValidationError('Organization name must be at least 3 characters long')
      return false
    }

    setValidationError('')
    return true
  }

  const validateMemberForm = (): boolean => {
    if (!newMember.email.trim()) {
      setValidationError('Email is required')
      return false
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(newMember.email)) {
      setValidationError('Please enter a valid email address')
      return false
    }

    setValidationError('')
    return true
  }

  const validateDomainForm = (): boolean => {
    if (!newDomain.domain.trim()) {
      setValidationError('Domain is required')
      return false
    }

    // More permissive domain validation that allows common domain formats
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/
    const input = newDomain.domain.trim().toLowerCase()
    
    // Remove any protocol or path if present
    const cleanDomain = input.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0]
    
    if (!domainRegex.test(cleanDomain)) {
      setValidationError('Please enter a valid domain name (e.g., example.com)')
      return false
    }

    // Update the form value with the cleaned domain
    setNewDomain(prev => ({ ...prev, domain: cleanDomain }))
    setValidationError('')
    return true
  }

  const handleCreateOrganization = async () => {
    if (!validateOrganizationForm()) return

    try {
      setIsCreatingOrg(true)
      
      const response = await fetch('/api/organizations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newOrganization,
          userId
        })
      })

      if (response.ok) {
        const data = await response.json()
        setOrganizations(prev => [data.organization, ...prev])
        setNewOrganization({ name: '', description: '' })
        setSelectedOrganization(data.organization.id)
        toast({
          title: "Success",
          description: "Organization created successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to create organization",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error creating organization:', error)
      toast({
        title: "Error",
        description: "Failed to create organization",
        variant: "destructive"
      })
    } finally {
      setIsCreatingOrg(false)
    }
  }

  const handleAddMember = async () => {
    if (!selectedOrganization || !validateMemberForm()) return

    try {
      setIsAddingMember(true)
      
      const response = await fetch(`/api/organizations/${selectedOrganization}/members`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newMember)
      })

      if (response.ok) {
        const data = await response.json()
        setMembers(prev => [data.member, ...prev])
        setNewMember({ email: '', role: 'MEMBER' })
        toast({
          title: "Success",
          description: "Member added successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to add member",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error adding member:', error)
      toast({
        title: "Error",
        description: "Failed to add member",
        variant: "destructive"
      })
    } finally {
      setIsAddingMember(false)
    }
  }

  const handleAddDomain = async () => {
    if (!selectedOrganization || !validateDomainForm()) return

    try {
      setIsAddingDomain(true)
      setValidationError('') // Clear any previous validation errors
      
      const response = await fetch(`/api/organizations/${selectedOrganization}/domains`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newDomain)
      })

      if (response.ok) {
        const data = await response.json()
        setDomains(prev => [data.domain, ...prev])
        setNewDomain({ domain: '' })
        toast({
          title: "Success",
          description: "Domain added successfully",
        })
      } else {
        const error = await response.json()
        const errorMessage = error.error || "Failed to add domain"
        setValidationError(errorMessage)
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error adding domain:', error)
      const errorMessage = error instanceof Error ? error.message : "Failed to add domain"
      setValidationError(errorMessage)
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive"
      })
    } finally {
      setIsAddingDomain(false)
    }
  }

  const handleRemoveMember = async (memberId: string) => {
    if (!selectedOrganization) return

    try {
      const response = await fetch(`/api/organizations/${selectedOrganization}/members/${memberId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setMembers(prev => prev.filter(m => m.id !== memberId))
        toast({
          title: "Success",
          description: "Member removed successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to remove member",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error removing member:', error)
      toast({
        title: "Error",
        description: "Failed to remove member",
        variant: "destructive"
      })
    }
  }

  const handleToggleDomain = async (domainId: string, isActive: boolean) => {
    if (!selectedOrganization) return

    try {
      const response = await fetch(`/api/organizations/${selectedOrganization}/domains/${domainId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive })
      })

      if (response.ok) {
        setDomains(prev => prev.map(d => 
          d.id === domainId ? { ...d, isActive } : d
        ))
        toast({
          title: "Success",
          description: `Domain ${isActive ? 'activated' : 'deactivated'} successfully`,
        })
      } else {
        const error = await response.json()
        const errorMessage = error.error || "Failed to update domain"
        setValidationError(errorMessage)
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error updating domain:', error)
      const errorMessage = error instanceof Error ? error.message : "Failed to update domain"
      setValidationError(errorMessage)
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive"
      })
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'ADMIN': return 'bg-red-100 text-red-800 border-red-200'
      case 'MEMBER': return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'VIEWER': return 'bg-gray-100 text-gray-800 border-gray-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'ADMIN': return <Crown className="h-4 w-4" />
      case 'MEMBER': return <User className="h-4 w-4" />
      case 'VIEWER': return <Shield className="h-4 w-4" />
      default: return <User className="h-4 w-4" />
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Team Management</h2>
          <p className="text-muted-foreground">
            Manage your team members and organizations
          </p>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Team Management</h2>
        <p className="text-muted-foreground">
          Manage your team members and organizations
        </p>
      </div>

      {/* Create Organization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Create Organization
          </CardTitle>
          <CardDescription>Set up a new organization for your team</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {validationError && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{validationError}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium">Organization Name</label>
              <Input
                placeholder="e.g., Acme Corp Security"
                value={newOrganization.name}
                onChange={(e) => setNewOrganization(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Description (Optional)</label>
              <Input
                placeholder="e.g., Security team for Acme Corporation"
                value={newOrganization.description}
                onChange={(e) => setNewOrganization(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>
          </div>
          
          <Button 
            onClick={handleCreateOrganization} 
            disabled={isCreatingOrg}
            className="w-full"
          >
            {isCreatingOrg ? 'Creating...' : 'Create Organization'}
          </Button>
        </CardContent>
      </Card>

      {/* Organizations List */}
      {organizations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Your Organizations</CardTitle>
            <CardDescription>Select an organization to manage its members and domains</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {organizations.map((org) => (
                <div
                  key={org.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedOrganization === org.id ? 'border-primary bg-primary/5' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedOrganization(org.id)}
                >
                  <div className="flex items-center justify-between mb-3">
                    <Building className="h-6 w-6 text-gray-600" />
                    {selectedOrganization === org.id && (
                      <Badge variant="default">Selected</Badge>
                    )}
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">{org.name}</h3>
                  {org.description && (
                    <p className="text-sm text-gray-500 mb-3">{org.description}</p>
                  )}
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>Created {new Date(org.createdAt).toLocaleDateString()}</span>
                    <div className="flex items-center space-x-2">
                      <span>{org._count.members} members</span>
                      <span>{org._count.domains} domains</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Organization Management */}
      {selectedOrganization && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Organization Management
            </CardTitle>
            <CardDescription>Manage members and domains for the selected organization</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="members" className="space-y-4">
              <TabsList>
                <TabsTrigger value="members">Team Members</TabsTrigger>
                <TabsTrigger value="domains">Domains</TabsTrigger>
              </TabsList>

              <TabsContent value="members" className="space-y-4">
                {/* Add Member */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Add Team Member</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {validationError && (
                      <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>{validationError}</AlertDescription>
                      </Alert>
                    )}
                    
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <label className="text-sm font-medium">Email Address</label>
                        <Input
                          type="email"
                          placeholder="member@example.com"
                          value={newMember.email}
                          onChange={(e) => setNewMember(prev => ({ ...prev, email: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Role</label>
                        <Select
                          value={newMember.role}
                          onValueChange={(value: 'ADMIN' | 'MEMBER' | 'VIEWER') => 
                            setNewMember(prev => ({ ...prev, role: value }))
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ADMIN">Admin - Full access</SelectItem>
                            <SelectItem value="MEMBER">Member - Read & write</SelectItem>
                            <SelectItem value="VIEWER">Viewer - Read only</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <Button 
                      onClick={handleAddMember} 
                      disabled={isAddingMember}
                      className="w-full"
                    >
                      {isAddingMember ? 'Adding...' : 'Add Member'}
                    </Button>
                  </CardContent>
                </Card>

                {/* Members List */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Current Members</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {members.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        No team members yet. Add your first team member above.
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {members.map((member) => (
                          <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center space-x-4">
                              <div className="flex-shrink-0">
                                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                                  <User className="h-5 w-5 text-gray-600" />
                                </div>
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2">
                                  <h3 className="text-sm font-medium text-gray-900">
                                    {member.user.name || member.user.email}
                                  </h3>
                                  <Badge variant="outline" className={getRoleColor(member.role)}>
                                    {getRoleIcon(member.role)}
                                    {member.role}
                                  </Badge>
                                </div>
                                <p className="text-sm text-gray-500 truncate">
                                  {member.user.email}
                                </p>
                                <p className="text-xs text-gray-400">
                                  Joined {new Date(member.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveMember(member.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="domains" className="space-y-4">
                {/* Add Domain */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Add Domain</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {validationError && (
                      <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>{validationError}</AlertDescription>
                      </Alert>
                    )}
                    
                    <div>
                      <label className="text-sm font-medium">Domain Name</label>
                      <Input
                        placeholder="example.com"
                        value={newDomain.domain}
                        onChange={(e) => setNewDomain(prev => ({ ...prev, domain: e.target.value }))}
                      />
                    </div>
                    
                    <Button 
                      onClick={handleAddDomain} 
                      disabled={isAddingDomain}
                      className="w-full"
                    >
                      {isAddingDomain ? 'Adding...' : 'Add Domain'}
                    </Button>
                  </CardContent>
                </Card>

                {/* Domains List */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Organization Domains</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {domains.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        No domains added yet. Add your first domain above.
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {domains.map((domain) => (
                          <div key={domain.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center space-x-4">
                              <div className="flex-shrink-0">
                                <Globe className="h-6 w-6 text-gray-600" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2">
                                  <h3 className="text-sm font-medium text-gray-900">
                                    {domain.domain}
                                  </h3>
                                  <Badge variant={domain.isActive ? "default" : "secondary"}>
                                    {domain.isActive ? 'Active' : 'Inactive'}
                                  </Badge>
                                </div>
                                <p className="text-xs text-gray-400">
                                  Added {new Date(domain.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleToggleDomain(domain.id, !domain.isActive)}
                              >
                                {domain.isActive ? 'Deactivate' : 'Activate'}
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {organizations.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Organizations Yet</h3>
            <p className="text-gray-500 mb-4">Create your first organization to start managing your team.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}