'use client'

import { SessionProvider } from 'next-auth/react'
import { ReactNode } from 'react'

interface SessionProviderProps {
  children: ReactNode
}

export function SessionAuthProvider({ children }: SessionProviderProps) {
  return <SessionProvider>{children}</SessionProvider>
}