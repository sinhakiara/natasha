import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create demo users
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@sentinel.com' },
    update: {},
    create: {
      email: 'admin@sentinel.com',
      name: 'Admin User',
    },
  })

  const memberUser = await prisma.user.upsert({
    where: { email: 'member@sentinel.com' },
    update: {},
    create: {
      email: 'member@sentinel.com',
      name: 'Member User',
    },
  })

  const viewerUser = await prisma.user.upsert({
    where: { email: 'viewer@sentinel.com' },
    update: {},
    create: {
      email: 'viewer@sentinel.com',
      name: 'Viewer User',
    },
  })

  // Create demo organization
  const organization = await prisma.organization.create({
    data: {
      name: 'Demo Security Team',
      description: 'Demo organization for security monitoring',
    },
  })

  // Create organization members with different roles
  await prisma.organizationMember.upsert({
    where: {
      userId_organizationId: {
        userId: adminUser.id,
        organizationId: organization.id,
      },
    },
    update: {},
    create: {
      userId: adminUser.id,
      organizationId: organization.id,
      role: 'ADMIN',
    },
  })

  await prisma.organizationMember.upsert({
    where: {
      userId_organizationId: {
        userId: memberUser.id,
        organizationId: organization.id,
      },
    },
    update: {},
    create: {
      userId: memberUser.id,
      organizationId: organization.id,
      role: 'MEMBER',
    },
  })

  await prisma.organizationMember.upsert({
    where: {
      userId_organizationId: {
        userId: viewerUser.id,
        organizationId: organization.id,
      },
    },
    update: {},
    create: {
      userId: viewerUser.id,
      organizationId: organization.id,
      role: 'VIEWER',
    },
  })

  // Create demo domain
  await prisma.domain.create({
    data: {
      domain: 'example.com',
      organizationId: organization.id,
    },
  })

  // Create demo monitors
  const githubMonitor = await prisma.monitor.create({
    data: {
      name: 'GitHub Repository Monitor',
      type: 'GITHUB_REPO',
      target: 'https://github.com/example/repo',
      config: JSON.stringify({
        scanFrequency: 'hourly',
        secretTypes: ['API_KEY', 'TOKEN', 'PASSWORD'],
        notifications: true,
      }),
      userId: adminUser.id,
      organizationId: organization.id,
    },
  })

  const domainMonitor = await prisma.monitor.create({
    data: {
      name: 'Domain Monitor',
      type: 'DOMAIN',
      target: 'example.com',
      config: JSON.stringify({
        scanFrequency: 'daily',
        checkSubdomains: true,
        monitorSSL: true,
      }),
      userId: memberUser.id,
      organizationId: organization.id,
    },
  })

  // Create demo leaks
  await prisma.leak.create({
    data: {
      monitorId: githubMonitor.id,
      type: 'API_KEY',
      severity: 'HIGH',
      title: 'GitHub API Key Detected',
      description: 'High-severity API key found in repository',
      content: 'ghp_xxxxxxxxxxxxxxxxxxxx',
      source: 'https://github.com/example/repo/blob/main/config.js',
      metadata: JSON.stringify({
        file: 'config.js',
        line: 42,
        commit: 'abc123',
      }),
      status: 'OPEN',
    },
  })

  await prisma.leak.create({
    data: {
      monitorId: domainMonitor.id,
      type: 'PASSWORD',
      severity: 'MEDIUM',
      title: 'Database Configuration Found',
      description: 'Database password exposed in configuration file',
      content: 'db_password=secret123',
      source: 'https://example.com/config/database.yml',
      metadata: JSON.stringify({
        file: 'database.yml',
        url: 'https://example.com/config/database.yml',
      }),
      status: 'OPEN',
    },
  })

  // Create demo scans
  const secretScan = await prisma.scan.create({
    data: {
      name: 'Secret Scan - Web Application',
      target: 'https://example.com',
      type: 'SECRET_SCAN',
      config: JSON.stringify({
        scanDepth: 'deep',
        includeJavaScript: true,
        checkComments: true,
      }),
      status: 'COMPLETED',
      userId: adminUser.id,
      organizationId: organization.id,
      startedAt: new Date(Date.now() - 3600000), // 1 hour ago
      completedAt: new Date(Date.now() - 1800000), // 30 minutes ago
    },
  })

  // Create demo findings
  await prisma.finding.create({
    data: {
      scanId: secretScan.id,
      type: 'SECRET',
      severity: 'HIGH',
      title: 'AWS Access Key Found',
      description: 'AWS access key detected in JavaScript file',
      content: 'AKIAIOSFODNN7EXAMPLE',
      source: 'https://example.com/js/app.js',
      metadata: JSON.stringify({
        file: 'app.js',
        line: 156,
        context: 'awsConfig',
      }),
      isValid: true,
    },
  })

  // Create demo alerts
  await prisma.alert.create({
    data: {
      title: 'High-Severity Leak Detected',
      message: 'GitHub API key detected in repository monitoring',
      type: 'LEAK_DETECTED',
      severity: 'HIGH',
      sourceId: githubMonitor.id,
      sourceType: 'monitor',
      userId: adminUser.id,
      monitorId: githubMonitor.id,
    },
  })

  await prisma.alert.create({
    data: {
      title: 'Secret Scan Completed',
      message: 'Secret scan completed with 1 finding',
      type: 'SCAN_COMPLETED',
      severity: 'MEDIUM',
      sourceId: secretScan.id,
      sourceType: 'scan',
      userId: memberUser.id,
    },
  })

  // Create demo token verifications
  await prisma.tokenVerification.create({
    data: {
      token: 'ghp_xxxxxxxxxxxxxxxxxxxx',
      type: 'GITHUB',
      service: 'GitHub',
      isValid: true,
      metadata: JSON.stringify({
        username: 'example-user',
        scopes: ['repo', 'user'],
        expiresAt: '2024-12-31T23:59:59Z',
      }),
      userId: adminUser.id,
      status: 'VERIFIED',
    },
  })

  await prisma.tokenVerification.create({
    data: {
      token: 'AKIAIOSFODNN7EXAMPLE',
      type: 'AWS',
      service: 'Amazon Web Services',
      isValid: false,
      metadata: JSON.stringify({
        error: 'Invalid access key',
        reason: 'Key not found in AWS',
      }),
      userId: memberUser.id,
      status: 'FAILED',
    },
  })

  // Create demo ZoomEye queries
  await prisma.zoomEyeQuery.create({
    data: {
      query: 'hostname:example.com',
      type: 'HOST',
      result: JSON.stringify({
        total: 5,
        matches: [
          {
            ip: '192.168.1.1',
            hostname: 'example.com',
            port: 80,
            banner: 'Apache/2.4.41',
          },
        ],
      }),
      userId: adminUser.id,
      status: 'COMPLETED',
    },
  })

  console.log('✅ Database seeded successfully!')
  console.log('Demo credentials:')
  console.log('Admin: admin@sentinel.com / demo123')
  console.log('Member: member@sentinel.com / demo123')
  console.log('Viewer: viewer@sentinel.com / demo123')
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })