'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Github, 
  Search, 
  Shield, 
  Globe, 
  Bell, 
  Activity,
  Key,
  Network,
  BarChart3,
  Users,
  Database,
  Code,
  RefreshCw,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Zap,
  Target,
  ChevronLeft,
  ChevronRight,
  Cpu,
  HardDrive,
  Wifi,
  Radio,
  Satellite
} from 'lucide-react'
import { Toaster } from '@/components/ui/toaster'
import { useToast } from '@/hooks/use-toast'
import { AuthGuard } from '@/components/auth/auth-guard'
import { UserProfile } from '@/components/auth/user-profile'
import { GitHubMonitor } from '@/components/monitors/github-monitor'
import { SignInButton } from '@/components/auth/sign-in-button'

import { VulnerabilityScanner } from '@/components/scans/vulnerability-scanner'
import { CodeScanner } from '@/components/scans/code-scanner'
import { TokenVerifier } from '@/components/tokens/token-verifier'
import { NetworkIntelligence } from '@/components/network/network-intelligence'
import { AnalyticsDashboard } from '@/components/reports/analytics-dashboard'
import RealTimeMonitoring from '@/components/monitoring/real-time-monitoring'
import { TeamManagement } from '@/components/team/team-management'
import { ThreatIntelligenceDashboard } from '@/components/threat-intelligence/threat-intelligence-dashboard'
import { EnhancedSecretScanner } from '@/components/secrets/enhanced-secret-scanner'

export default function CyberAegisDashboard() {
  const [activeTab, setActiveTab] = useState('overview')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [isSystemOnline, setIsSystemOnline] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [stats, setStats] = useState([
    { label: 'ACTIVE MONITORS', value: '0', change: '0', icon: Activity, trend: 'up', color: 'text-blue-400', performance: 'excellent' },
    { label: 'THREATS DETECTED', value: '0', change: '0', icon: Shield, trend: 'down', color: 'text-red-400', performance: 'critical' },
    { label: 'TOKENS VERIFIED', value: '0', change: '0', icon: Key, trend: 'up', color: 'text-green-400', performance: 'good' },
    { label: 'NETWORK ASSETS', value: '0', change: '0', icon: Globe, trend: 'up', color: 'text-purple-400', performance: 'good' }
  ])
  const [recentAlerts, setRecentAlerts] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [systemHealth, setSystemHealth] = useState({
    cpu: 85,
    memory: 72,
    disk: 45,
    network: 92
  })
  const { toast } = useToast()
  const { data: session } = useSession()

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    
    const url = new URL(window.location.href)
    if (tab === 'overview') {
      url.searchParams.delete('tab')
    } else {
      url.searchParams.set('tab', tab)
    }
    window.history.pushState({}, '', url.toString())
  }

  useEffect(() => {
    const handleTabParameter = () => {
      const urlParams = new URLSearchParams(window.location.search)
      const tabParam = urlParams.get('tab')
      if (tabParam && ['overview', 'realtime', 'monitors', 'scans', 'tokens', 'network', 'threatintel', 'reports', 'team'].includes(tabParam)) {
        setActiveTab(tabParam)
      }
    }

    handleTabParameter()
    window.addEventListener('popstate', handleTabParameter)
    fetchDashboardData()
    
    const interval = setInterval(() => {
      if (activeTab === 'overview') {
        fetchDashboardData()
      }
    }, 30000)
    
    return () => {
      window.removeEventListener('popstate', handleTabParameter)
      clearInterval(interval)
    }
  }, [activeTab])

  const features = [
    {
      id: 'github-monitor',
      title: 'GITHUB MONITOR',
      description: 'Real-time repository surveillance for exposed secrets',
      icon: Github,
      color: 'from-cyan-500 to-blue-500',
      badge: '99.9% UPTIME',
      status: 'ACTIVE'
    },
    {
      id: 'enhanced-secret-scanner',
      title: 'SECRET SCANNER',
      description: 'Advanced AI-powered secret detection across platforms',
      icon: Search,
      color: 'from-green-500 to-emerald-500',
      badge: 'AI-ENHANCED',
      status: 'ACTIVE'
    },
    {
      id: 'token-verifier',
      title: 'TOKEN VERIFIER',
      description: 'Multi-platform token validation system',
      icon: Key,
      color: 'from-purple-500 to-violet-500',
      badge: '14+ SERVICES',
      status: 'ACTIVE'
    },
    {
      id: 'network-intel',
      title: 'NETWORK INTEL',
      description: 'Asset reconnaissance and threat mapping',
      icon: Network,
      color: 'from-red-500 to-pink-500',
      badge: 'LIVE FEED',
      status: 'ACTIVE'
    }
  ]

  const fetchDashboardData = async () => {
    try {
      setIsLoading(true)
      const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3'
      
      const statsResponse = await fetch(`/api/monitoring/stats?userId=${userId}`)
      if (statsResponse.ok) {
        const data = await statsResponse.json()
        const metrics = data.metrics || {}
        setStats([
          { 
            label: 'ACTIVE MONITORS', 
            value: metrics.activeMonitors?.toString() || '0', 
            change: '0', 
            icon: Activity, 
            trend: 'up', 
            color: 'text-blue-400',
            performance: metrics.activeMonitors > 10 ? 'excellent' : metrics.activeMonitors > 5 ? 'good' : 'warning'
          },
          { 
            label: 'THREATS DETECTED', 
            value: metrics.totalLeaks?.toString() || '0', 
            change: '0', 
            icon: Shield, 
            trend: 'down', 
            color: 'text-red-400',
            performance: metrics.totalLeaks > 10 ? 'critical' : metrics.totalLeaks > 5 ? 'warning' : 'good'
          },
          { 
            label: 'TOKENS VERIFIED', 
            value: metrics.validTokens?.toString() || '0', 
            change: '0', 
            icon: Key, 
            trend: 'up', 
            color: 'text-green-400',
            performance: metrics.validTokens > 20 ? 'excellent' : metrics.validTokens > 10 ? 'good' : 'warning'
          },
          { 
            label: 'NETWORK ASSETS', 
            value: metrics.totalNetworkAssets?.toString() || '0', 
            change: '0', 
            icon: Globe, 
            trend: 'up', 
            color: 'text-purple-400',
            performance: metrics.totalNetworkAssets > 50 ? 'excellent' : metrics.totalNetworkAssets > 25 ? 'good' : 'warning'
          }
        ])
      }

      const alertsResponse = await fetch(`/api/alerts?userId=${userId}&limit=5`)
      if (alertsResponse.ok) {
        const alertsData = await alertsResponse.json()
        setRecentAlerts(alertsData.alerts || [])
      }

      // Fetch real system health data
      const healthResponse = await fetch(`/api/system/health`)
      if (healthResponse.ok) {
        const healthData = await healthResponse.json()
        setSystemHealth({
          cpu: Math.round(healthData.systemHealth.cpu),
          memory: Math.round(healthData.systemHealth.memory),
          disk: Math.round(healthData.systemHealth.disk),
          network: Math.round(healthData.systemHealth.network)
        })
      }

      setLastUpdate(new Date())
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
      toast({
        title: "SYSTEM ERROR",
        description: "Data fetch failed",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground font-sans tech-grid-enhanced">
        {/* Header */}
        <header className="border-b border-border bg-card/80 backdrop-blur-sm geometric-border">
          <div className="flex h-16 items-center px-8">
            <div className="flex items-center space-x-6">
              <div className="relative">
                <Shield className="h-10 w-10 text-primary pulse-glow" />
                <div className="absolute -top-1 -right-1 h-4 w-4 bg-green-500 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-2xl font-black tracking-tight cyberaegis-text-gradient">
                  CYBERAEGIS
                </h1>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Shield Defense System</p>
              </div>
            </div>
            <div className="ml-auto flex items-center space-x-6">
              <div className="flex items-center space-x-3 text-sm">
                <div className={`h-3 w-3 rounded-full ${isSystemOnline ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
                <span className="high-contrast-text">{isSystemOnline ? 'ONLINE' : 'OFFLINE'}</span>
              </div>
              <Button 
                className="cyberaegis-button border border-primary/30 hover:border-primary relative"
                onClick={() => {
                  // Show unread alerts count and toggle alerts visibility
                  const unreadAlerts = recentAlerts.filter(alert => !alert.isRead).length
                  if (unreadAlerts > 0) {
                    toast({
                      title: `${unreadAlerts} Unread Alerts`,
                      description: "Check the Overview tab for recent security alerts",
                      variant: "destructive"
                    })
                  } else {
                    toast({
                      title: "No New Alerts",
                      description: "All systems are operating normally",
                    })
                  }
                }}
              >
                <Bell className="h-4 w-4 mr-2" />
                ALERTS
                <Badge className="ml-2 bg-destructive text-destructive-foreground border-0">
                  {recentAlerts.filter(alert => !alert.isRead).length}
                </Badge>
              </Button>
              {session ? (
                <UserProfile />
              ) : (
                <SignInButton />
              )}
            </div>
          </div>
        </header>

        <div className="flex">
          {/* Sidebar */}
          <aside className={`${sidebarCollapsed ? 'w-20' : 'w-80'} border-r border-border bg-card/60 backdrop-blur-sm transition-all duration-300 cyberaegis-scroll`}>
            <div className="p-6">
              <Button 
                variant="ghost" 
                size="sm" 
                className="mb-8 w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-button"
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              >
                {sidebarCollapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
              </Button>
              
              {!sidebarCollapsed && (
                <nav className="space-y-3">
                  <Button
                    variant={activeTab === 'overview' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('overview')}
                  >
                    <BarChart3 className="h-5 w-5 mr-3" />
                    OVERVIEW
                  </Button>
                  <Button
                    variant={activeTab === 'realtime' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('realtime')}
                  >
                    <Radio className="h-5 w-5 mr-3" />
                    REAL-TIME
                  </Button>
                  <Button
                    variant={activeTab === 'monitors' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('monitors')}
                  >
                    <Activity className="h-5 w-5 mr-3" />
                    MONITORS
                  </Button>
                  <Button
                    variant={activeTab === 'scans' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('scans')}
                  >
                    <Search className="h-5 w-5 mr-3" />
                    SCANS
                  </Button>
                  <Button
                    variant={activeTab === 'tokens' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('tokens')}
                  >
                    <Key className="h-5 w-5 mr-3" />
                    TOKENS
                  </Button>
                  <Button
                    variant={activeTab === 'network' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('network')}
                  >
                    <Satellite className="h-5 w-5 mr-3" />
                    NETWORK
                  </Button>
                  <Button
                    variant={activeTab === 'threatintel' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('threatintel')}
                  >
                    <Target className="h-5 w-5 mr-3" />
                    THREAT INTEL
                  </Button>
                  <Button
                    variant={activeTab === 'reports' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('reports')}
                  >
                    <Database className="h-5 w-5 mr-3" />
                    REPORTS
                  </Button>
                  <Button
                    variant={activeTab === 'team' ? 'default' : 'ghost'}
                    className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/70 cyberaegis-sidebar-item font-medium"
                    onClick={() => handleTabChange('team')}
                  >
                    <Users className="h-5 w-5 mr-3" />
                    TEAM
                  </Button>
                </nav>
              )}
              
              {sidebarCollapsed && (
                <nav className="space-y-3">
                  <Button
                    variant={activeTab === 'overview' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('overview')}
                  >
                    <BarChart3 className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'realtime' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('realtime')}
                  >
                    <Radio className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'monitors' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('monitors')}
                  >
                    <Activity className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'scans' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('scans')}
                  >
                    <Search className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'tokens' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('tokens')}
                  >
                    <Key className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'network' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('network')}
                  >
                    <Satellite className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'threatintel' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('threatintel')}
                  >
                    <Target className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'reports' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('reports')}
                  >
                    <Database className="h-5 w-5" />
                  </Button>
                  <Button
                    variant={activeTab === 'team' ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-center text-muted-foreground hover:text-foreground cyberaegis-sidebar-item"
                    onClick={() => handleTabChange('team')}
                  >
                    <Users className="h-5 w-5" />
                  </Button>
                </nav>
              )}
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1 p-8 cyberaegis-scroll">
            {session ? (
              <AuthGuard requiredRoles={['ADMIN', 'MEMBER', 'VIEWER']}>
                {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {stats.map((stat, index) => (
                    <Card key={index} className="cyberaegis-card border-l-4 border-l-primary/50">
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="data-label security-mono">
                          {stat.label}
                        </CardTitle>
                        <div className="flex items-center space-x-2">
                          <stat.icon className={`h-5 w-5 ${stat.color}`} />
                          <div className={`performance-indicator performance-${stat.performance}`}>
                            {stat.performance.toUpperCase()}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="data-value security-mono">
                          {stat.value}
                        </div>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                            <span>{stat.change}% from last hour</span>
                            <TrendingUp className={`h-3 w-3 ${stat.trend === 'up' ? 'status-safe' : 'threat-critical'}`} />
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {lastUpdate.toLocaleTimeString()}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* System Health */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card className="cyberaegis-card border-l-4 border-l-blue-500/50">
                    <CardHeader>
                      <CardTitle className="text-lg font-bold high-contrast-text flex items-center justify-between">
                        <div className="flex items-center">
                          <Cpu className="h-5 w-5 mr-2 text-primary" />
                          SYSTEM HEALTH
                        </div>
                        <div className="performance-indicator performance-good">
                          OPERATIONAL
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="high-contrast-text security-mono">CPU</span>
                          <div className="flex items-center space-x-2">
                            <span className={`security-mono ${systemHealth.cpu > 90 ? 'threat-critical' : systemHealth.cpu > 75 ? 'threat-high' : 'status-safe'}`}>
                              {systemHealth.cpu}%
                            </span>
                            <div className={`performance-indicator performance-${systemHealth.cpu > 90 ? 'critical' : systemHealth.cpu > 75 ? 'warning' : 'excellent'}`}>
                              {systemHealth.cpu > 90 ? 'CRITICAL' : systemHealth.cpu > 75 ? 'WARNING' : 'NORMAL'}
                            </div>
                          </div>
                        </div>
                        <Progress value={systemHealth.cpu} className="h-3 bg-muted" />
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="high-contrast-text security-mono">MEMORY</span>
                          <div className="flex items-center space-x-2">
                            <span className={`security-mono ${systemHealth.memory > 90 ? 'threat-critical' : systemHealth.memory > 75 ? 'threat-high' : 'status-safe'}`}>
                              {systemHealth.memory}%
                            </span>
                            <div className={`performance-indicator performance-${systemHealth.memory > 90 ? 'critical' : systemHealth.memory > 75 ? 'warning' : 'excellent'}`}>
                              {systemHealth.memory > 90 ? 'CRITICAL' : systemHealth.memory > 75 ? 'WARNING' : 'NORMAL'}
                            </div>
                          </div>
                        </div>
                        <Progress value={systemHealth.memory} className="h-3 bg-muted" />
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="high-contrast-text security-mono">DISK</span>
                          <div className="flex items-center space-x-2">
                            <span className={`security-mono ${systemHealth.disk > 90 ? 'threat-critical' : systemHealth.disk > 75 ? 'threat-high' : 'status-safe'}`}>
                              {systemHealth.disk}%
                            </span>
                            <div className={`performance-indicator performance-${systemHealth.disk > 90 ? 'critical' : systemHealth.disk > 75 ? 'warning' : 'excellent'}`}>
                              {systemHealth.disk > 90 ? 'CRITICAL' : systemHealth.disk > 75 ? 'WARNING' : 'NORMAL'}
                            </div>
                          </div>
                        </div>
                        <Progress value={systemHealth.disk} className="h-3 bg-muted" />
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="high-contrast-text security-mono">NETWORK</span>
                          <div className="flex items-center space-x-2">
                            <span className={`security-mono ${systemHealth.network > 90 ? 'threat-critical' : systemHealth.network > 75 ? 'threat-high' : 'status-safe'}`}>
                              {systemHealth.network}%
                            </span>
                            <div className={`performance-indicator performance-${systemHealth.network > 90 ? 'critical' : systemHealth.network > 75 ? 'warning' : 'excellent'}`}>
                              {systemHealth.network > 90 ? 'CRITICAL' : systemHealth.network > 75 ? 'WARNING' : 'NORMAL'}
                            </div>
                          </div>
                        </div>
                        <Progress value={systemHealth.network} className="h-3 bg-muted" />
                      </div>
                      <div className="pt-4 border-t border-border/50">
                        <div className="flex justify-between items-center text-sm">
                          <span className="high-contrast-text security-mono">LAST UPDATE</span>
                          <span className="data-neutral security-mono">
                            {lastUpdate.toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="cyberaegis-card">
                    <CardHeader>
                      <CardTitle className="text-lg font-bold high-contrast-text flex items-center">
                        <Wifi className="h-5 w-5 mr-2 text-green-500" />
                        ACTIVE SYSTEMS
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {features.map((feature, index) => (
                          <div key={index} className="flex items-center justify-between p-3 rounded-lg border-l-4 border-l-primary/50 bg-muted/30">
                            <div className="flex items-center space-x-3">
                              <div className="relative">
                                <feature.icon className="h-5 w-5 text-primary" />
                                <div className="absolute -top-1 -right-1 h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-medium high-contrast-text security-mono">{feature.title}</p>
                                <p className="text-xs text-muted-foreground">{feature.description}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge className="bg-green-500/20 text-green-500 border-green-500/30 text-xs security-mono">
                                {feature.status}
                              </Badge>
                              <Badge className="bg-primary/20 text-primary border-primary/30 text-xs security-mono">
                                {feature.badge}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Recent Alerts */}
                <Card className="cyberaegis-card border-l-4 border-l-red-500/50">
                  <CardHeader>
                    <CardTitle className="text-lg font-bold text-foreground flex items-center justify-between">
                      <div className="flex items-center">
                        <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
                        <span className="text-foreground font-bold">RECENT ALERTS</span>
                      </div>
                      <div className="performance-indicator performance-warning">
                        {recentAlerts.length} ACTIVE
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-96 overflow-y-auto cyberaegis-scroll">
                      {recentAlerts.length > 0 ? recentAlerts.map((alert, index) => (
                        <div key={index} className={`flex items-center justify-between p-3 rounded-lg border-l-4 ${
                          alert.severity === 'critical' ? 'critical-alert border-l-red-500' :
                          alert.severity === 'high' ? 'high-alert border-l-orange-500' :
                          alert.severity === 'medium' ? 'medium-alert border-l-amber-500' :
                          alert.severity === 'low' ? 'low-alert border-l-blue-500' :
                          'info-alert border-l-slate-500'
                        }`}>
                          <div className="flex items-center space-x-3">
                            <div className={`h-3 w-3 rounded-full ${
                              alert.severity === 'critical' ? 'threat-critical animate-pulse' :
                              alert.severity === 'high' ? 'threat-high' :
                              alert.severity === 'medium' ? 'threat-medium' :
                              alert.severity === 'low' ? 'threat-low' :
                              'data-neutral'
                            }`}></div>
                            <div className="flex-1">
                              <p className="text-sm font-medium high-contrast-text security-mono">
                                {alert.title}
                              </p>
                              <p className="text-xs text-muted-foreground security-mono">
                                {alert.message || alert.description}
                              </p>
                              <p className="text-xs data-neutral security-mono mt-1">
                                {new Date(alert.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <Badge className={`${
                            alert.severity === 'critical' ? 'critical-alert' :
                            alert.severity === 'high' ? 'high-alert' :
                            alert.severity === 'medium' ? 'medium-alert' :
                            alert.severity === 'low' ? 'low-alert' :
                            'info-alert'
                          } text-xs security-mono`}>
                            {alert.severity?.toUpperCase() || 'INFO'}
                          </Badge>
                        </div>
                      )) : (
                        <div className="text-center py-8">
                          <CheckCircle className="h-12 w-12 status-safe mx-auto mb-4" />
                          <p className="text-muted-foreground">No recent alerts</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'realtime' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold high-contrast-text">REAL-TIME MONITORING</h2>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <span>Last updated: {lastUpdate.toLocaleTimeString()}</span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={fetchDashboardData}
                      className="border-border text-muted-foreground hover:text-foreground"
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <RealTimeMonitoring />
              </div>
            )}

            {activeTab === 'monitors' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold high-contrast-text">MONITORS</h2>
                <GitHubMonitor />
              </div>
            )}

            {activeTab === 'scans' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold high-contrast-text">SCANS</h2>
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                  <div className="xl:col-span-2">
                    <EnhancedSecretScanner />
                  </div>
                  <div className="space-y-6">
                    <VulnerabilityScanner />
                    <CodeScanner />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'tokens' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold high-contrast-text">TOKEN VERIFICATION</h2>
                <TokenVerifier />
              </div>
            )}

            {activeTab === 'network' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold high-contrast-text">NETWORK INTELLIGENCE</h2>
                <NetworkIntelligence />
              </div>
            )}

            {activeTab === 'threatintel' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold high-contrast-text">THREAT INTELLIGENCE</h2>
                <ThreatIntelligenceDashboard />
              </div>
            )}

            {activeTab === 'reports' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold high-contrast-text">REPORTS</h2>
                <AnalyticsDashboard />
              </div>
            )}

            {activeTab === 'team' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold high-contrast-text">TEAM</h2>
                <TeamManagement />
              </div>
            )}
              </AuthGuard>
            ) : (
              <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
                <Card className="w-full max-w-md">
                  <CardHeader className="text-center">
                    <div className="flex justify-center mb-4">
                      <Shield className="h-12 w-12 text-primary" />
                    </div>
                    <CardTitle className="text-2xl">Welcome to CyberAegis</CardTitle>
                    <CardDescription>
                      Please sign in to access your security monitoring dashboard
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <SignInButton className="w-full" />
                    <div className="mt-4 text-center text-sm text-muted-foreground">
                      <p className="font-medium mb-2">Quick Access - Demo Accounts</p>
                      <div className="space-y-1">
                        <p><span className="font-mono bg-muted px-2 py-1 rounded text-xs">admin@sentinel.com</span> / demo123</p>
                        <p><span className="font-mono bg-muted px-2 py-1 rounded text-xs">member@sentinel.com</span> / demo123</p>
                        <p><span className="font-mono bg-muted px-2 py-1 rounded text-xs">viewer@sentinel.com</span> / demo123</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </main>
        </div>
        <Toaster />
      </div>
  )
}