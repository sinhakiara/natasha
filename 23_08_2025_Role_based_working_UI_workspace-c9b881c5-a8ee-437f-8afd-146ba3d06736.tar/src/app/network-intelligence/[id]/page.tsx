'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Network, 
  ArrowLeft, 
  ExternalLink, 
  Server, 
  Globe,
  CheckCircle,
  AlertTriangle,
  Clock
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface ZoomEyeQuery {
  id: string
  query: string
  type: string
  result: string
  status: string
  createdAt: string
}

export default function QueryResultPage() {
  const params = useParams()
  const router = useRouter()
  const queryId = params.id as string
  const [query, setQuery] = useState<ZoomEyeQuery | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    if (queryId) {
      fetchQueryResult()
    }
  }, [queryId])

  const fetchQueryResult = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/zoomeye/${queryId}`)
      if (response.ok) {
        const data = await response.json()
        setQuery(data.query)
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch query result",
          variant: "destructive"
        })
        router.push('/?tab=network')
      }
    } catch (error) {
      console.error('Error fetching query result:', error)
      toast({
        title: "Error",
        description: "Failed to fetch query result",
        variant: "destructive"
      })
      router.push('/?tab=network')
    } finally {
      setIsLoading(false)
    }
  }

  const parseQueryResult = (result: string) => {
    try {
      return JSON.parse(result)
    } catch {
      return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <Clock className="h-3 w-3 animate-spin" />
      case 'FAILED':
        return <AlertTriangle className="h-3 w-3" />
      case 'PENDING':
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Clock className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading query results...</p>
        </div>
      </div>
    )
  }

  if (!query) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-4" />
          <p className="text-muted-foreground">Query not found</p>
        </div>
      </div>
    )
  }

  const result = parseQueryResult(query.result)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="flex h-16 items-center px-6">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.push('/?tab=network')}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Network Intelligence
            </Button>
            <Network className="h-8 w-8 text-primary" />
            <h1 className="text-xl font-semibold">Query Results</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Query Info */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Network className="h-5 w-5" />
                    Query Results
                  </CardTitle>
                  <CardDescription>{query.query}</CardDescription>
                </div>
                <Badge className={getStatusColor(query.status)}>
                  {getStatusIcon(query.status)}
                  {query.status}
                </Badge>
              </div>
            </CardHeader>
          </Card>

          {/* Results */}
          {query.status === 'COMPLETED' && result ? (
            <Card>
              <CardHeader>
                <CardTitle>Search Results</CardTitle>
                <CardDescription>
                  Found {result.total || 0} total results, showing {result.data?.length || 0} items
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Summary Stats */}
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{result.total || 0}</div>
                      <div className="text-sm text-gray-600">Total Results</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{result.data?.length || 0}</div>
                      <div className="text-sm text-gray-600">Shown</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {query.type === 'HOST' ? 'Hosts' : 'Web Apps'}
                      </div>
                      <div className="text-sm text-gray-600">Type</div>
                    </div>
                  </div>

                  {/* Results List */}
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {result.data?.map((item: any, index: number) => (
                      <div key={index} className="border rounded-lg p-4 hover:bg-gray-50">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            {query.type === 'HOST' ? (
                              <>
                                <Server className="h-4 w-4 text-gray-500" />
                                <span className="font-medium">{item.ip}:{item.port}</span>
                              </>
                            ) : (
                              <>
                                <Globe className="h-4 w-4 text-gray-500" />
                                <span className="font-medium">{item.title || item.site}</span>
                              </>
                            )}
                          </div>
                          <Badge variant="outline">
                            {item.protocol || item.app || 'Unknown'}
                          </Badge>
                        </div>
                        
                        <div className="text-sm text-gray-600 space-y-1">
                          {query.type === 'HOST' ? (
                            <>
                              {item.banner && <div>Banner: {item.banner}</div>}
                              {item.os && <div>OS: {item.os}</div>}
                              {item.app && <div>App: {item.app}</div>}
                              {item.hostname && <div>Hostname: {item.hostname}</div>}
                              {item.city && <div>Location: {item.city}, {item.country}</div>}
                            </>
                          ) : (
                            <>
                              {item.url && (
                                <div className="flex items-center space-x-1">
                                  <span>URL: </span>
                                  <a 
                                    href={item.url} 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="text-blue-600 hover:underline"
                                  >
                                    {item.url}
                                    <ExternalLink className="h-3 w-3 inline ml-1" />
                                  </a>
                                </div>
                              )}
                              {item.server && <div>Server: {item.server}</div>}
                              {item.ip && <div>IP: {item.ip}</div>}
                              {item.title && <div>Title: {item.title}</div>}
                              {item.keywords && <div>Keywords: {item.keywords}</div>}
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : query.status === 'FAILED' ? (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Query failed to execute. Please check the query syntax and try again.
              </AlertDescription>
            </Alert>
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <Clock className="h-8 w-8 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Query is still running...</p>
                <p className="text-sm text-gray-400 mt-2">
                  Results will appear here once the query completes.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}