import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { SessionAuthProvider } from "@/components/providers/session-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CyberAegis - Shield Defense System",
  description: "Advanced cybersecurity platform providing comprehensive threat detection, vulnerability scanning, and security monitoring for modern organizations.",
  keywords: ["CyberAegis", "Security", "Threat Detection", "Vulnerability Scanning", "Cybersecurity", "Defense System", "Monitoring"],
  authors: [{ name: "CyberAegis Security Team" }],
  openGraph: {
    title: "CyberAegis - Shield Defense System",
    description: "Advanced cybersecurity platform for comprehensive threat detection and monitoring",
    url: "https://cyberaegis.example.com",
    siteName: "CyberAegis",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CyberAegis - Shield Defense System",
    description: "Advanced cybersecurity platform for comprehensive threat detection and monitoring",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <SessionAuthProvider>
          {children}
          <Toaster />
        </SessionAuthProvider>
      </body>
    </html>
  );
}
