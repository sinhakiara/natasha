import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const scanId = id

    // First, delete all findings associated with this scan
    await db.finding.deleteMany({
      where: { scanId }
    })

    // Then delete the scan itself
    await db.scan.delete({
      where: { id: scanId }
    })

    return NextResponse.json({ 
      message: 'Scan and all associated findings deleted successfully' 
    })
  } catch (error) {
    console.error('Error deleting scan:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}