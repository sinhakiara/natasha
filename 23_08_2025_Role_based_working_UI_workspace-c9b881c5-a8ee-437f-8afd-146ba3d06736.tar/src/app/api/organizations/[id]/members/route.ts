import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdminAccess, requireOrganizationAccess } from '@/lib/auth-helpers'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const organizationId = id

    // Check if user has access to this organization
    await requireOrganizationAccess(request, organizationId)

    const members = await db.organizationMember.findMany({
      where: { organizationId },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            createdAt: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ members })
  } catch (error) {
    console.error('Error fetching organization members:', error)
    if (error.message === 'Unauthorized' || error.message === 'Access denied to this organization') {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }
    return NextResponse.json({ error: 'Failed to fetch organization members' }, { status: 500 })
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const organizationId = id
    const body = await request.json()
    const { email, role } = body

    // Check if user has admin access to this organization
    const { membership } = await requireAdminAccess(request, organizationId)

    if (!email || !role) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Validate role
    const validRoles = ['ADMIN', 'MEMBER', 'VIEWER']
    if (!validRoles.includes(role)) {
      return NextResponse.json({ error: 'Invalid role' }, { status: 400 })
    }

    // Find user by email
    let user = await db.user.findUnique({
      where: { email }
    })

    // If user doesn't exist, create a placeholder user (in real app, you'd send invitation)
    if (!user) {
      user = await db.user.create({
        data: {
          email,
          name: email.split('@')[0] // Use email prefix as name
        }
      })
    }

    // Check if user is already a member
    const existingMember = await db.organizationMember.findUnique({
      where: {
        userId_organizationId: {
          userId: user.id,
          organizationId
        }
      }
    })

    if (existingMember) {
      return NextResponse.json({ error: 'User is already a member of this organization' }, { status: 400 })
    }

    // Add member to organization
    const member = await db.organizationMember.create({
      data: {
        userId: user.id,
        organizationId,
        role
      },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            createdAt: true
          }
        }
      }
    })

    return NextResponse.json({ member })
  } catch (error) {
    console.error('Error adding organization member:', error)
    if (error.message === 'Unauthorized' || error.message === 'Access denied to this organization' || error.message === 'Admin access required') {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }
    return NextResponse.json({ error: 'Failed to add organization member' }, { status: 500 })
  }
}