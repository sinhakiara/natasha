import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; domainId: string }> }
) {
  try {
    const { id, domainId } = await params
    const organizationId = id
    const body = await request.json()
    const { isActive } = body

    if (typeof isActive !== 'boolean') {
      return NextResponse.json({ error: 'isActive must be a boolean' }, { status: 400 })
    }

    // Check if domain exists and belongs to the organization
    const domain = await db.domain.findUnique({
      where: {
        id: domainId,
        organizationId
      }
    })

    if (!domain) {
      return NextResponse.json({ error: 'Domain not found' }, { status: 404 })
    }

    // Update domain
    const updatedDomain = await db.domain.update({
      where: { id: domainId },
      data: { isActive }
    })

    return NextResponse.json({ domain: updatedDomain })
  } catch (error) {
    console.error('Error updating organization domain:', error)
    return NextResponse.json({ error: 'Failed to update organization domain' }, { status: 500 })
  }
}