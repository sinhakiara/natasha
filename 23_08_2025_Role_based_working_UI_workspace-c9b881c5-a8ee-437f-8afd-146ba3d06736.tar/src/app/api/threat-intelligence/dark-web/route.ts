import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<Record<string, never>> }
) {
  try {
    const searchParams = await request.nextUrl.searchParams
    const userId = searchParams.get('userId')
    const keywords = searchParams.get('keywords')
    const domains = searchParams.get('domains')
    const ips = searchParams.get('ips')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Enhanced dark web listings data with realistic dumps from various sources
    const mockListings = [
      {
        id: '1',
        type: 'data_sale',
        title: 'Corporate Database Dump - Fortune 500 Company',
        description: 'Comprehensive database containing employee credentials, customer PII, and financial records. Includes SSN, email addresses, passwords, and credit card information.',
        price: '15000',
        currency: 'USD',
        seller: 'darkweb_vendor_001',
        marketplace: 'Empire Market',
        listingDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['credentials', 'personal_data', 'financial_data', 'corporate_data'],
        estimatedRecords: 125000,
        verified: true,
        keywords: ['corporate', 'database', 'employee', 'credentials', 'fortune500', 'pii', 'ssn'],
        domains: ['example.com', 'company.org', 'enterprise.net'],
        ips: ['192.168.1.1', '10.0.0.1', '172.16.0.1'],
        source: 'Corporate Breach',
        dataQuality: 'high',
        encryption: 'none',
        format: 'sql_dump'
      },
      {
        id: '2',
        type: 'credential_leak',
        title: 'Premium Streaming & Social Media Accounts Bundle',
        description: 'Leaked credentials for Netflix, Spotify, Disney+, Amazon Prime, Facebook, Instagram, Twitter, and LinkedIn. Includes email/password pairs and some 2FA bypass methods.',
        price: '150',
        currency: 'USD',
        seller: 'credential_seller_pro',
        marketplace: 'Dark0de',
        listingDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'high',
        dataTypes: ['credentials', 'accounts', 'session_tokens'],
        estimatedRecords: 5000,
        verified: true,
        keywords: ['netflix', 'spotify', 'disney+', 'amazon', 'facebook', 'instagram', 'twitter', 'linkedin', 'credentials', 'accounts'],
        domains: ['netflix.com', 'spotify.com', 'disneyplus.com', 'amazon.com', 'facebook.com', 'instagram.com', 'twitter.com', 'linkedin.com'],
        ips: [],
        source: 'Credential Stuffing Attack',
        dataQuality: 'medium',
        encryption: 'none',
        format: 'txt_csv'
      },
      {
        id: '3',
        type: 'malware',
        title: 'Advanced Banking Trojan with C2 Panel',
        description: 'Sophisticated banking trojan with web injects, keylogger, screen capture, and ransomware capabilities. Includes admin panel and 24/7 support. Bypasses most AV solutions.',
        price: '25000',
        currency: 'USD',
        seller: 'malware_developer_elite',
        marketplace: 'Cannabia',
        listingDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['malware', 'source_code', 'exploits'],
        estimatedRecords: 1,
        verified: true,
        keywords: ['banking', 'trojan', 'malware', 'c2', 'webinject', 'keylogger', 'ransomware', 'av_bypass'],
        domains: ['bankofamerica.com', 'chase.com', 'wellsfargo.com', 'citibank.com'],
        ips: ['203.0.113.1', '198.51.100.1'],
        source: 'Malware Development',
        dataQuality: 'high',
        encryption: 'aes256',
        format: 'exe_dll'
      },
      {
        id: '4',
        type: 'services',
        title: 'Enterprise DDoS Attack Service - 1Tbps Capacity',
        description: 'Professional DDoS service with multiple attack vectors (SYN, UDP, HTTP, HTTPS). Offers stress testing and targeted attacks. Includes API access and dashboard.',
        price: '1000',
        currency: 'USD',
        seller: 'ddos_provider_enterprise',
        marketplace: 'Apollon',
        listingDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'high',
        dataTypes: ['services', 'attack_tools'],
        estimatedRecords: 1,
        verified: true,
        keywords: ['ddos', 'attack', 'booter', 'stresser', 'syn', 'udp', 'http', 'enterprise', '1tbps'],
        domains: [],
        ips: [],
        source: 'Attack Service',
        dataQuality: 'high',
        encryption: 'none',
        format: 'web_service'
      },
      {
        id: '5',
        type: 'fraud',
        title: 'Fresh Credit Card Dumps with CVV - High Validity Rate',
        description: 'Freshly dumped credit cards with full track data, CVV, expiration dates, and cardholder names. 85%+ validity rate. Includes Visa, MasterCard, Amex, and Discover.',
        price: '200',
        currency: 'USD',
        seller: 'carder_pro_elite',
        marketplace: 'White House Market',
        listingDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['financial_data', 'payment_cards'],
        estimatedRecords: 500,
        verified: true,
        keywords: ['credit', 'card', 'dumps', 'cvv', 'track', 'visa', 'mastercard', 'amex', 'discover', 'fresh'],
        domains: ['visa.com', 'mastercard.com', 'americanexpress.com', 'discover.com'],
        ips: [],
        source: 'POS Malware',
        dataQuality: 'high',
        encryption: 'none',
        format: 'txt_csv'
      },
      {
        id: '6',
        type: 'data_sale',
        title: 'Healthcare Records Database - HIPAA Violation',
        description: 'Comprehensive healthcare database containing patient records, medical history, insurance information, and prescription data. Includes COVID-19 test results and vaccination records.',
        price: '50000',
        currency: 'USD',
        seller: 'healthcare_breacher',
        marketplace: 'Tor2Door',
        listingDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['personal_data', 'medical_records', 'insurance_data'],
        estimatedRecords: 250000,
        verified: true,
        keywords: ['healthcare', 'medical', 'patient', 'hipaa', 'covid', 'vaccination', 'insurance', 'prescription'],
        domains: ['hospital.com', 'clinic.org', 'healthcare.net'],
        ips: ['10.1.1.1', '192.168.2.1'],
        source: 'Healthcare Breach',
        dataQuality: 'high',
        encryption: 'none',
        format: 'database_backup'
      },
      {
        id: '7',
        type: 'credential_leak',
        title: 'Government Employee Credentials - Multiple Agencies',
        description: 'Leaked credentials from various government agencies including email addresses, passwords, and access tokens. Includes federal, state, and local government employees.',
        price: '5000',
        currency: 'USD',
        seller: 'gov_breacher',
        marketplace: 'Monopoly Market',
        listingDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['credentials', 'government_data', 'access_tokens'],
        estimatedRecords: 15000,
        verified: true,
        keywords: ['government', 'federal', 'state', 'local', 'employee', 'credentials', 'agency', 'access'],
        domains: ['gov.gov', 'state.gov', 'local.gov'],
        ips: ['172.16.1.1', '10.2.2.2'],
        source: 'Government Breach',
        dataQuality: 'high',
        encryption: 'none',
        format: 'csv_json'
      },
      {
        id: '8',
        type: 'fraud',
        title: 'Identity Theft Package - Fullz with Documents',
        description: 'Complete identity theft packages including full personal information, SSN, driver\'s license numbers, passport scans, and utility bills. Ready for account takeover and fraud.',
        price: '300',
        currency: 'USD',
        seller: 'identity_theft_pro',
        marketplace: 'Cannazon',
        listingDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['personal_data', 'identity_documents', 'fraud_tools'],
        estimatedRecords: 1000,
        verified: true,
        keywords: ['identity', 'theft', 'fullz', 'ssn', 'driver_license', 'passport', 'utility', 'bills', 'fraud'],
        domains: [],
        ips: [],
        source: 'Identity Theft',
        dataQuality: 'medium',
        encryption: 'none',
        format: 'pdf_images'
      },
      {
        id: '9',
        type: 'services',
        title: 'Ransomware-as-a-Service (RaaS) - Customizable',
        description: 'Complete ransomware solution with encryption, payment processing, and customer support dashboard. Customizable payload and ransom notes. 70/30 revenue split.',
        price: '3000',
        currency: 'USD',
        seller: 'ransomware_developer',
        marketplace: 'DarkNet',
        listingDate: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['malware', 'ransomware', 'services'],
        estimatedRecords: 1,
        verified: true,
        keywords: ['ransomware', 'raas', 'encryption', 'payment', 'dashboard', 'customizable', 'payload'],
        domains: [],
        ips: [],
        source: 'Ransomware Development',
        dataQuality: 'high',
        encryption: 'none',
        format: 'exe_dashboard'
      },
      {
        id: '10',
        type: 'data_sale',
        title: 'E-commerce Customer Database - Multiple Platforms',
        description: 'Comprehensive e-commerce database containing customer information, order history, payment details, and shipping addresses from multiple online retailers.',
        price: '8000',
        currency: 'USD',
        seller: 'ecom_breacher',
        marketplace: 'Empire Market',
        listingDate: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'high',
        dataTypes: ['personal_data', 'financial_data', 'order_history'],
        estimatedRecords: 75000,
        verified: true,
        keywords: ['ecommerce', 'customer', 'orders', 'payment', 'shipping', 'retail', 'online', 'shopping'],
        domains: ['amazon.com', 'ebay.com', 'shopify.com', 'woocommerce.com'],
        ips: ['104.16.0.1', '172.67.0.1'],
        source: 'E-commerce Breach',
        dataQuality: 'high',
        encryption: 'none',
        format: 'sql_backup'
      },
      {
        id: '11',
        type: 'credential_leak',
        title: 'Gaming Platform Accounts - Steam, Epic, Xbox, PlayStation',
        description: 'Premium gaming accounts with high-value items, in-game currency, and rare skins. Includes Steam, Epic Games, Xbox Live, and PlayStation Network accounts.',
        price: '75',
        currency: 'USD',
        seller: 'gaming_account_seller',
        marketplace: 'Dark0de',
        listingDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'medium',
        dataTypes: ['credentials', 'gaming_accounts', 'digital_assets'],
        estimatedRecords: 2000,
        verified: false,
        keywords: ['gaming', 'steam', 'epic', 'xbox', 'playstation', 'accounts', 'skins', 'currency', 'items'],
        domains: ['steampowered.com', 'epicgames.com', 'xbox.com', 'playstation.com'],
        ips: [],
        source: 'Gaming Platform Breach',
        dataQuality: 'medium',
        encryption: 'none',
        format: 'json_txt'
      },
      {
        id: '12',
        type: 'services',
        title: 'Social Media Bot Farm - 10K Accounts',
        description: 'Complete bot farm setup with 10,000 verified social media accounts across multiple platforms. Includes automation tools and proxy rotation.',
        price: '2000',
        currency: 'USD',
        seller: 'bot_farm_provider',
        marketplace: 'Apollon',
        listingDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'high',
        dataTypes: ['services', 'bot_accounts', 'automation_tools'],
        estimatedRecords: 10000,
        verified: true,
        keywords: ['bot', 'farm', 'social', 'media', 'automation', 'accounts', 'proxies', 'verified'],
        domains: ['facebook.com', 'twitter.com', 'instagram.com', 'tiktok.com'],
        ips: [],
        source: 'Bot Farm Service',
        dataQuality: 'high',
        encryption: 'none',
        format: 'account_list_tools'
      },
      {
        id: '13',
        type: 'data_sale',
        title: 'Telecommunications Customer Database',
        description: 'Mobile carrier customer database including phone numbers, call records, SMS logs, location data, and account information. Covers multiple carriers and regions.',
        price: '25000',
        currency: 'USD',
        seller: 'telecom_breacher',
        marketplace: 'Tor2Door',
        listingDate: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['personal_data', 'communication_data', 'location_data'],
        estimatedRecords: 500000,
        verified: true,
        keywords: ['telecom', 'mobile', 'carrier', 'phone', 'calls', 'sms', 'location', 'customer'],
        domains: ['att.com', 'verizon.com', 't-mobile.com', 'sprint.com'],
        ips: ['12.34.56.78', '98.76.54.32'],
        source: 'Telecommunications Breach',
        dataQuality: 'high',
        encryption: 'none',
        format: 'database_dump'
      },
      {
        id: '14',
        type: 'fraud',
        title: 'Bank Account Login Credentials - Multiple Banks',
        description: 'Online banking credentials for various banks including username, password, security questions, and sometimes 2FA bypass methods. Includes business and personal accounts.',
        price: '500',
        currency: 'USD',
        seller: 'banking_credential_seller',
        marketplace: 'White House Market',
        listingDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'critical',
        dataTypes: ['financial_data', 'banking_credentials', 'access_tokens'],
        estimatedRecords: 250,
        verified: false,
        keywords: ['bank', 'banking', 'login', 'credentials', 'online', 'security', '2fa', 'business', 'personal'],
        domains: ['chase.com', 'bankofamerica.com', 'wellsfargo.com', 'citibank.com'],
        ips: [],
        source: 'Banking Malware',
        dataQuality: 'medium',
        encryption: 'none',
        format: 'txt_csv'
      },
      {
        id: '15',
        type: 'services',
        title: 'VPN and Proxy Service - Premium Access',
        description: 'Premium VPN and proxy service with dedicated IPs, multiple locations, and unlimited bandwidth. Includes residential proxies and mobile proxies for various use cases.',
        price: '300',
        currency: 'USD',
        seller: 'vpn_proxy_provider',
        marketplace: 'Monopoly Market',
        listingDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        lastSeen: new Date().toISOString(),
        threatLevel: 'medium',
        dataTypes: ['services', 'vpn', 'proxies', 'network_tools'],
        estimatedRecords: 1,
        verified: true,
        keywords: ['vpn', 'proxy', 'residential', 'mobile', 'dedicated', 'ip', 'bandwidth', 'locations'],
        domains: [],
        ips: [],
        source: 'Network Service',
        dataQuality: 'high',
        encryption: 'none',
        format: 'subscription_service'
      }
    ]

    // Filter listings based on search criteria
    let filteredListings = mockListings

    if (keywords) {
      const keywordList = keywords.toLowerCase().split(',').map(k => k.trim())
      filteredListings = filteredListings.filter(listing =>
        listing.keywords.some(keyword => 
          keywordList.some(searchKeyword => 
            keyword.toLowerCase().includes(searchKeyword) || 
            searchKeyword.includes(keyword.toLowerCase())
          )
        ) ||
        listing.title.toLowerCase().includes(keywords.toLowerCase()) ||
        listing.description.toLowerCase().includes(keywords.toLowerCase())
      )
    }

    if (domains) {
      const domainList = domains.toLowerCase().split(',').map(d => d.trim())
      filteredListings = filteredListings.filter(listing =>
        listing.domains.some(domain => 
          domainList.some(searchDomain => 
            domain.toLowerCase().includes(searchDomain) || 
            searchDomain.includes(domain.toLowerCase())
          )
        )
      )
    }

    if (ips) {
      const ipList = ips.toLowerCase().split(',').map(ip => ip.trim())
      filteredListings = filteredListings.filter(listing =>
        listing.ips.some(ip => 
          ipList.some(searchIp => 
            ip.includes(searchIp) || 
            searchIp.includes(ip)
          )
        )
      )
    }

    return NextResponse.json({ 
      listings: filteredListings,
      filters: {
        keywords: keywords || null,
        domains: domains || null,
        ips: ips || null
      }
    })
  } catch (error) {
    console.error('Error fetching dark web listings:', error)
    return NextResponse.json({ error: 'Failed to fetch dark web listings' }, { status: 500 })
  }
}