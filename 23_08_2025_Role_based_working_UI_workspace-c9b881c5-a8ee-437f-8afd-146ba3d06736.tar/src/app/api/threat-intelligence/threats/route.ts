import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<Record<string, never>> }
) {
  try {
    const searchParams = await request.nextUrl.searchParams
    const userId = searchParams.get('userId')
    const type = searchParams.get('type')
    const severity = searchParams.get('severity')
    const status = searchParams.get('status')
    const timeframe = searchParams.get('timeframe') || '7d'

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Calculate date range based on timeframe
    const now = new Date()
    let startDate = new Date()
    switch (timeframe) {
      case '1d':
        startDate.setDate(now.getDate() - 1)
        break
      case '7d':
        startDate.setDate(now.getDate() - 7)
        break
      case '30d':
        startDate.setDate(now.getDate() - 30)
        break
      case '90d':
        startDate.setDate(now.getDate() - 90)
        break
      default:
        startDate.setDate(now.getDate() - 7)
    }

    // Build where clause
    const where: any = {
      userId,
      createdAt: { gte: startDate }
    }

    if (type) {
      where.type = type
    }
    if (severity) {
      where.severity = severity
    }
    if (status) {
      where.status = status
    }

    // Fetch threats from database (using alerts as threats for demo)
    const threats = await db.alert.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 100
    })

    // Transform alerts to threat format
    const transformedThreats = threats.map(alert => ({
      id: alert.id,
      type: alert.type.toLowerCase().replace(' ', '_'),
      severity: alert.severity.toLowerCase(),
      title: alert.title,
      description: alert.message,
      source: alert.sourceType,
      affectedAssets: [alert.sourceId || 'unknown'],
      tags: [alert.type],
      confidence: 0.85,
      firstSeen: alert.createdAt.toISOString(),
      lastSeen: alert.updatedAt.toISOString(),
      status: alert.isRead ? 'resolved' : 'active',
      mitigation: 'Investigate and remediate based on alert type',
      impact: {
        operational: alert.severity === 'critical' ? 100000 : 
                   alert.severity === 'high' ? 50000 : 
                   alert.severity === 'medium' ? 10000 : 1000
      }
    }))

    return NextResponse.json({ threats: transformedThreats })
  } catch (error) {
    console.error('Error fetching threats:', error)
    return NextResponse.json({ error: 'Failed to fetch threats' }, { status: 500 })
  }
}