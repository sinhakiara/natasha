import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const alertId = id

    const alert = await db.alert.update({
      where: { id: alertId },
      data: { isRead: true },
    })

    return NextResponse.json({ alert })
  } catch (error) {
    console.error('Error marking alert as read:', error)
    return NextResponse.json({ error: 'Failed to mark alert as read' }, { status: 500 })
  }
}