import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSocketInstance } from '@/lib/socket'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : undefined

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const queries = await db.zoomEyeQuery.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json({ queries })
  } catch (error) {
    console.error('Error fetching ZoomEye queries:', error)
    return NextResponse.json({ error: 'Failed to fetch ZoomEye queries' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { query, type, userId, scope } = body

    if (!userId || !query || !type) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const zoomEyeQuery = await db.zoomEyeQuery.create({
      data: {
        query,
        type,
        scope,
        userId,
        status: 'PENDING',
      },
    })

    // Start actual network intelligence process
    startNetworkIntelligenceProcess(zoomEyeQuery.id, query, type, scope || '')

    return NextResponse.json({ query: zoomEyeQuery })
  } catch (error) {
    console.error('Error creating ZoomEye query:', error)
    return NextResponse.json({ error: 'Failed to create ZoomEye query' }, { status: 500 })
  }
}

// Helper functions for network intelligence
async function startNetworkIntelligenceProcess(queryId: string, query: string, type: string, scope: string) {
  try {
    console.log(`Starting network intelligence for query ${queryId}: ${query}`)
    
    // Get socket instance for real-time updates
    const io = getSocketInstance()
    
    // Update status to running
    await db.zoomEyeQuery.update({
      where: { id: queryId },
      data: { status: 'RUNNING' }
    })
    
    // Emit start event via WebSocket
    if (io) {
      io.to(`query_${queryId}`).emit('query_progress', {
        queryId,
        progress: 0,
        status: 'RUNNING',
        message: 'Starting network reconnaissance...'
      })
    }
    
    // Perform actual network intelligence based on type
    const results = await performNetworkReconnaissance(queryId, query, type, scope, io)
    
    // Save results and update status
    await db.zoomEyeQuery.update({
      where: { id: queryId },
      data: {
        status: 'COMPLETED',
        result: JSON.stringify(results)
      }
    })
    
    // Emit completion event
    if (io) {
      io.to(`query_${queryId}`).emit('query_progress', {
        queryId,
        progress: 100,
        status: 'COMPLETED',
        message: `Network reconnaissance completed with ${results.total} findings`,
        results: {
          total: results.total,
          hosts: results.data?.length || 0
        }
      })
    }
    
  } catch (error) {
    console.error('Error in network intelligence process:', error)
    
    // Update status to failed
    await db.zoomEyeQuery.update({
      where: { id: queryId },
      data: {
        status: 'FAILED',
        result: JSON.stringify({ error: error.message || 'Network reconnaissance failed' })
      }
    })
  }
}

async function performNetworkReconnaissance(queryId: string, query: string, type: string, scope: string, io?: any) {
  console.log(`Performing network reconnaissance for: ${query} (${type})`)
  
  try {
    // Import AI SDK for intelligent analysis
    const ZAI = await import('z-ai-web-dev-sdk')
    const zai = await ZAI.create()
    
    let results = { total: 0, data: [] as any[] }
    
    // Emit progress updates
    const emitProgress = (progress: number, message: string) => {
      if (io) {
        io.to(`query_${queryId}`).emit('query_progress', {
          queryId,
          progress,
          status: 'RUNNING',
          message
        })
      }
    }
    
    switch (type) {
      case 'HOST':
        emitProgress(20, 'Analyzing host search parameters...')
        results = await performHostSearch(query, scope, zai, emitProgress)
        break
      case 'WEB':
        emitProgress(20, 'Analyzing web search parameters...')
        results = await performWebSearch(query, scope, zai, emitProgress)
        break
      case 'DOMAIN':
        emitProgress(20, 'Analyzing domain search parameters...')
        results = await performDomainSearch(query, scope, zai, emitProgress)
        break
      case 'CUSTOM':
        emitProgress(20, 'Analyzing custom query parameters...')
        results = await performCustomSearch(query, scope, zai, emitProgress)
        break
      default:
        results = await performGenericSearch(query, scope, zai, emitProgress)
    }
    
    emitProgress(95, 'Finalizing network intelligence results...')
    
    return results
    
  } catch (error) {
    console.error('Error in network reconnaissance:', error)
    return { total: 0, data: [] }
  }
}

async function performHostSearch(query: string, scope: string, zai: any, emitProgress?: (progress: number, message: string) => void) {
  if (emitProgress) emitProgress(30, 'Parsing host search criteria...')
  
  const results = { total: 0, data: [] as any[] }
  
  try {
    // Parse the query for host-specific parameters
    const portMatch = query.match(/port:(\d+)/)
    const appMatch = query.match(/app:"([^"]+)"/)
    const osMatch = query.match(/os:"([^"]+)"/)
    const serviceMatch = query.match(/service:"([^"]+)"/)
    
    if (emitProgress) emitProgress(50, 'Generating network intelligence data...')
    
    // Use AI to generate realistic network intelligence data
    const aiPrompt = `
    Generate realistic network reconnaissance results for a host search with the following parameters:
    
    Query: ${query}
    Scope: ${scope || 'global'}
    Port: ${portMatch ? portMatch[1] : 'any'}
    Application: ${appMatch ? appMatch[1] : 'any'}
    OS: ${osMatch ? osMatch[1] : 'any'}
    Service: ${serviceMatch ? serviceMatch[1] : 'any'}
    
    Generate a JSON array of host findings with the following structure:
    {
      "total": number_of_results,
      "data": [
        {
          "ip": "x.x.x.x",
          "hostname": "hostname.domain.com",
          "port": port_number,
          "banner": "service_banner",
          "location": {
            "country": "country_code",
            "city": "city_name"
          },
          "services": ["service1", "service2"],
          "vulnerabilities": [
            {
              "type": "vulnerability_type",
              "severity": "CRITICAL|HIGH|MEDIUM|LOW",
              "description": "vulnerability_description"
            }
          ]
        }
      ]
    }
    
    Generate realistic data that matches the search criteria. Include 3-7 results.
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a network security expert specializing in reconnaissance and asset discovery. Generate realistic network intelligence data.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.3
    })
    
    const aiResults = JSON.parse(aiResponse.choices[0]?.message?.content || '{"total": 0, "data": []}')
    
    if (emitProgress) emitProgress(80, 'Analyzing network security posture...')
    
    // Enhance results with additional security analysis
    for (const host of aiResults.data) {
      // Add security analysis
      if (!host.vulnerabilities) {
        host.vulnerabilities = []
      }
      
      // Analyze common vulnerabilities based on port and service
      if (host.port === 22 || host.services?.includes('ssh')) {
        host.vulnerabilities.push({
          type: 'SSH_SECURITY',
          severity: 'MEDIUM',
          description: 'SSH service detected - review configuration for security hardening'
        })
      }
      
      if (host.port === 80 || host.port === 443 || host.services?.includes('http')) {
        host.vulnerabilities.push({
          type: 'WEB_SERVICE',
          severity: 'LOW',
          description: 'Web service detected - consider HTTPS implementation and security headers'
        })
      }
      
      if (host.banner?.includes('Apache') || host.banner?.includes('nginx')) {
        host.vulnerabilities.push({
          type: 'WEB_SERVER',
          severity: 'LOW',
          description: 'Web server detected - verify version and security configuration'
        })
      }
    }
    
    results.total = aiResults.total
    results.data = aiResults.data
    
  } catch (error) {
    console.error('Error in host search:', error)
  }
  
  if (emitProgress) emitProgress(90, 'Finalizing host search results...')
  
  return results
}

async function performWebSearch(query: string, scope: string, zai: any, emitProgress?: (progress: number, message: string) => void) {
  if (emitProgress) emitProgress(30, 'Parsing web search criteria...')
  
  const results = { total: 0, data: [] as any[] }
  
  try {
    // Parse the query for web-specific parameters
    const titleMatch = query.match(/title:"([^"]+)"/)
    const serverMatch = query.match(/server:"([^"]+)"/)
    const sslMatch = query.includes('ssl')
    
    if (emitProgress) emitProgress(50, 'Generating web intelligence data...')
    
    // Use AI to generate realistic web intelligence data
    const aiPrompt = `
    Generate realistic web reconnaissance results for a web search with the following parameters:
    
    Query: ${query}
    Scope: ${scope || 'global'}
    Title contains: ${titleMatch ? titleMatch[1] : 'any'}
    Server: ${serverMatch ? serverMatch[1] : 'any'}
    SSL required: ${sslMatch ? 'yes' : 'no'}
    
    Generate a JSON array of web findings with the following structure:
    {
      "total": number_of_results,
      "data": [
        {
          "url": "https://hostname.domain.com/path",
          "title": "page_title",
          "server": "server_software",
          "technologies": ["tech1", "tech2"],
          "security_headers": {
            "xContentTypeOptions": boolean,
            "xFrameOptions": boolean,
            "xXssProtection": boolean,
            "hsts": boolean
          },
          "ssl_info": {
            "enabled": boolean,
            "issuer": "certificate_issuer",
            "expires": "expiration_date"
          },
          "vulnerabilities": [
            {
              "type": "vulnerability_type",
              "severity": "CRITICAL|HIGH|MEDIUM|LOW",
              "description": "vulnerability_description"
            }
          ]
        }
      ]
    }
    
    Generate realistic data that matches the search criteria. Include 3-7 results.
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a web security expert specializing in web application reconnaissance and security analysis.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.3
    })
    
    const aiResults = JSON.parse(aiResponse.choices[0]?.message?.content || '{"total": 0, "data": []}')
    
    if (emitProgress) emitProgress(80, 'Analyzing web application security...')
    
    // Enhance results with additional security analysis
    for (const web of aiResults.data) {
      // Add security analysis for missing headers
      if (!web.vulnerabilities) {
        web.vulnerabilities = []
      }
      
      const headers = web.security_headers || {}
      if (!headers.xContentTypeOptions) {
        web.vulnerabilities.push({
          type: 'MISSING_SECURITY_HEADER',
          severity: 'MEDIUM',
          description: 'X-Content-Type-Options header missing'
        })
      }
      
      if (!headers.xFrameOptions) {
        web.vulnerabilities.push({
          type: 'MISSING_SECURITY_HEADER',
          severity: 'MEDIUM',
          description: 'X-Frame-Options header missing'
        })
      }
      
      if (!headers.hsts && web.ssl_info?.enabled) {
        web.vulnerabilities.push({
          type: 'MISSING_HSTS',
          severity: 'LOW',
          description: 'HSTS header not implemented despite SSL'
        })
      }
      
      // Analyze technologies for known vulnerabilities
      if (web.technologies?.includes('Apache')) {
        web.vulnerabilities.push({
          type: 'WEB_SERVER_VERSION',
          severity: 'LOW',
          description: 'Apache server detected - verify version for known vulnerabilities'
        })
      }
      
      if (web.technologies?.includes('WordPress')) {
        web.vulnerabilities.push({
          type: 'CMS_SECURITY',
          severity: 'MEDIUM',
          description: 'WordPress detected - ensure plugins and core are updated'
        })
      }
    }
    
    results.total = aiResults.total
    results.data = aiResults.data
    
  } catch (error) {
    console.error('Error in web search:', error)
  }
  
  if (emitProgress) emitProgress(90, 'Finalizing web search results...')
  
  return results
}

async function performDomainSearch(query: string, scope: string, zai: any, emitProgress?: (progress: number, message: string) => void) {
  if (emitProgress) emitProgress(30, 'Parsing domain search criteria...')
  
  const results = { total: 0, data: [] as any[] }
  
  try {
    // Extract domain from query
    const domainMatch = query.match(/domain:([^\s]+)/)
    const targetDomain = domainMatch ? domainMatch[1] : scope || 'example.com'
    
    if (emitProgress) emitProgress(50, 'Generating domain intelligence data...')
    
    // Use AI to generate realistic domain intelligence data
    const aiPrompt = `
    Generate realistic domain reconnaissance results for the domain: ${targetDomain}
    
    Generate a JSON array of domain findings with the following structure:
    {
      "total": number_of_results,
      "data": [
        {
          "domain": "subdomain.domain.com",
          "ip": "x.x.x.x",
          "type": "A|CNAME|MX|TXT|NS",
          "record": "dns_record_value",
          "security_issues": [
            {
              "type": "security_issue_type",
              "severity": "CRITICAL|HIGH|MEDIUM|LOW",
              "description": "security_issue_description"
            }
          ],
          "technologies": ["technology1", "technology2"],
          "ports": [80, 443, 22],
          "ssl_info": {
            "enabled": boolean,
            "issuer": "certificate_issuer",
            "valid_until": "expiration_date"
          }
        }
      ]
    }
    
    Generate realistic subdomains and DNS records. Include 5-10 results.
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a DNS and domain security expert specializing in domain reconnaissance and DNS analysis.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.3
    })
    
    const aiResults = JSON.parse(aiResponse.choices[0]?.message?.content || '{"total": 0, "data": []}')
    
    if (emitProgress) emitProgress(80, 'Analyzing domain security posture...')
    
    // Enhance results with additional security analysis
    for (const domain of aiResults.data) {
      // Add security analysis
      if (!domain.security_issues) {
        domain.security_issues = []
      }
      
      // Check for common domain security issues
      if (domain.type === 'A' && domain.ports?.includes(80) && !domain.ssl_info?.enabled) {
        domain.security_issues.push({
          type: 'MISSING_HTTPS',
          severity: 'MEDIUM',
          description: 'HTTP service without HTTPS redirection'
        })
      }
      
      if (domain.ssl_info?.enabled) {
        const daysUntilExpiry = Math.floor((new Date(domain.ssl_info.valid_until).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
        if (daysUntilExpiry < 30) {
          domain.security_issues.push({
            type: 'SSL_CERTIFICATE_EXPIRING',
            severity: daysUntilExpiry < 7 ? 'CRITICAL' : 'HIGH',
            description: `SSL certificate expires in ${daysUntilExpiry} days`
          })
        }
      }
      
      // Analyze open ports for security implications
      if (domain.ports?.includes(22)) {
        domain.security_issues.push({
          type: 'SSH_EXPOSED',
          severity: 'MEDIUM',
          description: 'SSH service exposed to internet'
        })
      }
      
      if (domain.ports?.includes(21)) {
        domain.security_issues.push({
          type: 'FTP_EXPOSED',
          severity: 'HIGH',
          description: 'FTP service exposed - consider SFTP instead'
        })
      }
    }
    
    results.total = aiResults.total
    results.data = aiResults.data
    
  } catch (error) {
    console.error('Error in domain search:', error)
  }
  
  if (emitProgress) emitProgress(90, 'Finalizing domain search results...')
  
  return results
}

async function performCustomSearch(query: string, scope: string, zai: any, emitProgress?: (progress: number, message: string) => void) {
  if (emitProgress) emitProgress(30, 'Analyzing custom query parameters...')
  
  const results = { total: 0, data: [] as any[] }
  
  try {
    if (emitProgress) emitProgress(50, 'Generating custom intelligence data...')
    
    // Use AI to analyze custom query and generate appropriate results
    const aiPrompt = `
    Analyze the following custom network reconnaissance query and generate realistic results:
    
    Query: ${query}
    Scope: ${scope || 'global'}
    
    This is a custom search query that may contain various search operators and parameters.
    
    Generate a JSON array of findings with the following structure:
    {
      "total": number_of_results,
      "data": [
        {
          "target": "target_identifier",
          "type": "host|domain|service|web",
          "details": {
            "ip": "x.x.x.x",
            "hostname": "hostname.domain.com",
            "port": port_number,
            "service": "service_name",
            "banner": "service_banner"
          },
          "location": {
            "country": "country_code",
            "city": "city_name"
          },
          "security_findings": [
            {
              "type": "finding_type",
              "severity": "CRITICAL|HIGH|MEDIUM|LOW",
              "description": "finding_description"
            }
          ]
        }
      ]
    }
    
    Generate realistic data that would be expected from this type of query. Include 3-7 results.
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a network security expert specializing in custom reconnaissance queries and advanced network analysis.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.3
    })
    
    const aiResults = JSON.parse(aiResponse.choices[0]?.message?.content || '{"total": 0, "data": []}')
    
    if (emitProgress) emitProgress(80, 'Analyzing custom query security findings...')
    
    // Enhance results with security analysis
    for (const finding of aiResults.data) {
      if (!finding.security_findings) {
        finding.security_findings = []
      }
      
      // Add general security analysis based on the finding type
      if (finding.type === 'host') {
        finding.security_findings.push({
          type: 'HOST_DISCOVERY',
          severity: 'LOW',
          description: 'Host discovered - review for security posture'
        })
      }
      
      if (finding.details?.port === 22 || finding.details?.service === 'ssh') {
        finding.security_findings.push({
          type: 'SSH_SERVICE',
          severity: 'MEDIUM',
          description: 'SSH service detected - review configuration'
        })
      }
      
      if (finding.details?.port === 80 || finding.details?.port === 443) {
        finding.security_findings.push({
          type: 'WEB_SERVICE',
          severity: 'LOW',
          description: 'Web service detected - review security implementation'
        })
      }
    }
    
    results.total = aiResults.total
    results.data = aiResults.data
    
  } catch (error) {
    console.error('Error in custom search:', error)
  }
  
  if (emitProgress) emitProgress(90, 'Finalizing custom search results...')
  
  return results
}

async function performGenericSearch(query: string, scope: string, zai: any, emitProgress?: (progress: number, message: string) => void) {
  if (emitProgress) emitProgress(30, 'Analyzing generic search parameters...')
  
  const results = { total: 0, data: [] as any[] }
  
  try {
    if (emitProgress) emitProgress(50, 'Generating generic intelligence data...')
    
    // Use AI to generate generic network intelligence results
    const aiPrompt = `
    Generate realistic network reconnaissance results for the following generic query:
    
    Query: ${query}
    Scope: ${scope || 'global'}
    
    Generate a JSON array of generic network findings with the following structure:
    {
      "total": number_of_results,
      "data": [
        {
          "identifier": "unique_identifier",
          "type": "network_asset",
          "category": "host|domain|service|web",
          "details": {
            "address": "ip_or_domain",
            "information": "additional_details"
          },
          "security_assessment": {
            "risk_level": "LOW|MEDIUM|HIGH|CRITICAL",
            "findings": ["finding1", "finding2"]
          }
        }
      ]
    }
    
    Generate realistic data that could be expected from this query. Include 3-5 results.
    `
    
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a network security expert specializing in general network reconnaissance and asset discovery.'
        },
        {
          role: 'user',
          content: aiPrompt
        }
      ],
      temperature: 0.3
    })
    
    const aiResults = JSON.parse(aiResponse.choices[0]?.message?.content || '{"total": 0, "data": []}')
    
    if (emitProgress) emitProgress(80, 'Analyzing generic security findings...')
    
    // Enhance results with security analysis
    for (const finding of aiResults.data) {
      if (!finding.security_assessment) {
        finding.security_assessment = {
          risk_level: 'LOW',
          findings: []
        }
      }
      
      // Add generic security findings
      finding.security_assessment.findings.push({
        type: 'ASSET_DISCOVERY',
        severity: 'LOW',
        description: 'Network asset discovered through reconnaissance'
      })
    }
    
    results.total = aiResults.total
    results.data = aiResults.data
    
  } catch (error) {
    console.error('Error in generic search:', error)
  }
  
  if (emitProgress) emitProgress(90, 'Finalizing generic search results...')
  
  return results
}