'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Search, Shield, Play, CheckCircle, AlertTriangle, Clock } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Scan {
  id: string
  name: string
  target: string
  type: string
  status: string
  createdAt: string
  findings: any[]
  _count: {
    findings: number
  }
}

export default function TestScanPage() {
  const [scans, setScans] = useState<Scan[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isCreating, setIsCreating] = useState(false)
  const [newScan, setNewScan] = useState({
    name: '',
    target: 'https://github.com/sinhakiara/natasha',
    type: 'SECRET_SCAN'
  })
  const [validationError, setValidationError] = useState('')
  const { toast } = useToast()

  // Fixed user ID for testing
  const userId = 'cmekggvj90000jv7wua1z6qe3'

  const fetchScans = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/scans?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setScans(data.scans || [])
      }
    } catch (error) {
      console.error('Error fetching scans:', error)
      toast({
        title: "Error",
        description: "Failed to fetch scans",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateScan = async () => {
    if (!newScan.name.trim()) {
      setValidationError('Scan name is required')
      return
    }

    if (!newScan.target.trim()) {
      setValidationError('Target is required')
      return
    }

    try {
      setIsCreating(true)
      setValidationError('')

      const response = await fetch('/api/scans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newScan,
          userId
        })
      })

      if (response.ok) {
        const data = await response.json()
        setScans(prev => [data.scan, ...prev])
        setNewScan({
          name: '',
          target: 'https://github.com/sinhakiara/natasha',
          type: 'SECRET_SCAN'
        })
        toast({
          title: "Success",
          description: "Scan started successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to create scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error creating scan:', error)
      toast({
        title: "Error",
        description: "Failed to create scan",
        variant: "destructive"
      })
    } finally {
      setIsCreating(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <Clock className="h-3 w-3 animate-spin" />
      case 'FAILED':
        return <AlertTriangle className="h-3 w-3" />
      case 'PENDING':
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  useState(() => {
    fetchScans()
  }, [])

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">CyberAegis - Test Scan Page</h1>
          <p className="text-muted-foreground">Test scanning functionality without authentication</p>
        </div>

        {/* Create Scan Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="h-5 w-5 mr-2" />
              Create New Scan
            </CardTitle>
            <CardDescription>
              Test scanning the GitHub repository with fake secrets
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Scan Name</label>
                  <Input
                    placeholder="Enter scan name"
                    value={newScan.name}
                    onChange={(e) => setNewScan(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Target</label>
                  <Input
                    placeholder="Enter target URL"
                    value={newScan.target}
                    onChange={(e) => setNewScan(prev => ({ ...prev, target: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Scan Type</label>
                  <select
                    className="w-full p-2 border border-border rounded-md bg-background text-foreground"
                    value={newScan.type}
                    onChange={(e) => setNewScan(prev => ({ ...prev, type: e.target.value }))}
                  >
                    <option value="SECRET_SCAN">Secret Scan</option>
                    <option value="VULNERABILITY_SCAN">Vulnerability Scan</option>
                    <option value="CODE_SCAN">Code Scan</option>
                    <option value="ENHANCED_SECRET_SCAN">Enhanced Secret Scan</option>
                  </select>
                </div>
              </div>

              {validationError && (
                <Alert variant="destructive">
                  <AlertDescription>{validationError}</AlertDescription>
                </Alert>
              )}

              <div className="flex gap-4">
                <Button 
                  onClick={handleCreateScan} 
                  disabled={isCreating}
                  className="flex items-center"
                >
                  <Play className="h-4 w-4 mr-2" />
                  {isCreating ? 'Creating...' : 'Start Scan'}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={fetchScans}
                  disabled={isLoading}
                >
                  {isLoading ? 'Loading...' : 'Refresh Scans'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Scans List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Recent Scans
            </CardTitle>
            <CardDescription>
              List of all scans created for testing
            </CardDescription>
          </CardHeader>
          <CardContent>
            {scans.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No scans found. Create your first scan above.
              </div>
            ) : (
              <div className="space-y-4">
                {scans.map((scan) => (
                  <div key={scan.id} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">{scan.name}</h3>
                        <p className="text-sm text-muted-foreground">{scan.target}</p>
                        <p className="text-xs text-muted-foreground">
                          Created: {new Date(scan.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(scan.status)}>
                          <span className="flex items-center gap-1">
                            {getStatusIcon(scan.status)}
                            {scan.status}
                          </span>
                        </Badge>
                        <Badge variant="outline">
                          {scan._count.findings} findings
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>Test Instructions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p>• This page allows you to test the scanning functionality without authentication</p>
              <p>• The target repository <code>https://github.com/sinhakiara/natasha</code> contains fake secrets for testing</p>
              <p>• Try different scan types to see how they work</p>
              <p>• All scans will use the test user ID: <code>cmekggvj90000jv7wua1z6qe3</code></p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}