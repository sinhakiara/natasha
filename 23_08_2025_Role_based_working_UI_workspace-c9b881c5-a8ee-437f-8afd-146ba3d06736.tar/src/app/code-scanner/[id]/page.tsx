'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Code, 
  ArrowLeft,
  FileText,
  Shield,
  Bug,
  Database,
  Eye,
  ExternalLink,
  Copy,
  AlertCircle,
  CheckCircle,
  Trash2,
  GitBranch,
  FileCode,
  AlertTriangle,
  TrendingUp,
  TrendingDown
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Finding {
  id: string
  type: string
  severity: string
  title: string
  description?: string
  content: string
  source: string
  metadata: string
  isVerified: boolean
  isValid?: boolean
  createdAt: string
  recommendation?: string
  language?: string
  filePath?: string
  lineNumber?: number
  category?: string
  owaspCategory?: string
  qualityMetrics?: {
    complexity: number
    maintainability: number
    reliability: number
    security: number
  }
}

interface Scan {
  id: string
  name: string
  target: string
  type: string
  status: string
  config: string
  startedAt?: string
  completedAt?: string
  createdAt: string
  findings: Finding[]
  _count: {
    findings: number
  }
}

export default function CodeScanDetailsPage() {
  const { data: session } = useSession()
  const params = useParams()
  const router = useRouter()
  const scanId = params.id as string
  const [scan, setScan] = useState<Scan | null>(null)
  const [findings, setFindings] = useState<Finding[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDeleting, setIsDeleting] = useState(false)
  const { toast } = useToast()

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3'

  useEffect(() => {
    if (scanId) {
      fetchScanDetails()
    }
  }, [scanId])

  const fetchScanDetails = async () => {
    try {
      setIsLoading(true)
      
      // Fetch scan details
      const scanResponse = await fetch(`/api/scans?userId=${userId}&type=CODE_SCAN`)
      if (scanResponse.ok) {
        const scanData = await scanResponse.json()
        const foundScan = scanData.scans?.find((s: Scan) => s.id === scanId)
        if (foundScan) {
          setScan(foundScan)
        }
      }

      // Fetch findings
      const findingsResponse = await fetch(`/api/scans/${scanId}/findings`)
      if (findingsResponse.ok) {
        const findingsData = await findingsResponse.json()
        setFindings(findingsData.findings || [])
      }
    } catch (error) {
      console.error('Error fetching scan details:', error)
      toast({
        title: "Error",
        description: "Failed to fetch scan details",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteScan = async () => {
    if (!confirm('Are you sure you want to delete this scan and all its findings? This action cannot be undone.')) {
      return
    }

    try {
      setIsDeleting(true)
      
      const response = await fetch(`/api/scans/${scanId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Scan deleted successfully",
        })
        router.push('/?tab=scans')
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to delete scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error deleting scan:', error)
      toast({
        title: "Error",
        description: "Failed to delete scan",
        variant: "destructive"
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <div className="h-3 w-3 animate-spin rounded-full border-2 border-blue-600 border-t-transparent" />
      case 'FAILED':
        return <AlertCircle className="h-3 w-3" />
      case 'PENDING':
        return <div className="h-3 w-3 rounded-full border-2 border-yellow-600 border-t-transparent" />
      default:
        return <div className="h-3 w-3 rounded-full border-2 border-gray-600 border-t-transparent" />
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'CODE_SCAN':
        return <Code className="h-5 w-5" />
      case 'SECRET_SCAN':
        return <Shield className="h-5 w-5" />
      case 'VULNERABILITY_SCAN':
        return <Bug className="h-5 w-5" />
      default:
        return <FileCode className="h-5 w-5" />
    }
  }

  const getTypeName = (type: string) => {
    switch (type) {
      case 'CODE_SCAN':
        return 'Code Scan'
      case 'SECRET_SCAN':
        return 'Secret Scan'
      case 'VULNERABILITY_SCAN':
        return 'Vulnerability Scan'
      default:
        return 'Custom Scan'
    }
  }

  const getFindingSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getFindingIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'security': return <Shield className="h-4 w-4" />
      case 'quality': return <TrendingUp className="h-4 w-4" />
      case 'performance': return <TrendingDown className="h-4 w-4" />
      case 'maintainability': return <Code className="h-4 w-4" />
      case 'reliability': return <Database className="h-4 w-4" />
      case 'standards': return <FileText className="h-4 w-4" />
      default: return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getLanguageIcon = (language: string) => {
    switch (language?.toLowerCase()) {
      case 'javascript': return '🟨'
      case 'python': return '🐍'
      case 'java': return '☕'
      case 'csharp': return '🔷'
      case 'php': return '🐘'
      case 'ruby': return '💎'
      case 'go': return '🐹'
      case 'rust': return '🦀'
      case 'cpp': return '⚡'
      case 'c': return '🔧'
      default: return '📄'
    }
  }

  const getQualityColor = (score: number) => {
    if (score >= 8.0) return 'text-green-600 bg-green-50'
    if (score >= 6.0) return 'text-yellow-600 bg-yellow-50'
    if (score >= 4.0) return 'text-orange-600 bg-orange-50'
    return 'text-red-600 bg-red-50'
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: "Text copied to clipboard",
    })
  }

  const formatTarget = (target: string) => {
    if (target.length > 80) {
      return target.substring(0, 80) + '...'
    }
    return target
  }

  const formatFilePath = (filePath: string) => {
    if (filePath.length > 60) {
      return filePath.substring(0, 30) + '...' + filePath.substring(filePath.length - 30)
    }
    return filePath
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" disabled>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-64"></div>
          </div>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (!scan) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.push('/?tab=scans')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Scanner
          </Button>
        </div>
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Scan Not Found</h3>
            <p className="text-gray-500 mb-4">The requested scan could not be found.</p>
            <Button onClick={() => router.push('/?tab=scans')}>
              Back to Scanner
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <RBACGuard requiredPermissions={['write']}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={() => router.push('/?tab=scans')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Scanner
            </Button>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">{scan.name}</h1>
              <p className="text-muted-foreground">
                {getTypeName(scan.type)} - {formatTarget(scan.target)}
              </p>
            </div>
          </div>
          <Button
            variant="destructive"
            size="sm"
            onClick={handleDeleteScan}
            disabled={isDeleting}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            {isDeleting ? 'Deleting...' : 'Delete Scan'}
          </Button>
        </div>

        {/* Scan Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getTypeIcon(scan.type)}
              Scan Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <div className="text-sm font-medium text-gray-500">Status</div>
                <Badge className={getStatusColor(scan.status)}>
                  {getStatusIcon(scan.status)}
                  {scan.status}
                </Badge>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Target</div>
                <div className="text-sm font-mono text-gray-900 truncate">{formatTarget(scan.target)}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Duration</div>
                <div className="text-sm text-gray-900">
                  {scan.completedAt && scan.startedAt 
                    ? `${Math.round((new Date(scan.completedAt).getTime() - new Date(scan.startedAt).getTime()) / 1000)} seconds`
                    : 'N/A'
                  }
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-gray-500">Findings</div>
                <div className="text-sm text-gray-900">{findings.length}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        {findings.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Code Analysis Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'critical').length}
                  </div>
                  <div className="text-sm text-red-600">Critical</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'high').length}
                  </div>
                  <div className="text-sm text-orange-600">High</div>
                </div>
                <div className="text-center p-3 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'medium').length}
                  </div>
                  <div className="text-sm text-yellow-600">Medium</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'low').length}
                  </div>
                  <div className="text-sm text-green-600">Low</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {findings.filter(f => f.severity?.toLowerCase() === 'info').length}
                  </div>
                  <div className="text-sm text-blue-600">Info</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Findings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="h-5 w-5" />
              Code Analysis Findings ({findings.length})
            </CardTitle>
            <CardDescription>
              Detailed view of code quality, security, and standards compliance issues
            </CardDescription>
          </CardHeader>
          <CardContent>
            {findings.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Issues Found</h3>
                <p className="text-gray-500">This scan did not detect any code quality or security issues.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {findings.map((finding) => (
                  <div key={finding.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-2">
                        {getFindingIcon(finding.type)}
                        <h3 className="font-medium text-gray-900">{finding.title || 'Code Analysis Finding'}</h3>
                        <Badge className={getFindingSeverityColor(finding.severity)}>
                          {finding.severity?.toUpperCase() || 'UNKNOWN'}
                        </Badge>
                        {finding.language && (
                          <Badge variant="outline">
                            {getLanguageIcon(finding.language)} {finding.language}
                          </Badge>
                        )}
                        {finding.category && (
                          <Badge variant="outline">
                            {finding.category}
                          </Badge>
                        )}
                        {finding.owaspCategory && (
                          <Badge variant="outline">
                            OWASP: {finding.owaspCategory}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-1">
                        {finding.source && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(finding.source)}
                            title="Copy source"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        )}
                        {finding.source && finding.source.startsWith('http') && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(finding.source, '_blank')}
                            title="Open source"
                          >
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>

                    {finding.description && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-1">Description</h4>
                        <p className="text-sm text-gray-600">{finding.description}</p>
                      </div>
                    )}

                    {finding.filePath && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-1">File Location</h4>
                        <p className="text-sm text-gray-600 font-mono">
                          {formatFilePath(finding.filePath)}
                          {finding.lineNumber && `:${finding.lineNumber}`}
                        </p>
                      </div>
                    )}

                    {finding.recommendation && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-1">Recommendation</h4>
                        <p className="text-sm text-gray-600">{finding.recommendation}</p>
                      </div>
                    )}

                    {finding.qualityMetrics && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-2">Quality Metrics</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          <div className="text-center p-2 rounded border">
                            <div className="text-xs text-gray-500">Complexity</div>
                            <div className={`text-sm font-medium ${getQualityColor(finding.qualityMetrics.complexity)}`}>
                              {finding.qualityMetrics.complexity}/10
                            </div>
                          </div>
                          <div className="text-center p-2 rounded border">
                            <div className="text-xs text-gray-500">Maintainability</div>
                            <div className={`text-sm font-medium ${getQualityColor(finding.qualityMetrics.maintainability)}`}>
                              {finding.qualityMetrics.maintainability}/10
                            </div>
                          </div>
                          <div className="text-center p-2 rounded border">
                            <div className="text-xs text-gray-500">Reliability</div>
                            <div className={`text-sm font-medium ${getQualityColor(finding.qualityMetrics.reliability)}`}>
                              {finding.qualityMetrics.reliability}/10
                            </div>
                          </div>
                          <div className="text-center p-2 rounded border">
                            <div className="text-xs text-gray-500">Security</div>
                            <div className={`text-sm font-medium ${getQualityColor(finding.qualityMetrics.security)}`}>
                              {finding.qualityMetrics.security}/10
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Source: {finding.source || 'N/A'}</span>
                      <span>Found: {new Date(finding.createdAt).toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </RBACGuard>
  )
}