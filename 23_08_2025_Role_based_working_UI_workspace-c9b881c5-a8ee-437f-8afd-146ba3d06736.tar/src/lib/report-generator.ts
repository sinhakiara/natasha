// Report generation utilities for PDF and HTML reports

export interface ReportData {
  title: string
  subtitle?: string
  generatedAt: string
  generatedBy: string
  summary: {
    totalItems: number
    criticalItems: number
    highItems: number
    mediumItems: number
    lowItems: number
  }
  sections: ReportSection[]
  metadata?: {
    scanType?: string
    target?: string
    duration?: string
    scope?: string
  }
}

export interface ReportSection {
  title: string
  content: string | ReportItem[]
  type: 'text' | 'table' | 'list'
}

export interface ReportItem {
  id: string
  title: string
  description: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  details?: Record<string, any>
  timestamp?: string
  source?: string
}

export function generateHTMLReport(data: ReportData): string {
  const severityColors = {
    critical: '#dc2626',
    high: '#ea580c',
    medium: '#ca8a04',
    low: '#16a34a',
    info: '#2563eb'
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString()
  }

  const renderSection = (section: ReportSection) => {
    if (section.type === 'text') {
      return `
        <div class="report-section">
          <h3>${section.title}</h3>
          <div class="section-content">
            <p>${section.content}</p>
          </div>
        </div>
      `
    } else if (section.type === 'list' && Array.isArray(section.content)) {
      const items = section.content as ReportItem[]
      return `
        <div class="report-section">
          <h3>${section.title}</h3>
          <div class="section-content">
            <ul class="report-list">
              ${items.map(item => `
                <li class="report-item">
                  <div class="item-header">
                    <span class="item-title">${item.title}</span>
                    <span class="severity-badge" style="background-color: ${severityColors[item.severity]}">
                      ${item.severity.toUpperCase()}
                    </span>
                  </div>
                  <p class="item-description">${item.description}</p>
                  ${item.timestamp ? `<p class="item-timestamp">Detected: ${formatDate(item.timestamp)}</p>` : ''}
                  ${item.source ? `<p class="item-source">Source: ${item.source}</p>` : ''}
                </li>
              `).join('')}
            </ul>
          </div>
        </div>
      `
    } else if (section.type === 'table' && Array.isArray(section.content)) {
      const items = section.content as ReportItem[]
      return `
        <div class="report-section">
          <h3>${section.title}</h3>
          <div class="section-content">
            <table class="report-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Severity</th>
                  <th>Description</th>
                  <th>Timestamp</th>
                  <th>Source</th>
                </tr>
              </thead>
              <tbody>
                ${items.map(item => `
                  <tr>
                    <td>${item.title}</td>
                    <td>
                      <span class="severity-badge" style="background-color: ${severityColors[item.severity]}">
                        ${item.severity.toUpperCase()}
                      </span>
                    </td>
                    <td>${item.description}</td>
                    <td>${item.timestamp ? formatDate(item.timestamp) : 'N/A'}</td>
                    <td>${item.source || 'N/A'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `
    }
    return ''
  }

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.title} - Report</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9fafb;
        }
        .report-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }
        .report-header {
            border-bottom: 2px solid #e5e7eb;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .report-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #1f2937;
            margin: 0 0 10px 0;
        }
        .report-subtitle {
            font-size: 1.2rem;
            color: #6b7280;
            margin: 0 0 20px 0;
        }
        .report-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: #6b7280;
        }
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .summary-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 20px;
            text-align: center;
        }
        .summary-number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0 0 5px 0;
        }
        .summary-label {
            font-size: 0.9rem;
            color: #6b7280;
            margin: 0;
        }
        .critical { color: #dc2626; }
        .high { color: #ea580c; }
        .medium { color: #ca8a04; }
        .low { color: #16a34a; }
        .info { color: #2563eb; }
        
        .report-section {
            margin: 30px 0;
        }
        .report-section h3 {
            font-size: 1.5rem;
            font-weight: 600;
            color: #1f2937;
            margin: 0 0 15px 0;
            border-left: 4px solid #3b82f6;
            padding-left: 15px;
        }
        .section-content {
            background: #f8fafc;
            border-radius: 6px;
            padding: 20px;
        }
        
        .report-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .report-item {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 10px;
        }
        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        .item-title {
            font-weight: 600;
            color: #1f2937;
        }
        .severity-badge {
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .item-description {
            color: #4b5563;
            margin: 0 0 8px 0;
        }
        .item-timestamp, .item-source {
            font-size: 0.8rem;
            color: #6b7280;
            margin: 0;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .report-table th,
        .report-table td {
            border: 1px solid #e2e8f0;
            padding: 12px;
            text-align: left;
        }
        .report-table th {
            background-color: #f8fafc;
            font-weight: 600;
            color: #374151;
        }
        .report-table tr:nth-child(even) {
            background-color: #f8fafc;
        }
        
        .metadata-section {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }
        .metadata-title {
            font-weight: 600;
            color: #1e40af;
            margin: 0 0 10px 0;
        }
        .metadata-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .metadata-item {
            display: flex;
            flex-direction: column;
        }
        .metadata-label {
            font-size: 0.8rem;
            color: #6b7280;
            margin: 0 0 2px 0;
        }
        .metadata-value {
            font-weight: 600;
            color: #1f2937;
        }
        
        @media print {
            body { background: white; }
            .report-container { box-shadow: none; }
        }
        
        @media (max-width: 768px) {
            .report-container { padding: 20px; }
            .summary-cards { grid-template-columns: 1fr 1fr; }
            .report-meta { flex-direction: column; gap: 10px; }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="report-header">
            <h1 class="report-title">${data.title}</h1>
            ${data.subtitle ? `<p class="report-subtitle">${data.subtitle}</p>` : ''}
            <div class="report-meta">
                <span>Generated: ${formatDate(data.generatedAt)}</span>
                <span>Generated by: ${data.generatedBy}</span>
            </div>
        </div>

        ${data.metadata ? `
        <div class="metadata-section">
            <h3 class="metadata-title">Scan Information</h3>
            <div class="metadata-grid">
                ${data.metadata.scanType ? `
                <div class="metadata-item">
                    <span class="metadata-label">Scan Type</span>
                    <span class="metadata-value">${data.metadata.scanType}</span>
                </div>
                ` : ''}
                ${data.metadata.target ? `
                <div class="metadata-item">
                    <span class="metadata-label">Target</span>
                    <span class="metadata-value">${data.metadata.target}</span>
                </div>
                ` : ''}
                ${data.metadata.duration ? `
                <div class="metadata-item">
                    <span class="metadata-label">Duration</span>
                    <span class="metadata-value">${data.metadata.duration}</span>
                </div>
                ` : ''}
                ${data.metadata.scope ? `
                <div class="metadata-item">
                    <span class="metadata-label">Scope</span>
                    <span class="metadata-value">${data.metadata.scope}</span>
                </div>
                ` : ''}
            </div>
        </div>
        ` : ''}

        <div class="summary-cards">
            <div class="summary-card">
                <div class="summary-number">${data.summary.totalItems}</div>
                <div class="summary-label">Total Items</div>
            </div>
            <div class="summary-card">
                <div class="summary-number critical">${data.summary.criticalItems}</div>
                <div class="summary-label">Critical</div>
            </div>
            <div class="summary-card">
                <div class="summary-number high">${data.summary.highItems}</div>
                <div class="summary-label">High</div>
            </div>
            <div class="summary-card">
                <div class="summary-number medium">${data.summary.mediumItems}</div>
                <div class="summary-label">Medium</div>
            </div>
            <div class="summary-card">
                <div class="summary-number low">${data.summary.lowItems}</div>
                <div class="summary-label">Low</div>
            </div>
        </div>

        ${data.sections.map(renderSection).join('')}
    </div>
</body>
</html>
  `
}

export function downloadReport(reportData: ReportData, format: 'html' | 'pdf' = 'html') {
  const timestamp = new Date().toISOString().split('T')[0]
  const filename = `${reportData.title.replace(/\s+/g, '_')}_${timestamp}`
  
  if (format === 'html') {
    const htmlContent = generateHTMLReport(reportData)
    const blob = new Blob([htmlContent], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${filename}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  } else if (format === 'pdf') {
    // For PDF generation, we'll use the browser's print functionality
    // In a real application, you might use a library like jsPDF or Puppeteer
    const htmlContent = generateHTMLReport(reportData)
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(htmlContent)
      printWindow.document.close()
      printWindow.focus()
      setTimeout(() => {
        printWindow.print()
      }, 1000)
    }
  }
}

export function prepareReportDataFromScans(scans: any[], type: string): ReportData {
  const allFindings = scans.flatMap(scan => scan.findings || [])
  
  const summary = {
    totalItems: allFindings.length,
    criticalItems: allFindings.filter((f: any) => f.severity === 'CRITICAL').length,
    highItems: allFindings.filter((f: any) => f.severity === 'HIGH').length,
    mediumItems: allFindings.filter((f: any) => f.severity === 'MEDIUM').length,
    lowItems: allFindings.filter((f: any) => f.severity === 'LOW').length
  }

  const sections: ReportSection[] = [
    {
      title: 'Executive Summary',
      content: `This report contains the results of ${type} scans performed on ${scans.length} target(s). A total of ${summary.totalItems} findings were identified, with ${summary.criticalItems} critical issues requiring immediate attention.`,
      type: 'text'
    },
    {
      title: 'Detailed Findings',
      content: allFindings.map((finding: any) => ({
        id: finding.id,
        title: finding.title || 'Security Finding',
        description: finding.description || 'No description available',
        severity: (finding.severity || 'low').toLowerCase(),
        details: finding.metadata || {},
        timestamp: finding.createdAt,
        source: finding.source
      })) as ReportItem[],
      type: 'table'
    }
  ]

  return {
    title: `${type} Security Scan Report`,
    subtitle: `Comprehensive security analysis results`,
    generatedAt: new Date().toISOString(),
    generatedBy: 'Security Sentinel Platform',
    summary,
    sections,
    metadata: {
      scanType: type,
      duration: scans.reduce((acc, scan) => {
        if (scan.startedAt && scan.completedAt) {
          const duration = new Date(scan.completedAt).getTime() - new Date(scan.startedAt).getTime()
          return acc + Math.round(duration / 1000)
        }
        return acc
      }, 0) + ' seconds'
    }
  }
}

export function prepareReportDataFromQueries(queries: any[]): ReportData {
  const completedQueries = queries.filter(q => q.status === 'COMPLETED')
  const allResults = completedQueries.flatMap(query => {
    try {
      return JSON.parse(query.result || '{}').data || []
    } catch {
      return []
    }
  })

  const summary = {
    totalItems: completedQueries.length,
    criticalItems: completedQueries.filter(q => {
      try {
        const result = JSON.parse(q.result || '{}')
        return (result.total || 0) > 100
      } catch {
        return false
      }
    }).length,
    highItems: completedQueries.filter(q => {
      try {
        const result = JSON.parse(q.result || '{}')
        return (result.total || 0) > 50
      } catch {
        return false
      }
    }).length,
    mediumItems: completedQueries.filter(q => {
      try {
        const result = JSON.parse(q.result || '{}')
        return (result.total || 0) > 10
      } catch {
        return false
      }
    }).length,
    lowItems: completedQueries.length - summary.criticalItems - summary.highItems - summary.mediumItems
  }

  const sections: ReportSection[] = [
    {
      title: 'Executive Summary',
      content: `This report contains the results of ${completedQueries.length} network intelligence queries. A total of ${allResults.length} network assets were discovered across all queries.`,
      type: 'text'
    },
    {
      title: 'Query Results',
      content: completedQueries.map((query: any) => {
        try {
          const result = JSON.parse(query.result || '{}')
          return {
            id: query.id,
            title: query.query,
            description: `Found ${result.data?.length || 0} assets out of ${result.total || 0} total results`,
            severity: result.total > 100 ? 'critical' : result.total > 50 ? 'high' : result.total > 10 ? 'medium' : 'low',
            details: {
              type: query.type,
              scope: query.scope,
              resultCount: result.data?.length || 0,
              totalCount: result.total || 0
            },
            timestamp: query.createdAt,
            source: 'ZoomEye'
          }
        } catch {
          return {
            id: query.id,
            title: query.query,
            description: 'Query completed but results unavailable',
            severity: 'low',
            timestamp: query.createdAt,
            source: 'ZoomEye'
          }
        }
      }) as ReportItem[],
      type: 'table'
    }
  ]

  return {
    title: 'Network Intelligence Report',
    subtitle: 'Network asset reconnaissance and intelligence gathering results',
    generatedAt: new Date().toISOString(),
    generatedBy: 'Security Sentinel Platform',
    summary,
    sections,
    metadata: {
      scanType: 'Network Intelligence',
      scope: completedQueries.map(q => q.scope).filter(Boolean).join(', ') || 'Global'
    }
  }
}

export function prepareReportDataFromTokens(tokens: any[]): ReportData {
  const summary = {
    totalItems: tokens.length,
    criticalItems: tokens.filter((t: any) => !t.isValid).length,
    highItems: tokens.filter((t: any) => t.isValid && t.type === 'API_KEY').length,
    mediumItems: tokens.filter((t: any) => t.isValid && t.type === 'OAUTH_TOKEN').length,
    lowItems: tokens.filter((t: any) => t.isValid && t.type === 'SESSION_TOKEN').length
  }

  const sections: ReportSection[] = [
    {
      title: 'Executive Summary',
      content: `This report contains the results of token verification for ${tokens.length} tokens. ${summary.criticalItems} tokens were found to be invalid or expired.`,
      type: 'text'
    },
    {
      title: 'Token Verification Results',
      content: tokens.map((token: any) => ({
        id: token.id,
        title: `${token.type} - ${token.service || 'Unknown Service'}`,
        description: `Token is ${token.isValid ? 'valid' : 'invalid'}. ${token.expiresAt ? `Expires on ${new Date(token.expiresAt).toLocaleDateString()}` : 'No expiration date'}`,
        severity: token.isValid ? 'low' : 'critical',
        details: {
          service: token.service,
          type: token.type,
          lastVerified: token.lastVerified
        },
        timestamp: token.createdAt,
        source: token.source
      })) as ReportItem[],
      type: 'table'
    }
  ]

  return {
    title: 'Token Verification Report',
    subtitle: 'Comprehensive token validation and verification results',
    generatedAt: new Date().toISOString(),
    generatedBy: 'Security Sentinel Platform',
    summary,
    sections
  }
}