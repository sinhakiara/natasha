export interface GitHubRepoInfo {
  owner: string
  repo: string
  isValid: boolean
}

export function parseGitHubUrl(url: string): GitHubRepoInfo {
  // Remove any trailing slashes and normalize the URL
  const normalizedUrl = url.replace(/\/$/, '')
  
  // GitHub URL patterns
  const patterns = [
    // https://github.com/owner/repo
    /^https?:\/\/github\.com\/([^\/]+)\/([^\/\?#]+)/i,
    // git@github.com:owner/repo.git
    /^git@github\.com:([^\/]+)\/([^\/]+\.git)?$/i,
    // github.com/owner/repo
    /^github\.com\/([^\/]+)\/([^\/\?#]+)/i,
  ]

  for (const pattern of patterns) {
    const match = normalizedUrl.match(pattern)
    if (match) {
      return {
        owner: match[1],
        repo: match[2].replace(/\.git$/, ''),
        isValid: true
      }
    }
  }

  return {
    owner: '',
    repo: '',
    isValid: false
  }
}

export function isValidGitHubRepo(owner: string, repo: string): boolean {
  return owner.length > 0 && repo.length > 0 && 
         /^[a-zA-Z0-9._-]+$/.test(owner) && 
         /^[a-zA-Z0-9._-]+$/.test(repo)
}

export function generateGitHubRepoUrl(owner: string, repo: string): string {
  return `https://github.com/${owner}/${repo}`
}

export function extractGitHubTokenFromUrl(url: string): string | null {
  // Check if URL contains a token (for private repos)
  const tokenMatch = url.match(/https:\/\/([^@]+)@github\.com\//)
  return tokenMatch ? tokenMatch[1] : null
}

export function sanitizeGitHubUrl(url: string): string {
  // Remove any authentication tokens from the URL for display/storage
  return url.replace(/https:\/\/[^@]+@github\.com\//, 'https://github.com/')
}