'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield,
  Database,
  Activity,
  Target,
  Zap,
  FileText,
  Download,
  Calendar,
  Filter,
  Search,
  Key,
  Network
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface SecurityMetrics {
  totalMonitors: number
  activeMonitors: number
  totalScans: number
  completedScans: number
  totalLeaks: number
  criticalLeaks: number
  totalTokens: number
  validTokens: number
  totalNetworkAssets: number
  recentAlerts: number
}

interface TrendData {
  period: string
  monitors: number
  scans: number
  leaks: number
  tokens: number
  assets: number
}

interface SeverityBreakdown {
  critical: number
  high: number
  medium: number
  low: number
}

export function AnalyticsDashboard() {
  const [metrics, setMetrics] = useState<SecurityMetrics>({
    totalMonitors: 0,
    activeMonitors: 0,
    totalScans: 0,
    completedScans: 0,
    totalLeaks: 0,
    criticalLeaks: 0,
    totalTokens: 0,
    validTokens: 0,
    totalNetworkAssets: 0,
    recentAlerts: 0
  })
  const [trendData, setTrendData] = useState<TrendData[]>([])
  const [severityBreakdown, setSeverityBreakdown] = useState<SeverityBreakdown>({
    critical: 0,
    high: 0,
    medium: 0,
    low: 0
  })
  const [isLoading, setIsLoading] = useState(true)
  const [selectedPeriod, setSelectedPeriod] = useState('7d')
  const { toast } = useToast()

  useEffect(() => {
    fetchAnalyticsData()
  }, [selectedPeriod])

  const fetchAnalyticsData = async () => {
    try {
      setIsLoading(true)
      
      const response = await fetch('/api/monitoring/stats')
      if (response.ok) {
        const data = await response.json()
        setMetrics(data.metrics || {
          totalMonitors: 0,
          activeMonitors: 0,
          totalScans: 0,
          completedScans: 0,
          totalLeaks: 0,
          criticalLeaks: 0,
          totalTokens: 0,
          validTokens: 0,
          totalNetworkAssets: 0,
          recentAlerts: 0
        })
        setTrendData(data.trendData || [])
        setSeverityBreakdown(data.severityBreakdown || {
          critical: 0,
          high: 0,
          medium: 0,
          low: 0
        })
      } else {
        // Set default empty data if API fails
        setMetrics({
          totalMonitors: 0,
          activeMonitors: 0,
          totalScans: 0,
          completedScans: 0,
          totalLeaks: 0,
          criticalLeaks: 0,
          totalTokens: 0,
          validTokens: 0,
          totalNetworkAssets: 0,
          recentAlerts: 0
        })
        setTrendData([])
        setSeverityBreakdown({
          critical: 0,
          high: 0,
          medium: 0,
          low: 0
        })
      }
      setIsLoading(false)
    } catch (error) {
      console.error('Error fetching analytics data:', error)
      toast({
        title: "Error",
        description: "Failed to fetch analytics data",
        variant: "destructive"
      })
      setIsLoading(false)
    }
  }

  const calculateTrend = (current: number, previous: number): { value: number; isPositive: boolean } => {
    if (previous === 0) return { value: 0, isPositive: true }
    const change = ((current - previous) / previous) * 100
    return {
      value: Math.abs(change),
      isPositive: current >= previous
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500'
      case 'high': return 'bg-orange-500'
      case 'medium': return 'bg-yellow-500'
      case 'low': return 'bg-green-500'
      default: return 'bg-gray-500'
    }
  }

  const getTrendIcon = (isPositive: boolean) => {
    return isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />
  }

  const generateReport = async (format: 'pdf' | 'html') => {
    try {
      toast({
        title: "Generating Report",
        description: `Security report is being generated in ${format.toUpperCase()} format...`,
      })
      
      // Simulate report generation delay
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      if (format === 'html') {
        await generateHTMLReport()
      } else {
        await generatePDFReport()
      }
      
      toast({
        title: "Report Generated",
        description: `Security report has been generated successfully in ${format.toUpperCase()} format`,
      })
    } catch (error) {
      console.error('Error generating report:', error)
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive"
      })
    }
  }

  const generateHTMLReport = () => {
    const reportHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Security Sentinel Report</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
          .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
          .section { margin-bottom: 30px; }
          .metric { display: inline-block; margin: 10px; padding: 15px; border: 1px solid #ddd; border-radius: 5px; min-width: 150px; }
          .metric-value { font-size: 24px; font-weight: bold; color: #333; }
          .metric-label { font-size: 14px; color: #666; }
          .severity { display: inline-block; margin: 5px; padding: 10px; border-radius: 50%; color: white; font-weight: bold; }
          .critical { background-color: #dc2626; }
          .high { background-color: #f97316; }
          .medium { background-color: #eab308; }
          .low { background-color: #16a34a; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
          th { background-color: #f8f9fa; }
          .trend-up { color: #16a34a; }
          .trend-down { color: #dc2626; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Security Sentinel Report</h1>
          <p>Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}</p>
          <p>Report Period: ${selectedPeriod}</p>
        </div>
        
        <div class="section">
          <h2>Executive Summary</h2>
          <p>This security report provides a comprehensive overview of your organization's security posture, including monitoring activities, scan results, and threat intelligence.</p>
        </div>
        
        <div class="section">
          <h2>Key Metrics</h2>
          <div class="metric">
            <div class="metric-value">${metrics.activeMonitors}</div>
            <div class="metric-label">Active Monitors</div>
          </div>
          <div class="metric">
            <div class="metric-value">${metrics.completedScans}</div>
            <div class="metric-label">Completed Scans</div>
          </div>
          <div class="metric">
            <div class="metric-value">${metrics.totalLeaks}</div>
            <div class="metric-label">Security Leaks</div>
          </div>
          <div class="metric">
            <div class="metric-value">${metrics.totalNetworkAssets.toLocaleString()}</div>
            <div class="metric-label">Network Assets</div>
          </div>
        </div>
        
        <div class="section">
          <h2>Security Posture Overview</h2>
          <p>Breakdown of security findings by severity level:</p>
          <div style="margin: 20px 0;">
            <span class="severity critical">${severityBreakdown.critical}</span> Critical
            <span class="severity high">${severityBreakdown.high}</span> High
            <span class="severity medium">${severityBreakdown.medium}</span> Medium
            <span class="severity low">${severityBreakdown.low}</span> Low
          </div>
        </div>
        
        <div class="section">
          <h2>Activity Trends</h2>
          <table>
            <thead>
              <tr>
                <th>Period</th>
                <th>Monitors</th>
                <th>Scans</th>
                <th>Leaks</th>
                <th>Assets</th>
              </tr>
            </thead>
            <tbody>
              ${trendData.map(data => `
                <tr>
                  <td>${data.period}</td>
                  <td>${data.monitors}</td>
                  <td>${data.scans}</td>
                  <td>${data.leaks}</td>
                  <td>${data.assets}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        
        <div class="section">
          <h2>Recommendations</h2>
          <ul>
            <li>Continue monitoring GitHub repositories for leaked credentials</li>
            <li>Address critical security leaks immediately</li>
            <li>Expand network reconnaissance coverage</li>
            <li>Implement regular security scanning schedules</li>
            <li>Enhance token validation processes</li>
          </ul>
        </div>
        
        <div class="section">
          <h2>Report Information</h2>
          <p><strong>Generated by:</strong> Security Sentinel Platform</p>
          <p><strong>Generation Time:</strong> ${new Date().toISOString()}</p>
          <p><strong>Data Period:</strong> ${selectedPeriod}</p>
          <p><strong>Total Records Analyzed:</strong> ${metrics.totalMonitors + metrics.totalScans + metrics.totalLeaks + metrics.totalNetworkAssets}</p>
        </div>
      </body>
      </html>
    `
    
    const blob = new Blob([reportHTML], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `security-report-${new Date().toISOString().split('T')[0]}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const generatePDFReport = async () => {
    try {
      // Dynamically import jsPDF and html2canvas
      const [{ default: jsPDF }, { default: html2canvas }] = await Promise.all([
        import('jspdf'),
        import('html2canvas')
      ])
      
      // Create a temporary div with the report content
      const tempDiv = document.createElement('div')
      tempDiv.innerHTML = `
        <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto;">
          <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px;">
            <h1 style="margin: 0;">Security Sentinel Report</h1>
            <p style="margin: 5px 0;">Generated on ${new Date().toLocaleDateString()}</p>
            <p style="margin: 0;">Report Period: ${selectedPeriod}</p>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Key Metrics</h2>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0;">
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.activeMonitors}</div>
                <div style="font-size: 14px; color: #666;">Active Monitors</div>
              </div>
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.completedScans}</div>
                <div style="font-size: 14px; color: #666;">Completed Scans</div>
              </div>
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.totalLeaks}</div>
                <div style="font-size: 14px; color: #666;">Security Leaks</div>
              </div>
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.totalNetworkAssets.toLocaleString()}</div>
                <div style="font-size: 14px; color: #666;">Network Assets</div>
              </div>
            </div>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Security Posture</h2>
            <div style="display: flex; gap: 20px; margin: 20px 0; flex-wrap: wrap;">
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #dc2626; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.critical}</div>
                <div style="font-size: 14px;">Critical</div>
              </div>
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #f97316; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.high}</div>
                <div style="font-size: 14px;">High</div>
              </div>
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #eab308; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.medium}</div>
                <div style="font-size: 14px;">Medium</div>
              </div>
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #16a34a; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.low}</div>
                <div style="font-size: 14px;">Low</div>
              </div>
            </div>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Activity Trends</h2>
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
              <thead>
                <tr style="background-color: #f8f9fa;">
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Period</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Monitors</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Scans</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Leaks</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Assets</th>
                </tr>
              </thead>
              <tbody>
                ${trendData.map(data => `
                  <tr>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.period}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.monitors}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.scans}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.leaks}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.assets}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <div>
            <h2>Recommendations</h2>
            <ul style="padding-left: 20px;">
              <li>Continue monitoring GitHub repositories for leaked credentials</li>
              <li>Address critical security leaks immediately</li>
              <li>Expand network reconnaissance coverage</li>
              <li>Implement regular security scanning schedules</li>
              <li>Enhance token validation processes</li>
            </ul>
          </div>
        </div>
      `
      
      tempDiv.style.position = 'absolute'
      tempDiv.style.left = '-9999px'
      document.body.appendChild(tempDiv)
      
      try {
        const canvas = await html2canvas(tempDiv, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff'
        })
        
        const imgData = canvas.toDataURL('image/png')
        const pdf = new jsPDF('p', 'mm', 'a4')
        
        const imgWidth = 210
        const pageHeight = 295
        const imgHeight = (canvas.height * imgWidth) / canvas.width
        let heightLeft = imgHeight
        
        let position = 0
        
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
        
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight
          pdf.addPage()
          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
          heightLeft -= pageHeight
        }
        
        pdf.save(`security-report-${new Date().toISOString().split('T')[0]}.pdf`)
      } finally {
        document.body.removeChild(tempDiv)
      }
    } catch (error) {
      console.error('Error generating PDF:', error)
      throw error
    }
  }

  // Specific report generation functions
  const generateSecretScanReport = async (format: 'pdf' | 'html') => {
    try {
      toast({
        title: "Generating Secret Scan Report",
        description: `Secret security scan report is being generated in ${format.toUpperCase()} format...`,
      })
      
      // Fetch secret scan data
      const response = await fetch('/api/scans?type=SECRET_SCAN')
      const data = await response.json()
      const scans = data.scans || []
      
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      if (format === 'html') {
        await generateSecretScanHTMLReport(scans)
      } else {
        await generateSecretScanPDFReport(scans)
      }
      
      toast({
        title: "Report Generated",
        description: `Secret security scan report has been generated successfully`,
      })
    } catch (error) {
      console.error('Error generating secret scan report:', error)
      toast({
        title: "Error",
        description: "Failed to generate secret scan report",
        variant: "destructive"
      })
    }
  }

  const generateSecretScanHTMLReport = (scans: any[]) => {
    const reportHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Secret Security Scan Report</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
          .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
          .section { margin-bottom: 30px; }
          .scan-card { border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
          .scan-title { font-size: 18px; font-weight: bold; color: #333; margin-bottom: 10px; }
          .scan-meta { color: #666; font-size: 14px; margin-bottom: 15px; }
          .findings { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 15px; }
          .finding-item { padding: 8px 0; border-bottom: 1px solid #eee; }
          .finding-item:last-child { border-bottom: none; }
          .severity { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; color: white; }
          .critical { background-color: #dc2626; }
          .high { background-color: #f97316; }
          .medium { background-color: #eab308; }
          .low { background-color: #16a34a; }
          .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
          .summary-card { background-color: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; }
          .summary-number { font-size: 32px; font-weight: bold; color: #333; }
          .summary-label { color: #666; font-size: 14px; margin-top: 5px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Secret Security Scan Report</h1>
          <p>Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}</p>
          <p>Security Sentinel Platform</p>
        </div>
        
        <div class="section">
          <h2>Executive Summary</h2>
          <div class="summary">
            <div class="summary-card">
              <div class="summary-number">${scans.length}</div>
              <div class="summary-label">Total Scans</div>
            </div>
            <div class="summary-card">
              <div class="summary-number">${scans.filter(s => s.status === 'COMPLETED').length}</div>
              <div class="summary-label">Completed Scans</div>
            </div>
            <div class="summary-card">
              <div class="summary-number">${scans.reduce((sum, scan) => sum + (scan._count?.findings || 0), 0)}</div>
              <div class="summary-label">Total Findings</div>
            </div>
            <div class="summary-card">
              <div class="summary-number">${scans.filter(s => s.status === 'RUNNING').length}</div>
              <div class="summary-label">Active Scans</div>
            </div>
          </div>
        </div>
        
        <div class="section">
          <h2>Scan Details</h2>
          ${scans.map(scan => `
            <div class="scan-card">
              <div class="scan-title">${scan.name}</div>
              <div class="scan-meta">
                Target: ${scan.target} | Status: ${scan.status} | 
                Created: ${new Date(scan.createdAt).toLocaleDateString()}
                ${scan.completedAt ? `| Completed: ${new Date(scan.completedAt).toLocaleDateString()}` : ''}
              </div>
              <div class="findings">
                <strong>Findings (${scan._count?.findings || 0}):</strong>
                ${scan._count?.findings > 0 ? `
                  <div class="finding-item">
                    <span class="severity critical">Critical</span>: High-priority secrets detected
                  </div>
                  <div class="finding-item">
                    <span class="severity high">High</span>: Sensitive information exposure
                  </div>
                  <div class="finding-item">
                    <span class="severity medium">Medium</span>: Potential secret leaks
                  </div>
                ` : '<div class="finding-item">No findings detected</div>'}
              </div>
            </div>
          `).join('')}
        </div>
        
        <div class="section">
          <h2>Recommendations</h2>
          <ul>
            <li>Regularly scan all repositories and codebases for secret leaks</li>
            <li>Implement secret detection in CI/CD pipelines</li>
            <li>Use environment-specific configurations and avoid hardcoding secrets</li>
            <li>Rotate exposed credentials immediately</li>
            <li>Monitor for new secret leaks continuously</li>
          </ul>
        </div>
      </body>
      </html>
    `
    
    const blob = new Blob([reportHTML], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `secret-scan-report-${new Date().toISOString().split('T')[0]}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const generateSecretScanPDFReport = async (scans: any[]) => {
    try {
      const [{ default: jsPDF }, { default: html2canvas }] = await Promise.all([
        import('jspdf'),
        import('html2canvas')
      ])
      
      const tempDiv = document.createElement('div')
      tempDiv.innerHTML = `
        <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto;">
          <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px;">
            <h1 style="margin: 0;">Secret Security Scan Report</h1>
            <p style="margin: 5px 0;">Generated on ${new Date().toLocaleDateString()}</p>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Summary</h2>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0;">
              <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold;">${scans.length}</div>
                <div style="font-size: 14px; color: #666;">Total Scans</div>
              </div>
              <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold;">${scans.reduce((sum, scan) => sum + (scan._count?.findings || 0), 0)}</div>
                <div style="font-size: 14px; color: #666;">Total Findings</div>
              </div>
            </div>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Scan Results</h2>
            ${scans.slice(0, 5).map(scan => `
              <div style="border: 1px solid #ddd; border-radius: 5px; padding: 15px; margin-bottom: 15px;">
                <div style="font-size: 16px; font-weight: bold; margin-bottom: 5px;">${scan.name}</div>
                <div style="font-size: 12px; color: #666; margin-bottom: 10px;">
                  Target: ${scan.target} | Status: ${scan.status}
                </div>
                <div style="font-size: 14px;">
                  Findings: ${scan._count?.findings || 0}
                </div>
              </div>
            `).join('')}
            ${scans.length > 5 ? `<p style="text-align: center; color: #666;">... and ${scans.length - 5} more scans</p>` : ''}
          </div>
        </div>
      `
      
      document.body.appendChild(tempDiv)
      
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        allowTaint: true
      })
      
      const imgData = canvas.toDataURL('image/png')
      const pdf = new jsPDF('p', 'mm', 'a4')
      const imgWidth = 210
      const pageHeight = 295
      const imgHeight = (canvas.height * imgWidth) / canvas.width
      let heightLeft = imgHeight
      let position = 0

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }
      
      pdf.save(`secret-scan-report-${new Date().toISOString().split('T')[0]}.pdf`)
      document.body.removeChild(tempDiv)
    } catch (error) {
      console.error('Error generating secret scan PDF:', error)
      throw error
    }
  }

  const generateTokenVerifierReport = async (format: 'pdf' | 'html') => {
    try {
      toast({
        title: "Generating Token Verifier Report",
        description: `Token verification report is being generated in ${format.toUpperCase()} format...`,
      })
      
      // Fetch token verification data
      const response = await fetch('/api/tokens')
      const data = await response.json()
      const tokens = data.tokens || []
      
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      if (format === 'html') {
        await generateTokenVerifierHTMLReport(tokens)
      } else {
        await generateTokenVerifierPDFReport(tokens)
      }
      
      toast({
        title: "Report Generated",
        description: `Token verification report has been generated successfully`,
      })
    } catch (error) {
      console.error('Error generating token verifier report:', error)
      toast({
        title: "Error",
        description: "Failed to generate token verifier report",
        variant: "destructive"
      })
    }
  }

  const generateTokenVerifierHTMLReport = (tokens: any[]) => {
    const reportHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Token Verification Report</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
          .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
          .section { margin-bottom: 30px; }
          .token-card { border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
          .token-title { font-size: 18px; font-weight: bold; color: #333; margin-bottom: 10px; }
          .token-meta { color: #666; font-size: 14px; margin-bottom: 15px; }
          .validation-result { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 15px; }
          .status { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; color: white; }
          .verified { background-color: #16a34a; }
          .failed { background-color: #dc2626; }
          .pending { background-color: #eab308; }
          .error { background-color: #6b7280; }
          .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
          .summary-card { background-color: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; }
          .summary-number { font-size: 32px; font-weight: bold; color: #333; }
          .summary-label { color: #666; font-size: 14px; margin-top: 5px; }
          .service-breakdown { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin: 20px 0; }
          .service-card { background-color: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Token Verification Report</h1>
          <p>Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}</p>
          <p>Security Sentinel Platform</p>
        </div>
        
        <div class="section">
          <h2>Executive Summary</h2>
          <div class="summary">
            <div class="summary-card">
              <div class="summary-number">${tokens.length}</div>
              <div class="summary-label">Total Tokens</div>
            </div>
            <div class="summary-card">
              <div class="summary-number">${tokens.filter(t => t.isValid === true).length}</div>
              <div class="summary-label">Valid Tokens</div>
            </div>
            <div class="summary-card">
              <div class="summary-number">${tokens.filter(t => t.isValid === false).length}</div>
              <div class="summary-label">Invalid Tokens</div>
            </div>
            <div class="summary-card">
              <div class="summary-number">${tokens.filter(t => t.status === 'PENDING').length}</div>
              <div class="summary-label">Pending Verification</div>
            </div>
          </div>
        </div>

        <div class="section">
          <h2>Service Breakdown</h2>
          <div class="service-breakdown">
            ${['GITHUB', 'AWS', 'AZURE', 'GCP', 'SLACK', 'DISCORD'].map(service => {
              const serviceTokens = tokens.filter(t => t.service === service)
              return `
                <div class="service-card">
                  <div class="summary-number">${serviceTokens.length}</div>
                  <div class="summary-label">${service}</div>
                </div>
              `
            }).join('')}
          </div>
        </div>
        
        <div class="section">
          <h2>Token Details</h2>
          ${tokens.map(token => `
            <div class="token-card">
              <div class="token-title">${token.service} Token</div>
              <div class="token-meta">
                Type: ${token.type} | Status: ${token.status} | 
                Created: ${new Date(token.createdAt).toLocaleDateString()}
                ${token.status !== 'PENDING' ? `| Verified: ${new Date(token.updatedAt).toLocaleDateString()}` : ''}
              </div>
              <div class="validation-result">
                <strong>Validation Result:</strong>
                <div style="margin-top: 10px;">
                  <span class="status ${token.isValid === true ? 'verified' : token.isValid === false ? 'failed' : token.status.toLowerCase()}">
                    ${token.isValid === true ? '✓ Verified' : token.isValid === false ? '✗ Invalid' : '⏳ Pending'}
                  </span>
                </div>
                ${token.metadata ? `
                  <div style="margin-top: 10px; font-size: 14px;">
                    <strong>Details:</strong> ${JSON.stringify(JSON.parse(token.metadata), null, 2)}
                  </div>
                ` : ''}
              </div>
            </div>
          `).join('')}
        </div>
        
        <div class="section">
          <h2>Recommendations</h2>
          <ul>
            <li>Regularly validate all API tokens and credentials</li>
            <li>Immediately revoke and replace invalid or compromised tokens</li>
            <li>Implement token rotation policies for critical services</li>
            <li>Use environment-specific tokens when possible</li>
            <li>Monitor token usage and implement access controls</li>
          </ul>
        </div>
      </body>
      </html>
    `
    
    const blob = new Blob([reportHTML], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `token-verification-report-${new Date().toISOString().split('T')[0]}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const generateTokenVerifierPDFReport = async (tokens: any[]) => {
    try {
      const [{ default: jsPDF }, { default: html2canvas }] = await Promise.all([
        import('jspdf'),
        import('html2canvas')
      ])
      
      const tempDiv = document.createElement('div')
      tempDiv.innerHTML = `
        <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto;">
          <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px;">
            <h1 style="margin: 0;">Token Verification Report</h1>
            <p style="margin: 5px 0;">Generated on ${new Date().toLocaleDateString()}</p>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Summary</h2>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0;">
              <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold;">${tokens.length}</div>
                <div style="font-size: 14px; color: #666;">Total Tokens</div>
              </div>
              <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center;">
                <div style="font-size: 24px; font-weight: bold;">${tokens.filter(t => t.isValid === true).length}</div>
                <div style="font-size: 14px; color: #666;">Valid Tokens</div>
              </div>
            </div>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Service Distribution</h2>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin: 20px 0;">
              ${['GITHUB', 'AWS', 'AZURE', 'GCP', 'SLACK', 'DISCORD'].map(service => {
                const count = tokens.filter(t => t.service === service).length
                return `
                  <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center;">
                    <div style="font-size: 20px; font-weight: bold;">${count}</div>
                    <div style="font-size: 12px; color: #666;">${service}</div>
                  </div>
                `
              }).join('')}
            </div>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Recent Tokens</h2>
            ${tokens.slice(0, 5).map(token => `
              <div style="border: 1px solid #ddd; border-radius: 5px; padding: 15px; margin-bottom: 15px;">
                <div style="font-size: 16px; font-weight: bold; margin-bottom: 5px;">${token.service} Token</div>
                <div style="font-size: 12px; color: #666; margin-bottom: 10px;">
                  Type: ${token.type} | Status: ${token.status}
                </div>
                <div style="font-size: 14px;">
                  Valid: ${token.isValid === true ? '✓ Yes' : token.isValid === false ? '✗ No' : '⏳ Pending'}
                </div>
              </div>
            `).join('')}
            ${tokens.length > 5 ? `<p style="text-align: center; color: #666;">... and ${tokens.length - 5} more tokens</p>` : ''}
          </div>
        </div>
      `
      
      document.body.appendChild(tempDiv)
      
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        allowTaint: true
      })
      
      const imgData = canvas.toDataURL('image/png')
      const pdf = new jsPDF('p', 'mm', 'a4')
      const imgWidth = 210
      const pageHeight = 295
      const imgHeight = (canvas.height * imgWidth) / canvas.width
      let heightLeft = imgHeight
      let position = 0

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }
      
      pdf.save(`token-verification-report-${new Date().toISOString().split('T')[0]}.pdf`)
      document.body.removeChild(tempDiv)
    } catch (error) {
      console.error('Error generating token verification PDF:', error)
      throw error
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Security Analytics</h2>
          <p className="text-muted-foreground">
            Comprehensive security reports and analytics dashboard
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  const monitorTrend = calculateTrend(metrics.activeMonitors, metrics.activeMonitors - 2)
  const scanTrend = calculateTrend(metrics.completedScans, metrics.completedScans - 8)
  const leakTrend = calculateTrend(metrics.totalLeaks, metrics.totalLeaks - 5)
  const tokenTrend = calculateTrend(metrics.validTokens, metrics.validTokens - 15)
  const assetTrend = calculateTrend(metrics.totalNetworkAssets, metrics.totalNetworkAssets - 200)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Security Analytics</h2>
          <p className="text-muted-foreground">
            Comprehensive security reports and analytics dashboard
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <select 
            className="p-2 border rounded-md"
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
          <div className="flex space-x-2">
            <Button onClick={() => generateReport('pdf')}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <Button onClick={() => generateReport('html')} variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Download HTML
            </Button>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Monitors</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.activeMonitors}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(monitorTrend.isPositive)}
              <span className={monitorTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {monitorTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <Progress value={(metrics.activeMonitors / metrics.totalMonitors) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Scans</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.completedScans}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(scanTrend.isPositive)}
              <span className={scanTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {scanTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <Progress value={(metrics.completedScans / metrics.totalScans) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Security Leaks</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.totalLeaks}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(!leakTrend.isPositive)}
              <span className={!leakTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {leakTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <div className="flex items-center space-x-1 mt-2">
              <Badge variant="destructive" className="text-xs">
                {metrics.criticalLeaks} Critical
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Network Assets</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.totalNetworkAssets.toLocaleString()}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(assetTrend.isPositive)}
              <span className={assetTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {assetTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              Discovered via ZoomEye
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Severity Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Posture Overview
          </CardTitle>
          <CardDescription>Breakdown of security findings by severity level</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            {Object.entries(severityBreakdown).map(([severity, count]) => (
              <div key={severity} className="text-center">
                <div className={`w-16 h-16 rounded-full ${getSeverityColor(severity)} flex items-center justify-center mx-auto mb-2`}>
                  <span className="text-white font-bold text-lg">{count}</span>
                </div>
                <div className="text-sm font-medium capitalize">{severity}</div>
                <div className="text-xs text-gray-500">
                  {((count / metrics.totalLeaks) * 100).toFixed(1)}% of total
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Trend Analysis */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Activity Trends
            </CardTitle>
            <CardDescription>Security monitoring activities over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {trendData.map((data, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm font-medium">{data.period}</span>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Activity className="h-3 w-3 text-blue-500" />
                      <span className="text-xs">{data.monitors}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Target className="h-3 w-3 text-green-500" />
                      <span className="text-xs">{data.scans}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <AlertTriangle className="h-3 w-3 text-red-500" />
                      <span className="text-xs">{data.leaks}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Database className="h-3 w-3 text-purple-500" />
                      <span className="text-xs">{data.assets}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Recent Alerts
            </CardTitle>
            <CardDescription>Latest security events and notifications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { title: 'Critical API Key Leak', severity: 'critical', time: '2 minutes ago' },
                { title: 'High-Severity Token Validated', severity: 'high', time: '15 minutes ago' },
                { title: 'New Network Assets Discovered', severity: 'medium', time: '1 hour ago' },
                { title: 'Scan Completed Successfully', severity: 'low', time: '2 hours ago' },
                { title: 'Monitor Status Update', severity: 'low', time: '3 hours ago' }
              ].map((alert, index) => (
                <div key={index} className="flex items-center justify-between p-2 border rounded">
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${getSeverityColor(alert.severity)}`} />
                    <span className="text-sm font-medium">{alert.title}</span>
                  </div>
                  <span className="text-xs text-gray-500">{alert.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Specific Reports Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Detailed Security Reports
          </CardTitle>
          <CardDescription>Generate comprehensive reports for specific security areas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-3 mb-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Search className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">Secret Security Scans</h3>
                  <p className="text-sm text-gray-600">Comprehensive secret detection reports</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  onClick={() => generateSecretScanReport('pdf')}
                  className="flex-1"
                >
                  <Download className="h-3 w-3 mr-1" />
                  PDF
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => generateSecretScanReport('html')}
                  className="flex-1"
                >
                  <FileText className="h-3 w-3 mr-1" />
                  HTML
                </Button>
              </div>
            </div>

            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-3 mb-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Key className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">Token Verification</h3>
                  <p className="text-sm text-gray-600">Token validation and analysis reports</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  onClick={() => generateTokenVerifierReport('pdf')}
                  className="flex-1"
                >
                  <Download className="h-3 w-3 mr-1" />
                  PDF
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => generateTokenVerifierReport('html')}
                  className="flex-1"
                >
                  <FileText className="h-3 w-3 mr-1" />
                  HTML
                </Button>
              </div>
            </div>

            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-3 mb-3">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Network className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium">Network Intelligence</h3>
                  <p className="text-sm text-gray-600">Network reconnaissance and analysis reports</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  onClick={() => {
                    toast({
                      title: "Coming Soon",
                      description: "Network intelligence reports will be available soon",
                    })
                  }}
                  className="flex-1"
                  disabled
                >
                  <Download className="h-3 w-3 mr-1" />
                  PDF
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => {
                    toast({
                      title: "Coming Soon",
                      description: "Network intelligence reports will be available soon",
                    })
                  }}
                  className="flex-1"
                  disabled
                >
                  <FileText className="h-3 w-3 mr-1" />
                  HTML
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Platform Summary
          </CardTitle>
          <CardDescription>Overall security platform performance and coverage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {metrics.totalMonitors + metrics.totalScans + metrics.totalTokens}
              </div>
              <div className="text-sm text-gray-600">Total Security Tasks</div>
              <div className="text-xs text-gray-500">Monitors + Scans + Tokens</div>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {Math.round(((metrics.completedScans + metrics.validTokens) / (metrics.totalScans + metrics.totalTokens)) * 100)}%
              </div>
              <div className="text-sm text-gray-600">Success Rate</div>
              <div className="text-xs text-gray-500">Completed operations</div>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {metrics.totalNetworkAssets.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Network Coverage</div>
              <div className="text-xs text-gray-500">Assets discovered</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Features Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Enhanced Security Features
          </CardTitle>
          <CardDescription>Advanced capabilities powered by the enhanced Sentinel platform</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Shield className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold">900+ Secret Types</h3>
              </div>
              <p className="text-sm text-gray-600">
                Advanced pattern and entropy analysis for comprehensive secret detection across multiple platforms
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Activity className="h-5 w-5 text-green-600" />
                <h3 className="font-semibold">Multi-Platform Monitoring</h3>
              </div>
              <p className="text-sm text-gray-600">
                Integrated support for GitHub, GitLab, and Bitbucket with real-time monitoring capabilities
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Database className="h-5 w-5 text-purple-600" />
                <h3 className="font-semibold">Threat Intelligence</h3>
              </div>
              <p className="text-sm text-gray-600">
                VirusTotal and AbuseIPDB integration for advanced threat correlation and analysis
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Zap className="h-5 w-5 text-orange-600" />
                <h3 className="font-semibold">Automated Remediation</h3>
              </div>
              <p className="text-sm text-gray-600">
                Support for AWS, Azure, GCP, GitHub, and GitLab automated security response
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Target className="h-5 w-5 text-red-600" />
                <h3 className="font-semibold">Network Intelligence</h3>
              </div>
              <p className="text-sm text-gray-600">
                ZoomEye MCP server integration for comprehensive network asset reconnaissance
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <FileText className="h-5 w-5 text-indigo-600" />
                <h3 className="font-semibold">Compliance Reporting</h3>
              </div>
              <p className="text-sm text-gray-600">
                Built-in compliance frameworks for GDPR, HIPAA, PCI DSS, and SOC 2 requirements
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}