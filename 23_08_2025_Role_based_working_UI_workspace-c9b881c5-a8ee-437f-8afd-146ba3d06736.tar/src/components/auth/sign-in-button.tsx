'use client'

import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { LogIn } from 'lucide-react'
import { useRouter } from 'next/navigation'

interface SignInButtonProps {
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link'
  size?: 'default' | 'sm' | 'lg' | 'icon'
  className?: string
}

export function SignInButton({ 
  variant = 'default', 
  size = 'sm',
  className = '' 
}: SignInButtonProps) {
  const { data: session } = useSession()
  const router = useRouter()

  const handleSignIn = () => {
    router.push('/auth/signin')
  }

  if (session) {
    return null
  }

  return (
    <Button 
      variant={variant} 
      size={size}
      className={className}
      onClick={handleSignIn}
    >
      <LogIn className="h-4 w-4 mr-2" />
      Sign In
    </Button>
  )
}