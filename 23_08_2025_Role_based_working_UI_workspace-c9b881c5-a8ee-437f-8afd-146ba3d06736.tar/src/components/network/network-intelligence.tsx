'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Network, 
  Search, 
  Plus, 
  Globe, 
  Server,
  Shield,
  Clock,
  ExternalLink,
  MapPin,
  Database,
  AlertTriangle,
  CheckCircle,
  Activity,
  Wifi,
  Lock,
  Unlock,
  Download,
  FileText
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { prepareReportDataFromQueries, downloadReport } from '@/lib/report-generator'

interface ZoomEyeQuery {
  id: string
  query: string
  type: string
  scope?: string
  result: string
  status: string
  createdAt: string
}

interface NewQueryForm {
  query: string
  type: string
  scope?: string
}

const QUERY_TYPES = [
  { value: 'HOST', label: 'Host Search', icon: Server, description: 'Search for hosts, ports, and services' },
  { value: 'WEB', label: 'Web Search', icon: Globe, description: 'Search for web applications and websites' },
  { value: 'DOMAIN', label: 'Domain Search', icon: Database, description: 'Search for domain-related information' },
  { value: 'CUSTOM', label: 'Custom Query', icon: Search, description: 'Advanced custom ZoomEye queries' }
]

const SAMPLE_QUERIES = [
  { type: 'HOST', query: 'port:22 +ssh', description: 'SSH servers' },
  { type: 'HOST', query: 'port:443 +ssl', description: 'HTTPS servers' },
  { type: 'HOST', query: 'app:"Apache"', description: 'Apache web servers' },
  { type: 'WEB', query: 'title:"admin"', description: 'Pages with admin in title' },
  { type: 'WEB', query: 'server:"nginx"', description: 'Nginx web servers' },
  { type: 'DOMAIN', query: 'domain:example.com', description: 'Domain information' }
]

// Enhanced Sentinel Security Platform - Network Intelligence Component
export function NetworkIntelligence() {
  const { data: session } = useSession()
  const router = useRouter()
  const [queries, setQueries] = useState<ZoomEyeQuery[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isQuerying, setIsQuerying] = useState(false)
  const [newQuery, setNewQuery] = useState<NewQueryForm>({
    query: '',
    type: 'HOST',
    scope: ''
  })
  const [validationError, setValidationError] = useState('')
  const [activeQueryId, setActiveQueryId] = useState<string | null>(null)
  const [queryProgress, setQueryProgress] = useState(0)
  const { toast } = useToast()

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3' // Admin user ID as fallback

  useEffect(() => {
    fetchQueries()
    
    // Only set up polling for running queries to reduce unnecessary refreshes
    const interval = setInterval(() => {
      const hasRunningQueries = queries.some(q => q.status === 'RUNNING')
      if (hasRunningQueries) {
        fetchQueries()
      }
    }, 8000) // Poll every 8 seconds instead of 3, and only when there are running queries

    return () => clearInterval(interval)
  }, [queries.some(q => q.status === 'RUNNING')]) // Only re-run when running query status changes

  useEffect(() => {
    // Simulate query progress for active queries
    const runningQueries = queries.filter(q => q.status === 'RUNNING')
    if (runningQueries.length > 0) {
      const progressInterval = setInterval(() => {
        setQueryProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval)
            return 95
          }
          return prev + Math.random() * 15
        })
      }, 800)

      return () => clearInterval(progressInterval)
    } else {
      setQueryProgress(0)
    }
  }, [queries]) // Keep this dependency but it won't cause infinite loop now

  const fetchQueries = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/zoomeye?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setQueries(data.queries || [])
      }
    } catch (error) {
      console.error('Error fetching queries:', error)
      toast({
        title: "Error",
        description: "Failed to fetch queries",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const validateForm = (): boolean => {
    if (!newQuery.query.trim()) {
      setValidationError('Query is required')
      return false
    }

    if (!newQuery.type) {
      setValidationError('Query type is required')
      return false
    }

    // Basic query validation
    const query = newQuery.query.trim()
    if (query.length < 3) {
      setValidationError('Query must be at least 3 characters long')
      return false
    }

    // Validate query syntax based on type
    if (newQuery.type === 'HOST') {
      // Basic validation for host search queries
      if (!query.match(/^(port:|app:|os:|service:|protocol:|version:|banner:|hostname:|city:|country:)/)) {
        setValidationError('Invalid host search query format. Use syntax like: port:22, app:Apache, etc.')
        return false
      }
    }

    setValidationError('')
    return true
  }

  const handleExecuteQuery = async () => {
    if (!validateForm()) return

    try {
      setIsQuerying(true)
      
      const response = await fetch('/api/zoomeye', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newQuery,
          userId
        })
      })

      if (response.ok) {
        const data = await response.json()
        setQueries(prev => [data.query, ...prev])
        setNewQuery({
          query: '',
          type: 'HOST',
          scope: ''
        })
        toast({
          title: "Query Executed",
          description: "ZoomEye query is now running",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to execute query",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error executing query:', error)
      toast({
        title: "Error",
        description: "Failed to execute query",
        variant: "destructive"
      })
    } finally {
      setIsQuerying(false)
    }
  }

  const handleUseSampleQuery = (sample: typeof SAMPLE_QUERIES[0]) => {
    setNewQuery(prev => ({
      ...prev,
      query: sample.query,
      type: sample.type
    }))
  }

  const handleViewResults = (query: ZoomEyeQuery) => {
    router.push(`/network-intelligence/${query.id}`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <Clock className="h-3 w-3 animate-spin" />
      case 'FAILED':
        return <AlertTriangle className="h-3 w-3" />
      case 'PENDING':
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getQueryTypeInfo = (type: string) => {
    return QUERY_TYPES.find(t => t.value === type) || QUERY_TYPES[3]
  }

  const parseQueryResult = (result: string) => {
    try {
      return JSON.parse(result)
    } catch {
      return null
    }
  }

  const getSeverityColor = (count: number) => {
    if (count === 0) return 'bg-green-100 text-green-800'
    if (count <= 10) return 'bg-yellow-100 text-yellow-800'
    if (count <= 100) return 'bg-orange-100 text-orange-800'
    return 'bg-red-100 text-red-800'
  }

  const handleGenerateReport = (format: 'html' | 'pdf' = 'html') => {
    if (queries.length === 0) {
      toast({
        title: "No Data",
        description: "No queries available for report generation",
        variant: "destructive"
      })
      return
    }

    try {
      const reportData = prepareReportDataFromQueries(queries)
      downloadReport(reportData, format)
      toast({
        title: "Report Generated",
        description: `Network Intelligence report has been generated in ${format.toUpperCase()} format`,
      })
    } catch (error) {
      console.error('Error generating report:', error)
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive"
      })
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Network Intelligence</h2>
          <p className="text-muted-foreground">
            Network asset reconnaissance and intelligence gathering with ZoomEye
          </p>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <RBACGuard requiredPermissions={['write']}>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Network Intelligence</h2>
          <p className="text-muted-foreground">
            Network asset reconnaissance and intelligence gathering with ZoomEye
          </p>
        </div>

      {/* Execute New Query */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            ZoomEye Query
          </CardTitle>
          <CardDescription>Search for network assets using ZoomEye dorks and queries</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {validationError && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{validationError}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium">Query Type</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={newQuery.type}
                onChange={(e) => setNewQuery(prev => ({ ...prev, type: e.target.value }))}
              >
                {QUERY_TYPES.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-1">
                {QUERY_TYPES.find(t => t.value === newQuery.type)?.description}
              </p>
            </div>
            <div>
              <label className="text-sm font-medium">Search Scope (Optional)</label>
              <Input
                placeholder="e.g., domain:yourdomain.com or 192.168.1.0/24"
                value={newQuery.scope || ''}
                onChange={(e) => setNewQuery(prev => ({ ...prev, scope: e.target.value }))}
              />
              <p className="text-xs text-gray-500 mt-1">
                Limit search to specific domains, IP ranges, or organizations
              </p>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">ZoomEye Query</label>
            <Input
              placeholder="e.g., port:22 +ssh"
              value={newQuery.query}
              onChange={(e) => setNewQuery(prev => ({ ...prev, query: e.target.value }))}
            />
          </div>

          {/* Sample Queries */}
          <div>
            <label className="text-sm font-medium">Sample Queries</label>
            <div className="grid gap-2 mt-2">
              {SAMPLE_QUERIES.filter(q => q.type === newQuery.type).map((sample, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="justify-start text-left"
                  onClick={() => handleUseSampleQuery(sample)}
                >
                  <span className="font-medium">{sample.query}</span>
                  <span className="text-gray-500 ml-2">- {sample.description}</span>
                </Button>
              ))}
            </div>
          </div>
          
          <Button 
            onClick={handleExecuteQuery} 
            disabled={isQuerying}
            className="w-full"
          >
            {isQuerying ? 'Executing...' : 'Search ZoomEye'}
          </Button>
        </CardContent>
      </Card>

      {/* Active Query Progress */}
      {queries.some(query => query.status === 'RUNNING') && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 animate-pulse" />
              Active Queries
            </CardTitle>
          </CardHeader>
          <CardContent>
            {queries.filter(query => query.status === 'RUNNING').map((query) => (
              <div key={query.id} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {(() => {
                      const IconComponent = getQueryTypeInfo(query.type).icon
                      return IconComponent && <IconComponent className="h-4 w-4" />
                    })()}
                    <span className="font-medium">{query.query}</span>
                  </div>
                  <Badge className={getStatusColor(query.status)}>
                    {getStatusIcon(query.status)}
                    {query.status}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>
                      Executing {getQueryTypeInfo(query.type).label}...
                      {query.scope && (
                        <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          Scope: {query.scope}
                        </span>
                      )}
                    </span>
                    <span>{Math.round(queryProgress)}%</span>
                  </div>
                  <Progress value={queryProgress} className="h-2" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Recent Queries */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Recent Queries</CardTitle>
              <CardDescription>Your latest ZoomEye search queries and results</CardDescription>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleGenerateReport('html')}
                disabled={queries.length === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                HTML Report
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleGenerateReport('pdf')}
                disabled={queries.length === 0}
              >
                <FileText className="h-4 w-4 mr-2" />
                PDF Report
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {queries.length === 0 ? (
            <div className="text-center py-8">
              <Network className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No queries yet</h3>
              <p className="text-gray-500">Execute your first query to start gathering network intelligence</p>
            </div>
          ) : (
            <div className="space-y-4">
              {queries
                .filter(query => query.status !== 'RUNNING')
                .map((query) => {
                const result = parseQueryResult(query.result)
                const resultCount = result?.data?.length || 0
                const totalCount = result?.total || 0
                
                return (
                  <div key={query.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-4">
                      <div className="flex-shrink-0">
                        {(() => {
                          const IconComponent = getQueryTypeInfo(query.type).icon
                          return IconComponent && <IconComponent className="h-5 w-5 text-gray-600" />
                        })()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <h3 className="text-sm font-medium text-gray-900 truncate">
                            {query.query}
                          </h3>
                          <Badge className={getStatusColor(query.status)}>
                            {getStatusIcon(query.status)}
                            {query.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-500">
                          {getQueryTypeInfo(query.type).label} • {new Date(query.createdAt).toLocaleString()}
                          {query.scope && (
                            <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                              Scope: {query.scope}
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {query.status === 'COMPLETED' && (
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-600">Results:</span>
                          <Badge className={getSeverityColor(resultCount)}>
                            {resultCount}{totalCount > resultCount ? `/${totalCount}` : ''}
                          </Badge>
                        </div>
                      )}
                      
                      <div className="flex items-center space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleViewResults(query)}
                          disabled={query.status !== 'COMPLETED'}
                        >
                          View Results
                        </Button>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
      </div>
    </RBACGuard>
  )
}