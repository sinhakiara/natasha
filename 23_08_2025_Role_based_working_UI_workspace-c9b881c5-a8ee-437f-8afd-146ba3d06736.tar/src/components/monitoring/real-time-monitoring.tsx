'use client'

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { AlertTriangle, Shield, Eye, Activity, Bell, Settings } from 'lucide-react'
import { io, Socket } from 'socket.io-client'

interface RealTimeAlert {
  id: string
  title: string
  message: string
  type: string
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  sourceId?: string
  sourceType?: string
  timestamp: string
  isRead: boolean
}

interface MonitoringStats {
  totalAlerts: number
  unreadAlerts: number
  criticalAlerts: number
  activeMonitors: number
  recentScans: number
}

export default function RealTimeMonitoring() {
  const { data: session } = useSession()
  const [socket, setSocket] = useState<Socket | null>(null)
  const [alerts, setAlerts] = useState<RealTimeAlert[]>([])
  const [stats, setStats] = useState<MonitoringStats>({
    totalAlerts: 0,
    unreadAlerts: 0,
    criticalAlerts: 0,
    activeMonitors: 0,
    recentScans: 0
  })
  const [isConnected, setIsConnected] = useState(false)
  const [selectedAlert, setSelectedAlert] = useState<RealTimeAlert | null>(null)

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3' // Admin user ID as fallback

  useEffect(() => {
    // Initialize socket connection
    const newSocket = io('http://localhost:3000', {
      path: '/api/socketio'
    })
    
    setSocket(newSocket)

    // Socket event handlers
    newSocket.on('connect', () => {
      setIsConnected(true)
      console.log('Connected to real-time monitoring server')
    })

    newSocket.on('disconnect', () => {
      setIsConnected(false)
      console.log('Disconnected from real-time monitoring server')
    })

    newSocket.on('new_alert', (alert: RealTimeAlert) => {
      setAlerts(prev => [alert, ...prev])
      updateStats(prev => ({
        ...prev,
        totalAlerts: prev.totalAlerts + 1,
        unreadAlerts: prev.unreadAlerts + 1,
        criticalAlerts: alert.severity === 'CRITICAL' ? prev.criticalAlerts + 1 : prev.criticalAlerts
      }))
    })

    newSocket.on('monitoring_stats', (newStats: MonitoringStats) => {
      setStats(newStats)
    })

    newSocket.on('scan_update', (data) => {
      console.log('Scan update:', data)
      // Update UI with scan progress
    })

    // Fetch initial data
    fetchInitialData()

    return () => {
      newSocket.close()
    }
  }, [])

  const fetchInitialData = async () => {
    try {
      // Fetch recent alerts
      const alertsResponse = await fetch(`/api/alerts?userId=${userId}&limit=50`)
      if (alertsResponse.ok) {
        const alertsData = await alertsResponse.json()
        setAlerts(alertsData.alerts || [])
      }

      // Fetch monitoring stats
      const statsResponse = await fetch(`/api/monitoring/stats?userId=${userId}`)
      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setStats(statsData)
      }
    } catch (error) {
      console.error('Error fetching initial data:', error)
    }
  }

  const updateStats = (updater: (prev: MonitoringStats) => MonitoringStats) => {
    setStats(prev => {
      const newStats = updater(prev)
      // Emit updated stats to server
      if (socket) {
        socket.emit('stats_update', newStats)
      }
      return newStats
    })
  }

  const markAlertAsRead = async (alertId: string) => {
    try {
      const response = await fetch(`/api/alerts/${alertId}/read`, {
        method: 'POST'
      })
      
      if (response.ok) {
        setAlerts(prev => prev.map(alert => 
          alert.id === alertId ? { ...alert, isRead: true } : alert
        ))
        updateStats(prev => ({
          ...prev,
          unreadAlerts: Math.max(0, prev.unreadAlerts - 1)
        }))
      }
    } catch (error) {
      console.error('Error marking alert as read:', error)
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'bg-red-500 text-white'
      case 'HIGH': return 'bg-orange-500 text-white'
      case 'MEDIUM': return 'bg-yellow-500 text-white'
      case 'LOW': return 'bg-green-500 text-white'
      default: return 'bg-gray-500 text-white'
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return <AlertTriangle className="h-4 w-4" />
      case 'HIGH': return <AlertTriangle className="h-4 w-4" />
      case 'MEDIUM': return <Shield className="h-4 w-4" />
      case 'LOW': return <Eye className="h-4 w-4" />
      default: return <Activity className="h-4 w-4" />
    }
  }

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString()
  }

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-sm font-medium">
            {isConnected ? 'Real-time Connected' : 'Disconnected'}
          </span>
        </div>
        <Button variant="outline" size="sm">
          <Settings className="h-4 w-4 mr-2" />
          Settings
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Alerts</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalAlerts}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unread Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.unreadAlerts}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.criticalAlerts}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Monitors</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeMonitors}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recent Scans</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.recentScans}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="alerts" className="space-y-4">
        <TabsList>
          <TabsTrigger value="alerts">Real-time Alerts</TabsTrigger>
          <TabsTrigger value="activity">Activity Feed</TabsTrigger>
          <TabsTrigger value="monitors">Monitor Status</TabsTrigger>
        </TabsList>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live Security Alerts</CardTitle>
              <CardDescription>
                Real-time security alerts and notifications from your monitors
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] w-full">
                <div className="space-y-4">
                  {alerts.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No alerts yet. Your monitors are running quietly.
                    </div>
                  ) : (
                    alerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                          alert.isRead ? 'bg-muted/30' : 'bg-background border-primary/20'
                        } ${selectedAlert?.id === alert.id ? 'ring-2 ring-primary' : ''}`}
                        onClick={() => setSelectedAlert(alert)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3">
                            <div className={getSeverityColor(alert.severity)}>
                              {getSeverityIcon(alert.severity)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2">
                                <h4 className="font-semibold">{alert.title}</h4>
                                <Badge variant="outline" className={getSeverityColor(alert.severity)}>
                                  {alert.severity}
                                </Badge>
                                {!alert.isRead && (
                                  <Badge variant="default" className="bg-blue-500">
                                    New
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">
                                {alert.message}
                              </p>
                              <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                                <span>{formatTimestamp(alert.timestamp)}</span>
                                {alert.sourceType && (
                                  <span>Source: {alert.sourceType}</span>
                                )}
                              </div>
                            </div>
                          </div>
                          {!alert.isRead && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                markAlertAsRead(alert.id)
                              }}
                            >
                              Mark as Read
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Activity Feed</CardTitle>
              <CardDescription>
                Recent monitoring and scanning activities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] w-full">
                <div className="space-y-4">
                  <div className="text-center py-8 text-muted-foreground">
                    Activity feed will be populated as monitoring events occur.
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monitors" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monitor Status</CardTitle>
              <CardDescription>
                Real-time status of all active monitors
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] w-full">
                <div className="space-y-4">
                  <div className="text-center py-8 text-muted-foreground">
                    Monitor status will be displayed here when monitors are active.
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}