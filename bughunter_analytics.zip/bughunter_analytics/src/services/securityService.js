import { supabase } from '../lib/supabase';

export const securityService = {
  // KPI and Metrics
  async getSystemMetrics() {
    try {
      const { data, error } = await supabase?.from('system_metrics')?.select('*')?.order('recorded_at', { ascending: false })?.limit(10);

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching system metrics:', error);
      throw error;
    }
  },

  // Activities Feed
  async getRecentActivities(limit = 20) {
    try {
      const { data, error } = await supabase?.from('activities')?.select(`
          *,
          target:targets(domain),
          user:user_profiles(full_name)
        `)?.order('created_at', { ascending: false })?.limit(limit);

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching activities:', error);
      throw error;
    }
  },

  // Vulnerabilities
  async getVulnerabilities(filters = {}) {
    try {
      let query = supabase?.from('vulnerabilities')?.select(`
          *,
          target:targets(domain),
          subdomain:subdomains(subdomain),
          discovered_by_user:user_profiles!discovered_by(full_name)
        `);

      if (filters?.severity) {
        query = query?.eq('severity', filters?.severity);
      }
      
      if (filters?.status) {
        query = query?.eq('status', filters?.status);
      }

      if (filters?.target_id) {
        query = query?.eq('target_id', filters?.target_id);
      }

      const { data, error } = await query?.order('discovered_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching vulnerabilities:', error);
      throw error;
    }
  },

  async createVulnerability(vulnerabilityData) {
    try {
      const { data, error } = await supabase?.from('vulnerabilities')?.insert([{
          ...vulnerabilityData,
          discovered_by: (await supabase?.auth?.getUser())?.data?.user?.id
        }])?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating vulnerability:', error);
      throw error;
    }
  },

  async updateVulnerabilityStatus(id, status) {
    try {
      const updateData = { status };
      if (status === 'resolved') {
        updateData.resolved_at = new Date()?.toISOString();
      }

      const { data, error } = await supabase?.from('vulnerabilities')?.update(updateData)?.eq('id', id)?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating vulnerability status:', error);
      throw error;
    }
  },

  // Subdomains
  async getSubdomains(targetId = null) {
    try {
      let query = supabase?.from('subdomains')?.select(`
          *,
          target:targets(domain)
        `);

      if (targetId) {
        query = query?.eq('target_id', targetId);
      }

      const { data, error } = await query?.order('discovered_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching subdomains:', error);
      throw error;
    }
  },

  async createSubdomain(subdomainData) {
    try {
      const { data, error } = await supabase?.from('subdomains')?.insert([subdomainData])?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating subdomain:', error);
      throw error;
    }
  },

  // Targets
  async getTargets() {
    try {
      const { data, error } = await supabase?.from('targets')?.select(`
          *,
          owner:user_profiles(full_name),
          _count_subdomains:subdomains(count),
          _count_vulnerabilities:vulnerabilities(count)
        `)?.order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching targets:', error);
      throw error;
    }
  },

  async createTarget(targetData) {
    try {
      const { data, error } = await supabase?.from('targets')?.insert([{
          ...targetData,
          owner_id: (await supabase?.auth?.getUser())?.data?.user?.id
        }])?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating target:', error);
      throw error;
    }
  },

  // Scan Sessions
  async getScanSessions(targetId = null) {
    try {
      let query = supabase?.from('scan_sessions')?.select(`
          *,
          target:targets(domain),
          started_by_user:user_profiles!started_by(full_name)
        `);

      if (targetId) {
        query = query?.eq('target_id', targetId);
      }

      const { data, error } = await query?.order('started_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching scan sessions:', error);
      throw error;
    }
  },

  async createScanSession(scanData) {
    try {
      const { data, error } = await supabase?.from('scan_sessions')?.insert([{
          ...scanData,
          started_by: (await supabase?.auth?.getUser())?.data?.user?.id
        }])?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating scan session:', error);
      throw error;
    }
  },

  // Real-time subscriptions
  subscribeToActivities(callback) {
    const subscription = supabase?.channel('activities')?.on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'activities'
      }, callback)?.subscribe();

    return () => supabase?.removeChannel(subscription);
  },

  subscribeToVulnerabilities(callback) {
    const subscription = supabase?.channel('vulnerabilities')?.on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'vulnerabilities'
      }, callback)?.subscribe();

    return () => supabase?.removeChannel(subscription);
  },

  subscribeToScanSessions(callback) {
    const subscription = supabase?.channel('scan_sessions')?.on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'scan_sessions'
      }, callback)?.subscribe();

    return () => supabase?.removeChannel(subscription);
  },

  // Dashboard aggregations
  async getDashboardStats() {
    try {
      const [metricsResult, activitiesResult, vulnerabilitiesResult, subdomainsResult] = await Promise.all([
        this.getSystemMetrics(),
        this.getRecentActivities(10),
        this.getVulnerabilities(),
        this.getSubdomains()
      ]);

      const vulnerabilityStats = {
        total: vulnerabilitiesResult?.length || 0,
        critical: vulnerabilitiesResult?.filter(v => v?.severity === 'critical')?.length || 0,
        high: vulnerabilitiesResult?.filter(v => v?.severity === 'high')?.length || 0,
        medium: vulnerabilitiesResult?.filter(v => v?.severity === 'medium')?.length || 0,
        low: vulnerabilitiesResult?.filter(v => v?.severity === 'low')?.length || 0,
        open: vulnerabilitiesResult?.filter(v => v?.status === 'open')?.length || 0,
        resolved: vulnerabilitiesResult?.filter(v => v?.status === 'resolved')?.length || 0
      };

      const subdomainStats = {
        total: subdomainsResult?.length || 0,
        active: subdomainsResult?.filter(s => s?.status === 'active')?.length || 0,
        inactive: subdomainsResult?.filter(s => s?.status === 'inactive')?.length || 0,
        withSsl: subdomainsResult?.filter(s => s?.ssl_enabled)?.length || 0
      };

      return {
        metrics: metricsResult,
        activities: activitiesResult,
        vulnerabilities: vulnerabilityStats,
        subdomains: subdomainStats,
        recentVulnerabilities: vulnerabilitiesResult?.slice(0, 10) || [],
        recentSubdomains: subdomainsResult?.slice(0, 10) || []
      };
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      throw error;
    }
  }
};