import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import { securityService } from '../../../services/securityService';

const ActivityFeed = ({ activities: initialActivities }) => {
  const [activities, setActivities] = useState(initialActivities || []);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(!initialActivities);

  useEffect(() => {
    if (!initialActivities) {
      let isMounted = true;
      const loadActivities = async () => {
        try {
          const data = await securityService?.getRecentActivities();
          if (isMounted) {
            setActivities(data);
          }
        } catch (error) {
          console.error('Error loading activities:', error);
        } finally {
          if (isMounted) {
            setLoading(false);
          }
        }
      };
      
      loadActivities();

      return () => {
        isMounted = false;
      };
    } else {
      setActivities(initialActivities);
      setLoading(false);
    }
  }, [initialActivities]);

  // Subscribe to real-time updates
  useEffect(() => {
    const unsubscribe = securityService?.subscribeToActivities((payload) => {
      if (payload?.eventType === 'INSERT') {
        setActivities(prev => [payload?.new, ...prev?.slice(0, 19)]);
      }
    });

    return unsubscribe;
  }, []);

  const getActivityIcon = (type) => {
    switch (type) {
      case 'vulnerability': return 'AlertTriangle';
      case 'subdomain': return 'Globe';
      case 'scan': return 'Search';
      case 'alert': return 'Bell';
      default: return 'Activity';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-error';
      case 'high': return 'text-warning';
      case 'medium': return 'text-accent';
      case 'low': return 'text-success';
      case 'warning': return 'text-warning';
      case 'success': return 'text-success';
      default: return 'text-muted-foreground';
    }
  };

  const getSeverityBg = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-error/10 border-error/20';
      case 'high': return 'bg-warning/10 border-warning/20';
      case 'medium': return 'bg-accent/10 border-accent/20';
      case 'low': return 'bg-success/10 border-success/20';
      case 'warning': return 'bg-warning/10 border-warning/20';
      case 'success': return 'bg-success/10 border-success/20';
      default: return 'bg-muted/10 border-border';
    }
  };

  const filteredActivities = filter === 'all' 
    ? activities 
    : activities?.filter(activity => activity?.type === filter);

  const filterOptions = [
    { value: 'all', label: 'All Activities', icon: 'Activity' },
    { value: 'vulnerability', label: 'Vulnerabilities', icon: 'AlertTriangle' },
    { value: 'subdomain', label: 'Subdomains', icon: 'Globe' },
    { value: 'scan', label: 'Scans', icon: 'Search' },
    { value: 'alert', label: 'Alerts', icon: 'Bell' }
  ];

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const created = new Date(timestamp);
    const diff = now - created;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return created?.toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            {[...Array(5)]?.map((_, i) => (
              <div key={i} className="h-16 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Activity" size={18} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Real-time Activity</h3>
            <p className="text-sm text-muted-foreground">Live security intelligence feed</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-success rounded-full pulse-animation"></div>
          <span className="text-xs text-success font-medium">Live</span>
        </div>
      </div>
      <div className="flex items-center space-x-2 mb-4 overflow-x-auto">
        {filterOptions?.map((option) => (
          <button
            key={option?.value}
            onClick={() => setFilter(option?.value)}
            className={`flex items-center space-x-2 px-3 py-1 rounded-md text-xs font-medium transition-all duration-150 whitespace-nowrap ${
              filter === option?.value
                ? 'bg-primary/20 text-primary border border-primary/30' :'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <Icon name={option?.icon} size={14} />
            <span>{option?.label}</span>
          </button>
        ))}
      </div>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {filteredActivities?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Activity" size={32} className="text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No activities found</p>
          </div>
        ) : (
          filteredActivities?.map((activity) => (
            <div
              key={activity?.id}
              className={`p-4 rounded-lg border transition-all duration-150 hover:border-primary/30 ${getSeverityBg(activity?.severity)}`}
            >
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-lg bg-background/50 flex items-center justify-center ${getSeverityColor(activity?.severity)}`}>
                  <Icon name={getActivityIcon(activity?.type)} size={16} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-medium text-foreground truncate">{activity?.title}</h4>
                    <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">
                      {formatTimeAgo(activity?.created_at)}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="Globe" size={12} className="text-muted-foreground" />
                    <span className="text-xs font-mono text-muted-foreground">
                      {activity?.target?.domain || 'System'}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getSeverityBg(activity?.severity)} ${getSeverityColor(activity?.severity)}`}>
                      {activity?.severity}
                    </span>
                  </div>
                  
                  <p className="text-xs text-muted-foreground">{activity?.description}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      <div className="mt-4 pt-4 border-t border-border">
        <button className="w-full flex items-center justify-center space-x-2 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors duration-150">
          <Icon name="MoreHorizontal" size={16} />
          <span>View all activities</span>
        </button>
      </div>
    </div>
  );
};

export default ActivityFeed;