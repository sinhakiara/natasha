import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import { securityService } from '../../../services/securityService';

const TopTargetsTable = () => {
  const [targets, setTargets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    const loadTargets = async () => {
      try {
        const data = await securityService?.getTargets();
        if (isMounted) {
          setTargets(data?.slice(0, 10) || []); // Top 10 targets
        }
      } catch (error) {
        console.error('Error loading targets:', error);
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadTargets();

    return () => {
      isMounted = false;
    };
  }, []);

  const getRiskLevel = (vulnerabilityCount) => {
    if (vulnerabilityCount >= 10) return { level: 'High', color: 'text-error' };
    if (vulnerabilityCount >= 5) return { level: 'Medium', color: 'text-warning' };
    if (vulnerabilityCount > 0) return { level: 'Low', color: 'text-accent' };
    return { level: 'None', color: 'text-success' };
  };

  if (loading) {
    return (
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            {[...Array(5)]?.map((_, i) => (
              <div key={i} className="h-12 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="Target" size={18} className="text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Target Overview</h3>
          <p className="text-sm text-muted-foreground">Active reconnaissance targets and their status</p>
        </div>
      </div>
      {targets?.length === 0 ? (
        <div className="text-center py-8">
          <Icon name="Target" size={32} className="text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">No targets configured</p>
          <button className="mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
            Add Target
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Domain</th>
                <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Subdomains</th>
                <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Vulnerabilities</th>
                <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Risk Level</th>
                <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Last Scan</th>
                <th className="text-left py-2 px-4 text-sm font-medium text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {targets?.map((target, index) => {
                const vulnerabilityCount = target?._count_vulnerabilities?.[0]?.count || 0;
                const subdomainCount = target?._count_subdomains?.[0]?.count || 0;
                const risk = getRiskLevel(vulnerabilityCount);
                
                return (
                  <tr key={target?.id} className={`border-b border-border/50 hover:bg-muted/30 transition-colors ${index % 2 === 0 ? 'bg-background' : 'bg-muted/5'}`}>
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        <Icon name="Globe" size={14} className="text-muted-foreground" />
                        <span className="font-mono text-sm text-foreground">{target?.domain}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-foreground">{subdomainCount}</span>
                        <Icon name="ExternalLink" size={12} className="text-muted-foreground" />
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-foreground">{vulnerabilityCount}</span>
                        {vulnerabilityCount > 0 && (
                          <Icon name="AlertTriangle" size={12} className="text-warning" />
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-sm font-medium ${risk?.color}`}>
                        {risk?.level}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-muted-foreground">
                        {target?.updated_at ? new Date(target.updated_at)?.toLocaleDateString() : 'Never'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        target?.is_active
                          ? 'bg-success/20 text-success' :'bg-muted text-muted-foreground'
                      }`}>
                        {target?.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <div className="mt-4 pt-4 border-t border-border">
        <button className="w-full flex items-center justify-center space-x-2 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors duration-150">
          <Icon name="Plus" size={16} />
          <span>Add New Target</span>
        </button>
      </div>
    </div>
  );
};

export default TopTargetsTable;