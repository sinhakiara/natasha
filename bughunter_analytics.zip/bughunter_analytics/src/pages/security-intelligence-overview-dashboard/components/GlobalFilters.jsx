import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const GlobalFilters = ({ onFiltersChange }) => {
  const [selectedTargets, setSelectedTargets] = useState(['target-alpha.com']);
  const [timeRange, setTimeRange] = useState('7d');
  const [severityThreshold, setSeverityThreshold] = useState('all');
  const [autoRefresh, setAutoRefresh] = useState('1m');
  const [isAutoRefreshEnabled, setIsAutoRefreshEnabled] = useState(true);

  const targetOptions = [
    { value: 'target-alpha.com', label: 'target-alpha.com' },
    { value: 'beta-corp.net', label: 'beta-corp.net' },
    { value: 'gamma-systems.org', label: 'gamma-systems.org' },
    { value: 'delta-tech.io', label: 'delta-tech.io' },
    { value: 'epsilon-labs.com', label: 'epsilon-labs.com' }
  ];

  const timeRangeOptions = [
    { value: '24h', label: 'Last 24 hours' },
    { value: '7d', label: 'Last 7 days' },
    { value: '30d', label: 'Last 30 days' },
    { value: '90d', label: 'Last 90 days' },
    { value: 'custom', label: 'Custom range' }
  ];

  const severityOptions = [
    { value: 'all', label: 'All Severities' },
    { value: 'critical', label: 'Critical & Above' },
    { value: 'high', label: 'High & Above' },
    { value: 'medium', label: 'Medium & Above' },
    { value: 'low', label: 'Low & Above' }
  ];

  const refreshIntervals = [
    { value: '30s', label: '30 seconds' },
    { value: '1m', label: '1 minute' },
    { value: '5m', label: '5 minutes' },
    { value: '15m', label: '15 minutes' },
    { value: 'manual', label: 'Manual only' }
  ];

  const handleFiltersUpdate = () => {
    const filters = {
      targets: selectedTargets,
      timeRange,
      severityThreshold,
      autoRefresh: isAutoRefreshEnabled ? autoRefresh : 'manual'
    };
    
    if (onFiltersChange) {
      onFiltersChange(filters);
    }
  };

  const handleTargetChange = (value) => {
    setSelectedTargets(Array.isArray(value) ? value : [value]);
    handleFiltersUpdate();
  };

  const handleTimeRangeChange = (value) => {
    setTimeRange(value);
    handleFiltersUpdate();
  };

  const handleSeverityChange = (value) => {
    setSeverityThreshold(value);
    handleFiltersUpdate();
  };

  const handleAutoRefreshToggle = () => {
    setIsAutoRefreshEnabled(!isAutoRefreshEnabled);
    handleFiltersUpdate();
  };

  const handleRefreshIntervalChange = (value) => {
    setAutoRefresh(value);
    if (value === 'manual') {
      setIsAutoRefreshEnabled(false);
    } else {
      setIsAutoRefreshEnabled(true);
    }
    handleFiltersUpdate();
  };

  const getSeverityColor = () => {
    switch (severityThreshold) {
      case 'critical': return 'text-error';
      case 'high': return 'text-warning';
      case 'medium': return 'text-accent';
      case 'low': return 'text-success';
      default: return 'text-primary';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        {/* Left side - Main filters */}
        <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          {/* Target Selector */}
          <div className="min-w-0 flex-1 sm:flex-none sm:w-64">
            <Select
              label="Targets"
              options={targetOptions}
              value={selectedTargets}
              onChange={handleTargetChange}
              multiple
              searchable
              placeholder="Select targets..."
              className="text-sm"
            />
          </div>

          {/* Time Range */}
          <div className="min-w-0 flex-1 sm:flex-none sm:w-48">
            <Select
              label="Time Range"
              options={timeRangeOptions}
              value={timeRange}
              onChange={handleTimeRangeChange}
              className="text-sm"
            />
          </div>

          {/* Severity Threshold */}
          <div className="min-w-0 flex-1 sm:flex-none sm:w-48">
            <Select
              label="Severity Filter"
              options={severityOptions}
              value={severityThreshold}
              onChange={handleSeverityChange}
              className="text-sm"
            />
          </div>
        </div>

        {/* Right side - Auto-refresh and actions */}
        <div className="flex items-center space-x-4">
          {/* Auto-refresh controls */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <button
                onClick={handleAutoRefreshToggle}
                className={`w-10 h-6 rounded-full transition-all duration-200 ${
                  isAutoRefreshEnabled 
                    ? 'bg-primary' :'bg-muted'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${
                  isAutoRefreshEnabled ? 'translate-x-5' : 'translate-x-1'
                }`} />
              </button>
              <span className="text-sm text-muted-foreground">Auto-refresh</span>
            </div>

            {isAutoRefreshEnabled && (
              <div className="min-w-0 w-32">
                <Select
                  options={refreshIntervals?.filter(option => option?.value !== 'manual')}
                  value={autoRefresh}
                  onChange={handleRefreshIntervalChange}
                  className="text-sm"
                />
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              iconName="RefreshCw"
              className="h-9 px-3"
              onClick={() => window.location?.reload()}
            >
              Refresh
            </Button>
            
            <Button
              variant="outline"
              iconName="Download"
              className="h-9 px-3"
            >
              Export
            </Button>
          </div>
        </div>
      </div>
      {/* Filter summary */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-muted-foreground">Active filters:</span>
          
          <div className="flex items-center space-x-1 px-2 py-1 bg-primary/10 text-primary rounded-full">
            <Icon name="Target" size={12} />
            <span className="text-xs font-medium">{selectedTargets?.length} target{selectedTargets?.length !== 1 ? 's' : ''}</span>
          </div>
          
          <div className="flex items-center space-x-1 px-2 py-1 bg-accent/10 text-accent rounded-full">
            <Icon name="Clock" size={12} />
            <span className="text-xs font-medium">{timeRangeOptions?.find(opt => opt?.value === timeRange)?.label}</span>
          </div>
          
          {severityThreshold !== 'all' && (
            <div className={`flex items-center space-x-1 px-2 py-1 bg-current/10 rounded-full ${getSeverityColor()}`}>
              <Icon name="AlertTriangle" size={12} />
              <span className="text-xs font-medium">{severityOptions?.find(opt => opt?.value === severityThreshold)?.label}</span>
            </div>
          )}
          
          {isAutoRefreshEnabled && (
            <div className="flex items-center space-x-1 px-2 py-1 bg-success/10 text-success rounded-full">
              <Icon name="RefreshCw" size={12} />
              <span className="text-xs font-medium">Auto {refreshIntervals?.find(opt => opt?.value === autoRefresh)?.label}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GlobalFilters;