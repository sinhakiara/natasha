import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import KPICard from './components/KPICard';
import VulnerabilityTimeline from './components/VulnerabilityTimeline';
import ActivityFeed from './components/ActivityFeed';
import VulnerabilityDistribution from './components/VulnerabilityDistribution';
import TopTargetsTable from './components/TopTargetsTable';
import GlobalFilters from './components/GlobalFilters';
import { securityService } from '../../services/securityService';
import { useAuth } from '../../contexts/AuthContext';

const SecurityIntelligenceOverviewDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const [filters, setFilters] = useState({
    targets: ['target-alpha.com'],
    timeRange: '7d',
    severityThreshold: 'all',
    autoRefresh: '1m'
  });
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load dashboard data
  useEffect(() => {
    if (authLoading) return;

    let isMounted = true;
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        const data = await securityService?.getDashboardStats();
        if (isMounted) {
          setDashboardData(data);
          setError(null);
        }
      } catch (err) {
        if (isMounted) {
          setError(err?.message || 'Failed to load dashboard data');
          if (err?.message?.includes('Failed to fetch') || 
              err?.message?.includes('NetworkError') ||
              err?.name === 'TypeError' && err?.message?.includes('fetch')) {
            setError('Cannot connect to database. Your Supabase project may be paused or deleted. Please visit your Supabase dashboard to check project status.');
          }
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadDashboardData();

    return () => {
      isMounted = false;
    };
  }, [authLoading]);

  // Auto-refresh logic
  useEffect(() => {
    if (filters?.autoRefresh !== 'manual') {
      const interval = setInterval(() => {
        setLastUpdated(new Date());
      }, getRefreshInterval(filters?.autoRefresh));

      return () => clearInterval(interval);
    }
  }, [filters?.autoRefresh]);

  const getRefreshInterval = (interval) => {
    switch (interval) {
      case '30s': return 30000;
      case '1m': return 60000;
      case '5m': return 300000;
      case '15m': return 900000;
      default: return 60000;
    }
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
    setLastUpdated(new Date());
  };

  // Transform metrics data into KPI format
  const getKpiData = () => {
    if (!dashboardData?.metrics) return [];

    const metricsMap = dashboardData?.metrics?.reduce((acc, metric) => {
      acc[metric?.metric_name] = metric;
      return acc;
    }, {});

    return [
      {
        title: 'Total Vulnerabilities',
        value: dashboardData?.vulnerabilities?.total?.toString() || '0',
        change: metricsMap?.total_vulnerabilities?.metric_change ? `+${metricsMap?.total_vulnerabilities?.metric_change}%` : '+0%',
        changeType: 'negative',
        icon: 'AlertTriangle',
        color: 'error',
        sparklineData: metricsMap?.total_vulnerabilities?.sparkline_data || [0]
      },
      {
        title: 'Active Subdomains',
        value: dashboardData?.subdomains?.active?.toLocaleString() || '0',
        change: metricsMap?.active_subdomains?.metric_change ? `+${metricsMap?.active_subdomains?.metric_change}%` : '+0%',
        changeType: 'positive',
        icon: 'Globe',
        color: 'primary',
        sparklineData: metricsMap?.active_subdomains?.sparkline_data || [0]
      },
      {
        title: 'Critical Findings',
        value: dashboardData?.vulnerabilities?.critical?.toString() || '0',
        change: metricsMap?.critical_findings?.metric_change ? `+${metricsMap?.critical_findings?.metric_change}` : '+0',
        changeType: 'negative',
        icon: 'Shield',
        color: 'error',
        sparklineData: metricsMap?.critical_findings?.sparkline_data || [0]
      },
      {
        title: 'Scan Completion',
        value: metricsMap?.scan_completion?.metric_value ? `${metricsMap?.scan_completion?.metric_value}%` : '0%',
        change: metricsMap?.scan_completion?.metric_change ? `+${metricsMap?.scan_completion?.metric_change}%` : '+0%',
        changeType: 'positive',
        icon: 'CheckCircle',
        color: 'success',
        sparklineData: metricsMap?.scan_completion?.sparkline_data || [0]
      },
      {
        title: 'False Positive Rate',
        value: metricsMap?.false_positive_rate?.metric_value ? `${metricsMap?.false_positive_rate?.metric_value}%` : '0%',
        change: metricsMap?.false_positive_rate?.metric_change ? `${metricsMap?.false_positive_rate?.metric_change}%` : '0%',
        changeType: 'positive',
        icon: 'XCircle',
        color: 'warning',
        sparklineData: metricsMap?.false_positive_rate?.sparkline_data || [0]
      },
      {
        title: 'Avg Response Time',
        value: metricsMap?.avg_response_time?.metric_value ? `${metricsMap?.avg_response_time?.metric_value}s` : '0s',
        change: metricsMap?.avg_response_time?.metric_change ? `${metricsMap?.avg_response_time?.metric_change}s` : '0s',
        changeType: 'positive',
        icon: 'Zap',
        color: 'accent',
        sparklineData: metricsMap?.avg_response_time?.sparkline_data || [0]
      }
    ];
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="bg-error/10 border border-error/20 rounded-lg p-6 text-center">
              <h2 className="text-xl font-semibold text-error mb-2">Error Loading Dashboard</h2>
              <p className="text-muted-foreground mb-4">{error}</p>
              <button 
                onClick={() => window.location?.reload()} 
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  const kpiData = getKpiData();

  return (
    <>
      <Helmet>
        <title>Security Intelligence Overview Dashboard - BugHunter Analytics</title>
        <meta name="description" content="Comprehensive security intelligence dashboard providing real-time vulnerability monitoring, reconnaissance analytics, and threat intelligence for bug bounty hunters and security researchers." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-foreground mb-2">
                    Security Intelligence Overview
                  </h1>
                  <p className="text-muted-foreground">
                    Comprehensive reconnaissance analytics and vulnerability monitoring across all active targets
                  </p>
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <span>Last updated:</span>
                  <span className="font-medium text-foreground">
                    {lastUpdated?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
              </div>
            </div>

            {/* Global Filters */}
            <GlobalFilters onFiltersChange={handleFiltersChange} />

            {/* KPI Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6 mb-8">
              {kpiData?.map((kpi, index) => (
                <KPICard
                  key={index}
                  title={kpi?.title}
                  value={kpi?.value}
                  change={kpi?.change}
                  changeType={kpi?.changeType}
                  icon={kpi?.icon}
                  color={kpi?.color}
                  sparklineData={kpi?.sparklineData}
                />
              ))}
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
              {/* Vulnerability Timeline - Takes 2 columns on xl screens */}
              <div className="xl:col-span-2">
                <VulnerabilityTimeline vulnerabilities={dashboardData?.recentVulnerabilities || []} />
              </div>
              
              {/* Activity Feed - Takes 1 column on xl screens */}
              <div className="xl:col-span-1">
                <ActivityFeed activities={dashboardData?.activities || []} />
              </div>
            </div>

            {/* Bottom Section Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
              {/* Vulnerability Distribution */}
              <div>
                <VulnerabilityDistribution vulnerabilityStats={dashboardData?.vulnerabilities} />
              </div>
              
              {/* Top Targets Table */}
              <div>
                <TopTargetsTable />
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default SecurityIntelligenceOverviewDashboard;