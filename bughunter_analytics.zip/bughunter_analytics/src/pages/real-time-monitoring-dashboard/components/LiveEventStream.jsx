import React, { useState, useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';

const LiveEventStream = ({ events: propEvents, isLive }) => {
  const [events, setEvents] = useState(propEvents || []);
  const [filter, setFilter] = useState('all');
  const [autoScroll, setAutoScroll] = useState(true);
  const streamRef = useRef(null);
  const [newEventCount, setNewEventCount] = useState(0);

  // Update events when props change
  useEffect(() => {
    if (propEvents) {
      setEvents(propEvents);
    }
  }, [propEvents]);

  // Auto-scroll to bottom when new events arrive
  useEffect(() => {
    if (autoScroll && streamRef?.current && isLive) {
      streamRef.current.scrollTop = streamRef?.current?.scrollHeight;
    }
  }, [events, autoScroll, isLive]);

  // Track new events when not auto-scrolling
  useEffect(() => {
    if (!autoScroll && propEvents) {
      setNewEventCount(prev => prev + 1);
    } else {
      setNewEventCount(0);
    }
  }, [propEvents, autoScroll]);

  const handleScroll = () => {
    if (streamRef?.current) {
      const { scrollTop, scrollHeight, clientHeight } = streamRef?.current;
      const isAtBottom = scrollTop + clientHeight >= scrollHeight - 10;
      setAutoScroll(isAtBottom);
      
      if (isAtBottom) {
        setNewEventCount(0);
      }
    }
  };

  const scrollToBottom = () => {
    setAutoScroll(true);
    setNewEventCount(0);
  };

  const getEventIcon = (type, severity) => {
    switch (type) {
      case 'vulnerability':
        return severity === 'critical' ? 'AlertTriangle' : 'Shield';
      case 'subdomain':
        return 'Globe';
      case 'scan':
        return 'Search';
      case 'alert':
        return 'Bell';
      case 'system':
        return 'Settings';
      default:
        return 'Activity';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-error';
      case 'high': return 'text-warning';
      case 'medium': return 'text-accent';
      case 'low': return 'text-success';
      case 'info': return 'text-primary';
      default: return 'text-muted-foreground';
    }
  };

  const getSeverityBg = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-error/10 border-error/20';
      case 'high': return 'bg-warning/10 border-warning/20';
      case 'medium': return 'bg-accent/10 border-accent/20';
      case 'low': return 'bg-success/10 border-success/20';
      case 'info': return 'bg-primary/10 border-primary/20';
      default: return 'bg-muted/10 border-border';
    }
  };

  const filteredEvents = filter === 'all' 
    ? events 
    : events?.filter(event => event?.type === filter);

  const filterOptions = [
    { value: 'all', label: 'All Events', icon: 'Activity' },
    { value: 'vulnerability', label: 'Vulnerabilities', icon: 'AlertTriangle' },
    { value: 'subdomain', label: 'Subdomains', icon: 'Globe' },
    { value: 'scan', label: 'Scans', icon: 'Search' },
    { value: 'alert', label: 'Alerts', icon: 'Bell' },
    { value: 'system', label: 'System', icon: 'Settings' }
  ];

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp)?.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const created = new Date(timestamp);
    const diff = now - created;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (seconds < 60) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return created?.toLocaleDateString();
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Activity" size={18} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Live Event Stream</h3>
            <p className="text-sm text-muted-foreground">Real-time security events and system activities</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1">
            <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-success animate-pulse' : 'bg-muted-foreground'}`} />
            <span className={`text-xs font-medium ${isLive ? 'text-success' : 'text-muted-foreground'}`}>
              {isLive ? 'LIVE' : 'PAUSED'}
            </span>
          </div>
          
          <div className="text-sm text-muted-foreground">
            {filteredEvents?.length || 0} events
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center space-x-2 mb-4 overflow-x-auto">
        {filterOptions?.map((option) => (
          <button
            key={option?.value}
            onClick={() => setFilter(option?.value)}
            className={`flex items-center space-x-2 px-3 py-1 rounded-md text-xs font-medium transition-all duration-150 whitespace-nowrap ${
              filter === option?.value
                ? 'bg-primary/20 text-primary border border-primary/30' :'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <Icon name={option?.icon} size={14} />
            <span>{option?.label}</span>
          </button>
        ))}
      </div>

      {/* New Events Notification */}
      {newEventCount > 0 && (
        <div className="mb-4">
          <button
            onClick={scrollToBottom}
            className="w-full flex items-center justify-center space-x-2 py-2 bg-primary/10 text-primary border border-primary/20 rounded-lg hover:bg-primary/20 transition-colors"
          >
            <Icon name="ArrowDown" size={16} />
            <span className="text-sm font-medium">
              {newEventCount} new event{newEventCount !== 1 ? 's' : ''} - Click to scroll down
            </span>
          </button>
        </div>
      )}

      {/* Event Stream */}
      <div 
        ref={streamRef}
        onScroll={handleScroll}
        className="space-y-2 max-h-96 overflow-y-auto scroll-smooth"
      >
        {filteredEvents?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Activity" size={32} className="text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {events?.length === 0 ? 'No events detected yet' : 'No events match your current filter'}
            </p>
          </div>
        ) : (
          filteredEvents?.map((event, index) => (
            <div
              key={`${event?.id}-${index}`}
              className={`p-3 rounded-lg border transition-all duration-150 hover:border-primary/30 ${getSeverityBg(event?.severity)} ${
                index === 0 && isLive ? 'animate-pulse' : ''
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className={`w-6 h-6 rounded-lg bg-background/50 flex items-center justify-center ${getSeverityColor(event?.severity)}`}>
                  <Icon name={getEventIcon(event?.type, event?.severity)} size={14} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-medium text-foreground truncate">{event?.title}</h4>
                    <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">
                      {formatTimestamp(event?.created_at)}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 mb-1">
                    {event?.target?.domain && (
                      <>
                        <Icon name="Globe" size={10} className="text-muted-foreground" />
                        <span className="text-xs font-mono text-muted-foreground">{event?.target?.domain}</span>
                      </>
                    )}
                    <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${getSeverityBg(event?.severity)} ${getSeverityColor(event?.severity)}`}>
                      {event?.severity}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {formatTimeAgo(event?.created_at)}
                    </span>
                  </div>
                  
                  {event?.description && (
                    <p className="text-xs text-muted-foreground truncate">{event?.description}</p>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <label className="flex items-center space-x-2 text-sm text-muted-foreground">
            <input
              type="checkbox"
              checked={autoScroll}
              onChange={(e) => setAutoScroll(e?.target?.checked)}
              className="rounded border-border"
            />
            <span>Auto-scroll to new events</span>
          </label>
          
          <button
            onClick={() => setEvents([])}
            className="flex items-center space-x-1 px-3 py-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <Icon name="Trash2" size={14} />
            <span>Clear events</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default LiveEventStream;