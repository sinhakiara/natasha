import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const NetworkActivityHeatmap = () => {
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [activityData, setActivityData] = useState([]);
  const [timeRange, setTimeRange] = useState('1h');
  const [zoomLevel, setZoomLevel] = useState(1);

  const mockActivityData = [
    {
      id: 1,
      country: 'United States',
      city: 'San Francisco',
      lat: 37.7749,
      lng: -122.4194,
      activity: 'high',
      count: 156,
      type: 'subdomain_discovery',
      lastSeen: new Date(Date.now() - 300000)
    },
    {
      id: 2,
      country: 'United Kingdom',
      city: 'London',
      lat: 51.5074,
      lng: -0.1278,
      activity: 'medium',
      count: 89,
      type: 'vulnerability_scan',
      lastSeen: new Date(Date.now() - 600000)
    },
    {
      id: 3,
      country: 'Germany',
      city: 'Frankfurt',
      lat: 50.1109,
      lng: 8.6821,
      activity: 'high',
      count: 203,
      type: 'port_scan',
      lastSeen: new Date(Date.now() - 120000)
    },
    {
      id: 4,
      country: 'Japan',
      city: 'Tokyo',
      lat: 35.6762,
      lng: 139.6503,
      activity: 'low',
      count: 34,
      type: 'ssl_check',
      lastSeen: new Date(Date.now() - 900000)
    },
    {
      id: 5,
      country: 'Australia',
      city: 'Sydney',
      lat: -33.8688,
      lng: 151.2093,
      activity: 'medium',
      count: 67,
      type: 'dns_lookup',
      lastSeen: new Date(Date.now() - 450000)
    },
    {
      id: 6,
      country: 'Canada',
      city: 'Toronto',
      lat: 43.6532,
      lng: -79.3832,
      activity: 'high',
      count: 178,
      type: 'reconnaissance',
      lastSeen: new Date(Date.now() - 180000)
    }
  ];

  useEffect(() => {
    setActivityData(mockActivityData);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActivityData(prev => prev?.map(item => ({
        ...item,
        count: item?.count + Math.floor(Math.random() * 10),
        lastSeen: Math.random() > 0.7 ? new Date() : item?.lastSeen
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getActivityColor = (activity) => {
    switch (activity) {
      case 'high': return 'bg-error';
      case 'medium': return 'bg-warning';
      case 'low': return 'bg-success';
      default: return 'bg-muted';
    }
  };

  const getActivitySize = (activity) => {
    switch (activity) {
      case 'high': return 'w-4 h-4';
      case 'medium': return 'w-3 h-3';
      case 'low': return 'w-2 h-2';
      default: return 'w-2 h-2';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'subdomain_discovery': return 'Globe';
      case 'vulnerability_scan': return 'Shield';
      case 'port_scan': return 'Wifi';
      case 'ssl_check': return 'Lock';
      case 'dns_lookup': return 'Zap';
      case 'reconnaissance': return 'Search';
      default: return 'Activity';
    }
  };

  const handleRegionClick = (region) => {
    setSelectedRegion(region);
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(3, prev + 0.5));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(0.5, prev - 0.5));
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Icon name="Map" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Network Activity Heatmap</h3>
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Time Range Selector */}
            <div className="flex items-center space-x-1 bg-muted/10 rounded-lg p-1">
              {['1h', '6h', '24h', '7d']?.map((range) => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-2 py-1 rounded text-xs transition-colors duration-150 ${
                    timeRange === range
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center space-x-1">
              <button
                onClick={handleZoomOut}
                className="p-1 hover:bg-muted/20 rounded transition-colors duration-150"
                disabled={zoomLevel <= 0.5}
              >
                <Icon name="ZoomOut" size={16} className="text-muted-foreground" />
              </button>
              <span className="text-xs text-muted-foreground px-2">{zoomLevel}x</span>
              <button
                onClick={handleZoomIn}
                className="p-1 hover:bg-muted/20 rounded transition-colors duration-150"
                disabled={zoomLevel >= 3}
              >
                <Icon name="ZoomIn" size={16} className="text-muted-foreground" />
              </button>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center space-x-6 text-xs">
          <div className="flex items-center space-x-2">
            <span className="text-muted-foreground">Activity Level:</span>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-muted-foreground">Low</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 bg-warning rounded-full"></div>
                <span className="text-muted-foreground">Medium</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-4 h-4 bg-error rounded-full"></div>
                <span className="text-muted-foreground">High</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Map Container */}
      <div className="relative h-96 bg-slate-900 overflow-hidden">
        {/* World Map Background */}
        <div 
          className="absolute inset-0 bg-slate-800 opacity-20"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23334155' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            transform: `scale(${zoomLevel})`
          }}
        />

        {/* Activity Points */}
        <div className="absolute inset-0 p-8">
          {activityData?.map((item, index) => (
            <div
              key={item?.id}
              className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 hover:scale-125"
              style={{
                left: `${20 + (index * 12)}%`,
                top: `${30 + (index % 2 === 0 ? 10 : -10) + Math.sin(index) * 20}%`,
                transform: `scale(${zoomLevel})`
              }}
              onClick={() => handleRegionClick(item)}
            >
              <div className={`${getActivitySize(item?.activity)} ${getActivityColor(item?.activity)} rounded-full pulse-animation relative`}>
                <div className={`absolute inset-0 ${getActivityColor(item?.activity)} rounded-full animate-ping opacity-30`}></div>
              </div>
              
              {/* Tooltip on hover */}
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 hover:opacity-100 transition-opacity duration-200 pointer-events-none">
                <div className="bg-popover border border-border rounded-lg p-2 text-xs whitespace-nowrap security-shadow">
                  <div className="font-medium text-foreground">{item?.city}, {item?.country}</div>
                  <div className="text-muted-foreground">{item?.count} events</div>
                  <div className="text-muted-foreground capitalize">{item?.type?.replace('_', ' ')}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Zoom indicator */}
        <div className="absolute top-4 right-4 bg-card/90 border border-border rounded-lg p-2">
          <div className="text-xs text-muted-foreground">Zoom: {zoomLevel}x</div>
        </div>
      </div>
      {/* Activity Summary */}
      <div className="p-4 border-t border-border">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-lg font-bold text-error">
              {activityData?.filter(item => item?.activity === 'high')?.length}
            </div>
            <div className="text-xs text-muted-foreground">High Activity</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-warning">
              {activityData?.filter(item => item?.activity === 'medium')?.length}
            </div>
            <div className="text-xs text-muted-foreground">Medium Activity</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-success">
              {activityData?.filter(item => item?.activity === 'low')?.length}
            </div>
            <div className="text-xs text-muted-foreground">Low Activity</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-primary">
              {activityData?.reduce((sum, item) => sum + item?.count, 0)?.toLocaleString()}
            </div>
            <div className="text-xs text-muted-foreground">Total Events</div>
          </div>
        </div>
      </div>
      {/* Selected Region Details */}
      {selectedRegion && (
        <div className="absolute top-4 left-4 bg-popover border border-border rounded-lg p-4 security-shadow max-w-xs">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium text-foreground">{selectedRegion?.city}, {selectedRegion?.country}</h4>
            <button
              onClick={() => setSelectedRegion(null)}
              className="p-1 hover:bg-muted/20 rounded transition-colors duration-150"
            >
              <Icon name="X" size={14} className="text-muted-foreground" />
            </button>
          </div>
          
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Activity Level:</span>
              <span className={`capitalize ${
                selectedRegion?.activity === 'high' ? 'text-error' :
                selectedRegion?.activity === 'medium'? 'text-warning' : 'text-success'
              }`}>
                {selectedRegion?.activity}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Event Count:</span>
              <span className="text-foreground font-medium">{selectedRegion?.count}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Type:</span>
              <div className="flex items-center space-x-1">
                <Icon name={getTypeIcon(selectedRegion?.type)} size={12} />
                <span className="text-foreground capitalize">{selectedRegion?.type?.replace('_', ' ')}</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Last Seen:</span>
              <span className="text-foreground">{selectedRegion?.lastSeen?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
          
          <button className="w-full mt-3 px-3 py-1 bg-primary/10 text-primary border border-primary/20 rounded-lg text-sm hover:bg-primary/20 transition-colors duration-150">
            Investigate Region
          </button>
        </div>
      )}
    </div>
  );
};

export default NetworkActivityHeatmap;