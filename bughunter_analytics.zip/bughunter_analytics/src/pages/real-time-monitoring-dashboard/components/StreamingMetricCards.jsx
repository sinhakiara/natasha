import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const StreamingMetricCards = () => {
  const [metrics, setMetrics] = useState({
    subdomainChanges: { count: 247, change: '+12', flash: false },
    vulnerabilities: { count: 18, change: '+3', flash: false },
    sslExpirations: { count: 5, change: '+1', flash: false },
    dnsAnomalies: { count: 32, change: '+7', flash: false },
    portAlerts: { count: 156, change: '+23', flash: false },
    toolStatus: { count: 8, change: '2 offline', flash: false }
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => {
        const newMetrics = { ...prev };
        
        // Randomly update metrics with flash effect
        Object.keys(newMetrics)?.forEach(key => {
          if (Math.random() > 0.7) {
            const increment = Math.floor(Math.random() * 5) + 1;
            newMetrics[key] = {
              ...newMetrics?.[key],
              count: newMetrics?.[key]?.count + increment,
              flash: true
            };
            
            // Remove flash after animation
            setTimeout(() => {
              setMetrics(current => ({
                ...current,
                [key]: { ...current?.[key], flash: false }
              }));
            }, 1000);
          }
        });
        
        return newMetrics;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const metricConfigs = [
    {
      key: 'subdomainChanges',
      title: 'Subdomain Changes',
      icon: 'Globe',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      key: 'vulnerabilities',
      title: 'New Vulnerabilities',
      icon: 'Shield',
      color: 'text-error',
      bgColor: 'bg-error/10'
    },
    {
      key: 'sslExpirations',
      title: 'SSL Expirations',
      icon: 'Lock',
      color: 'text-warning',
      bgColor: 'bg-warning/10'
    },
    {
      key: 'dnsAnomalies',
      title: 'DNS Anomalies',
      icon: 'Zap',
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    },
    {
      key: 'portAlerts',
      title: 'Port Scan Alerts',
      icon: 'Wifi',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      key: 'toolStatus',
      title: 'Tool Status',
      icon: 'Settings',
      color: 'text-muted-foreground',
      bgColor: 'bg-muted/10'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
      {metricConfigs?.map((config) => {
        const metric = metrics?.[config?.key];
        return (
          <div
            key={config?.key}
            className={`bg-card border border-border rounded-lg p-4 transition-all duration-300 ${
              metric?.flash ? 'ring-2 ring-primary cyberpunk-glow' : ''
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className={`w-8 h-8 ${config?.bgColor} rounded-lg flex items-center justify-center`}>
                <Icon name={config?.icon} size={16} className={config?.color} />
              </div>
              <div className={`text-xs px-2 py-1 rounded-full ${config?.bgColor} ${config?.color}`}>
                {metric?.change}
              </div>
            </div>
            <div className="space-y-1">
              <div className={`text-2xl font-bold ${config?.color}`}>
                {metric?.count?.toLocaleString()}
              </div>
              <div className="text-xs text-muted-foreground">
                {config?.title}
              </div>
            </div>
            {metric?.flash && (
              <div className="mt-2 flex items-center space-x-1">
                <div className="w-2 h-2 bg-primary rounded-full pulse-animation"></div>
                <span className="text-xs text-primary">Live Update</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default StreamingMetricCards;