import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const SystemStatusBar = () => {
  const [systemHealth, setSystemHealth] = useState(98.7);
  const [activeScans, setActiveScans] = useState(12);
  const [wsStatus, setWsStatus] = useState('connected');
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setSystemHealth(prev => Math.max(95, Math.min(100, prev + (Math.random() - 0.5) * 0.5)));
      setActiveScans(prev => Math.max(0, prev + Math.floor(Math.random() * 3) - 1));
      setLastUpdate(new Date());
      
      // Simulate occasional connection issues
      if (Math.random() > 0.95) {
        setWsStatus(prev => prev === 'connected' ? 'reconnecting' : 'connected');
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getHealthColor = () => {
    if (systemHealth >= 98) return 'text-success';
    if (systemHealth >= 95) return 'text-warning';
    return 'text-error';
  };

  const getWsStatusColor = () => {
    switch (wsStatus) {
      case 'connected': return 'text-success';
      case 'reconnecting': return 'text-warning';
      default: return 'text-error';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-8">
          {/* System Health */}
          <div className="flex items-center space-x-2">
            <Icon name="Activity" size={18} className={getHealthColor()} />
            <div>
              <div className="text-sm font-medium text-foreground">System Health</div>
              <div className={`text-lg font-bold ${getHealthColor()}`}>
                {systemHealth?.toFixed(1)}%
              </div>
            </div>
          </div>

          {/* Active Scans */}
          <div className="flex items-center space-x-2">
            <Icon name="Radar" size={18} className="text-primary" />
            <div>
              <div className="text-sm font-medium text-foreground">Active Scans</div>
              <div className="text-lg font-bold text-primary">{activeScans}</div>
            </div>
          </div>

          {/* WebSocket Status */}
          <div className="flex items-center space-x-2">
            <Icon 
              name={wsStatus === 'reconnecting' ? 'RotateCw' : 'Wifi'} 
              size={18} 
              className={`${getWsStatusColor()} ${wsStatus === 'reconnecting' ? 'animate-spin' : ''}`} 
            />
            <div>
              <div className="text-sm font-medium text-foreground">Connection</div>
              <div className={`text-sm font-medium ${getWsStatusColor()}`}>
                {wsStatus?.charAt(0)?.toUpperCase() + wsStatus?.slice(1)}
              </div>
            </div>
          </div>

          {/* Last Update */}
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={18} className="text-muted-foreground" />
            <div>
              <div className="text-sm font-medium text-foreground">Last Update</div>
              <div className="text-sm text-muted-foreground">
                {lastUpdate?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </div>
            </div>
          </div>
        </div>

        {/* Emergency Controls */}
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 px-4 py-2 bg-error/10 text-error border border-error/20 rounded-lg hover:bg-error/20 transition-colors duration-150">
            <Icon name="AlertTriangle" size={16} />
            <span className="text-sm font-medium">Emergency Alert</span>
          </button>
          
          <button className="flex items-center space-x-2 px-4 py-2 bg-warning/10 text-warning border border-warning/20 rounded-lg hover:bg-warning/20 transition-colors duration-150">
            <Icon name="Pause" size={16} />
            <span className="text-sm font-medium">Pause All</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SystemStatusBar;