import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const AlertQueue = () => {
  const [alerts, setAlerts] = useState([]);
  const [sortBy, setSortBy] = useState('priority');

  const mockAlerts = [
    {
      id: 1,
      title: 'Critical SQL Injection',
      target: 'api.target-alpha.com',
      priority: 'critical',
      timestamp: new Date(Date.now() - 300000),
      acknowledged: false,
      escalationTimer: 15,
      description: 'SQL injection vulnerability in user authentication endpoint'
    },
    {
      id: 2,
      title: 'SSL Certificate Expired',
      target: 'secure.target-alpha.com',
      priority: 'high',
      timestamp: new Date(Date.now() - 600000),
      acknowledged: false,
      escalationTimer: 45,
      description: 'SSL certificate has expired, affecting secure communications'
    },
    {
      id: 3,
      title: 'Subdomain Takeover Risk',
      target: 'old.target-alpha.com',
      priority: 'high',
      timestamp: new Date(Date.now() - 900000),
      acknowledged: true,
      escalationTimer: null,
      description: 'Subdomain pointing to unclaimed cloud resource'
    },
    {
      id: 4,
      title: 'Port Scan Detected',
      target: '192.168.1.100',
      priority: 'medium',
      timestamp: new Date(Date.now() - 1200000),
      acknowledged: false,
      escalationTimer: 120,
      description: 'Suspicious port scanning activity from external IP'
    },
    {
      id: 5,
      title: 'DNS Record Change',
      target: 'mail.target-alpha.com',
      priority: 'low',
      timestamp: new Date(Date.now() - 1800000),
      acknowledged: false,
      escalationTimer: 240,
      description: 'Unexpected change in DNS MX records'
    }
  ];

  useEffect(() => {
    setAlerts(mockAlerts);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setAlerts(prev => prev?.map(alert => ({
        ...alert,
        escalationTimer: alert?.escalationTimer && !alert?.acknowledged 
          ? Math.max(0, alert?.escalationTimer - 1)
          : alert?.escalationTimer
      })));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'text-error border-error/20 bg-error/5';
      case 'high': return 'text-warning border-warning/20 bg-warning/5';
      case 'medium': return 'text-accent border-accent/20 bg-accent/5';
      case 'low': return 'text-success border-success/20 bg-success/5';
      default: return 'text-muted-foreground border-border bg-muted/5';
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 'critical': return 'AlertTriangle';
      case 'high': return 'AlertCircle';
      case 'medium': return 'Info';
      case 'low': return 'CheckCircle';
      default: return 'Circle';
    }
  };

  const handleAcknowledge = (alertId) => {
    setAlerts(prev => prev?.map(alert => 
      alert?.id === alertId 
        ? { ...alert, acknowledged: true, escalationTimer: null }
        : alert
    ));
  };

  const handleEscalate = (alertId) => {
    // Simulate escalation
    console.log(`Escalating alert ${alertId}`);
  };

  const sortedAlerts = [...alerts]?.sort((a, b) => {
    if (sortBy === 'priority') {
      const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
      return priorityOrder?.[b?.priority] - priorityOrder?.[a?.priority];
    }
    if (sortBy === 'time') {
      return b?.timestamp - a?.timestamp;
    }
    return 0;
  });

  const formatTimer = (seconds) => {
    if (!seconds) return null;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  return (
    <div className="bg-card border border-border rounded-lg h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Icon name="Bell" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Alert Queue</h3>
            <span className="bg-error text-error-foreground text-xs px-2 py-1 rounded-full">
              {alerts?.filter(a => !a?.acknowledged)?.length}
            </span>
          </div>
        </div>

        {/* Sort Controls */}
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">Sort by:</span>
          <button
            onClick={() => setSortBy('priority')}
            className={`px-2 py-1 rounded text-xs transition-colors duration-150 ${
              sortBy === 'priority' ?'bg-primary/10 text-primary' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            Priority
          </button>
          <button
            onClick={() => setSortBy('time')}
            className={`px-2 py-1 rounded text-xs transition-colors duration-150 ${
              sortBy === 'time' ?'bg-primary/10 text-primary' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            Time
          </button>
        </div>
      </div>
      {/* Alert List */}
      <div className="h-96 overflow-y-auto">
        {sortedAlerts?.length === 0 ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center">
              <Icon name="CheckCircle" size={48} className="mx-auto mb-2 opacity-50" />
              <p>No active alerts</p>
            </div>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {sortedAlerts?.map((alert) => (
              <div
                key={alert?.id}
                className={`border rounded-lg p-3 transition-all duration-300 ${
                  alert?.acknowledged 
                    ? 'opacity-60 bg-muted/5 border-border' 
                    : getPriorityColor(alert?.priority)
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-start space-x-2 flex-1">
                    <Icon 
                      name={getPriorityIcon(alert?.priority)} 
                      size={16} 
                      className={alert?.acknowledged ? 'text-muted-foreground' : ''} 
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className={`font-medium text-sm mb-1 ${
                        alert?.acknowledged ? 'text-muted-foreground line-through' : 'text-foreground'
                      }`}>
                        {alert?.title}
                      </h4>
                      <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                        {alert?.description}
                      </p>
                      <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                        <span className="font-mono">{alert?.target}</span>
                        <span>•</span>
                        <span>{alert?.timestamp?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>
                  </div>

                  {/* Escalation Timer */}
                  {alert?.escalationTimer !== null && !alert?.acknowledged && (
                    <div className={`text-xs px-2 py-1 rounded-full ${
                      alert?.escalationTimer < 60 ? 'bg-error/20 text-error' : 'bg-warning/20 text-warning'
                    }`}>
                      {formatTimer(alert?.escalationTimer)}
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                {!alert?.acknowledged && (
                  <div className="flex items-center space-x-2 mt-3">
                    <button
                      onClick={() => handleAcknowledge(alert?.id)}
                      className="flex items-center space-x-1 px-2 py-1 bg-success/10 text-success border border-success/20 rounded text-xs hover:bg-success/20 transition-colors duration-150"
                    >
                      <Icon name="Check" size={12} />
                      <span>Acknowledge</span>
                    </button>
                    <button
                      onClick={() => handleEscalate(alert?.id)}
                      className="flex items-center space-x-1 px-2 py-1 bg-warning/10 text-warning border border-warning/20 rounded text-xs hover:bg-warning/20 transition-colors duration-150"
                    >
                      <Icon name="ArrowUp" size={12} />
                      <span>Escalate</span>
                    </button>
                  </div>
                )}

                {alert?.acknowledged && (
                  <div className="flex items-center space-x-1 mt-2 text-xs text-success">
                    <Icon name="CheckCircle" size={12} />
                    <span>Acknowledged</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AlertQueue;