import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import SystemStatusBar from './components/SystemStatusBar';
import StreamingMetricCards from './components/StreamingMetricCards';
import LiveEventStream from './components/LiveEventStream';
import NetworkActivityHeatmap from './components/NetworkActivityHeatmap';
import AlertQueue from './components/AlertQueue';
import { securityService } from '../../services/securityService';
import { useAuth } from '../../contexts/AuthContext';

const RealTimeMonitoringDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const [activities, setActivities] = useState([]);
  const [scanSessions, setScanSessions] = useState([]);
  const [dashboardStats, setDashboardStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isLive, setIsLive] = useState(true);

  // Load initial data
  useEffect(() => {
    if (authLoading) return;

    let isMounted = true;
    const loadData = async () => {
      try {
        setLoading(true);
        const [statsData, activitiesData, scansData] = await Promise.all([
          securityService?.getDashboardStats(),
          securityService?.getRecentActivities(50),
          securityService?.getScanSessions()
        ]);

        if (isMounted) {
          setDashboardStats(statsData);
          setActivities(activitiesData);
          setScanSessions(scansData?.slice(0, 10) || []);
          setError(null);
        }
      } catch (err) {
        if (isMounted) {
          setError(err?.message || 'Failed to load monitoring data');
          if (err?.message?.includes('Failed to fetch') || 
              err?.message?.includes('NetworkError') ||
              err?.name === 'TypeError' && err?.message?.includes('fetch')) {
            setError('Cannot connect to database. Your Supabase project may be paused or deleted. Please visit your Supabase dashboard to check project status.');
          }
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isMounted = false;
    };
  }, [authLoading]);

  // Real-time subscriptions
  useEffect(() => {
    if (!isLive) return;

    const unsubscribeActivities = securityService?.subscribeToActivities((payload) => {
      if (payload?.eventType === 'INSERT') {
        setActivities(prev => [payload?.new, ...prev?.slice(0, 49)]);
      }
    });

    const unsubscribeScans = securityService?.subscribeToScanSessions((payload) => {
      if (payload?.eventType === 'INSERT') {
        setScanSessions(prev => [payload?.new, ...prev?.slice(0, 9)]);
      } else if (payload?.eventType === 'UPDATE') {
        setScanSessions(prev => 
          prev?.map(scan => scan?.id === payload?.new?.id ? payload?.new : scan)
        );
      }
    });

    return () => {
      unsubscribeActivities();
      unsubscribeScans();
    };
  }, [isLive]);

  // Auto-refresh dashboard stats
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(async () => {
      try {
        const stats = await securityService?.getDashboardStats();
        setDashboardStats(stats);
      } catch (error) {
        console.error('Error refreshing stats:', error);
      }
    }, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, [isLive]);

  const handleToggleLive = () => {
    setIsLive(!isLive);
  };

  // Generate system status
  const getSystemStatus = () => {
    const runningScanCount = scanSessions?.filter(scan => scan?.status === 'running')?.length || 0;
    const recentCriticalCount = activities?.filter(activity => 
      activity?.severity === 'critical' && 
      new Date(activity?.created_at) > new Date(Date.now() - 3600000) // Last hour
    )?.length || 0;

    return {
      overall: recentCriticalCount === 0 ? 'healthy' : 'warning',
      activeScans: runningScanCount,
      criticalAlerts: recentCriticalCount,
      uptime: '99.9%',
      lastUpdate: new Date()?.toISOString()
    };
  };

  // Generate streaming metrics
  const getStreamingMetrics = () => {
    if (!dashboardStats) return [];

    return [
      {
        title: 'Active Threats',
        value: dashboardStats?.vulnerabilities?.critical || 0,
        change: '+2',
        changeType: 'increase',
        unit: '',
        color: 'error'
      },
      {
        title: 'Scan Throughput',
        value: scanSessions?.filter(s => s?.status === 'completed')?.length || 0,
        change: '+15%',
        changeType: 'increase',
        unit: '/hour',
        color: 'success'
      },
      {
        title: 'Event Rate',
        value: activities?.length || 0,
        change: '+8',
        changeType: 'increase',
        unit: '/min',
        color: 'primary'
      },
      {
        title: 'Response Time',
        value: '2.3',
        change: '-0.1s',
        changeType: 'decrease',
        unit: 's',
        color: 'accent'
      }
    ];
  };

  // Generate alert queue from recent critical activities
  const getAlertQueue = () => {
    return activities
      ?.filter(activity => activity?.severity === 'critical' || activity?.severity === 'high')
      ?.slice(0, 20)
      ?.map(activity => ({
        id: activity?.id,
        title: activity?.title,
        severity: activity?.severity,
        source: activity?.target?.domain || 'System',
        timestamp: activity?.created_at,
        description: activity?.description,
        status: 'unread'
      })) || [];
  };

  // Generate network activity data
  const getNetworkActivityData = () => {
    // Generate heatmap data from subdomains and activities
    const hourlyData = {};
    const now = new Date();

    // Initialize 24 hours of data
    for (let i = 0; i < 24; i++) {
      const hour = new Date(now.getTime() - (i * 60 * 60 * 1000))?.getHours();
      hourlyData[hour] = { hour, activity: 0, threats: 0 };
    }

    // Map activities to hours
    activities?.forEach(activity => {
      const hour = new Date(activity?.created_at)?.getHours();
      if (hourlyData?.[hour]) {
        hourlyData[hour].activity += 1;
        if (activity?.severity === 'critical' || activity?.severity === 'high') {
          hourlyData[hour].threats += 1;
        }
      }
    });

    return Object.values(hourlyData)?.reverse();
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading monitoring dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="bg-error/10 border border-error/20 rounded-lg p-6 text-center">
              <h2 className="text-xl font-semibold text-error mb-2">Error Loading Monitoring Dashboard</h2>
              <p className="text-muted-foreground mb-4">{error}</p>
              <button 
                onClick={() => window.location?.reload()} 
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  const systemStatus = getSystemStatus();
  const streamingMetrics = getStreamingMetrics();
  const alertQueue = getAlertQueue();
  const networkActivityData = getNetworkActivityData();

  return (
    <>
      <Helmet>
        <title>Real-time Security Monitoring Dashboard - BugHunter Analytics</title>
        <meta name="description" content="Real-time security monitoring dashboard providing live threat detection, system status monitoring, and instant alerting for security researchers and bug bounty hunters." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-foreground mb-2">
                    Real-time Security Monitoring
                  </h1>
                  <p className="text-muted-foreground">
                    Live threat detection and system monitoring across all security assets
                  </p>
                </div>
                
                <div className="flex items-center space-x-4">
                  <button
                    onClick={handleToggleLive}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                      isLive
                        ? 'bg-success text-success-foreground hover:bg-success/90'
                        : 'bg-muted text-muted-foreground hover:bg-muted/80'
                    }`}
                  >
                    <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-white animate-pulse' : 'bg-muted-foreground'}`} />
                    <span>{isLive ? 'Live' : 'Paused'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* System Status Bar */}
            <SystemStatusBar 
              status={systemStatus}
              isLive={isLive}
            />

            {/* Streaming Metrics Cards */}
            <StreamingMetricCards 
              metrics={streamingMetrics}
              isLive={isLive}
            />

            {/* Main Monitoring Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
              {/* Live Event Stream - Takes 2 columns */}
              <div className="xl:col-span-2">
                <LiveEventStream 
                  events={activities}
                  isLive={isLive}
                />
              </div>
              
              {/* Alert Queue - Takes 1 column */}
              <div className="xl:col-span-1">
                <AlertQueue 
                  alerts={alertQueue}
                  isLive={isLive}
                />
              </div>
            </div>

            {/* Network Activity Heatmap */}
            <NetworkActivityHeatmap 
              data={networkActivityData}
              isLive={isLive}
            />
          </div>
        </main>
      </div>
    </>
  );
};

export default RealTimeMonitoringDashboard;