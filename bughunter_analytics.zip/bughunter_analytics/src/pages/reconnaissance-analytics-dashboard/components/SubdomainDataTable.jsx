import React, { useState, useMemo } from 'react';
import Icon from '../../../components/AppIcon';

const SubdomainDataTable = ({ subdomains: propSubdomains }) => {
  const [sortConfig, setSortConfig] = useState({ key: 'lastScan', direction: 'desc' });
  const [filterConfig, setFilterConfig] = useState({
    status: 'all',
    technology: 'all', 
    responseCode: 'all',
    searchTerm: ''
  });
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Use provided subdomains or fallback to empty array
  const subdomainData = propSubdomains || [];

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' }
  ];

  const technologyOptions = [
    { value: 'all', label: 'All Technologies' },
    ...Array.from(new Set(subdomainData?.map(item => item?.technology)?.filter(Boolean)))
      ?.map(tech => ({ value: tech, label: tech }))
  ];

  const responseCodeOptions = [
    { value: 'all', label: 'All Codes' },
    { value: '200', label: '200 - OK' },
    { value: '403', label: '403 - Forbidden' },
    { value: '404', label: '404 - Not Found' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'text-success';
      case 'inactive': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'active': return 'bg-success/20 text-success';
      case 'inactive': return 'bg-error/20 text-error';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getResponseCodeColor = (code) => {
    if (code >= 200 && code < 300) return 'text-success';
    if (code >= 300 && code < 400) return 'text-warning';
    if (code >= 400) return 'text-error';
    return 'text-muted-foreground';
  };

  const filteredData = useMemo(() => {
    return subdomainData?.filter(item => {
      const matchesStatus = filterConfig?.status === 'all' || item?.status === filterConfig?.status;
      const matchesTechnology = filterConfig?.technology === 'all' || item?.technology === filterConfig?.technology;
      const matchesResponseCode = filterConfig?.responseCode === 'all' || item?.responseCode?.toString() === filterConfig?.responseCode;
      const matchesSearch = filterConfig?.searchTerm === '' || 
        item?.subdomain?.toLowerCase()?.includes(filterConfig?.searchTerm?.toLowerCase()) ||
        item?.ipAddress?.includes(filterConfig?.searchTerm);
      
      return matchesStatus && matchesTechnology && matchesResponseCode && matchesSearch;
    });
  }, [subdomainData, filterConfig]);

  const sortedData = useMemo(() => {
    if (!sortConfig?.key) return filteredData;

    return [...filteredData]?.sort((a, b) => {
      let aValue = a?.[sortConfig?.key];
      let bValue = b?.[sortConfig?.key];

      if (sortConfig?.key === 'lastScan') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (aValue < bValue) return sortConfig?.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig?.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortConfig]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData?.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage]);

  const totalPages = Math.ceil(sortedData?.length / itemsPerPage);

  const handleSort = (key) => {
    setSortConfig(prevConfig => ({
      key,
      direction: prevConfig?.key === key && prevConfig?.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleFilterChange = (key, value) => {
    setFilterConfig(prev => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'Never';
    return new Date(timestamp)?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const SortButton = ({ column, children }) => (
    <button
      onClick={() => handleSort(column)}
      className="flex items-center space-x-1 text-left font-medium text-muted-foreground hover:text-foreground transition-colors duration-150"
    >
      <span>{children}</span>
      <Icon 
        name={
          sortConfig?.key === column 
            ? sortConfig?.direction === 'asc' ?'ChevronUp' :'ChevronDown' :'ChevronsUpDown'
        } 
        size={14} 
      />
    </button>
  );

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-1">
            Subdomain Discovery Results
          </h3>
          <p className="text-sm text-muted-foreground">
            Detailed analysis of discovered subdomains and their properties
          </p>
        </div>

        <button className="flex items-center space-x-2 px-3 py-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150">
          <Icon name="Download" size={16} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Export CSV</span>
        </button>
      </div>
      
      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div>
          <input
            type="text"
            placeholder="Search subdomains or IPs..."
            value={filterConfig?.searchTerm}
            onChange={(e) => handleFilterChange('searchTerm', e?.target?.value)}
            className="w-full px-3 py-2 bg-input border border-border rounded-lg text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <select
          value={filterConfig?.status}
          onChange={(e) => handleFilterChange('status', e?.target?.value)}
          className="px-3 py-2 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        >
          {statusOptions?.map(option => (
            <option key={option?.value} value={option?.value}>{option?.label}</option>
          ))}
        </select>

        <select
          value={filterConfig?.technology}
          onChange={(e) => handleFilterChange('technology', e?.target?.value)}
          className="px-3 py-2 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        >
          {technologyOptions?.map(option => (
            <option key={option?.value} value={option?.value}>{option?.label}</option>
          ))}
        </select>

        <select
          value={filterConfig?.responseCode}
          onChange={(e) => handleFilterChange('responseCode', e?.target?.value)}
          className="px-3 py-2 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        >
          {responseCodeOptions?.map(option => (
            <option key={option?.value} value={option?.value}>{option?.label}</option>
          ))}
        </select>
      </div>
      
      {/* Results Summary */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-muted-foreground">
          Showing {paginatedData?.length} of {sortedData?.length} results
        </span>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">Last updated:</span>
          <span className="text-sm text-foreground">
            {formatTimestamp(new Date()?.toISOString())}
          </span>
        </div>
      </div>
      
      {/* Table */}
      {paginatedData?.length === 0 ? (
        <div className="text-center py-12">
          <Icon name="Globe" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h4 className="text-lg font-medium text-foreground mb-2">No Subdomains Found</h4>
          <p className="text-sm text-muted-foreground">
            {subdomainData?.length === 0 
              ? "No subdomains have been discovered yet. Start a reconnaissance scan to populate this data."
              : "No subdomains match your current filter criteria. Try adjusting your filters."
            }
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4">
                  <SortButton column="subdomain">Subdomain</SortButton>
                </th>
                <th className="text-left py-3 px-4">
                  <SortButton column="ipAddress">IP Address</SortButton>
                </th>
                <th className="text-left py-3 px-4">
                  <SortButton column="status">Status</SortButton>
                </th>
                <th className="text-left py-3 px-4">
                  <SortButton column="responseCode">Response</SortButton>
                </th>
                <th className="text-left py-3 px-4">
                  <SortButton column="technology">Technology</SortButton>
                </th>
                <th className="text-left py-3 px-4">Ports</th>
                <th className="text-left py-3 px-4">SSL</th>
                <th className="text-left py-3 px-4">
                  <SortButton column="lastScan">Last Scan</SortButton>
                </th>
              </tr>
            </thead>
            <tbody>
              {paginatedData?.map((item) => (
                <tr key={item?.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors duration-150">
                  <td className="py-3 px-4">
                    <div className="flex flex-col">
                      <span className="font-mono text-sm text-foreground">{item?.subdomain}</span>
                      {item?.cdn !== 'None' && (
                        <span className="text-xs text-muted-foreground">via {item?.cdn}</span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-mono text-sm text-muted-foreground">{item?.ipAddress}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${getStatusBadgeColor(item?.status)}`}>
                      {item?.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`font-mono text-sm ${getResponseCodeColor(item?.responseCode)}`}>
                      {item?.responseCode}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex flex-col">
                      <span className="text-sm text-foreground">{item?.technology}</span>
                      <span className="text-xs text-muted-foreground">{item?.version}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex flex-wrap gap-1">
                      {item?.ports?.map(port => (
                        <span key={port} className="text-xs px-2 py-1 bg-muted rounded font-mono text-muted-foreground">
                          {port}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <Icon 
                      name={item?.ssl ? "Shield" : "ShieldOff"} 
                      size={16} 
                      className={item?.ssl ? "text-success" : "text-error"} 
                    />
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-muted-foreground">
                      {formatTimestamp(item?.lastScan)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="flex items-center space-x-1 px-3 py-2 bg-muted hover:bg-muted/80 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors duration-150"
            >
              <Icon name="ChevronLeft" size={16} />
              <span className="text-sm">Previous</span>
            </button>
            
            <span className="text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </span>
            
            <button
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="flex items-center space-x-1 px-3 py-2 bg-muted hover:bg-muted/80 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors duration-150"
            >
              <span className="text-sm">Next</span>
              <Icon name="ChevronRight" size={16} />
            </button>
          </div>
          
          <div className="text-sm text-muted-foreground">
            {sortedData?.length} total subdomains discovered
          </div>
        </div>
      )}
    </div>
  );
};

export default SubdomainDataTable;