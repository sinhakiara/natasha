import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import Icon from '../../../components/AppIcon';

const TechnologyStackChart = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const technologyData = [
    { name: 'Web Servers', value: 34, count: 89, color: '#00F5FF', icon: 'Server' },
    { name: 'Frameworks', value: 28, count: 73, color: '#10B981', icon: 'Code' },
    { name: 'Databases', value: 18, count: 47, color: '#F59E0B', icon: 'Database' },
    { name: 'CDN/Cache', value: 12, count: 31, color: '#EF4444', icon: 'Zap' },
    { name: 'Analytics', value: 8, count: 21, color: '#8B5CF6', icon: 'BarChart3' }
  ];

  const detailedTechnologies = [
    { name: 'Apache', category: 'Web Servers', version: '2.4.41', count: 45, risk: 'medium', lastSeen: '2025-08-18' },
    { name: 'Nginx', category: 'Web Servers', version: '1.18.0', count: 34, risk: 'low', lastSeen: '2025-08-18' },
    { name: 'React', category: 'Frameworks', version: '18.2.0', count: 28, risk: 'low', lastSeen: '2025-08-17' },
    { name: 'Node.js', category: 'Frameworks', version: '16.14.2', count: 25, risk: 'medium', lastSeen: '2025-08-18' },
    { name: 'MySQL', category: 'Databases', version: '8.0.28', count: 23, risk: 'low', lastSeen: '2025-08-17' },
    { name: 'PostgreSQL', category: 'Databases', version: '13.7', count: 18, risk: 'low', lastSeen: '2025-08-18' },
    { name: 'Cloudflare', category: 'CDN/Cache', version: 'N/A', count: 31, risk: 'low', lastSeen: '2025-08-18' },
    { name: 'Google Analytics', category: 'Analytics', version: 'GA4', count: 21, risk: 'low', lastSeen: '2025-08-17' }
  ];

  const categories = [
    { id: 'all', label: 'All Categories' },
    { id: 'Web Servers', label: 'Web Servers' },
    { id: 'Frameworks', label: 'Frameworks' },
    { id: 'Databases', label: 'Databases' },
    { id: 'CDN/Cache', label: 'CDN/Cache' },
    { id: 'Analytics', label: 'Analytics' }
  ];

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'high': return 'text-error';
      case 'medium': return 'text-warning';
      case 'low': return 'text-success';
      default: return 'text-muted-foreground';
    }
  };

  const getRiskBadgeColor = (risk) => {
    switch (risk) {
      case 'high': return 'bg-error/20 text-error';
      case 'medium': return 'bg-warning/20 text-warning';
      case 'low': return 'bg-success/20 text-success';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const filteredTechnologies = selectedCategory === 'all' 
    ? detailedTechnologies 
    : detailedTechnologies?.filter(tech => tech?.category === selectedCategory);

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      const data = payload?.[0]?.payload;
      return (
        <div className="bg-popover border border-border rounded-lg p-4 security-shadow">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name={data?.icon} size={16} className="text-primary" />
            <span className="font-medium text-foreground">{data?.name}</span>
          </div>
          <div className="text-sm text-muted-foreground">
            <p>Technologies: {data?.count}</p>
            <p>Percentage: {data?.value}%</p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-1">
            Technology Stack Distribution
          </h3>
          <p className="text-sm text-muted-foreground">
            Identified technologies and versions
          </p>
        </div>

        <button className="flex items-center space-x-2 px-3 py-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150">
          <Icon name="Download" size={16} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Export</span>
        </button>
      </div>
      {/* Pie Chart */}
      <div className="h-64 mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={technologyData}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={2}
              dataKey="value"
            >
              {technologyData?.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry?.color} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      {/* Legend */}
      <div className="grid grid-cols-1 gap-2 mb-6">
        {technologyData?.map((item) => (
          <div key={item?.name} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors duration-150">
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item?.color }}
                />
                <Icon name={item?.icon} size={16} className="text-muted-foreground" />
              </div>
              <span className="text-sm font-medium text-foreground">{item?.name}</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">{item?.count} found</span>
              <span className="text-sm font-medium text-foreground">{item?.value}%</span>
            </div>
          </div>
        ))}
      </div>
      {/* Category Filter */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        {categories?.map((category) => (
          <button
            key={category?.id}
            onClick={() => setSelectedCategory(category?.id)}
            className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors duration-150 ${
              selectedCategory === category?.id
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            {category?.label}
          </button>
        ))}
      </div>
      {/* Detailed Technology List */}
      <div className="space-y-2">
        <h4 className="text-sm font-medium text-foreground mb-3">
          Detailed Technology Breakdown
        </h4>
        
        <div className="max-h-64 overflow-y-auto space-y-2">
          {filteredTechnologies?.map((tech, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">{tech?.name}</span>
                  <span className="text-xs text-muted-foreground">{tech?.category}</span>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-xs font-mono text-muted-foreground">{tech?.version}</div>
                  <div className="text-xs text-muted-foreground">{tech?.count} instances</div>
                </div>
                
                <span className={`text-xs px-2 py-1 rounded-full ${getRiskBadgeColor(tech?.risk)}`}>
                  {tech?.risk}
                </span>
                
                <div className="text-xs text-muted-foreground">
                  {new Date(tech.lastSeen)?.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TechnologyStackChart;