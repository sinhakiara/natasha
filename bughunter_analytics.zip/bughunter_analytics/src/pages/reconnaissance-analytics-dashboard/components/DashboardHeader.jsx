import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const DashboardHeader = () => {
  const [selectedTarget, setSelectedTarget] = useState('target-alpha.com');
  const [isTargetDropdownOpen, setIsTargetDropdownOpen] = useState(false);
  const [selectedDateRange, setSelectedDateRange] = useState('7d');
  const [isDateDropdownOpen, setIsDateDropdownOpen] = useState(false);
  const [toolComparison, setToolComparison] = useState(true);

  const targets = [
    { value: 'target-alpha.com', label: 'target-alpha.com', status: 'active', subdomains: 847 },
    { value: 'beta-corp.net', label: 'beta-corp.net', status: 'scanning', subdomains: 234 },
    { value: 'gamma-systems.org', label: 'gamma-systems.org', status: 'completed', subdomains: 156 },
    { value: 'delta-tech.io', label: 'delta-tech.io', status: 'pending', subdomains: 0 }
  ];

  const dateRanges = [
    { value: '24h', label: 'Last 24 Hours', description: 'Recent activity' },
    { value: '7d', label: 'Last 7 Days', description: 'Weekly overview' },
    { value: '30d', label: 'Last 30 Days', description: 'Monthly trends' },
    { value: '90d', label: 'Last 90 Days', description: 'Quarterly analysis' },
    { value: 'custom', label: 'Custom Range', description: 'Select specific dates' }
  ];

  const campaigns = [
    { id: 'campaign-1', name: 'Q3 Security Assessment', progress: 78, active: true },
    { id: 'campaign-2', name: 'Infrastructure Mapping', progress: 45, active: false },
    { id: 'campaign-3', name: 'Bug Bounty Research', progress: 92, active: true }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'text-success';
      case 'scanning': return 'text-warning';
      case 'completed': return 'text-accent';
      case 'pending': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'active': return 'bg-success/20 text-success';
      case 'scanning': return 'bg-warning/20 text-warning';
      case 'completed': return 'bg-accent/20 text-accent';
      case 'pending': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const handleTargetSelect = (target) => {
    setSelectedTarget(target?.value);
    setIsTargetDropdownOpen(false);
  };

  const handleDateRangeSelect = (range) => {
    setSelectedDateRange(range?.value);
    setIsDateDropdownOpen(false);
  };

  const selectedTargetData = targets?.find(t => t?.value === selectedTarget);
  const selectedDateRangeData = dateRanges?.find(d => d?.value === selectedDateRange);

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-8">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        {/* Left Section - Title and Target */}
        <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground mb-1">
              Reconnaissance Analytics
            </h1>
            <p className="text-sm text-muted-foreground">
              Comprehensive subdomain discovery and attack surface analysis
            </p>
          </div>

          {/* Target Selector */}
          <div className="relative">
            <button
              onClick={() => setIsTargetDropdownOpen(!isTargetDropdownOpen)}
              className="flex items-center space-x-3 px-4 py-3 bg-muted hover:bg-muted/80 rounded-lg border border-border transition-colors duration-150"
            >
              <div className="flex items-center space-x-2">
                <Icon name="Target" size={18} className="text-primary" />
                <div className="text-left">
                  <div className="font-mono text-sm text-foreground">{selectedTarget}</div>
                  <div className="text-xs text-muted-foreground">
                    {selectedTargetData?.subdomains} subdomains
                  </div>
                </div>
              </div>
              <Icon 
                name={isTargetDropdownOpen ? "ChevronUp" : "ChevronDown"} 
                size={16} 
                className="text-muted-foreground" 
              />
            </button>

            {isTargetDropdownOpen && (
              <div className="absolute top-full left-0 mt-2 w-80 bg-popover border border-border rounded-lg security-shadow z-50">
                <div className="p-3">
                  <div className="text-xs text-muted-foreground mb-3 px-2">Select Target Organization</div>
                  {targets?.map((target) => (
                    <button
                      key={target?.value}
                      onClick={() => handleTargetSelect(target)}
                      className="w-full flex items-center justify-between px-3 py-3 text-sm hover:bg-muted rounded-lg transition-colors duration-150"
                    >
                      <div className="flex items-center space-x-3">
                        <Icon name="Globe" size={16} className="text-muted-foreground" />
                        <div className="text-left">
                          <div className="font-mono text-foreground">{target?.label}</div>
                          <div className="text-xs text-muted-foreground">
                            {target?.subdomains} subdomains discovered
                          </div>
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusBadgeColor(target?.status)}`}>
                        {target?.status}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Section - Controls */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          {/* Tool Comparison Toggle */}
          <div className="flex items-center space-x-3">
            <label className="text-sm text-muted-foreground">Tool Comparison</label>
            <button
              onClick={() => setToolComparison(!toolComparison)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 ${
                toolComparison ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                  toolComparison ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Date Range Picker */}
          <div className="relative">
            <button
              onClick={() => setIsDateDropdownOpen(!isDateDropdownOpen)}
              className="flex items-center space-x-2 px-4 py-2 bg-muted hover:bg-muted/80 rounded-lg border border-border transition-colors duration-150"
            >
              <Icon name="Calendar" size={16} className="text-muted-foreground" />
              <span className="text-sm text-foreground">{selectedDateRangeData?.label}</span>
              <Icon 
                name={isDateDropdownOpen ? "ChevronUp" : "ChevronDown"} 
                size={14} 
                className="text-muted-foreground" 
              />
            </button>

            {isDateDropdownOpen && (
              <div className="absolute top-full right-0 mt-2 w-64 bg-popover border border-border rounded-lg security-shadow z-50">
                <div className="p-2">
                  {dateRanges?.map((range) => (
                    <button
                      key={range?.value}
                      onClick={() => handleDateRangeSelect(range)}
                      className={`w-full flex items-center justify-between px-3 py-2 text-sm hover:bg-muted rounded-md transition-colors duration-150 ${
                        selectedDateRange === range?.value ? 'bg-primary/10 text-primary' : 'text-foreground'
                      }`}
                    >
                      <div className="text-left">
                        <div className="font-medium">{range?.label}</div>
                        <div className="text-xs text-muted-foreground">{range?.description}</div>
                      </div>
                      {selectedDateRange === range?.value && (
                        <Icon name="Check" size={16} className="text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Export Controls */}
          <div className="flex items-center space-x-2">
            <button className="flex items-center space-x-2 px-3 py-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150">
              <Icon name="FileText" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Report</span>
            </button>
            
            <button className="flex items-center space-x-2 px-3 py-2 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg transition-colors duration-150">
              <Icon name="Download" size={16} />
              <span className="text-sm font-medium">Export</span>
            </button>
          </div>
        </div>
      </div>
      {/* Campaign Progress Indicators */}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-foreground">Active Campaigns</h3>
          <button className="text-xs text-primary hover:text-primary/80 transition-colors duration-150">
            View All
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {campaigns?.map((campaign) => (
            <div key={campaign?.id} className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
              <div className={`w-2 h-2 rounded-full ${campaign?.active ? 'bg-success pulse-animation' : 'bg-muted-foreground'}`} />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground truncate">{campaign?.name}</div>
                <div className="flex items-center space-x-2 mt-1">
                  <div className="flex-1 bg-muted rounded-full h-1.5">
                    <div 
                      className="bg-primary h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${campaign?.progress}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">{campaign?.progress}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Click outside handlers */}
      {(isTargetDropdownOpen || isDateDropdownOpen) && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => {
            setIsTargetDropdownOpen(false);
            setIsDateDropdownOpen(false);
          }}
        />
      )}
    </div>
  );
};

export default DashboardHeader;