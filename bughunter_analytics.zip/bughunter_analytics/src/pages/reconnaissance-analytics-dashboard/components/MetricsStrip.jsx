import React from 'react';
import Icon from '../../../components/AppIcon';

const MetricsStrip = () => {
  const metrics = [
    {
      id: 'subdomain-growth',
      title: 'Subdomain Growth Rate',
      value: '847',
      unit: 'domains',
      change: '+12.3%',
      changeType: 'positive',
      icon: 'TrendingUp',
      description: 'New subdomains discovered in last 24h',
      trend: [45, 52, 48, 61, 55, 67, 73, 69, 78, 84, 79, 87]
    },
    {
      id: 'dns-resolution',
      title: 'DNS Resolution Success',
      value: '94.7',
      unit: '%',
      change: '+2.1%',
      changeType: 'positive',
      icon: 'Globe',
      description: 'Successfully resolved DNS queries',
      trend: [88, 89, 91, 90, 92, 93, 94, 93, 95, 94, 95, 95]
    },
    {
      id: 'tech-diversity',
      title: 'Technology Stack Diversity',
      value: '156',
      unit: 'techs',
      change: '+8.4%',
      changeType: 'positive',
      icon: 'Layers',
      description: 'Unique technologies identified',
      trend: [142, 145, 148, 151, 149, 152, 154, 153, 156, 155, 157, 156]
    },
    {
      id: 'port-coverage',
      title: 'Port Scan Coverage',
      value: '78.2',
      unit: '%',
      change: '-1.2%',
      changeType: 'negative',
      icon: 'Shield',
      description: 'Ports successfully scanned',
      trend: [82, 81, 80, 79, 78, 79, 78, 77, 78, 79, 78, 78]
    }
  ];

  const renderMiniChart = (trend) => {
    const max = Math.max(...trend);
    const min = Math.min(...trend);
    const range = max - min;
    
    return (
      <div className="flex items-end space-x-0.5 h-8 w-16">
        {trend?.map((value, index) => {
          const height = range > 0 ? ((value - min) / range) * 100 : 50;
          return (
            <div
              key={index}
              className="bg-primary/30 rounded-sm flex-1"
              style={{ height: `${Math.max(height, 10)}%` }}
            />
          );
        })}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
      {metrics?.map((metric) => (
        <div
          key={metric?.id}
          className="bg-card border border-border rounded-lg p-6 hover:border-primary/30 transition-all duration-200"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Icon name={metric?.icon} size={20} className="text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">
                  {metric?.title}
                </h3>
                <p className="text-xs text-muted-foreground/70 mt-1">
                  {metric?.description}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-end justify-between">
            <div className="flex-1">
              <div className="flex items-baseline space-x-2 mb-2">
                <span className="text-2xl font-bold text-foreground">
                  {metric?.value}
                </span>
                <span className="text-sm text-muted-foreground">
                  {metric?.unit}
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className={`text-xs font-medium flex items-center space-x-1 ${
                  metric?.changeType === 'positive' ?'text-success' 
                    : metric?.changeType === 'negative' ?'text-error' :'text-muted-foreground'
                }`}>
                  <Icon 
                    name={metric?.changeType === 'positive' ? 'ArrowUp' : 'ArrowDown'} 
                    size={12} 
                  />
                  <span>{metric?.change}</span>
                </span>
                <span className="text-xs text-muted-foreground">vs last period</span>
              </div>
            </div>

            <div className="ml-4">
              {renderMiniChart(metric?.trend)}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MetricsStrip;