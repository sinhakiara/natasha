import React, { useState, useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';

const NetworkTopologyVisualization = () => {
  const svgRef = useRef(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const nodes = [
    { id: 'root', label: 'target-alpha.com', type: 'root', x: 400, y: 300, connections: ['api', 'www', 'admin'] },
    { id: 'api', label: 'api.target-alpha.com', type: 'subdomain', x: 200, y: 200, connections: ['v1', 'v2'] },
    { id: 'www', label: 'www.target-alpha.com', type: 'subdomain', x: 600, y: 200, connections: ['cdn', 'assets'] },
    { id: 'admin', label: 'admin.target-alpha.com', type: 'subdomain', x: 400, y: 100, connections: ['panel'] },
    { id: 'v1', label: 'v1.api.target-alpha.com', type: 'endpoint', x: 100, y: 150, connections: [] },
    { id: 'v2', label: 'v2.api.target-alpha.com', type: 'endpoint', x: 100, y: 250, connections: [] },
    { id: 'cdn', label: 'cdn.target-alpha.com', type: 'service', x: 700, y: 150, connections: [] },
    { id: 'assets', label: 'assets.target-alpha.com', type: 'service', x: 700, y: 250, connections: [] },
    { id: 'panel', label: 'panel.admin.target-alpha.com', type: 'endpoint', x: 300, y: 50, connections: [] }
  ];

  const getNodeColor = (type) => {
    switch (type) {
      case 'root': return '#00F5FF';
      case 'subdomain': return '#10B981';
      case 'endpoint': return '#F59E0B';
      case 'service': return '#EF4444';
      default: return '#94A3B8';
    }
  };

  const getNodeIcon = (type) => {
    switch (type) {
      case 'root': return 'Globe';
      case 'subdomain': return 'GitBranch';
      case 'endpoint': return 'Target';
      case 'service': return 'Server';
      default: return 'Circle';
    }
  };

  const handleMouseDown = (e) => {
    setIsDragging(true);
    setDragStart({ x: e?.clientX - panOffset?.x, y: e?.clientY - panOffset?.y });
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      setPanOffset({
        x: e?.clientX - dragStart?.x,
        y: e?.clientY - dragStart?.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev * 1.2, 3));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev / 1.2, 0.3));
  };

  const resetView = () => {
    setZoomLevel(1);
    setPanOffset({ x: 0, y: 0 });
    setSelectedNode(null);
  };

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragStart]);

  const renderConnections = () => {
    const connections = [];
    nodes?.forEach(node => {
      node?.connections?.forEach(connectionId => {
        const targetNode = nodes?.find(n => n?.id === connectionId);
        if (targetNode) {
          connections?.push(
            <line
              key={`${node?.id}-${connectionId}`}
              x1={node?.x}
              y1={node?.y}
              x2={targetNode?.x}
              y2={targetNode?.y}
              stroke="rgba(148, 163, 184, 0.3)"
              strokeWidth="2"
              strokeDasharray={node?.type === 'root' ? '0' : '5,5'}
            />
          );
        }
      });
    });
    return connections;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-1">
            Network Topology Visualization
          </h3>
          <p className="text-sm text-muted-foreground">
            Interactive subdomain relationship mapping
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleZoomOut}
            className="p-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150"
            title="Zoom Out"
          >
            <Icon name="ZoomOut" size={16} className="text-muted-foreground" />
          </button>
          
          <button
            onClick={handleZoomIn}
            className="p-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150"
            title="Zoom In"
          >
            <Icon name="ZoomIn" size={16} className="text-muted-foreground" />
          </button>
          
          <button
            onClick={resetView}
            className="p-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150"
            title="Reset View"
          >
            <Icon name="RotateCcw" size={16} className="text-muted-foreground" />
          </button>
          
          <button className="flex items-center space-x-2 px-3 py-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150">
            <Icon name="Download" size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Export</span>
          </button>
        </div>
      </div>
      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 mb-6 p-4 bg-muted/30 rounded-lg">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#00F5FF' }} />
          <span className="text-xs text-muted-foreground">Root Domain</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#10B981' }} />
          <span className="text-xs text-muted-foreground">Subdomain</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#F59E0B' }} />
          <span className="text-xs text-muted-foreground">Endpoint</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#EF4444' }} />
          <span className="text-xs text-muted-foreground">Service</span>
        </div>
      </div>
      {/* Visualization Container */}
      <div className="relative bg-background border border-border rounded-lg overflow-hidden" style={{ height: '500px' }}>
        <svg
          ref={svgRef}
          width="100%"
          height="100%"
          className="cursor-grab active:cursor-grabbing"
          onMouseDown={handleMouseDown}
          style={{
            transform: `translate(${panOffset?.x}px, ${panOffset?.y}px) scale(${zoomLevel})`
          }}
        >
          {/* Grid Pattern */}
          <defs>
            <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
              <path d="M 50 0 L 0 0 0 50" fill="none" stroke="rgba(148, 163, 184, 0.1)" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />

          {/* Connections */}
          <g>
            {renderConnections()}
          </g>

          {/* Nodes */}
          <g>
            {nodes?.map((node) => (
              <g key={node?.id}>
                {/* Node Circle */}
                <circle
                  cx={node?.x}
                  cy={node?.y}
                  r={selectedNode?.id === node?.id ? 25 : 20}
                  fill={getNodeColor(node?.type)}
                  fillOpacity={0.2}
                  stroke={getNodeColor(node?.type)}
                  strokeWidth={selectedNode?.id === node?.id ? 3 : 2}
                  className="cursor-pointer transition-all duration-200 hover:fill-opacity-30"
                  onClick={() => setSelectedNode(node)}
                />
                
                {/* Node Icon */}
                <foreignObject
                  x={node?.x - 10}
                  y={node?.y - 10}
                  width="20"
                  height="20"
                  className="pointer-events-none"
                >
                  <div className="flex items-center justify-center w-full h-full">
                    <Icon 
                      name={getNodeIcon(node?.type)} 
                      size={14} 
                      color={getNodeColor(node?.type)} 
                    />
                  </div>
                </foreignObject>

                {/* Node Label */}
                <text
                  x={node?.x}
                  y={node?.y + 35}
                  textAnchor="middle"
                  className="text-xs font-mono fill-current text-muted-foreground pointer-events-none"
                  style={{ fontSize: '10px' }}
                >
                  {node?.label?.length > 20 ? `${node?.label?.substring(0, 20)}...` : node?.label}
                </text>
              </g>
            ))}
          </g>
        </svg>

        {/* Zoom Level Indicator */}
        <div className="absolute top-4 right-4 bg-card border border-border rounded-lg px-3 py-2">
          <span className="text-xs text-muted-foreground">
            Zoom: {Math.round(zoomLevel * 100)}%
          </span>
        </div>
      </div>
      {/* Selected Node Details */}
      {selectedNode && (
        <div className="mt-6 p-4 bg-muted/30 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <div 
                className="w-4 h-4 rounded-full"
                style={{ backgroundColor: getNodeColor(selectedNode?.type) }}
              />
              <h4 className="text-sm font-semibold text-foreground">
                {selectedNode?.label}
              </h4>
            </div>
            <button
              onClick={() => setSelectedNode(null)}
              className="p-1 hover:bg-muted rounded"
            >
              <Icon name="X" size={16} className="text-muted-foreground" />
            </button>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Type:</span>
              <span className="ml-2 text-foreground capitalize">{selectedNode?.type}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Connections:</span>
              <span className="ml-2 text-foreground">{selectedNode?.connections?.length}</span>
            </div>
          </div>
          
          {selectedNode?.connections?.length > 0 && (
            <div className="mt-3">
              <span className="text-xs text-muted-foreground">Connected to:</span>
              <div className="flex flex-wrap gap-2 mt-2">
                {selectedNode?.connections?.map(connectionId => {
                  const connectedNode = nodes?.find(n => n?.id === connectionId);
                  return connectedNode ? (
                    <span
                      key={connectionId}
                      className="text-xs px-2 py-1 bg-muted rounded-full text-muted-foreground font-mono"
                    >
                      {connectedNode?.label}
                    </span>
                  ) : null;
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NetworkTopologyVisualization;