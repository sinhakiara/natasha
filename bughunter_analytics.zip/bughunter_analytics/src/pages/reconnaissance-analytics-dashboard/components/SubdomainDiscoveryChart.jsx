import React, { useState } from 'react';
import { ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Icon from '../../../components/AppIcon';

const SubdomainDiscoveryChart = () => {
  const [selectedTools, setSelectedTools] = useState(['subfinder', 'amass', 'assetfinder']);
  const [timeRange, setTimeRange] = useState('7d');

  const chartData = [
    {
      date: '2025-08-11',
      total: 245,
      subfinder: 89,
      amass: 156,
      assetfinder: 67,
      nuclei: 34
    },
    {
      date: '2025-08-12',
      total: 312,
      subfinder: 102,
      amass: 178,
      assetfinder: 89,
      nuclei: 45
    },
    {
      date: '2025-08-13',
      total: 387,
      subfinder: 134,
      amass: 201,
      assetfinder: 98,
      nuclei: 52
    },
    {
      date: '2025-08-14',
      total: 456,
      subfinder: 167,
      amass: 234,
      assetfinder: 112,
      nuclei: 67
    },
    {
      date: '2025-08-15',
      total: 523,
      subfinder: 189,
      amass: 267,
      assetfinder: 134,
      nuclei: 78
    },
    {
      date: '2025-08-16',
      total: 612,
      subfinder: 223,
      amass: 298,
      assetfinder: 156,
      nuclei: 89
    },
    {
      date: '2025-08-17',
      total: 698,
      subfinder: 245,
      amass: 334,
      assetfinder: 178,
      nuclei: 98
    },
    {
      date: '2025-08-18',
      total: 847,
      subfinder: 289,
      amass: 378,
      assetfinder: 201,
      nuclei: 112
    }
  ];

  const tools = [
    { id: 'subfinder', name: 'Subfinder', color: '#00F5FF', icon: 'Search' },
    { id: 'amass', name: 'Amass', color: '#10B981', icon: 'Radar' },
    { id: 'assetfinder', name: 'Assetfinder', color: '#F59E0B', icon: 'Target' },
    { id: 'nuclei', name: 'Nuclei', color: '#EF4444', icon: 'Zap' }
  ];

  const timeRanges = [
    { id: '24h', label: '24 Hours' },
    { id: '7d', label: '7 Days' },
    { id: '30d', label: '30 Days' },
    { id: '90d', label: '90 Days' }
  ];

  const toggleTool = (toolId) => {
    setSelectedTools(prev => 
      prev?.includes(toolId) 
        ? prev?.filter(id => id !== toolId)
        : [...prev, toolId]
    );
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg p-4 security-shadow">
          <p className="text-sm font-medium text-foreground mb-2">
            {new Date(label)?.toLocaleDateString('en-US', { 
              weekday: 'short', 
              month: 'short', 
              day: 'numeric' 
            })}
          </p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center justify-between space-x-4 text-xs">
              <div className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: entry?.color }}
                />
                <span className="text-muted-foreground">{entry?.name}:</span>
              </div>
              <span className="font-medium text-foreground">{entry?.value}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-1">
            Subdomain Discovery Timeline
          </h3>
          <p className="text-sm text-muted-foreground">
            Performance comparison across enumeration tools
          </p>
        </div>

        <div className="flex items-center space-x-4">
          {/* Time Range Selector */}
          <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
            {timeRanges?.map((range) => (
              <button
                key={range?.id}
                onClick={() => setTimeRange(range?.id)}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors duration-150 ${
                  timeRange === range?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {range?.label}
              </button>
            ))}
          </div>

          {/* Export Button */}
          <button className="flex items-center space-x-2 px-3 py-2 bg-muted hover:bg-muted/80 rounded-lg transition-colors duration-150">
            <Icon name="Download" size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Export</span>
          </button>
        </div>
      </div>
      {/* Tool Legend/Toggles */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        {tools?.map((tool) => (
          <button
            key={tool?.id}
            onClick={() => toggleTool(tool?.id)}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg border transition-all duration-150 ${
              selectedTools?.includes(tool?.id)
                ? 'border-primary/30 bg-primary/5' :'border-border bg-transparent hover:border-border/60'
            }`}
          >
            <Icon 
              name={tool?.icon} 
              size={16} 
              className={selectedTools?.includes(tool?.id) ? 'text-primary' : 'text-muted-foreground'} 
            />
            <span 
              className={`text-sm font-medium ${
                selectedTools?.includes(tool?.id) ? 'text-foreground' : 'text-muted-foreground'
              }`}
            >
              {tool?.name}
            </span>
            <div 
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: tool?.color }}
            />
          </button>
        ))}
      </div>
      {/* Chart */}
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
            <XAxis 
              dataKey="date" 
              stroke="#94A3B8"
              fontSize={12}
              tickFormatter={(value) => new Date(value)?.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            />
            <YAxis stroke="#94A3B8" fontSize={12} />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            
            <Bar 
              dataKey="total" 
              fill="rgba(0, 245, 255, 0.1)" 
              stroke="#00F5FF" 
              strokeWidth={1}
              name="Total Discovered"
              radius={[2, 2, 0, 0]}
            />
            
            {selectedTools?.includes('subfinder') && (
              <Line 
                type="monotone" 
                dataKey="subfinder" 
                stroke="#00F5FF" 
                strokeWidth={2}
                dot={{ fill: '#00F5FF', strokeWidth: 2, r: 4 }}
                name="Subfinder"
              />
            )}
            
            {selectedTools?.includes('amass') && (
              <Line 
                type="monotone" 
                dataKey="amass" 
                stroke="#10B981" 
                strokeWidth={2}
                dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                name="Amass"
              />
            )}
            
            {selectedTools?.includes('assetfinder') && (
              <Line 
                type="monotone" 
                dataKey="assetfinder" 
                stroke="#F59E0B" 
                strokeWidth={2}
                dot={{ fill: '#F59E0B', strokeWidth: 2, r: 4 }}
                name="Assetfinder"
              />
            )}
            
            {selectedTools?.includes('nuclei') && (
              <Line 
                type="monotone" 
                dataKey="nuclei" 
                stroke="#EF4444" 
                strokeWidth={2}
                dot={{ fill: '#EF4444', strokeWidth: 2, r: 4 }}
                name="Nuclei"
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default SubdomainDiscoveryChart;