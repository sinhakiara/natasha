import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import MetricsStrip from './components/MetricsStrip';
import SubdomainDiscoveryChart from './components/SubdomainDiscoveryChart';
import TechnologyStackChart from './components/TechnologyStackChart';
import NetworkTopologyVisualization from './components/NetworkTopologyVisualization';
import SubdomainDataTable from './components/SubdomainDataTable';
import DashboardHeader from './components/DashboardHeader';
import { securityService } from '../../services/securityService';
import { useAuth } from '../../contexts/AuthContext';

const ReconnaissanceAnalyticsDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const [subdomains, setSubdomains] = useState([]);
  const [targets, setTargets] = useState([]);
  const [selectedTarget, setSelectedTarget] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Load data
  useEffect(() => {
    if (authLoading) return;

    let isMounted = true;
    const loadData = async () => {
      try {
        setLoading(true);
        const [subdomainData, targetData] = await Promise.all([
          securityService?.getSubdomains(selectedTarget || null),
          securityService?.getTargets()
        ]);

        if (isMounted) {
          setSubdomains(subdomainData);
          setTargets(targetData);
          setError(null);
        }
      } catch (err) {
        if (isMounted) {
          setError(err?.message || 'Failed to load reconnaissance data');
          if (err?.message?.includes('Failed to fetch') || 
              err?.message?.includes('NetworkError') ||
              err?.name === 'TypeError' && err?.message?.includes('fetch')) {
            setError('Cannot connect to database. Your Supabase project may be paused or deleted. Please visit your Supabase dashboard to check project status.');
          }
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isMounted = false;
    };
  }, [authLoading, selectedTarget]);

  const handleTargetChange = (targetId) => {
    setSelectedTarget(targetId);
    setLastUpdated(new Date());
  };

  const handleRefresh = () => {
    setLastUpdated(new Date());
    // This will trigger the useEffect to reload data
  };

  // Calculate metrics
  const getMetrics = () => {
    const total = subdomains?.length || 0;
    const active = subdomains?.filter(s => s?.status === 'active')?.length || 0;
    const withSsl = subdomains?.filter(s => s?.ssl_enabled)?.length || 0;
    const technologies = [...new Set(subdomains?.map(s => s?.technology)?.filter(Boolean))]?.length || 0;
    
    return {
      totalSubdomains: total,
      activeSubdomains: active,
      sslEnabled: withSsl,
      technologiesDetected: technologies,
      sslPercentage: total > 0 ? Math.round((withSsl / total) * 100) : 0,
      activePercentage: total > 0 ? Math.round((active / total) * 100) : 0
    };
  };

  // Get technology distribution
  const getTechnologyData = () => {
    const techCount = {};
    subdomains?.forEach(subdomain => {
      if (subdomain?.technology) {
        techCount[subdomain.technology] = (techCount?.[subdomain?.technology] || 0) + 1;
      }
    });

    return Object.entries(techCount)
      ?.map(([name, count]) => ({ name, count }))
      ?.sort((a, b) => b?.count - a?.count)
      ?.slice(0, 10); // Top 10 technologies
  };

  // Transform subdomains for table display
  const getTableData = () => {
    return subdomains?.map(subdomain => ({
      id: subdomain?.id,
      subdomain: subdomain?.subdomain,
      ipAddress: subdomain?.ip_address,
      status: subdomain?.status,
      responseCode: subdomain?.response_code || 200,
      technology: subdomain?.technology || 'Unknown',
      version: subdomain?.version || 'N/A',
      lastScan: subdomain?.last_scan || subdomain?.updated_at,
      ports: subdomain?.ports || [],
      ssl: subdomain?.ssl_enabled || false,
      cdn: subdomain?.cdn || 'None',
      target: subdomain?.target?.domain
    })) || [];
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading reconnaissance data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="bg-error/10 border border-error/20 rounded-lg p-6 text-center">
              <h2 className="text-xl font-semibold text-error mb-2">Error Loading Reconnaissance Data</h2>
              <p className="text-muted-foreground mb-4">{error}</p>
              <button 
                onClick={() => window.location?.reload()} 
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  const metrics = getMetrics();
  const technologyData = getTechnologyData();
  const tableData = getTableData();

  return (
    <>
      <Helmet>
        <title>Reconnaissance Analytics Dashboard - BugHunter Analytics</title>
        <meta name="description" content="Advanced reconnaissance analytics dashboard providing comprehensive subdomain discovery, technology stack analysis, and network topology visualization for security researchers." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-6 py-8">
            {/* Dashboard Header */}
            <DashboardHeader
              targets={targets}
              selectedTarget={selectedTarget}
              onTargetChange={handleTargetChange}
              onRefresh={handleRefresh}
              lastUpdated={lastUpdated}
            />

            {/* Metrics Strip */}
            <MetricsStrip metrics={metrics} />

            {/* Main Analytics Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
              {/* Subdomain Discovery Chart */}
              <div className="xl:col-span-2">
                <SubdomainDiscoveryChart subdomains={subdomains} />
              </div>
              
              {/* Technology Stack Chart */}
              <div className="xl:col-span-1">
                <TechnologyStackChart data={technologyData} />
              </div>
            </div>

            {/* Network Topology and Data Table */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
              {/* Network Topology Visualization */}
              <div>
                <NetworkTopologyVisualization 
                  subdomains={tableData}
                  selectedTarget={targets?.find(t => t?.id === selectedTarget)?.domain}
                />
              </div>
              
              {/* Subdomain Data Table */}
              <div>
                <SubdomainDataTable propSubdomains={tableData} />
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default ReconnaissanceAnalyticsDashboard;