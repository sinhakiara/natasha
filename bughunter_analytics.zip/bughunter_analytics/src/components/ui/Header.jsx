import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const Header = () => {
  const location = useLocation();
  const [connectionStatus, setConnectionStatus] = useState('connected');
  const [alertCount, setAlertCount] = useState(3);
  const [selectedTarget, setSelectedTarget] = useState('target-alpha.com');
  const [isTargetDropdownOpen, setIsTargetDropdownOpen] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  const navigationItems = [
    {
      label: 'Overview',
      path: '/security-intelligence-overview-dashboard',
      icon: 'Shield',
      tooltip: 'Security Intelligence Overview Dashboard'
    },
    {
      label: 'Reconnaissance',
      path: '/reconnaissance-analytics-dashboard',
      icon: 'Search',
      tooltip: 'Reconnaissance Analytics Dashboard'
    },
    {
      label: 'Vulnerabilities',
      path: '/vulnerability-management-dashboard',
      icon: 'AlertTriangle',
      tooltip: 'Vulnerability Management Dashboard'
    },
    {
      label: 'Live Monitoring',
      path: '/real-time-monitoring-dashboard',
      icon: 'Activity',
      tooltip: 'Real-time Monitoring Dashboard',
      badge: alertCount > 0 ? alertCount : null
    }
  ];

  const targets = [
    { value: 'target-alpha.com', label: 'target-alpha.com', status: 'active' },
    { value: 'beta-corp.net', label: 'beta-corp.net', status: 'scanning' },
    { value: 'gamma-systems.org', label: 'gamma-systems.org', status: 'completed' },
    { value: 'delta-tech.io', label: 'delta-tech.io', status: 'pending' }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date());
      // Simulate connection status changes
      const statuses = ['connected', 'reconnecting', 'disconnected'];
      const randomStatus = statuses?.[Math.floor(Math.random() * statuses?.length)];
      if (Math.random() > 0.9) {
        setConnectionStatus(randomStatus);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getConnectionStatusColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'text-success';
      case 'reconnecting':
        return 'text-warning';
      case 'disconnected':
        return 'text-error';
      default:
        return 'text-muted-foreground';
    }
  };

  const getConnectionStatusIcon = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'Wifi';
      case 'reconnecting':
        return 'RotateCw';
      case 'disconnected':
        return 'WifiOff';
      default:
        return 'Wifi';
    }
  };

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  const handleTargetSelect = (target) => {
    setSelectedTarget(target?.value);
    setIsTargetDropdownOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-6">
          <Link to="/security-intelligence-overview-dashboard" className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="Shield" size={20} className="text-primary-foreground" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-success rounded-full pulse-animation"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-semibold text-foreground">BugHunter</span>
              <span className="text-xs text-muted-foreground -mt-1">Analytics</span>
            </div>
          </Link>

          {/* Target Context Selector */}
          <div className="relative">
            <button
              onClick={() => setIsTargetDropdownOpen(!isTargetDropdownOpen)}
              className="flex items-center space-x-2 px-3 py-2 bg-card rounded-lg border border-border hover:border-primary/50 transition-colors duration-150"
            >
              <Icon name="Target" size={16} className="text-muted-foreground" />
              <span className="text-sm font-mono text-foreground">{selectedTarget}</span>
              <Icon 
                name={isTargetDropdownOpen ? "ChevronUp" : "ChevronDown"} 
                size={16} 
                className="text-muted-foreground" 
              />
            </button>

            {isTargetDropdownOpen && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-popover border border-border rounded-lg security-shadow z-50">
                <div className="p-2">
                  <div className="text-xs text-muted-foreground mb-2 px-2">Select Target</div>
                  {targets?.map((target) => (
                    <button
                      key={target?.value}
                      onClick={() => handleTargetSelect(target)}
                      className="w-full flex items-center justify-between px-3 py-2 text-sm hover:bg-muted rounded-md transition-colors duration-150"
                    >
                      <span className="font-mono text-foreground">{target?.label}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        target?.status === 'active' ? 'bg-success/20 text-success' :
                        target?.status === 'scanning' ? 'bg-warning/20 text-warning' :
                        target?.status === 'completed'? 'bg-accent/20 text-accent' : 'bg-muted text-muted-foreground'
                      }`}>
                        {target?.status}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex items-center space-x-1">
          {navigationItems?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`relative flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-150 ${
                isActivePath(item?.path)
                  ? 'bg-primary/10 text-primary border border-primary/20' :'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
              title={item?.tooltip}
            >
              <Icon name={item?.icon} size={18} />
              <span className="text-sm font-medium">{item?.label}</span>
              {item?.badge && (
                <span className="absolute -top-1 -right-1 bg-error text-error-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center pulse-animation">
                  {item?.badge}
                </span>
              )}
            </Link>
          ))}
        </nav>

        {/* Status Indicators */}
        <div className="flex items-center space-x-4">
          {/* Real-time Status Indicator */}
          <div className="flex items-center space-x-2 px-3 py-2 bg-card rounded-lg border border-border">
            <Icon 
              name={getConnectionStatusIcon()} 
              size={16} 
              className={`${getConnectionStatusColor()} ${connectionStatus === 'reconnecting' ? 'animate-spin' : ''}`} 
            />
            <div className="flex flex-col">
              <span className={`text-xs font-medium ${getConnectionStatusColor()}`}>
                {connectionStatus?.charAt(0)?.toUpperCase() + connectionStatus?.slice(1)}
              </span>
              <span className="text-xs text-muted-foreground">
                {lastUpdate?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>

          {/* User Menu */}
          <div className="flex items-center space-x-2">
            <button className="w-8 h-8 bg-muted rounded-full flex items-center justify-center hover:bg-muted/80 transition-colors duration-150">
              <Icon name="User" size={16} className="text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>
      {/* Click outside handler for dropdown */}
      {isTargetDropdownOpen && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setIsTargetDropdownOpen(false)}
        />
      )}
    </header>
  );
};

export default Header;