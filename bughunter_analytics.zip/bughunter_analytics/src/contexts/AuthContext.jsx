import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { authService } from '../services/authService';

const AuthContext = createContext({});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Get initial session - Use Promise chain
    supabase?.auth?.getSession()?.then(({ data: { session } }) => {
        if (session?.user) {
          setUser(session?.user);
          fetchUserProfile(session?.user?.id); // Fire-and-forget, NO AWAIT
        }
        setLoading(false);
      })?.catch((error) => {
        console.error('Error getting session:', error);
        setError(error?.message);
        setLoading(false);
      });

    // Listen for auth changes - NEVER ASYNC callback
    const { data: { subscription } } = supabase?.auth?.onAuthStateChange(
      (event, session) => {  // NO ASYNC keyword here
        if (session?.user) {
          setUser(session?.user);
          fetchUserProfile(session?.user?.id);  // Fire-and-forget, NO AWAIT
        } else {
          setUser(null);
          setUserProfile(null);
        }
        setLoading(false);
      }
    );

    return () => subscription?.unsubscribe();
  }, []);

  const fetchUserProfile = (userId) => {
    authService?.getUserProfile(userId)?.then((profile) => {
        setUserProfile(profile);
      })?.catch((error) => {
        console.error('Error fetching user profile:', error);
        setError(error?.message);
      });
  };

  const signUp = async (email, password, userData) => {
    try {
      setLoading(true);
      setError(null);
      const data = await authService?.signUp(email, password, userData);
      return data;
    } catch (error) {
      setError(error?.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email, password) => {
    try {
      setLoading(true);
      setError(null);
      const data = await authService?.signIn(email, password);
      return data;
    } catch (error) {
      setError(error?.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setError(null);
      await authService?.signOut();
      setUser(null);
      setUserProfile(null);
    } catch (error) {
      setError(error?.message);
      throw error;
    }
  };

  const updateProfile = async (updates) => {
    try {
      if (!user?.id) throw new Error('No authenticated user');
      setError(null);
      const updatedProfile = await authService?.updateUserProfile(user?.id, updates);
      setUserProfile(updatedProfile);
      return updatedProfile;
    } catch (error) {
      setError(error?.message);
      throw error;
    }
  };

  const resetPassword = async (email) => {
    try {
      setError(null);
      const data = await authService?.resetPassword(email);
      return data;
    } catch (error) {
      setError(error?.message);
      throw error;
    }
  };

  const value = {
    user,
    userProfile,
    loading,
    error,
    signUp,
    signIn,
    signOut,
    updateProfile,
    resetPassword,
    isAuthenticated: !!user,
    isAdmin: userProfile?.role === 'admin',
    isAnalyst: userProfile?.role === 'analyst' || userProfile?.role === 'admin'
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};