import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import ReconnaissanceAnalyticsDashboard from './pages/reconnaissance-analytics-dashboard';
import VulnerabilityManagementDashboard from './pages/vulnerability-management-dashboard';
import RealTimeMonitoringDashboard from './pages/real-time-monitoring-dashboard';
import SecurityIntelligenceOverviewDashboard from './pages/security-intelligence-overview-dashboard';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<RealTimeMonitoringDashboard />} />
        <Route path="/reconnaissance-analytics-dashboard" element={<ReconnaissanceAnalyticsDashboard />} />
        <Route path="/vulnerability-management-dashboard" element={<VulnerabilityManagementDashboard />} />
        <Route path="/real-time-monitoring-dashboard" element={<RealTimeMonitoringDashboard />} />
        <Route path="/security-intelligence-overview-dashboard" element={<SecurityIntelligenceOverviewDashboard />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
