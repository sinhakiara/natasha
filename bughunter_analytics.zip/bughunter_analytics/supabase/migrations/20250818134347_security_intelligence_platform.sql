-- Location: supabase/migrations/20250818134347_security_intelligence_platform.sql
-- Schema Analysis: Fresh project - no existing schema
-- Integration Type: Complete new security intelligence system
-- Dependencies: None (fresh installation)

-- 1. Custom Types
CREATE TYPE public.user_role AS ENUM ('admin', 'analyst', 'viewer');
CREATE TYPE public.vulnerability_severity AS ENUM ('critical', 'high', 'medium', 'low', 'info');
CREATE TYPE public.vulnerability_status AS ENUM ('open', 'in_progress', 'resolved', 'dismissed');
CREATE TYPE public.scan_status AS ENUM ('pending', 'running', 'completed', 'failed');
CREATE TYPE public.asset_status AS ENUM ('active', 'inactive', 'unknown');
CREATE TYPE public.activity_type AS ENUM ('vulnerability', 'subdomain', 'scan', 'alert', 'system');

-- 2. Core User Management
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    role public.user_role DEFAULT 'viewer'::public.user_role,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Target Management
CREATE TABLE public.targets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    domain TEXT NOT NULL UNIQUE,
    description TEXT,
    owner_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Subdomain Discovery
CREATE TABLE public.subdomains (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target_id UUID REFERENCES public.targets(id) ON DELETE CASCADE,
    subdomain TEXT NOT NULL,
    ip_address INET,
    status public.asset_status DEFAULT 'unknown'::public.asset_status,
    response_code INTEGER,
    technology TEXT,
    version TEXT,
    ports INTEGER[],
    ssl_enabled BOOLEAN DEFAULT false,
    cdn TEXT,
    last_scan TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    discovered_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Vulnerabilities
CREATE TABLE public.vulnerabilities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target_id UUID REFERENCES public.targets(id) ON DELETE CASCADE,
    subdomain_id UUID REFERENCES public.subdomains(id) ON DELETE SET NULL,
    cve_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    severity public.vulnerability_severity NOT NULL,
    cvss_score DECIMAL(3,1),
    status public.vulnerability_status DEFAULT 'open'::public.vulnerability_status,
    affected_assets TEXT[],
    proof_of_concept TEXT,
    remediation TEXT,
    discovered_by UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    discovered_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. Scan Sessions
CREATE TABLE public.scan_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target_id UUID REFERENCES public.targets(id) ON DELETE CASCADE,
    scan_type TEXT NOT NULL,
    status public.scan_status DEFAULT 'pending'::public.scan_status,
    progress INTEGER DEFAULT 0,
    started_by UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ,
    results JSONB,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 7. Activity Feed
CREATE TABLE public.activities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type public.activity_type NOT NULL,
    severity public.vulnerability_severity DEFAULT 'info'::public.vulnerability_severity,
    title TEXT NOT NULL,
    description TEXT,
    target_id UUID REFERENCES public.targets(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. System Metrics (for KPIs)
CREATE TABLE public.system_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    metric_name TEXT NOT NULL,
    metric_value DECIMAL NOT NULL,
    metric_change DECIMAL,
    change_type TEXT, -- 'positive', 'negative', 'neutral'
    sparkline_data DECIMAL[],
    recorded_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 9. Essential Indexes
CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_targets_domain ON public.targets(domain);
CREATE INDEX idx_targets_owner_id ON public.targets(owner_id);
CREATE INDEX idx_subdomains_target_id ON public.subdomains(target_id);
CREATE INDEX idx_subdomains_subdomain ON public.subdomains(subdomain);
CREATE INDEX idx_vulnerabilities_target_id ON public.vulnerabilities(target_id);
CREATE INDEX idx_vulnerabilities_severity ON public.vulnerabilities(severity);
CREATE INDEX idx_vulnerabilities_status ON public.vulnerabilities(status);
CREATE INDEX idx_scan_sessions_target_id ON public.scan_sessions(target_id);
CREATE INDEX idx_activities_type ON public.activities(type);
CREATE INDEX idx_activities_target_id ON public.activities(target_id);
CREATE INDEX idx_activities_created_at ON public.activities(created_at DESC);
CREATE INDEX idx_system_metrics_name ON public.system_metrics(metric_name);
CREATE INDEX idx_system_metrics_recorded_at ON public.system_metrics(recorded_at DESC);

-- 10. Enable Row Level Security
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.targets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subdomains ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vulnerabilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scan_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_metrics ENABLE ROW LEVEL SECURITY;

-- 11. RLS Policies

-- Pattern 1: Core user table - Simple ownership
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Pattern 2: Simple user ownership for targets
CREATE POLICY "users_manage_own_targets"
ON public.targets
FOR ALL
TO authenticated
USING (owner_id = auth.uid())
WITH CHECK (owner_id = auth.uid());

-- Pattern 6: Role-based access for system-wide data
CREATE OR REPLACE FUNCTION public.is_admin_or_analyst()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    WHERE up.id = auth.uid() 
    AND up.role IN ('admin', 'analyst')
    AND up.is_active = true
)
$$;

-- Subdomains: Users can see subdomains for their targets + admins/analysts see all
CREATE POLICY "users_can_view_target_subdomains"
ON public.subdomains
FOR SELECT
TO authenticated
USING (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

CREATE POLICY "users_can_manage_target_subdomains"
ON public.subdomains
FOR INSERT
TO authenticated
WITH CHECK (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

CREATE POLICY "users_can_update_target_subdomains"
ON public.subdomains
FOR UPDATE
TO authenticated
USING (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
)
WITH CHECK (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

-- Vulnerabilities: Similar pattern to subdomains
CREATE POLICY "users_can_view_target_vulnerabilities"
ON public.vulnerabilities
FOR SELECT
TO authenticated
USING (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

CREATE POLICY "users_can_manage_target_vulnerabilities"
ON public.vulnerabilities
FOR INSERT
TO authenticated
WITH CHECK (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

CREATE POLICY "users_can_update_target_vulnerabilities"
ON public.vulnerabilities
FOR UPDATE
TO authenticated
USING (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
)
WITH CHECK (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

-- Scan sessions: Users can manage scans for their targets
CREATE POLICY "users_can_view_target_scans"
ON public.scan_sessions
FOR SELECT
TO authenticated
USING (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

CREATE POLICY "users_can_manage_target_scans"
ON public.scan_sessions
FOR ALL
TO authenticated
USING (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
)
WITH CHECK (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR public.is_admin_or_analyst()
);

-- Activities: Users see activities for their targets + all system activities
CREATE POLICY "users_can_view_relevant_activities"
ON public.activities
FOR SELECT
TO authenticated
USING (
    target_id IN (
        SELECT t.id FROM public.targets t WHERE t.owner_id = auth.uid()
    ) OR 
    target_id IS NULL OR 
    public.is_admin_or_analyst()
);

CREATE POLICY "system_can_create_activities"
ON public.activities
FOR INSERT
TO authenticated
WITH CHECK (true);

-- System metrics: Only admins can manage, all users can view
CREATE POLICY "all_users_can_view_system_metrics"
ON public.system_metrics
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "admins_can_manage_system_metrics"
ON public.system_metrics
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.user_profiles up
        WHERE up.id = auth.uid() AND up.role = 'admin' AND up.is_active = true
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.user_profiles up
        WHERE up.id = auth.uid() AND up.role = 'admin' AND up.is_active = true
    )
);

-- 12. Functions for automatic profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO public.user_profiles (id, email, full_name, role)
    VALUES (
        NEW.id, 
        NEW.email, 
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'role', 'viewer')::public.user_role
    );
    RETURN NEW;
END;
$$;

-- 13. Trigger for new user creation
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 14. Functions for updated_at timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- Apply to tables with updated_at columns
CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_targets_updated_at BEFORE UPDATE ON public.targets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_subdomains_updated_at BEFORE UPDATE ON public.subdomains FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_vulnerabilities_updated_at BEFORE UPDATE ON public.vulnerabilities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_scan_sessions_updated_at BEFORE UPDATE ON public.scan_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 15. Mock Data for Development
DO $$
DECLARE
    admin_user_id UUID := gen_random_uuid();
    analyst_user_id UUID := gen_random_uuid();
    target1_id UUID := gen_random_uuid();
    target2_id UUID := gen_random_uuid();
    subdomain1_id UUID := gen_random_uuid();
    subdomain2_id UUID := gen_random_uuid();
    subdomain3_id UUID := gen_random_uuid();
    vulnerability1_id UUID := gen_random_uuid();
    vulnerability2_id UUID := gen_random_uuid();
    scan_session_id UUID := gen_random_uuid();
BEGIN
    -- Create complete auth.users records
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (admin_user_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@security.com', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Security Admin", "role": "admin"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (analyst_user_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'analyst@security.com', crypt('analyst123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Security Analyst", "role": "analyst"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Create targets
    INSERT INTO public.targets (id, domain, description, owner_id) VALUES
        (target1_id, 'target-alpha.com', 'Primary target for reconnaissance', admin_user_id),
        (target2_id, 'target-beta.com', 'Secondary target for analysis', analyst_user_id);

    -- Create subdomains
    INSERT INTO public.subdomains (id, target_id, subdomain, ip_address, status, response_code, technology, version, ports, ssl_enabled, cdn) VALUES
        (subdomain1_id, target1_id, 'api.target-alpha.com', '192.168.1.100'::inet, 'active'::public.asset_status, 200, 'Node.js', '16.14.2', ARRAY[80, 443, 8080], true, 'Cloudflare'),
        (subdomain2_id, target1_id, 'admin.target-alpha.com', '192.168.1.102'::inet, 'active'::public.asset_status, 403, 'Nginx', '1.18.0', ARRAY[80, 443, 22], true, 'None'),
        (subdomain3_id, target2_id, 'www.target-beta.com', '192.168.2.100'::inet, 'active'::public.asset_status, 200, 'Apache', '2.4.41', ARRAY[80, 443], true, 'AWS CloudFront');

    -- Create vulnerabilities
    INSERT INTO public.vulnerabilities (id, target_id, subdomain_id, cve_id, title, description, severity, cvss_score, status, affected_assets, discovered_by) VALUES
        (vulnerability1_id, target1_id, subdomain1_id, 'CVE-2024-1234', 'SQL Injection in API Endpoint', 'Union-based SQL injection vulnerability in the /api/users endpoint allows unauthorized data access', 'critical'::public.vulnerability_severity, 9.8, 'open'::public.vulnerability_status, ARRAY['api.target-alpha.com'], admin_user_id),
        (vulnerability2_id, target1_id, subdomain2_id, 'CVE-2024-5678', 'Cross-Site Scripting (XSS)', 'Reflected XSS vulnerability in admin panel search functionality', 'high'::public.vulnerability_severity, 7.5, 'in_progress'::public.vulnerability_status, ARRAY['admin.target-alpha.com'], analyst_user_id);

    -- Create scan session
    INSERT INTO public.scan_sessions (id, target_id, scan_type, status, progress, started_by, results) VALUES
        (scan_session_id, target1_id, 'subdomain_enumeration', 'completed'::public.scan_status, 100, admin_user_id, '{"subdomains_found": 15, "active_subdomains": 12, "technologies_detected": ["Node.js", "Nginx", "Apache"]}'::jsonb);

    -- Create activities
    INSERT INTO public.activities (type, severity, title, description, target_id, user_id) VALUES
        ('vulnerability'::public.activity_type, 'critical'::public.vulnerability_severity, 'SQL Injection discovered', 'Union-based SQL injection in /api/users endpoint', target1_id, admin_user_id),
        ('subdomain'::public.activity_type, 'info'::public.vulnerability_severity, 'New subdomain discovered', 'dev.target-alpha.com found via certificate transparency', target1_id, null),
        ('scan'::public.activity_type, 'info'::public.vulnerability_severity, 'Port scan completed', '1,024 ports scanned, 12 services identified', target1_id, admin_user_id),
        ('alert'::public.activity_type, 'medium'::public.vulnerability_severity, 'SSL certificate expiring', 'Certificate expires in 7 days', target1_id, null);

    -- Create system metrics (KPIs)
    INSERT INTO public.system_metrics (metric_name, metric_value, metric_change, change_type, sparkline_data) VALUES
        ('total_vulnerabilities', 146, 12.5, 'negative', ARRAY[120, 125, 132, 128, 135, 142, 146]),
        ('active_subdomains', 1247, 8.3, 'positive', ARRAY[1180, 1195, 1210, 1225, 1235, 1242, 1247]),
        ('critical_findings', 12, 3, 'negative', ARRAY[8, 9, 10, 9, 11, 10, 12]),
        ('scan_completion', 94.2, 2.1, 'positive', ARRAY[89, 90, 91, 92, 93, 94, 94.2]),
        ('false_positive_rate', 3.8, -0.5, 'positive', ARRAY[4.5, 4.3, 4.1, 4.0, 3.9, 3.8, 3.8]),
        ('avg_response_time', 2.3, -0.2, 'positive', ARRAY[2.8, 2.7, 2.5, 2.4, 2.3, 2.3, 2.3]);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error during mock data insertion: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error during mock data insertion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error during mock data insertion: %', SQLERRM;
END $$;

-- 16. Cleanup function for development
CREATE OR REPLACE FUNCTION public.cleanup_mock_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    auth_user_ids_to_delete UUID[];
BEGIN
    -- Get auth user IDs for mock data
    SELECT ARRAY_AGG(id) INTO auth_user_ids_to_delete
    FROM auth.users
    WHERE email IN ('admin@security.com', 'analyst@security.com');

    -- Delete in dependency order
    DELETE FROM public.activities WHERE user_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.scan_sessions WHERE started_by = ANY(auth_user_ids_to_delete);
    DELETE FROM public.vulnerabilities WHERE discovered_by = ANY(auth_user_ids_to_delete);
    DELETE FROM public.subdomains WHERE target_id IN (
        SELECT id FROM public.targets WHERE owner_id = ANY(auth_user_ids_to_delete)
    );
    DELETE FROM public.targets WHERE owner_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.system_metrics;
    DELETE FROM public.user_profiles WHERE id = ANY(auth_user_ids_to_delete);
    DELETE FROM auth.users WHERE id = ANY(auth_user_ids_to_delete);

    RAISE NOTICE 'Mock data cleaned up successfully';
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END;
$$;