'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Github, 
  Search, 
  Shield, 
  Globe, 
  Bell, 
  Settings, 
  Activity,
  Key,
  Network,
  BarChart3,
  Users,
  Database,
  Code,
  RefreshCw,
  Bug
} from 'lucide-react'
import { Toaster } from '@/components/ui/toaster'
import { useToast } from '@/hooks/use-toast'
import { AuthGuard } from '@/components/auth/auth-guard'
import { SignOutButton } from '@/components/auth/sign-out-button'
import { UserProfile } from '@/components/auth/user-profile'
import { GitHubMonitor } from '@/components/monitors/github-monitor'
import { SecretScanner } from '@/components/scans/secret-scanner'
import { VulnerabilityScanner } from '@/components/scans/vulnerability-scanner'
import { CodeScanner } from '@/components/scans/code-scanner'
import { TokenVerifier } from '@/components/tokens/token-verifier'
import { NetworkIntelligence } from '@/components/network/network-intelligence'
import { AnalyticsDashboard } from '@/components/reports/analytics-dashboard'
import RealTimeMonitoring from '@/components/monitoring/real-time-monitoring'
import { TeamManagement } from '@/components/team/team-management'

export default function SecurityDashboard() {
  const [activeTab, setActiveTab] = useState('overview')
  const [scanType, setScanType] = useState('secret')
  const [stats, setStats] = useState([
    { label: 'Active Monitors', value: '0', change: '0', icon: Activity },
    { label: 'Leaks Detected', value: '0', change: '0', icon: Shield },
    { label: 'Tokens Verified', value: '0', change: '0', icon: Key },
    { label: 'Network Assets', value: '0', change: '0', icon: Globe }
  ])
  const [recentAlerts, setRecentAlerts] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()
  const { data: session } = useSession()

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    
    // Update URL without full page reload
    const url = new URL(window.location.href)
    if (tab === 'overview') {
      url.searchParams.delete('tab')
    } else {
      url.searchParams.set('tab', tab)
    }
    window.history.pushState({}, '', url.toString())
  }

  useEffect(() => {
    const handleTabParameter = () => {
      // Check for tab parameter in URL
      const urlParams = new URLSearchParams(window.location.search)
      const tabParam = urlParams.get('tab')
      if (tabParam && ['overview', 'realtime', 'monitors', 'scans', 'tokens', 'network', 'reports', 'team'].includes(tabParam)) {
        setActiveTab(tabParam)
      }
    }

    // Initial check
    handleTabParameter()
    
    // Listen for popstate events (back/forward navigation)
    window.addEventListener('popstate', handleTabParameter)
    
    fetchDashboardData()
    
    // Cleanup
    return () => {
      window.removeEventListener('popstate', handleTabParameter)
    }
  }, [])

  const features = [
    {
      id: 'github-monitor',
      title: 'GitHub Monitor',
      description: 'Real-time GitHub repository monitoring for leaked secrets and credentials',
      icon: Github,
      color: 'bg-gray-900'
    },
    {
      id: 'secret-scanner',
      title: 'Secret Scanner',
      description: 'Advanced secret detection across multiple platforms and repositories',
      icon: Search,
      color: 'bg-blue-600'
    },
    {
      id: 'token-verifier',
      title: 'Token Verifier',
      description: 'Verify and validate tokens from various services and platforms',
      icon: Key,
      color: 'bg-green-600'
    },
    {
      id: 'zoomeye-integration',
      title: 'ZoomEye Integration',
      description: 'Network asset reconnaissance and intelligence gathering',
      icon: Network,
      color: 'bg-purple-600'
    }
  ]

  const fetchDashboardData = async () => {
    try {
      setIsLoading(true)
      const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3'
      
      // Fetch stats data
      const statsResponse = await fetch(`/api/monitoring/stats?userId=${userId}`)
      if (statsResponse.ok) {
        const data = await statsResponse.json()
        const metrics = data.metrics || {}
        setStats([
          { label: 'Active Monitors', value: metrics.activeMonitors?.toString() || '0', change: '0', icon: Activity },
          { label: 'Leaks Detected', value: metrics.totalLeaks?.toString() || '0', change: '0', icon: Shield },
          { label: 'Tokens Verified', value: metrics.validTokens?.toString() || '0', change: '0', icon: Key },
          { label: 'Network Assets', value: metrics.totalNetworkAssets?.toString() || '0', change: '0', icon: Globe }
        ])
      }

      // Fetch recent alerts
      const alertsResponse = await fetch(`/api/alerts?userId=${userId}&limit=5`)
      if (alertsResponse.ok) {
        const alertsData = await alertsResponse.json()
        setRecentAlerts(alertsData.alerts || [])
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
      toast({
        title: "Error",
        description: "Failed to fetch dashboard data",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AuthGuard requiredRoles={['ADMIN', 'MEMBER', 'VIEWER']}>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b bg-card">
          <div className="flex h-16 items-center px-6">
            <div className="flex items-center space-x-4">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-xl font-semibold">Security Sentinel</h1>
            </div>
            <div className="ml-auto flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Alerts
              </Button>
              <UserProfile />
            </div>
          </div>
        </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 border-r bg-card/50">
          <nav className="p-4">
            <div className="space-y-2">
              <Button
                variant={activeTab === 'overview' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('overview')}
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                Overview
              </Button>
              <Button
                variant={activeTab === 'realtime' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('realtime')}
              >
                <Bell className="h-4 w-4 mr-2" />
                Real-time Monitoring
              </Button>
              <Button
                variant={activeTab === 'monitors' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('monitors')}
              >
                <Activity className="h-4 w-4 mr-2" />
                Monitors
              </Button>
              <Button
                variant={activeTab === 'scans' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('scans')}
              >
                <Search className="h-4 w-4 mr-2" />
                Scans
              </Button>
              <Button
                variant={activeTab === 'tokens' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('tokens')}
              >
                <Key className="h-4 w-4 mr-2" />
                Token Verification
              </Button>
              <Button
                variant={activeTab === 'network' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('network')}
              >
                <Network className="h-4 w-4 mr-2" />
                Network Intelligence
              </Button>
              <Button
                variant={activeTab === 'reports' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('reports')}
              >
                <Database className="h-4 w-4 mr-2" />
                Reports
              </Button>
              <Button
                variant={activeTab === 'team' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => handleTabChange('team')}
              >
                <Users className="h-4 w-4 mr-2" />
                Team
              </Button>
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
                <p className="text-muted-foreground">
                  Comprehensive security monitoring platform combining GitHub leak detection, secret scanning, and network intelligence
                </p>
              </div>

              {/* Stats Cards */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {stats.map((stat) => (
                  <Card key={stat.label}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
                      <stat.icon className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{stat.value}</div>
                      <p className="text-xs text-muted-foreground">
                        {stat.change !== '0' && (
                          <span className="text-green-600">{stat.change}</span>
                        )}
                        {stat.change === '0' && (
                          <span className="text-gray-500">No data</span>
                        )}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Feature Cards */}
              <div className="grid gap-6 md:grid-cols-2">
                {features.map((feature) => (
                  <Card key={feature.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center space-x-4">
                        <div className={`p-2 rounded-lg ${feature.color}`}>
                          <feature.icon className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{feature.title}</CardTitle>
                          <CardDescription>{feature.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        className="w-full"
                        onClick={() => {
                          const targetTab = feature.id === 'github-monitor' ? 'monitors' : 
                                         feature.id === 'secret-scanner' ? 'scans' :
                                         feature.id === 'token-verifier' ? 'tokens' : 'network'
                          handleTabChange(targetTab)
                          toast({
                            title: "Navigation",
                            description: `Switched to ${feature.title}`,
                          })
                        }}
                      >
                        Access Feature
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Recent Alerts */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Recent Alerts</CardTitle>
                      <CardDescription>Latest security events and notifications</CardDescription>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleTabChange('realtime')}
                    >
                      View All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="animate-pulse">
                          <div className="h-16 bg-gray-200 rounded-lg"></div>
                        </div>
                      ))}
                    </div>
                  ) : recentAlerts.length === 0 ? (
                    <div className="text-center py-8">
                      <Shield className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No Recent Alerts</h3>
                      <p className="text-gray-500">Your security monitoring is active and will alert you to any issues.</p>
                    </div>
                  ) : (
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {recentAlerts.map((alert, index) => (
                        <Alert key={index} className={`border-l-4 ${
                          alert.severity === 'high' ? 'border-l-red-500' :
                          alert.severity === 'medium' ? 'border-l-yellow-500' :
                          alert.severity === 'low' ? 'border-l-blue-500' :
                          'border-l-gray-500'
                        }`}>
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <AlertDescription className="font-medium text-sm">{alert.title || 'Security Alert'}</AlertDescription>
                              <AlertDescription className="text-xs text-gray-600 mt-1">{alert.description || 'No description available'}</AlertDescription>
                            </div>
                            <div className="text-right ml-4">
                              <Badge variant={
                                alert.severity === 'high' ? 'destructive' :
                                alert.severity === 'medium' ? 'default' :
                                alert.severity === 'low' ? 'secondary' :
                                'outline'
                              }>
                                {alert.severity?.toUpperCase() || 'INFO'}
                              </Badge>
                              <div className="text-xs text-muted-foreground mt-1">
                                {alert.createdAt ? new Date(alert.createdAt).toLocaleString() : 'Just now'}
                              </div>
                            </div>
                          </div>
                        </Alert>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>Common security tasks and operations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <Button 
                      variant="outline" 
                      className="h-auto p-4 flex flex-col items-center space-y-2"
                      onClick={() => handleTabChange('monitors')}
                    >
                      <Activity className="h-6 w-6" />
                      <span className="text-sm">Start Monitor</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-auto p-4 flex flex-col items-center space-y-2"
                      onClick={() => handleTabChange('scans')}
                    >
                      <Search className="h-6 w-6" />
                      <span className="text-sm">Run Scan</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-auto p-4 flex flex-col items-center space-y-2"
                      onClick={() => handleTabChange('network')}
                    >
                      <Network className="h-6 w-6" />
                      <span className="text-sm">Network Scan</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-auto p-4 flex flex-col items-center space-y-2"
                      onClick={() => handleTabChange('reports')}
                    >
                      <Database className="h-6 w-6" />
                      <span className="text-sm">Generate Report</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'realtime' && <RealTimeMonitoring />}

          {activeTab === 'monitors' && <GitHubMonitor />}

          {activeTab === 'scans' && (
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <h2 className="text-3xl font-bold tracking-tight">Security Scans</h2>
                <div className="flex space-x-2">
                  <Button
                    variant={scanType === 'secret' ? 'default' : 'outline'}
                    onClick={() => setScanType('secret')}
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Secret Scanner
                  </Button>
                  <Button
                    variant={scanType === 'vulnerability' ? 'default' : 'outline'}
                    onClick={() => setScanType('vulnerability')}
                  >
                    <Bug className="h-4 w-4 mr-2" />
                    Vulnerability Scanner
                  </Button>
                  <Button
                    variant={scanType === 'code' ? 'default' : 'outline'}
                    onClick={() => setScanType('code')}
                  >
                    <Code className="h-4 w-4 mr-2" />
                    Code Scanner
                  </Button>
                </div>
              </div>
              {scanType === 'secret' && <SecretScanner />}
              {scanType === 'vulnerability' && <VulnerabilityScanner />}
              {scanType === 'code' && <CodeScanner />}
            </div>
          )}

          {activeTab === 'tokens' && <TokenVerifier />}

          {activeTab === 'network' && <NetworkIntelligence />}

          {activeTab === 'reports' && <AnalyticsDashboard />}

          {activeTab === 'team' && <TeamManagement />}
        </main>
      </div>
      <Toaster />
    </div>
    </AuthGuard>
  )
}