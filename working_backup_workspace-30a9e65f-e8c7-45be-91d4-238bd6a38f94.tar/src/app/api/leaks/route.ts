import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const monitorId = searchParams.get('monitorId')
    const userId = searchParams.get('userId')
    const severity = searchParams.get('severity')
    const status = searchParams.get('status')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const where: any = {
      monitor: {
        userId
      }
    }

    if (monitorId) {
      where.monitorId = monitorId
    }

    if (severity) {
      where.severity = severity
    }

    if (status) {
      where.status = status
    }

    const leaks = await db.leak.findMany({
      where,
      include: {
        monitor: {
          select: { id: true, name: true, type: true, target: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    return NextResponse.json({ leaks })
  } catch (error) {
    console.error('Error fetching leaks:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { monitorId, type, severity, title, description, content, source, metadata } = body

    if (!monitorId || !type || !severity || !title || !content) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Verify the monitor exists and belongs to a user
    const monitor = await db.monitor.findUnique({
      where: { id: monitorId },
      include: { user: true }
    })

    if (!monitor) {
      return NextResponse.json({ error: 'Monitor not found' }, { status: 404 })
    }

    const leak = await db.leak.create({
      data: {
        monitorId,
        type,
        severity,
        title,
        description,
        content,
        source,
        metadata: JSON.stringify(metadata || {}),
      },
      include: {
        monitor: {
          select: { id: true, name: true, type: true, target: true }
        }
      }
    })

    // Create an alert for the leak
    await db.alert.create({
      data: {
        title: `Leak Detected: ${title}`,
        message: description || `A ${type} leak was detected in ${monitor.name}`,
        type: 'LEAK_DETECTED',
        severity,
        sourceId: leak.id,
        sourceType: 'leak',
        userId: monitor.userId,
        monitorId,
      }
    })

    return NextResponse.json({ leak }, { status: 201 })
  } catch (error) {
    console.error('Error creating leak:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}