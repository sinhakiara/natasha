import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : undefined

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const verifications = await db.tokenVerification.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json({ verifications })
  } catch (error) {
    console.error('Error fetching token verifications:', error)
    return NextResponse.json({ error: 'Failed to fetch token verifications' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { token, type, service, userId } = body

    if (!userId || !token || !type || !service) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const verification = await db.tokenVerification.create({
      data: {
        token,
        type,
        service,
        userId,
        status: 'PENDING',
      },
    })

    // Simulate verification process (in real app, this would be async)
    setTimeout(async () => {
      try {
        // Mock verification logic
        const isValid = Math.random() > 0.3 // 70% success rate for demo
        
        const metadata = {
          verifiedAt: new Date().toISOString(),
          ...(type === 'GITHUB' && isValid && {
            username: 'demo-user',
            scopes: ['repo', 'user'],
            expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          }),
          ...(type === 'AWS' && isValid && {
            account: '123456789012',
            region: 'us-east-1',
            permissions: ['read', 'write']
          }),
          ...(!isValid && {
            error: 'Token validation failed',
            reason: 'Invalid or expired token'
          })
        }

        await db.tokenVerification.update({
          where: { id: verification.id },
          data: {
            isValid,
            status: isValid ? 'VERIFIED' : 'FAILED',
            metadata: JSON.stringify(metadata)
          }
        })
      } catch (error) {
        console.error('Error updating verification:', error)
        await db.tokenVerification.update({
          where: { id: verification.id },
          data: {
            isValid: false,
            status: 'ERROR',
            metadata: JSON.stringify({ error: 'Verification process failed' })
          }
        })
      }
    }, 2000) // 2 second delay for demo

    return NextResponse.json({ verification })
  } catch (error) {
    console.error('Error creating token verification:', error)
    return NextResponse.json({ error: 'Failed to create token verification' }, { status: 500 })
  }
}