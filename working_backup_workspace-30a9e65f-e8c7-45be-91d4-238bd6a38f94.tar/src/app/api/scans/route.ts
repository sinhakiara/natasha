import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const organizationId = searchParams.get('organizationId')
    const status = searchParams.get('status')
    const type = searchParams.get('type')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    const where: any = {
      userId,
      ...(organizationId && { organizationId }),
      ...(status && { status }),
      ...(type && { type }),
    }

    const scans = await db.scan.findMany({
      where,
      include: {
        user: {
          select: { id: true, name: true, email: true }
        },
        organization: {
          select: { id: true, name: true }
        },
        findings: {
          select: {
            id: true,
            type: true,
            severity: true,
            title: true,
            isValid: true,
            createdAt: true
          }
        },
        _count: {
          select: { findings: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    return NextResponse.json({ scans })
  } catch (error) {
    console.error('Error fetching scans:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, target, type, config, userId, organizationId } = body

    if (!name || !target || !type || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const scan = await db.scan.create({
      data: {
        name,
        target,
        type,
        config: JSON.stringify(config || {}),
        status: 'PENDING',
        userId,
        organizationId,
      },
      include: {
        user: {
          select: { id: true, name: true, email: true }
        },
        organization: {
          select: { id: true, name: true }
        }
      }
    })

    // Start the scan process asynchronously
    startScanProcess(scan.id, target, type, config || {})

    return NextResponse.json({ scan }, { status: 201 })
  } catch (error) {
    console.error('Error creating scan:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function startScanProcess(scanId: string, target: string, type: string, config: any) {
  try {
    console.log(`Starting scan process for ${scanId}: ${target} (${type})`)
    
    // Update scan status to running
    await db.scan.update({
      where: { id: scanId },
      data: { 
        status: 'RUNNING',
        startedAt: new Date()
      }
    })

    console.log(`Scan ${scanId} status updated to RUNNING`)

    // Perform the actual scan based on type
    const scanner = new SecretScanner(config)
    const findings = await scanner.scan(target, type)
    
    console.log(`Scan ${scanId} completed with ${findings.length} findings`)

    // Save findings to database
    for (const finding of findings) {
      await db.finding.create({
        data: {
          scanId,
          type: finding.type,
          severity: finding.severity,
          title: finding.title,
          description: finding.description,
          content: finding.content,
          redactedContent: finding.redactedContent,
          source: finding.source,
          metadata: JSON.stringify(finding.metadata || {}),
          isVerified: finding.isVerified || false,
          isValid: finding.isValid,
        }
      })
    }

    console.log(`Findings saved to database for scan ${scanId}`)

    // Update scan status to completed
    await db.scan.update({
      where: { id: scanId },
      data: { 
        status: 'COMPLETED',
        completedAt: new Date(),
        result: JSON.stringify({
          totalFindings: findings.length,
          summary: {
            critical: findings.filter(f => f.severity === 'CRITICAL').length,
            high: findings.filter(f => f.severity === 'HIGH').length,
            medium: findings.filter(f => f.severity === 'MEDIUM').length,
            low: findings.filter(f => f.severity === 'LOW').length,
          }
        })
      }
    })

    console.log(`Scan ${scanId} marked as COMPLETED`)

    // Create an alert for the completed scan
    const scan = await db.scan.findUnique({
      where: { id: scanId },
      include: { user: true }
    })

    if (scan && findings.length > 0) {
      await db.alert.create({
        data: {
          title: `Scan Completed: ${scan.name}`,
          message: `Scan completed with ${findings.length} findings detected`,
          type: 'SCAN_COMPLETED',
          severity: findings.some(f => f.severity === 'CRITICAL') ? 'CRITICAL' : 'MEDIUM',
          sourceId: scanId,
          sourceType: 'scan',
          userId: scan.userId,
        }
      })
    }

  } catch (error) {
    console.error('Error during scan process:', error)
    
    // Update scan status to failed
    await db.scan.update({
      where: { id: scanId },
      data: { 
        status: 'FAILED',
        completedAt: new Date()
      }
    })
    
    console.log(`Scan ${scanId} marked as FAILED`)
  }
}

// Export the startScanProcess function for use in other modules
export { startScanProcess }
class SecretScanner {
  private config: any

  constructor(config: any = {}) {
    this.config = {
      maxFileSize: 10 * 1024 * 1024, // 10MB
      includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.rs', '.c', '.cpp', '.h', '.json', '.yaml', '.yml', '.env', '.conf', '.config', '.xml', '.properties', '.ini', '.sql'],
      excludePaths: ['node_modules', '.git', 'dist', 'build', 'vendor', '__pycache__', '.pytest_cache'],
      secretPatterns: this.getDefaultSecretPatterns(),
      ...config
    }
  }

  private getDefaultSecretPatterns() {
    return {
      // AWS Patterns - Enhanced with more specific validation
      'aws_access_key_id': /AKIA[0-9A-Z]{16}(?![0-9A-Z])/g,
      'aws_secret_access_key': /(?<![A-Za-z0-9+/])[0-9a-zA-Z/+]{40}(?![A-Za-z0-9+/])/g,
      'aws_session_token': /(?<![A-Za-z0-9+/=])(?:AwsSecret[A-Za-z0-9/+=]{40}|FwoGZXIvYXdzED[a-zA-Z0-9+/]{200,})(?![A-Za-z0-9+/=])/g,
      'aws_account_id': /(?<![0-9])[0-9]{12}(?![0-9])/g,
      'aws_arn': /arn:aws:[a-z0-9-]+:[a-z0-9-]*:[0-9]{12}:[a-zA-Z0-9-_/:]+/g,
      
      // GitHub Patterns - Enhanced with newer token formats
      'github_personal_access_token': /(?<![A-Za-z0-9_])(?:ghp_[0-9a-zA-Z_]{36}|github_pat_[0-9a-zA-Z_]{80,})(?![A-Za-z0-9_])/g,
      'github_oauth_access_token': /(?<![A-Za-z0-9_])gho_[0-9a-zA-Z_]{36}(?![A-Za-z0-9_])/g,
      'github_app_token': /(?<![A-Za-z0-9_])ghu_[0-9a-zA-Z_]{36}(?![A-Za-z0-9_])/g,
      'github_refresh_token': /(?<![A-Za-z0-9_])ghr_[0-9a-zA-Z_]{36}(?![A-Za-z0-9_])/g,
      'github_fine_grained_token': /(?<![A-Za-z0-9_])github_pat_[0-9a-zA-Z_]{80,}(?![A-Za-z0-9_])/g,
      
      // Google Cloud Patterns - Enhanced
      'google_api_key': /(?<![A-Za-z0-9_-])AIza[0-9A-Za-z\-_]{35}(?![A-Za-z0-9_-])/g,
      'google_oauth_client_id': /(?<![A-Za-z0-9_-])[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com(?![A-Za-z0-9_-])/g,
      'google_oauth_client_secret': /(?<![A-Za-z0-9_-])[0-9A-Za-z_-]{24}(?![A-Za-z0-9_-])/g,
      'google_service_account_key': /(?<![A-Za-z0-9_-])"type":\s*"service_account"|(?<![A-Za-z0-9_-])private_key":\s*"-----BEGIN PRIVATE KEY-----(?![A-Za-z0-9_-])/g,
      'google_fcm_key': /(?<![A-Za-z0-9_-])AAAA[A-Za-z0-9_-]{170}(?![A-Za-z0-9_-])/g,
      'google_recaptcha_key': /(?<![A-Za-z0-9_-])6L[0-9A-Za-z_-]{38}(?![A-Za-z0-9_-])/g,
      
      // Azure Patterns - Enhanced
      'azure_client_secret': /(?<![A-Za-z0-9~\-_])[0-9a-zA-Z~\-_]{32,}(?![A-Za-z0-9~\-_])/g,
      'azure_storage_key': /(?<![A-Za-z0-9+/=])[A-Za-z0-9+/]{88}==(?![A-Za-z0-9+/=])/g,
      'azure_sas_token': /(?<![A-Za-z0-9&=?])\?sv=[0-9a-zA-Z-]+&ss=[a-z]+&srt=[a-z]+&sp=[a-z]+&se=[0-9T-]+&sig=[a-zA-Z0-9+/=]+(?![A-Za-z0-9&=?])/g,
      'azure_connection_string': /(?<![A-Za-z0-9])DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[^;]+(?![A-Za-z0-9])/g,
      
      // Database Credentials - Enhanced with more database types
      'database_url': /(?<![A-Za-z0-9:])(?:postgresql|mysql|mongodb|redis|sqlite|mssql|oracle|cockroachdb):\/\/[^:\s]+:[^@\s]+@[^\/\s]+\/[^\s\'"<>]+(?![A-Za-z0-9:])/g,
      'jdbc_url': /(?<![A-Za-z0-9:])jdbc:[^:]+:[^;]+|(?<![A-Za-z0-9:])jdbc:[^:]+:\/\/[^:]+:[^@]+@[^\/]+\/[^\s;]+(?![A-Za-z0-9:])/g,
      'mongo_connection_string': /(?<![A-Za-z0-9:])mongodb(?:\+srv)?:\/\/[^:\s]+:[^@\s]+@[^\/\s]+\/[^\s\'"<>]+(?![A-Za-z0-9:])/g,
      'redis_url': /(?<![A-Za-z0-9:])redis:\/\/[:\w]+@[^:\s]+:[^@\s]+(?![A-Za-z0-9:])/g,
      'postgres_url': /(?<![A-Za-z0-9:])postgres:\/\/[^:\s]+:[^@\s]+@[^\/\s]+\/[^\s\'"<>]+(?![A-Za-z0-9:])/g,
      
      // Private Keys and Certificates - Enhanced with more key types
      'private_key': /(?<![A-Za-z0-9])-----BEGIN(?: [A-Z]+)? PRIVATE KEY-----[\s\S]*?-----END(?: [A-Z]+)? PRIVATE KEY-----(?![A-Za-z0-9])/g,
      'rsa_private_key': /(?<![A-Za-z0-9])-----BEGIN RSA PRIVATE KEY-----[\s\S]*?-----END RSA PRIVATE KEY-----(?![A-Za-z0-9])/g,
      'ssh_private_key': /(?<![A-Za-z0-9])-----BEGIN OPENSSH PRIVATE KEY-----[\s\S]*?-----END OPENSSH PRIVATE KEY-----(?![A-Za-z0-9])/g,
      'ssh_ed25519_private_key': /(?<![A-Za-z0-9])-----BEGIN ED25519 PRIVATE KEY-----[\s\S]*?-----END ED25519 PRIVATE KEY-----(?![A-Za-z0-9])/g,
      'ssh_ecdsa_private_key': /(?<![A-Za-z0-9])-----BEGIN EC PRIVATE KEY-----[\s\S]*?-----END EC PRIVATE KEY-----(?![A-Za-z0-9])/g,
      'certificate': /(?<![A-Za-z0-9])-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----(?![A-Za-z0-9])/g,
      'pgp_private_key': /(?<![A-Za-z0-9])-----BEGIN PGP PRIVATE KEY BLOCK-----[\s\S]*?-----END PGP PRIVATE KEY BLOCK-----(?![A-Za-z0-9])/g,
      'ssh_public_key': /(?<![A-Za-z0-9])ssh-(?:rsa|ed25519|ecdsa) [A-Za-z0-9+/]+ [^@\s]+@[^@\s]+(?![A-Za-z0-9])/g,
      
      // Authentication Tokens - Enhanced with more formats
      'bearer_token': /(?<![A-Za-z0-9])bearer\s+[a-zA-Z0-9_\-\.~=+/]{10,}|(?<![A-Za-z0-9])authorization:\s*bearer\s+[a-zA-Z0-9_\-\.~=+/]{10,}(?![A-Za-z0-9])/gi,
      'basic_auth': /(?<![A-Za-z0-9])basic\s+[a-zA-Z0-9+/=]+|(?<![A-Za-z0-9])authorization:\s*basic\s+[a-zA-Z0-9+/=]+(?![A-Za-z0-9])/gi,
      'api_key': /(?<![A-Za-z0-9])api[_-]?key[\s\'":=]+[a-zA-Z0-9_\-]{16,}|(?<![A-Za-z0-9])x-api-key[\s\'":=]+[a-zA-Z0-9_\-]{16,}|(?<![A-Za-z0-9])x[_-]?api[_-]?key[\s\'":=]+[a-zA-Z0-9_\-]{16,}(?![A-Za-z0-9])/gi,
      'auth_token': /(?<![A-Za-z0-9])auth[_-]?token[\s\'":=]+[a-zA-Z0-9_\-]{16,}|(?<![A-Za-z0-9])authentication[_-]?token[\s\'":=]+[a-zA-Z0-9_\-]{16,}(?![A-Za-z0-9])/gi,
      'access_token': /(?<![A-Za-z0-9])access[_-]?token[\s\'":=]+[a-zA-Z0-9_\-]{16,}(?![A-Za-z0-9])/gi,
      'refresh_token': /(?<![A-Za-z0-9])refresh[_-]?token[\s\'":=]+[a-zA-Z0-9_\-]{16,}(?![A-Za-z0-9])/gi,
      
      // JWT Tokens - Enhanced with better validation
      'jwt_token': /(?<![A-Za-z0-9_-])eyJ[a-zA-Z0-9_-]{10,}\.eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}(?![A-Za-z0-9_-])/g,
      
      // Web Services - Enhanced with more services
      'slack_token': /(?<![A-Za-z0-9])xox[baprs]-[0-9a-zA-Z-]{43,}|(?<![A-Za-z0-9])xox[beo]-[0-9a-zA-Z-]{24,}(?![A-Za-z0-9])/g,
      'slack_webhook': /(?<![A-Za-z0-9])https:\/\/hooks\.slack\.com\/services\/[A-Z0-9]+\/[A-Z0-9]+\/[A-Za-z0-9_]+(?![A-Za-z0-9])/g,
      'discord_token': /(?<![A-Za-z0-9])[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}|(?<![A-Za-z0-9])mfa\.[\w-]{84}(?![A-Za-z0-9])/g,
      'discord_webhook': /(?<![A-Za-z0-9])https:\/\/discord\.com\/api\/webhooks\/[0-9]+\/[A-Za-z0-9_-]+(?![A-Za-z0-9])/g,
      'discord_bot_token': /(?<![A-Za-z0-9])[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}(?![A-Za-z0-9])/g,
      
      // Payment Services - Enhanced
      'stripe_api_key': /(?<![A-Za-z0-9])sk_[a-zA-Z0-9_]{24,}(?![A-Za-z0-9])/g,
      'stripe_publishable_key': /(?<![A-Za-z0-9])pk_[a-zA-Z0-9_]{24,}(?![A-Za-z0-9])/g,
      'stripe_webhook': /(?<![A-Za-z0-9])whsec_[a-zA-Z0-9_]{43,}(?![A-Za-z0-9])/g,
      'paypal_client_id': /(?<![A-Za-z0-9])[A-Za-z0-9]{16}(?![A-Za-z0-9])/g,
      'paypal_client_secret': /(?<![A-Za-z0-9])[A-Za-z0-9]{32}(?![A-Za-z0-9])/g,
      'braintree_api_key': /(?<![A-Za-z0-9])[a-f0-9]{32}(?![A-Za-z0-9])/g,
      
      // Cloud Services - Enhanced
      'heroku_api_key': /(?<![A-Za-z0-9])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?![A-Za-z0-9])/g,
      'netlify_access_token': /(?<![A-Za-z0-9])[a-zA-Z0-9_-]{43,}(?![A-Za-z0-9])/g,
      'shopify_token': /(?<![A-Za-z0-9])shpat_[a-zA-Z0-9_]{32}|(?<![A-Za-z0-9])shpca_[a-zA-Z0-9_]{32}|(?<![A-Za-z0-9])shpss_[a-zA-Z0-9_]{32}(?![A-Za-z0-9])/g,
      'digitalocean_token': /(?<![A-Za-z0-9])dop_v1_[a-f0-9]{64}(?![A-Za-z0-9])/g,
      'cloudflare_api_key': /(?<![A-Za-z0-9])[a-f0-9]{37}(?![A-Za-z0-9])/g,
      'cloudflare_origin_ca_key': /(?<![A-Za-z0-9])v1\.0-[a-f0-9]{56}(?![A-Za-z0-9])/g,
      
      // Communication Services - Enhanced
      'twilio_api_key': /(?<![A-Za-z0-9])SK[a-zA-Z0-9]{32}(?![A-Za-z0-9])/g,
      'twilio_auth_token': /(?<![A-Za-z0-9])[a-zA-Z0-9]{32}(?![A-Za-z0-9])/g,
      'twilio_account_sid': /(?<![A-Za-z0-9])AC[a-zA-Z0-9]{32}(?![A-Za-z0-9])/g,
      'sendgrid_api_key': /(?<![A-Za-z0-9])SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}(?![A-Za-z0-9])/g,
      'mailgun_api_key': /(?<![A-Za-z0-9])key-[a-zA-Z0-9]{32}(?![A-Za-z0-9])/g,
      'postmark_api_key': /(?<![A-Za-z0-9])postmark-api-token[a-zA-Z0-9]{32}(?![A-Za-z0-9])/g,
      
      // Monitoring & Analytics - Enhanced
      'datadog_api_key': /(?<![A-Za-z0-9])[a-zA-Z0-9]{32}(?![A-Za-z0-9])/g,
      'datadog_app_key': /(?<![A-Za-z0-9])[a-zA-Z0-9]{40}(?![A-Za-z0-9])/g,
      'new_relic_api_key': /(?<![A-Za-z0-9])NRAK-[a-zA-Z0-9]{27}(?![A-Za-z0-9])/g,
      'new_relic_browser_key': /(?<![A-Za-z0-9])[a-f0-9]{32}(?![A-Za-z0-9])/g,
      'pagerduty_api_key': /(?<![A-Za-z0-9])P[a-zA-Z0-9]{40}(?![A-Za-z0-9])/g,
      'splunk_token': /(?<![A-Za-z0-9])[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}(?![A-Za-z0-9])/g,
      'grafana_api_key': /(?<![A-Za-z0-9])eyJ[a-zA-Z0-9_-]{200,}(?![A-Za-z0-9])/g,
      
      // Development & DevOps - Enhanced
      'npm_token': /(?<![A-Za-z0-9])npm_[a-zA-Z0-9_-]{36}(?![A-Za-z0-9])/g,
      'pypi_api_token': /(?<![A-Za-z0-9])pypi-[a-zA-Z0-9_-]{150,}(?![A-Za-z0-9])/g,
      'docker_hub_token': /(?<![A-Za-z0-9])dckr_pat_[a-zA-Z0-9_-]{64}(?![A-Za-z0-9])/g,
      'github_actions_token': /(?<![A-Za-z0-9])ghs_[a-zA-Z0-9_]{36}(?![A-Za-z0-9])/g,
      'gitlab_personal_access_token': /(?<![A-Za-z0-9])glpat-[a-zA-Z0-9_-]{20}(?![A-Za-z0-9])/g,
      'bitbucket_token': /(?<![A-Za-z0-9])[a-zA-Z0-9:_-]{40}(?![A-Za-z0-9])/g,
      
      // Project Management - Enhanced
      'jira_api_token': /(?<![A-Za-z0-9])[a-zA-Z0-9]{24}(?![A-Za-z0-9])/g,
      'trello_api_key': /(?<![A-Za-z0-9])[a-f0-9]{32}(?![A-Za-z0-9])/g,
      'asana_api_key': /(?<![A-Za-z0-9])[0-9]{16}(?![A-Za-z0-9])/g,
      'base64_api_key': /(?<![A-Za-z0-9])[A-Za-z0-9+/]{40,}[=]{0,2}(?![A-Za-z0-9])/g,
      
      // Configuration Files - Enhanced
      'env_file_key': /(?<![A-Za-z0-9])[A-Z_]{2,}=[a-zA-Z0-9_\-\.~=+/]{8,}(?![A-Za-z0-9])/g,
      'config_secret': /(?<![A-Za-z0-9])secret[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{8,}(?![A-Za-z0-9])/gi,
      'credential': /(?<![A-Za-z0-9])credential[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{8,}(?![A-Za-z0-9])/gi,
      'configuration_key': /(?<![A-Za-z0-9])config[_-]?key[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{8,}(?![A-Za-z0-9])/gi,
      
      // Common Security Patterns - Enhanced
      'password': /(?<![A-Za-z0-9])(?:password|pwd|pass|passwd)[\s\'":=]+([^\\s\'"<>]{8,})(?![A-Za-z0-9])/gi,
      'webhook': /(?<![A-Za-z0-9])webhook[_-]?url[\s\'":=]+https?:\/\/[^\s\'"<>]+(?![A-Za-z0-9])/gi,
      'authorization': /(?<![A-Za-z0-9])authorization[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{10,}(?![A-Za-z0-9])/gi,
      'token': /(?<![A-Za-z0-9])token[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{16,}(?![A-Za-z0-9])/gi,
      'secret': /(?<![A-Za-z0-9])secret[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{8,}(?![A-Za-z0-9])/gi,
      
      // Hashed Values - Enhanced with context awareness
      'md5_hash': /(?<![A-Za-z0-9])[a-fA-F0-9]{32}(?![A-Za-z0-9])/g,
      'sha1_hash': /(?<![A-Za-z0-9])[a-fA-F0-9]{40}(?![A-Za-z0-9])/g,
      'sha256_hash': /(?<![A-Za-z0-9])[a-fA-F0-9]{64}(?![A-Za-z0-9])/g,
      'sha512_hash': /(?<![A-Za-z0-9])[a-fA-F0-9]{128}(?![A-Za-z0-9])/g,
      'bcrypt_hash': /(?<![A-Za-z0-9])\$2[aby]?\$\d{1,2}\$[A-Za-z0-9\.\/]{53}(?![A-Za-z0-9])/g,
      
      // Base64 Encoded Data - Enhanced
      'base64_secret': /(?<![A-Za-z0-9])[A-Za-z0-9+/]{40,}[=]{0,2}(?![A-Za-z0-9])/g,
      'base64_url': /(?<![A-Za-z0-9])[A-Za-z0-9_-]{40,}[=]{0,2}(?![A-Za-z0-9])/g,
      
      // Generic API Patterns - Enhanced
      'generic_api_key': /(?<![A-Za-z0-9])[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}(?![A-Za-z0-9])/g,
      'hex_key': /(?<![A-Za-z0-9])[a-fA-F0-9]{32,}(?![A-Za-z0-9])/g,
      'uuid': /(?<![A-Za-z0-9])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?![A-Za-z0-9])/g,
      
      // Additional Enhanced Patterns
      'oauth_token': /(?<![A-Za-z0-9])oauth[_-]?token[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{16,}(?![A-Za-z0-9])/gi,
      'session_token': /(?<![A-Za-z0-9])session[_-]?token[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{16,}(?![A-Za-z0-9])/gi,
      'csrf_token': /(?<![A-Za-z0-9])csrf[_-]?token[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{16,}(?![A-Za-z0-9])/gi,
      'api_secret': /(?<![A-Za-z0-9])api[_-]?secret[\s\'":=]+[a-zA-Z0-9_\-\.~=+/]{16,}(?![A-Za-z0-9])/gi,
      
      // Cryptocurrency Keys - Enhanced
      'bitcoin_private_key': /(?<![A-Za-z0-9])[5KL][1-9A-HJ-NP-Za-km-z]{50}(?![A-Za-z0-9])/g,
      'ethereum_private_key': /(?<![A-Za-z0-9])[0-9a-fA-F]{64}(?![A-Za-z0-9])/g,
      'crypto_wallet_seed': /(?<![A-Za-z0-9])[0-9a-fA-F]{128}(?![A-Za-z0-9])/g,
    }
  }

  async scan(target: string, type: string): Promise<any[]> {
    const findings: any[] = []
    console.log(`Starting scan of ${target} with type ${type}`)

    try {
      if (type === 'SECRET_SCAN') {
        if (target.startsWith('http')) {
          console.log(`Scanning URL: ${target}`)
          // Scan URL/website
          const urlFindings = await this.scanUrl(target)
          findings.push(...urlFindings)
          console.log(`URL scan found ${urlFindings.length} findings`)
        } else if (target.includes('github.com')) {
          console.log(`Scanning GitHub repository: ${target}`)
          // Scan GitHub repository
          const githubFindings = await this.scanGitHubRepository(target)
          findings.push(...githubFindings)
          console.log(`GitHub scan found ${githubFindings.length} findings`)
        } else {
          console.log(`Scanning local path: ${target}`)
          // Scan local directory or file
          const localFindings = await this.scanLocalPath(target)
          findings.push(...localFindings)
          console.log(`Local scan found ${localFindings.length} findings`)
        }
      } else if (type === 'VULNERABILITY_SCAN') {
        console.log(`Scanning vulnerabilities: ${target}`)
        // Basic vulnerability scanning
        const vulnFindings = await this.scanVulnerabilities(target)
        findings.push(...vulnFindings)
        console.log(`Vulnerability scan found ${vulnFindings.length} findings`)
      } else if (type === 'CODE_SCAN') {
        console.log(`Scanning code: ${target}`)
        // Code-specific scanning
        const codeFindings = await this.scanCode(target)
        findings.push(...codeFindings)
        console.log(`Code scan found ${codeFindings.length} findings`)
      }
    } catch (error) {
      console.error('Error during scan:', error)
    }

    console.log(`Total findings from scan: ${findings.length}`)
    return findings
  }

  private async scanUrl(url: string): Promise<any[]> {
    const findings: any[] = []
    console.log(`Starting URL scan for: ${url}`)
    
    try {
      // Fetch the URL content
      console.log(`Fetching content from URL...`)
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Security-SecretScanner/1.0'
        }
      })

      if (response.ok) {
        console.log(`Successfully fetched content from URL`)
        const content = await response.text()
        console.log(`Content length: ${content.length} characters`)
        const urlFindings = this.scanContent(content, url)
        findings.push(...urlFindings)
        console.log(`Found ${urlFindings.length} secrets in URL content`)
      } else {
        console.log(`Failed to fetch URL content: ${response.status} ${response.statusText}`)
      }
    } catch (error) {
      console.error('Error scanning URL:', error)
    }

    return findings
  }

  private async scanGitHubRepository(repoUrl: string): Promise<any[]> {
    const findings: any[] = []
    
    try {
      // Parse GitHub URL
      const { owner, repo } = this.parseGitHubUrl(repoUrl)
      
      if (!owner || !repo) {
        return findings
      }

      // Get repository contents
      const contents = await this.getGitHubRepositoryContents(owner, repo)
      
      // Scan each file
      for (const item of contents) {
        if (item.type === 'file' && this.shouldScanFile(item.path)) {
          const content = await this.getGitHubFileContent(owner, repo, item.path)
          if (content) {
            const fileFindings = this.scanContent(content, `github:${owner}/${repo}/${item.path}`)
            findings.push(...fileFindings)
          }
        }
      }
    } catch (error) {
      console.error('Error scanning GitHub repository:', error)
    }

    return findings
  }

  private async scanLocalPath(path: string): Promise<any[]> {
    // This would be implemented for local file system scanning
    // For now, return empty array as we're in a browser/server environment
    return []
  }

  private async scanVulnerabilities(target: string): Promise<any[]> {
    const findings: any[] = []
    
    try {
      if (target.startsWith('http')) {
        // Basic web vulnerability checks
        const vulnFindings = await this.checkWebVulnerabilities(target)
        findings.push(...vulnFindings)
      }
    } catch (error) {
      console.error('Error scanning vulnerabilities:', error)
    }

    return findings
  }

  private async scanCode(target: string): Promise<any[]> {
    const findings: any[] = []
    
    try {
      // Code-specific security checks
      const codeFindings = await this.checkCodeSecurity(target)
      findings.push(...codeFindings)
    } catch (error) {
      console.error('Error scanning code:', error)
    }

    return findings
  }

  private scanContent(content: string, source: string): any[] {
    const findings: any[] = []
    console.log(`Scanning content from ${source}, length: ${content.length}`)

    for (const [patternName, pattern] of Object.entries(this.config.secretPatterns)) {
      const matches = content.matchAll(pattern)
      let matchCount = 0
      
      for (const match of matches) {
        matchCount++
        const secret = match[1] || match[0]
        
        // Skip false positives
        if (this.isFalsePositive(secret, patternName, content, match.index)) {
          continue
        }

        const finding = {
          type: this.mapPatternToFindingType(patternName),
          severity: this.getSeverityForPattern(patternName),
          title: `${this.mapPatternToFindingType(patternName)} detected`,
          description: `A potential ${patternName.replace(/_/g, ' ')} was found`,
          content: secret, // Store the original secret
          redactedContent: this.redactSecret(secret), // Store redacted version separately
          source,
          metadata: {
            pattern: patternName,
            line: this.getLineNumber(content, match.index),
            matchedText: secret,
            context: this.getContext(content, match.index, 50)
          },
          isVerified: false,
          isValid: null
        }

        findings.push(finding)
      }
      
      if (matchCount > 0) {
        console.log(`Pattern ${patternName} found ${matchCount} matches`)
      }
    }

    console.log(`Total findings from content scan: ${findings.length}`)
    return findings
  }

  private parseGitHubUrl(url: string): { owner: string; repo: string } {
    const match = url.match(/github\.com\/([^\/]+)\/([^\/\?#]+)/)
    return match ? { owner: match[1], repo: match[2] } : { owner: '', repo: '' }
  }

  private async getGitHubRepositoryContents(owner: string, repo: string, path: string = ''): Promise<any[]> {
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`
    const headers: any = {
      'User-Agent': 'Security-SecretScanner/1.0'
    }
    
    // Add GitHub API key if available
    const githubApiKey = this.config.githubApiKey
    if (githubApiKey) {
      headers['Authorization'] = `token ${githubApiKey}`
    }
    
    const response = await fetch(url, { headers })
    
    if (!response.ok) {
      return []
    }

    const data = await response.json()
    
    if (Array.isArray(data)) {
      const contents: any[] = []
      
      for (const item of data) {
        if (item.type === 'dir') {
          const subContents = await this.getGitHubRepositoryContents(owner, repo, item.path)
          contents.push(...subContents)
        } else {
          contents.push(item)
        }
      }
      
      return contents
    }

    return [data]
  }

  private async getGitHubFileContent(owner: string, repo: string, path: string): Promise<string | null> {
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`
    const headers: any = {
      'User-Agent': 'Security-SecretScanner/1.0'
    }
    
    // Add GitHub API key if available
    const githubApiKey = this.config.githubApiKey
    if (githubApiKey) {
      headers['Authorization'] = `token ${githubApiKey}`
    }
    
    const response = await fetch(url, { headers })
    
    if (!response.ok) {
      return null
    }

    const data = await response.json()
    return data.content ? Buffer.from(data.content, 'base64').toString('utf-8') : null
  }

  private shouldScanFile(path: string): boolean {
    const ext = path.substring(path.lastIndexOf('.')).toLowerCase()
    if (!this.config.includeExtensions.includes(ext)) {
      return false
    }

    for (const excludePath of this.config.excludePaths) {
      if (path.includes(excludePath)) {
        return false
      }
    }

    return true
  }

  private isFalsePositive(secret: string, patternName: string, content: string, index: number): boolean {
    // Ensure all patterns are valid RegExp objects
    const falsePositives = [
      /example/i,
      /test/i,
      /dummy/i,
      /placeholder/i,
      /your_/i,
      /change_me/i,
    ]

    // Check regex patterns
    try {
      for (const fp of falsePositives) {
        if (fp.test(secret)) {
          return true
        }
      }
    } catch (error) {
      console.error('Error in false positive check:', error)
    }

    // Check function-based patterns
    if (secret.length < 10 && secret.toLowerCase().includes('secret')) {
      return true
    }
    
    if (secret.toLowerCase() === 'password') {
      return true
    }

    return false
  }

  private mapPatternToFindingType(patternName: string): 'SECRET' | 'VULNERABILITY' | 'MISCONFIGURATION' | 'CUSTOM' {
    const mapping: Record<string, 'SECRET' | 'VULNERABILITY' | 'MISCONFIGURATION' | 'CUSTOM'> = {
      // API Keys and Tokens
      'aws_access_key_id': 'SECRET',
      'aws_secret_access_key': 'SECRET',
      'aws_session_token': 'SECRET',
      'github_personal_access_token': 'SECRET',
      'github_oauth_access_token': 'SECRET',
      'github_app_token': 'SECRET',
      'github_refresh_token': 'SECRET',
      'slack_token': 'SECRET',
      'slack_webhook': 'SECRET',
      'discord_token': 'SECRET',
      'discord_webhook': 'SECRET',
      
      // Cloud Provider Keys
      'google_api_key': 'SECRET',
      'google_oauth_client_id': 'SECRET',
      'google_oauth_client_secret': 'SECRET',
      'google_service_account_key': 'SECRET',
      'azure_client_secret': 'SECRET',
      'azure_storage_key': 'SECRET',
      'azure_sas_token': 'SECRET',
      
      // Database Credentials
      'database_url': 'SECRET',
      'jdbc_url': 'SECRET',
      'mongo_connection_string': 'SECRET',
      
      // Private Keys and Certificates
      'private_key': 'SECRET',
      'rsa_private_key': 'SECRET',
      'ssh_private_key': 'SECRET',
      'certificate': 'SECRET',
      'pgp_private_key': 'SECRET',
      
      // Authentication Tokens
      'bearer_token': 'SECRET',
      'basic_auth': 'SECRET',
      'api_key': 'SECRET',
      'auth_token': 'SECRET',
      
      // Web Services
      'heroku_api_key': 'SECRET',
      'netlify_access_token': 'SECRET',
      'shopify_token': 'SECRET',
      'stripe_api_key': 'SECRET',
      'stripe_publishable_key': 'SECRET',
      'stripe_webhook': 'SECRET',
      
      // Additional Service Tokens
      'twilio_api_key': 'SECRET',
      'twilio_auth_token': 'SECRET',
      'sendgrid_api_key': 'SECRET',
      'mailgun_api_key': 'SECRET',
      'datadog_api_key': 'SECRET',
      'new_relic_api_key': 'SECRET',
      'pagerduty_api_key': 'SECRET',
      'splunk_token': 'SECRET',
      'jira_api_token': 'SECRET',
      'docker_hub_token': 'SECRET',
      'npm_token': 'SECRET',
      'pypi_api_token': 'SECRET',
      
      // Configuration and Environment Files
      'env_file_key': 'SECRET',
      'config_secret': 'SECRET',
      'credential': 'SECRET',
      
      // Other Common Patterns
      'password': 'SECRET',
      'webhook': 'SECRET',
      'authorization': 'SECRET',
      'token': 'SECRET',
      
      // JWT Tokens
      'jwt_token': 'SECRET',
      
      // Hashed Values
      'md5_hash': 'MISCONFIGURATION',
      'sha1_hash': 'MISCONFIGURATION',
      'sha256_hash': 'MISCONFIGURATION',
      'sha512_hash': 'MISCONFIGURATION',
      
      // Base64 Encoded Data
      'base64_secret': 'SECRET',
      
      // AWS Specific Patterns
      'aws_account_id': 'MISCONFIGURATION',
      'aws_arn': 'MISCONFIGURATION',
      
      // Generic API Patterns
      'generic_api_key': 'SECRET',
      'hex_key': 'SECRET',
    }

    const result = mapping[patternName] || 'SECRET'
    return result
  }

  private getSeverityForPattern(patternName: string): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
    const severity: Record<string, 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'> = {
      // API Keys and Tokens
      'aws_access_key_id': 'CRITICAL',
      'aws_secret_access_key': 'CRITICAL',
      'aws_session_token': 'CRITICAL',
      'github_personal_access_token': 'HIGH',
      'github_oauth_access_token': 'HIGH',
      'github_app_token': 'HIGH',
      'github_refresh_token': 'HIGH',
      'slack_token': 'HIGH',
      'slack_webhook': 'MEDIUM',
      'discord_token': 'HIGH',
      'discord_webhook': 'MEDIUM',
      
      // Cloud Provider Keys
      'google_api_key': 'HIGH',
      'google_oauth_client_id': 'MEDIUM',
      'google_oauth_client_secret': 'HIGH',
      'google_service_account_key': 'CRITICAL',
      'azure_client_secret': 'HIGH',
      'azure_storage_key': 'HIGH',
      'azure_sas_token': 'HIGH',
      
      // Database Credentials
      'database_url': 'HIGH',
      'jdbc_url': 'HIGH',
      'mongo_connection_string': 'HIGH',
      
      // Private Keys and Certificates
      'private_key': 'CRITICAL',
      'rsa_private_key': 'CRITICAL',
      'ssh_private_key': 'CRITICAL',
      'certificate': 'MEDIUM',
      'pgp_private_key': 'CRITICAL',
      
      // Authentication Tokens
      'bearer_token': 'HIGH',
      'basic_auth': 'MEDIUM',
      'api_key': 'HIGH',
      'auth_token': 'HIGH',
      
      // Web Services
      'heroku_api_key': 'HIGH',
      'netlify_access_token': 'HIGH',
      'shopify_token': 'HIGH',
      'stripe_api_key': 'CRITICAL',
      'stripe_publishable_key': 'MEDIUM',
      'stripe_webhook': 'HIGH',
      
      // Additional Service Tokens
      'twilio_api_key': 'HIGH',
      'twilio_auth_token': 'HIGH',
      'sendgrid_api_key': 'HIGH',
      'mailgun_api_key': 'HIGH',
      'datadog_api_key': 'HIGH',
      'new_relic_api_key': 'HIGH',
      'pagerduty_api_key': 'HIGH',
      'splunk_token': 'MEDIUM',
      'jira_api_token': 'HIGH',
      'docker_hub_token': 'HIGH',
      'npm_token': 'HIGH',
      'pypi_api_token': 'HIGH',
      
      // Configuration and Environment Files
      'env_file_key': 'HIGH',
      'config_secret': 'HIGH',
      'credential': 'HIGH',
      
      // Other Common Patterns
      'password': 'HIGH',
      'webhook': 'MEDIUM',
      'authorization': 'HIGH',
      'token': 'HIGH',
      
      // JWT Tokens
      'jwt_token': 'HIGH',
      
      // Hashed Values
      'md5_hash': 'LOW',
      'sha1_hash': 'LOW',
      'sha256_hash': 'LOW',
      'sha512_hash': 'LOW',
      
      // Base64 Encoded Data
      'base64_secret': 'MEDIUM',
      
      // AWS Specific Patterns
      'aws_account_id': 'LOW',
      'aws_arn': 'LOW',
      
      // Generic API Patterns
      'generic_api_key': 'MEDIUM',
      'hex_key': 'MEDIUM',
    }

    return severity[patternName] || 'MEDIUM'
  }

  private redactSecret(secret: string): string {
    if (secret.length <= 8) {
      return '*'.repeat(secret.length)
    }
    
    const visibleChars = 4
    return secret.substring(0, visibleChars) + '*'.repeat(secret.length - visibleChars * 2) + secret.substring(secret.length - visibleChars)
  }

  private getLineNumber(content: string, index: number): number {
    const lines = content.substring(0, index).split('\n')
    return lines.length
  }

  private getContext(content: string, index: number, contextSize: number): string {
    const start = Math.max(0, index - contextSize)
    const end = Math.min(content.length, index + contextSize)
    return content.substring(start, end)
  }

  private async checkWebVulnerabilities(target: string): Promise<any[]> {
    const findings: any[] = []
    
    try {
      if (target.startsWith('http')) {
        console.log(`Checking web vulnerabilities for: ${target}`)
        
        // Fetch the target URL
        const response = await fetch(target, {
          headers: {
            'User-Agent': 'Security-VulnerabilityScanner/1.0'
          },
          timeout: 10000 // 10 second timeout
        })

        if (response.ok) {
          const content = await response.text()
          const headers = response.headers

          // Check for common security headers
          const securityHeaders = {
            'X-Content-Type-Options': headers.get('X-Content-Type-Options'),
            'X-Frame-Options': headers.get('X-Frame-Options'),
            'X-XSS-Protection': headers.get('X-XSS-Protection'),
            'Strict-Transport-Security': headers.get('Strict-Transport-Security'),
            'Content-Security-Policy': headers.get('Content-Security-Policy'),
            'Referrer-Policy': headers.get('Referrer-Policy'),
            'Permissions-Policy': headers.get('Permissions-Policy')
          }

          // Check for missing security headers
          const missingHeaders = Object.entries(securityHeaders)
            .filter(([key, value]) => !value)
            .map(([key]) => key)

          if (missingHeaders.length > 0) {
            findings.push({
              type: 'VULNERABILITY',
              severity: 'MEDIUM',
              title: 'Missing Security Headers',
              description: `Missing security headers: ${missingHeaders.join(', ')}`,
              content: `Missing headers: ${missingHeaders.join(', ')}`,
              source: target,
              metadata: {
                pattern: 'missing_security_headers',
                missingHeaders: missingHeaders,
                recommendation: 'Implement missing security headers to improve security posture'
              },
              isVerified: false,
              isValid: true
            })
          }

          // Check for potentially sensitive information exposure
          const sensitiveInfoPatterns = [
            { pattern: /debug\s*=\s*true/gi, type: 'Debug Mode', severity: 'MEDIUM' },
            { pattern: /test\s*=\s*true/gi, type: 'Test Mode', severity: 'LOW' },
            { pattern: /password\s*=\s*["\'][^"\']+["\']/gi, type: 'Hardcoded Password', severity: 'HIGH' },
            { pattern: /api[_-]?key\s*=\s*["\'][^"\']+["\']/gi, type: 'Exposed API Key', severity: 'HIGH' },
            { pattern: /secret\s*=\s*["\'][^"\']+["\']/gi, type: 'Exposed Secret', severity: 'HIGH' }
          ]

          for (const { pattern, type, severity } of sensitiveInfoPatterns) {
            const matches = content.match(pattern)
            if (matches) {
              findings.push({
                type: 'VULNERABILITY',
                severity,
                title: `${type} Exposure`,
                description: `Found ${type.toLowerCase()} in web content`,
                content: `Found ${matches.length} instances of ${type.toLowerCase()}`,
                source: target,
                metadata: {
                  pattern: type.toLowerCase().replace(/\s+/g, '_'),
                  matchCount: matches.length,
                  recommendation: `Remove ${type.toLowerCase()} from production code`
                },
                isVerified: false,
                isValid: true
              })
            }
          }

          // Check for outdated software versions in HTML comments
          const versionPatterns = [
            { pattern: /jQuery\s+v?(\d+\.\d+\.\d+)/gi, software: 'jQuery' },
            { pattern: /Bootstrap\s+v?(\d+\.\d+\.\d+)/gi, software: 'Bootstrap' },
            { pattern: /React\s+v?(\d+\.\d+\.\d+)/gi, software: 'React' },
            { pattern: /Angular\s+v?(\d+\.\d+\.\d+)/gi, software: 'Angular' },
            { pattern: /WordPress\s+(\d+\.\d+\.\d+)/gi, software: 'WordPress' }
          ]

          for (const { pattern, software } of versionPatterns) {
            const matches = content.match(pattern)
            if (matches) {
              findings.push({
                type: 'VULNERABILITY',
                severity: 'MEDIUM',
                title: `${software} Version Detected`,
                description: `Found ${software} version in web content`,
                content: matches[0],
                source: target,
                metadata: {
                  pattern: 'software_version_exposure',
                  software,
                  version: matches[0],
                  recommendation: 'Verify software version is up-to-date and not vulnerable'
                },
                isVerified: false,
                isValid: true
              })
            }
          }

          // Check for common web vulnerabilities indicators
          const vulnPatterns = [
            { pattern: /eval\s*\(/gi, type: 'eval() Usage', severity: 'HIGH', description: 'Potential code execution vulnerability' },
            { pattern: /innerHTML\s*=/gi, type: 'innerHTML Usage', severity: 'MEDIUM', description: 'Potential XSS vulnerability' },
            { pattern: /document\.write/gi, type: 'document.write', severity: 'MEDIUM', description: 'Potential XSS vulnerability' },
            { pattern: /\.exe|\.bat|\.cmd|\.ps1/gi, type: 'Executable Reference', severity: 'MEDIUM', description: 'Reference to executable files' }
          ]

          for (const { pattern, type, severity, description } of vulnPatterns) {
            const matches = content.match(pattern)
            if (matches) {
              findings.push({
                type: 'VULNERABILITY',
                severity,
                title: type,
                description,
                content: `Found ${matches.length} instances`,
                source: target,
                metadata: {
                  pattern: type.toLowerCase().replace(/\s+/g, '_'),
                  matchCount: matches.length,
                  recommendation: `Review and mitigate potential ${type.toLowerCase()}`
                },
                isVerified: false,
                isValid: true
              })
            }
          }
        }
      }
    } catch (error) {
      console.error('Error checking web vulnerabilities:', error)
    }

    return findings
  }

  private async checkCodeSecurity(target: string): Promise<any[]> {
    const findings: any[] = []
    
    try {
      console.log(`Checking code security for: ${target}`)
      
      if (target.startsWith('http')) {
        // Fetch code from URL
        const response = await fetch(target, {
          headers: {
            'User-Agent': 'Security-CodeScanner/1.0'
          }
        })

        if (response.ok) {
          const content = await response.text()
          const codeFindings = this.analyzeCodeSecurity(content, target)
          findings.push(...codeFindings)
        }
      } else if (target.includes('github.com')) {
        // Scan GitHub repository for code security issues
        const { owner, repo } = this.parseGitHubUrl(target)
        
        if (owner && repo) {
          const contents = await this.getGitHubRepositoryContents(owner, repo)
          
          for (const item of contents) {
            if (item.type === 'file' && this.shouldScanFile(item.path)) {
              const fileContent = await this.getGitHubFileContent(owner, repo, item.path)
              if (fileContent) {
                const fileFindings = this.analyzeCodeSecurity(fileContent, `github:${owner}/${repo}/${item.path}`)
                findings.push(...fileFindings)
              }
            }
          }
        }
      }
    } catch (error) {
      console.error('Error checking code security:', error)
    }

    return findings
  }

  private analyzeCodeSecurity(content: string, source: string): any[] {
    const findings: any[] = []
    
    // Security vulnerability patterns
    const securityPatterns = [
      // SQL Injection patterns
      {
        pattern: /SELECT\s+.*\s+FROM\s+.*WHERE\s+.*["']\s*\+\s*["']/gi,
        type: 'SQL Injection',
        severity: 'HIGH',
        description: 'Potential SQL injection vulnerability'
      },
      {
        pattern: /execute\s*\(|exec\s*\(|sp_executesql/gi,
        type: 'Dynamic SQL Execution',
        severity: 'HIGH',
        description: 'Dynamic SQL execution detected'
      },
      
      // XSS patterns
      {
        pattern: /innerHTML\s*=\s*|outerHTML\s*=\s*|document\.write\s*\(/gi,
        type: 'XSS Vulnerability',
        severity: 'HIGH',
        description: 'Potential cross-site scripting vulnerability'
      },
      {
        pattern: /eval\s*\(|setInterval\s*\(|setTimeout\s*\([^,]+,\s*["']/gi,
        type: 'Code Execution',
        severity: 'HIGH',
        description: 'Dynamic code execution detected'
      },
      
      // Command Injection
      {
        pattern: /exec\s*\(|system\s*\(|shell_exec\s*\(|passthru\s*\(/gi,
        type: 'Command Injection',
        severity: 'CRITICAL',
        description: 'Potential command injection vulnerability'
      },
      
      // Path Traversal
      {
        pattern: /\.\.\/|\.\.\\\.\./gi,
        type: 'Path Traversal',
        severity: 'HIGH',
        description: 'Potential path traversal vulnerability'
      },
      
      // Insecure Cryptography
      {
        pattern: /md5\s*\(|sha1\s*\(/gi,
        type: 'Weak Cryptography',
        severity: 'MEDIUM',
        description: 'Weak hashing algorithm detected'
      },
      {
        pattern: /DES\s*\(|RC4\s*\(/gi,
        type: 'Weak Encryption',
        severity: 'HIGH',
        description: 'Weak encryption algorithm detected'
      },
      
      // Hardcoded Secrets
      {
        pattern: /password\s*=\s*["\'][^"\']{8,}["']/gi,
        type: 'Hardcoded Password',
        severity: 'HIGH',
        description: 'Hardcoded password detected'
      },
      {
        pattern: /api[_-]?key\s*=\s*["\'][^"\']{16,}["']/gi,
        type: 'Hardcoded API Key',
        severity: 'HIGH',
        description: 'Hardcoded API key detected'
      },
      
      // Insecure Randomness
      {
        pattern: /Math\.random\s*\(/gi,
        type: 'Insecure Randomness',
        severity: 'MEDIUM',
        description: 'Insecure random number generation detected'
      },
      
      // Buffer Overflow patterns
      {
        pattern: /strcpy\s*\(|sprintf\s*\(|gets\s*\(/gi,
        type: 'Buffer Overflow',
        severity: 'HIGH',
        description: 'Potential buffer overflow vulnerability'
      },
      
      // Information Disclosure
      {
        pattern: /console\.log\s*\(|console\.debug\s*\(|alert\s*\(/gi,
        type: 'Information Disclosure',
        severity: 'LOW',
        description: 'Debug information disclosure detected'
      },
      
      // Insecure File Operations
      {
        pattern: /file_get_contents\s*\(|fopen\s*\(|readfile\s*\(/gi,
        type: 'Insecure File Operation',
        severity: 'MEDIUM',
        description: 'Potential insecure file operation'
      }
    ]

    // Language-specific patterns
    const languagePatterns = [
      // JavaScript/TypeScript
      {
        pattern: /document\.cookie\s*=/gi,
        type: 'Insecure Cookie Handling',
        severity: 'MEDIUM',
        description: 'Insecure cookie handling detected',
        languages: ['javascript', 'typescript']
      },
      {
        pattern: /localStorage\s*\.|sessionStorage\s*\./gi,
        type: 'Insecure Storage',
        severity: 'LOW',
        description: 'Sensitive data in client-side storage',
        languages: ['javascript', 'typescript']
      },
      
      // Python
      {
        pattern: /pickle\.load\s*\(|marshal\.load\s*\(/gi,
        type: 'Insecure Deserialization',
        severity: 'HIGH',
        description: 'Insecure deserialization detected',
        languages: ['python']
      },
      {
        pattern: /subprocess\.call\s*\(|os\.system\s*\(/gi,
        type: 'Command Injection',
        severity: 'HIGH',
        description: 'Potential command injection',
        languages: ['python']
      },
      
      // PHP
      {
        pattern: /\$\_(GET|POST|REQUEST)\[/gi,
        type: 'Unvalidated Input',
        severity: 'MEDIUM',
        description: 'Unvalidated user input detected',
        languages: ['php']
      },
      {
        pattern: /mysql_query\s*\(|mysqli_query\s*\(/gi,
        type: 'SQL Injection',
        severity: 'HIGH',
        description: 'Potential SQL injection',
        languages: ['php']
      },
      
      // Java
      {
        pattern: /Runtime\.getRuntime\s*\(\)\.exec\s*\(/gi,
        type: 'Command Injection',
        severity: 'HIGH',
        description: 'Potential command injection',
        languages: ['java']
      },
      {
        pattern: /Class\.forName\s*\(/gi,
        type: 'Unsafe Reflection',
        severity: 'MEDIUM',
        description: 'Unsafe reflection detected',
        languages: ['java']
      }
    ]

    // Check general security patterns
    for (const { pattern, type, severity, description } of securityPatterns) {
      const matches = content.match(pattern)
      if (matches) {
        findings.push({
          type: 'VULNERABILITY',
          severity,
          title: type,
          description,
          content: `Found ${matches.length} instances`,
          source,
          metadata: {
            pattern: type.toLowerCase().replace(/\s+/g, '_'),
            matchCount: matches.length,
            recommendation: `Review and fix ${type.toLowerCase()} issues`
          },
          isVerified: false,
          isValid: true
        })
      }
    }

    // Check language-specific patterns
    const fileExtension = source.split('.').pop()?.toLowerCase()
    for (const { pattern, type, severity, description, languages } of languagePatterns) {
      if (!languages || languages.includes(fileExtension)) {
        const matches = content.match(pattern)
        if (matches) {
          findings.push({
            type: 'VULNERABILITY',
            severity,
            title: type,
            description,
            content: `Found ${matches.length} instances`,
            source,
            metadata: {
              pattern: type.toLowerCase().replace(/\s+/g, '_'),
              matchCount: matches.length,
              language: fileExtension,
              recommendation: `Review and fix ${type.toLowerCase()} issues`
            },
            isVerified: false,
            isValid: true
          })
        }
      }
    }

    // Code quality issues that could lead to security problems
    const codeQualityPatterns = [
      {
        pattern: /TODO:|FIXME:|HACK:/gi,
        type: 'Code Quality Issue',
        severity: 'LOW',
        description: 'Development comments found in code'
      },
      {
        pattern: /die\s*\(|exit\s*\(/gi,
        type: 'Abrupt Termination',
        severity: 'LOW',
        description: 'Abrupt script termination detected'
      },
      {
        pattern: /@deprecated/gi,
        type: 'Deprecated Code',
        severity: 'MEDIUM',
        description: 'Deprecated functions or methods detected'
      }
    ]

    for (const { pattern, type, severity, description } of codeQualityPatterns) {
      const matches = content.match(pattern)
      if (matches) {
        findings.push({
          type: 'MISCONFIGURATION',
          severity,
          title: type,
          description,
          content: `Found ${matches.length} instances`,
          source,
          metadata: {
            pattern: type.toLowerCase().replace(/\s+/g, '_'),
            matchCount: matches.length,
            recommendation: `Address ${type.toLowerCase()} to improve code quality`
          },
          isVerified: false,
          isValid: true
        })
      }
    }

    return findings
  }
}