import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Get total alerts count
    const totalAlerts = await db.alert.count({
      where: { userId }
    })

    // Get unread alerts count
    const unreadAlerts = await db.alert.count({
      where: { userId, isRead: false }
    })

    // Get critical alerts count
    const criticalAlerts = await db.alert.count({
      where: { userId, severity: 'CRITICAL' }
    })

    // Get active monitors count
    const activeMonitors = await db.monitor.count({
      where: { userId, isActive: true }
    })

    // Get recent scans count (last 24 hours)
    const oneDayAgo = new Date()
    oneDayAgo.setDate(oneDayAgo.getDate() - 1)
    
    const recentScans = await db.scan.count({
      where: {
        userId,
        createdAt: { gte: oneDayAgo }
      }
    })

    const stats = {
      totalAlerts,
      unreadAlerts,
      criticalAlerts,
      activeMonitors,
      recentScans
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error('Error fetching monitoring stats:', error)
    return NextResponse.json({ error: 'Failed to fetch monitoring stats' }, { status: 500 })
  }
}