import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const organizationId = params.id

    const domains = await db.domain.findMany({
      where: { organizationId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ domains })
  } catch (error) {
    console.error('Error fetching organization domains:', error)
    return NextResponse.json({ error: 'Failed to fetch organization domains' }, { status: 500 })
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const organizationId = params.id
    const body = await request.json()
    const { domain } = body

    if (!domain) {
      return NextResponse.json({ error: 'Domain is required' }, { status: 400 })
    }

    // Check if domain already exists for this organization
    const existingDomain = await db.domain.findUnique({
      where: {
        domain_organizationId: {
          domain,
          organizationId
        }
      }
    })

    if (existingDomain) {
      return NextResponse.json({ error: 'Domain already exists for this organization' }, { status: 400 })
    }

    // Add domain to organization
    const newDomain = await db.domain.create({
      data: {
        domain,
        organizationId,
        isActive: true
      }
    })

    return NextResponse.json({ domain: newDomain })
  } catch (error) {
    console.error('Error adding organization domain:', error)
    return NextResponse.json({ error: 'Failed to add organization domain' }, { status: 500 })
  }
}