import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const organizationId = params.id

    const members = await db.organizationMember.findMany({
      where: { organizationId },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            createdAt: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ members })
  } catch (error) {
    console.error('Error fetching organization members:', error)
    return NextResponse.json({ error: 'Failed to fetch organization members' }, { status: 500 })
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const organizationId = params.id
    const body = await request.json()
    const { email, role } = body

    if (!email || !role) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Find user by email
    let user = await db.user.findUnique({
      where: { email }
    })

    // If user doesn't exist, create a placeholder user (in real app, you'd send invitation)
    if (!user) {
      user = await db.user.create({
        data: {
          email,
          name: email.split('@')[0] // Use email prefix as name
        }
      })
    }

    // Check if user is already a member
    const existingMember = await db.organizationMember.findUnique({
      where: {
        userId_organizationId: {
          userId: user.id,
          organizationId
        }
      }
    })

    if (existingMember) {
      return NextResponse.json({ error: 'User is already a member of this organization' }, { status: 400 })
    }

    // Add member to organization
    const member = await db.organizationMember.create({
      data: {
        userId: user.id,
        organizationId,
        role
      },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            createdAt: true
          }
        }
      }
    })

    return NextResponse.json({ member })
  } catch (error) {
    console.error('Error adding organization member:', error)
    return NextResponse.json({ error: 'Failed to add organization member' }, { status: 500 })
  }
}