import { Server } from 'socket.io';

let ioInstance: Server | null = null;

export const setupSocket = (io?: Server) => {
  if (io) {
    ioInstance = io;
  }
  
  if (!ioInstance) {
    throw new Error('Socket.IO instance not provided');
  }

  ioInstance.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Handle real-time monitoring events
    socket.on('join_monitoring', (userId: string) => {
      socket.join(`monitoring_${userId}`);
      console.log(`User ${userId} joined monitoring room`);
    });

    socket.on('leave_monitoring', (userId: string) => {
      socket.leave(`monitoring_${userId}`);
      console.log(`User ${userId} left monitoring room`);
    });

    // Handle alert subscriptions
    socket.on('subscribe_alerts', (userId: string) => {
      socket.join(`alerts_${userId}`);
      console.log(`User ${userId} subscribed to alerts`);
    });

    socket.on('unsubscribe_alerts', (userId: string) => {
      socket.leave(`alerts_${userId}`);
      console.log(`User ${userId} unsubscribed from alerts`);
    });

    // Handle scan updates
    socket.on('scan_update', (data: { scanId: string; progress: number; status: string }) => {
      socket.to(`scan_${data.scanId}`).emit('scan_progress', data);
      console.log('Scan update:', data);
    });

    // Handle monitoring stats updates
    socket.on('stats_update', (stats: any) => {
      socket.broadcast.emit('monitoring_stats', stats);
    });

    // Handle monitoring events
    socket.on('monitoring_event', (event: { type: string; data: any; userId: string }) => {
      ioInstance?.to(`monitoring_${event.userId}`).emit('monitoring_event', event);
    });

    // Handle messages (backward compatibility)
    socket.on('message', (msg: { text: string; senderId: string }) => {
      socket.emit('message', {
        text: `Echo: ${msg.text}`,
        senderId: 'system',
        timestamp: new Date().toISOString(),
      });
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });

    // Send welcome message
    socket.emit('message', {
      text: 'Welcome to Real-time Security Monitoring!',
      senderId: 'system',
      timestamp: new Date().toISOString(),
    });
  });

  return ioInstance;
};

// Helper functions for emitting events
export const emitAlert = (alert: any, userId: string) => {
  if (ioInstance) {
    ioInstance.to(`alerts_${userId}`).emit('new_alert', alert);
  }
};

export const emitMonitoringEvent = (event: { type: string; data: any; userId: string }) => {
  if (ioInstance) {
    ioInstance.to(`monitoring_${userId}`).emit('monitoring_event', event);
  }
};

export const emitScanUpdate = (scanId: string, progress: number, status: string) => {
  if (ioInstance) {
    ioInstance.to(`scan_${scanId}`).emit('scan_progress', { scanId, progress, status });
  }
};

export const getSocketInstance = () => ioInstance;