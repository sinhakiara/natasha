'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Search, 
  Plus, 
  Play, 
  Pause, 
  Trash2, 
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  Shield,
  Bug,
  Code,
  Eye,
  ExternalLink,
  Copy,
  Key,
  Database,
  AlertCircle,
  Wifi,
  WifiOff
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { useSocket } from '@/hooks/useSocket'

interface Scan {
  id: string
  name: string
  target: string
  type: string
  status: string
  config: string
  startedAt?: string
  completedAt?: string
  createdAt: string
  findings: any[]
  _count: {
    findings: number
  }
}

interface NewScanForm {
  name: string
  target: string
  type: string
  config?: {
    maxFileSize?: number
    includeExtensions?: string[]
    excludePaths?: string[]
    deepScan?: boolean
  }
}

export function SecretScanner() {
  const { data: session } = useSession()
  const [scans, setScans] = useState<Scan[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [newScan, setNewScan] = useState<NewScanForm>({
    name: '',
    target: '',
    type: 'SECRET_SCAN',
    config: {
      maxFileSize: 10 * 1024 * 1024,
      includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.json', '.yaml', '.yml', '.env'],
      excludePaths: ['node_modules', '.git', 'dist', 'build'],
      deepScan: false
    }
  })
  const [validationError, setValidationError] = useState('')
  const [activeScanId, setActiveScanId] = useState<string | null>(null)
  const [scanProgress, setScanProgress] = useState(0)
  const [selectedScanFindings, setSelectedScanFindings] = useState<any[]>([])
  const [selectedScan, setSelectedScan] = useState<Scan | null>(null)
  const [visibleSecrets, setVisibleSecrets] = useState<Set<string>>(new Set())
  const [githubApiKey, setGithubApiKey] = useState('')
  const [showGithubKeyInput, setShowGithubKeyInput] = useState(false)
  const [isValidatingKey, setIsValidatingKey] = useState(false)
  const [keyValidationStatus, setKeyValidationStatus] = useState<'valid' | 'invalid' | 'unknown'>('unknown')
  const [keyValidationError, setKeyValidationError] = useState('')
  const { toast } = useToast()
  const hasActiveScansRef = useRef(false)

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3' // Admin user ID as fallback

  // Initialize socket connection
  const { 
    socket, 
    isConnected, 
    joinScanRoom, 
    leaveScanRoom, 
    onScanProgress, 
    offScanProgress,
    onMonitoringEvent,
    offMonitoringEvent
  } = useSocket({ userId, autoConnect: true })

  // Handle real-time scan updates
  useEffect(() => {
    if (isConnected) {
      const handleScanProgress = (data: { scanId: string; progress: number; status: string }) => {
        console.log('Real-time scan progress update:', data)
        
        // Update scan progress
        setScanProgress(data.progress)
        
        // Update scans list with new status
        setScans(prevScans => 
          prevScans.map(scan => 
            scan.id === data.scanId 
              ? { ...scan, status: data.status }
              : scan
          )
        )
        
        // Show notification for status changes
        if (data.status === 'COMPLETED') {
          toast({
            title: "Scan Completed",
            description: `Scan has completed successfully`,
          })
          setScanProgress(0)
        } else if (data.status === 'FAILED') {
          toast({
            title: "Scan Failed",
            description: `Scan has failed`,
            variant: "destructive"
          })
          setScanProgress(0)
        }
        
        setLastUpdate(new Date())
      }

      const handleMonitoringEvent = (event: { type: string; data: any; userId: string }) => {
        if (event.userId === userId) {
          console.log('Monitoring event:', event)
          
          if (event.type === 'scan_started') {
            setScans(prevScans => 
              prevScans.map(scan => 
                scan.id === event.data.scanId 
                  ? { ...scan, status: 'RUNNING', startedAt: new Date().toISOString() }
                  : scan
              )
            )
          } else if (event.type === 'scan_updated') {
            fetchScans(true) // Refresh scans list
          }
        }
      }

      // Subscribe to scan progress events
      onScanProgress(handleScanProgress)
      onMonitoringEvent(handleMonitoringEvent)

      return () => {
        offScanProgress(handleScanProgress)
        offMonitoringEvent(handleMonitoringEvent)
      }
    }
  }, [isConnected, userId, onScanProgress, offScanProgress, onMonitoringEvent, offMonitoringEvent, toast])

  // Join scan rooms for active scans
  useEffect(() => {
    if (isConnected) {
      const activeScans = scans.filter(scan => scan.status === 'RUNNING')
      activeScans.forEach(scan => {
        joinScanRoom(scan.id)
      })

      return () => {
        activeScans.forEach(scan => {
          leaveScanRoom(scan.id)
        })
      }
    }
  }, [scans, isConnected, joinScanRoom, leaveScanRoom])

  useEffect(() => {
    fetchScans()
  }, [])

  useEffect(() => {
    // Update the ref when scans change
    hasActiveScansRef.current = scans.some(scan => scan.status === 'RUNNING')
  }, [scans])

  useEffect(() => {
    // Set up polling for active scans (fallback mechanism)
    const interval = setInterval(() => {
      if (hasActiveScansRef.current && !isConnected) {
        console.log('Polling for scan updates (WebSocket not connected)...')
        fetchScans(true) // Pass true to indicate this is a polling request
      }
    }, 10000) // Poll every 10 seconds as fallback

    return () => clearInterval(interval)
  }, [hasActiveScansRef.current, isConnected])

  useEffect(() => {
    // Simulate scan progress for active scans
    const activeScans = scans.filter(scan => scan.status === 'RUNNING')
    if (activeScans.length > 0) {
      const progressInterval = setInterval(() => {
        setScanProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval)
            return 95
          }
          return prev + Math.random() * 10
        })
      }, 1000)

      return () => clearInterval(progressInterval)
    } else {
      setScanProgress(0)
    }
  }, [scans.length, scans.filter(scan => scan.status === 'RUNNING').length]) // More specific dependencies

  const fetchScans = async (isPolling = false) => {
    try {
      // Only show loading state for manual fetches, not polling
      if (!isPolling) {
        setIsLoading(true)
      }
      
      const response = await fetch(`/api/scans?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setScans(data.scans || [])
        
        // Log scan status updates for debugging
        const runningScans = data.scans?.filter((scan: Scan) => scan.status === 'RUNNING') || []
        if (runningScans.length > 0) {
          console.log(`Found ${runningScans.length} running scans:`, runningScans.map((s: Scan) => s.name))
        }
      }
    } catch (error) {
      console.error('Error fetching scans:', error)
      if (!isPolling) {
        toast({
          title: "Error",
          description: "Failed to fetch scans",
          variant: "destructive"
        })
      }
    } finally {
      if (!isPolling) {
        setIsLoading(false)
      }
    }
  }

  const validateForm = (): boolean => {
    if (!newScan.name.trim()) {
      setValidationError('Scan name is required')
      return false
    }

    if (!newScan.target.trim()) {
      setValidationError('Target is required')
      return false
    }

    // Validate target based on type
    if (newScan.type === 'SECRET_SCAN') {
      if (!newScan.target.startsWith('http') && !newScan.target.includes('github.com')) {
        setValidationError('Target must be a URL or GitHub repository')
        return false
      }
    }

    setValidationError('')
    return true
  }

  const handleCreateScan = async () => {
    if (!validateForm()) return

    try {
      setIsCreating(true)
      
      // Include GitHub API key in config if available
      const scanConfig = {
        ...newScan.config,
        githubApiKey: githubApiKey || undefined
      }
      
      const response = await fetch('/api/scans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newScan,
          config: scanConfig,
          userId
        })
      })

      if (response.ok) {
        const data = await response.json()
        setScans(prev => [data.scan, ...prev])
        setNewScan({
          name: '',
          target: '',
          type: 'SECRET_SCAN',
          config: {
            maxFileSize: 10 * 1024 * 1024,
            includeExtensions: ['.js', '.ts', '.py', '.java', '.php', '.rb', '.go', '.json', '.yaml', '.yml', '.env'],
            excludePaths: ['node_modules', '.git', 'dist', 'build'],
            deepScan: false
          }
        })
        toast({
          title: "Success",
          description: "Scan started successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to create scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error creating scan:', error)
      toast({
        title: "Error",
        description: "Failed to create scan",
        variant: "destructive"
      })
    } finally {
      setIsCreating(false)
    }
  }

  const handleStopScan = async (scanId: string) => {
    try {
      // In a real implementation, this would call an API to stop the scan
      setScans(prev => prev.map(scan => 
        scan.id === scanId ? { ...scan, status: 'FAILED' } : scan
      ))
      
      toast({
        title: "Success",
        description: "Scan stopped successfully",
      })
    } catch (error) {
      console.error('Error stopping scan:', error)
      toast({
        title: "Error",
        description: "Failed to stop scan",
        variant: "destructive"
      })
    }
  }

  const handleDeleteScan = async (scanId: string) => {
    if (!confirm('Are you sure you want to delete this scan and all its findings? This action cannot be undone.')) {
      return
    }

    try {
      const response = await fetch(`/api/scans/${scanId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setScans(prev => prev.filter(scan => scan.id !== scanId))
        toast({
          title: "Success",
          description: "Scan deleted successfully",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to delete scan",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error deleting scan:', error)
      toast({
        title: "Error",
        description: "Failed to delete scan",
        variant: "destructive"
      })
    }
  }

  const handleViewFindings = async (scanId: string) => {
    // Navigate to the scan details page instead of showing modal
    window.location.href = `/secret-scanner/${scanId}`
  }

  const handleViewScanDetails = async (scanId: string) => {
    try {
      // Find the scan in the current state
      const scan = scans.find(s => s.id === scanId)
      if (scan) {
        const duration = scan.completedAt && scan.startedAt 
          ? `${Math.round((new Date(scan.completedAt).getTime() - new Date(scan.startedAt).getTime()) / 1000)} seconds`
          : 'N/A'
        
        toast({
          title: "Scan Details",
          description: `${scan.name} - ${getTypeName(scan.type)}\nTarget: ${scan.target}\nStatus: ${scan.status}\nDuration: ${duration}\nFindings: ${scan._count?.findings || 0}`,
        })
      }
    } catch (error) {
      console.error('Error showing scan details:', error)
      toast({
        title: "Error",
        description: "Failed to show scan details",
        variant: "destructive"
      })
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200'
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <CheckCircle className="h-3 w-3" />
      case 'RUNNING':
        return <Clock className="h-3 w-3 animate-spin" />
      case 'FAILED':
        return <AlertTriangle className="h-3 w-3" />
      case 'PENDING':
        return <Clock className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'SECRET_SCAN':
        return <Search className="h-5 w-5" />
      case 'VULNERABILITY_SCAN':
        return <Bug className="h-5 w-5" />
      case 'CODE_SCAN':
        return <Code className="h-5 w-5" />
      default:
        return <Shield className="h-5 w-5" />
    }
  }

  const getTypeName = (type: string) => {
    switch (type) {
      case 'SECRET_SCAN':
        return 'Secret Scan'
      case 'VULNERABILITY_SCAN':
        return 'Vulnerability Scan'
      case 'CODE_SCAN':
        return 'Code Scan'
      default:
        return 'Custom Scan'
    }
  }

  const getSeverityColor = (count: number) => {
    if (count === 0) return 'bg-green-100 text-green-800'
    if (count <= 3) return 'bg-yellow-100 text-yellow-800'
    if (count <= 10) return 'bg-orange-100 text-orange-800'
    return 'bg-red-100 text-red-800'
  }

  const formatTarget = (target: string) => {
    if (target.length > 50) {
      return target.substring(0, 50) + '...'
    }
    return target
  }

  const getFindingSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getFindingIcon = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'secret': return <Key className="h-4 w-4" />
      case 'vulnerability': return <AlertCircle className="h-4 w-4" />
      case 'sast': return <Code className="h-4 w-4" />
      case 'dependency': return <Database className="h-4 w-4" />
      default: return <AlertTriangle className="h-4 w-4" />
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied",
      description: "Text copied to clipboard",
    })
  }

  const maskSecret = (secret: string) => {
    if (secret.length <= 8) return '*'.repeat(secret.length)
    return secret.substring(0, 4) + '*'.repeat(secret.length - 8) + secret.substring(secret.length - 4)
  }

  const toggleSecretVisibility = (findingId: string) => {
    setVisibleSecrets(prev => {
      const newSet = new Set(prev)
      if (newSet.has(findingId)) {
        newSet.delete(findingId)
      } else {
        newSet.add(findingId)
      }
      return newSet
    })
  }

  const handleSaveGithubKey = async () => {
    if (!githubApiKey.trim()) {
      setKeyValidationStatus('invalid')
      setKeyValidationError('GitHub API key is required')
      toast({
        title: "Error",
        description: "GitHub API key is required",
        variant: "destructive"
      })
      return
    }

    // Validate the key before saving
    const isValid = await validateGithubApiKey(githubApiKey)
    
    if (isValid) {
      // Save to localStorage for now (in a real app, this would be encrypted and stored securely)
      localStorage.setItem('githubApiKey', githubApiKey.trim())
      toast({
        title: "Success",
        description: "GitHub API key saved and validated successfully",
      })
      setShowGithubKeyInput(false)
    }
  }

  const handleRemoveGithubKey = () => {
    localStorage.removeItem('githubApiKey')
    setGithubApiKey('')
    setKeyValidationStatus('unknown')
    setKeyValidationError('')
    toast({
      title: "Success",
      description: "GitHub API key removed",
    })
  }

  const validateGithubApiKey = async (key: string) => {
    if (!key.trim()) {
      setKeyValidationStatus('invalid')
      setKeyValidationError('API key is required')
      return false
    }

    setIsValidatingKey(true)
    setKeyValidationError('')

    try {
      // Test the GitHub API key by making a request to get user info
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `token ${key.trim()}`,
          'User-Agent': 'Security-SecretScanner/1.0'
        }
      })

      if (response.ok) {
        const userData = await response.json()
        console.log('GitHub API key validated for user:', userData.login)
        
        setKeyValidationStatus('valid')
        toast({
          title: "Success",
          description: `GitHub API key validated successfully for user: ${userData.login}`,
        })
        return true
      } else {
        const errorData = await response.json()
        console.error('GitHub API key validation failed:', errorData)
        
        setKeyValidationStatus('invalid')
        setKeyValidationError(errorData.message || 'Invalid API key')
        toast({
          title: "Validation Failed",
          description: `Invalid GitHub API key: ${errorData.message || 'Unknown error'}`,
          variant: "destructive"
        })
        return false
      }
    } catch (error) {
      console.error('Error validating GitHub API key:', error)
      
      setKeyValidationStatus('invalid')
      setKeyValidationError('Network error or invalid key format')
      toast({
        title: "Validation Error",
        description: "Failed to validate API key. Please check your network connection and key format.",
        variant: "destructive"
      })
      return false
    } finally {
      setIsValidatingKey(false)
    }
  }

  const handleValidateKey = async () => {
    await validateGithubApiKey(githubApiKey)
  }

  // Load GitHub API key from localStorage on component mount
  useEffect(() => {
    const savedKey = localStorage.getItem('githubApiKey')
    if (savedKey) {
      setGithubApiKey(savedKey)
    }
  }, [])

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Secret Scanner</h2>
          <p className="text-muted-foreground">
            Advanced secret detection across multiple platforms and repositories
          </p>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <RBACGuard requiredPermissions={['write']}>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Secret Scanner</h2>
          <p className="text-muted-foreground">
            Advanced secret detection across multiple platforms and repositories
          </p>
        </div>

      {/* Create New Scan */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Start New Scan
          </CardTitle>
          <CardDescription>Configure and run a comprehensive secret scan</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {validationError && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{validationError}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium">Scan Name</label>
              <Input
                placeholder="e.g., Weekly Security Scan"
                value={newScan.name}
                onChange={(e) => setNewScan(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Scan Type</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={newScan.type}
                onChange={(e) => setNewScan(prev => ({ ...prev, type: e.target.value }))}
              >
                <option value="SECRET_SCAN">Secret Scan</option>
                <option value="VULNERABILITY_SCAN">Vulnerability Scan</option>
                <option value="CODE_SCAN">Code Scan</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">Target</label>
            <Input
              placeholder="e.g., https://github.com/acme/organization or https://example.com"
              value={newScan.target}
              onChange={(e) => setNewScan(prev => ({ ...prev, target: e.target.value }))}
            />
          </div>
          
          {newScan.type === 'SECRET_SCAN' && (
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="deepScan"
                  checked={newScan.config?.deepScan || false}
                  onChange={(e) => setNewScan(prev => ({
                    ...prev,
                    config: { ...prev.config, deepScan: e.target.checked }
                  }))}
                />
                <label htmlFor="deepScan" className="text-sm font-medium">
                  Enable Deep Scan (slower but more thorough)
                </label>
              </div>
              
              <div>
                <label className="text-sm font-medium">Max File Size (MB)</label>
                <Input
                  type="number"
                  value={(newScan.config?.maxFileSize || 0) / (1024 * 1024)}
                  onChange={(e) => setNewScan(prev => ({
                    ...prev,
                    config: { ...prev.config, maxFileSize: parseInt(e.target.value) * 1024 * 1024 }
                  }))}
                />
              </div>
            </div>
          )}
          
          <Button 
            onClick={handleCreateScan} 
            disabled={isCreating}
            className="w-full"
          >
            {isCreating ? 'Creating...' : 'Start Scan'}
          </Button>
        </CardContent>
      </Card>

      {/* GitHub API Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            GitHub API Settings
          </CardTitle>
          <CardDescription>
            Configure your GitHub API key for enhanced repository scanning capabilities
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {githubApiKey ? (
            <div className="space-y-3">
              <div className={`flex items-center justify-between p-3 rounded-lg ${
                keyValidationStatus === 'valid' 
                  ? 'bg-green-50 border border-green-200' 
                  : keyValidationStatus === 'invalid'
                  ? 'bg-red-50 border border-red-200'
                  : 'bg-blue-50 border border-blue-200'
              }`}>
                <div className="flex items-center space-x-2">
                  {keyValidationStatus === 'valid' && <CheckCircle className="h-4 w-4 text-green-600" />}
                  {keyValidationStatus === 'invalid' && <AlertTriangle className="h-4 w-4 text-red-600" />}
                  {keyValidationStatus === 'unknown' && <AlertCircle className="h-4 w-4 text-blue-600" />}
                  <span className={`text-sm font-medium ${
                    keyValidationStatus === 'valid' ? 'text-green-800' :
                    keyValidationStatus === 'invalid' ? 'text-red-800' :
                    'text-blue-800'
                  }`}>
                    {keyValidationStatus === 'valid' ? 'GitHub API Key Validated' :
                     keyValidationStatus === 'invalid' ? 'GitHub API Key Invalid' :
                     'GitHub API Key Configured'}
                  </span>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleValidateKey}
                    disabled={isValidatingKey}
                  >
                    {isValidatingKey ? 'Validating...' : 'Revalidate'}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRemoveGithubKey}
                  >
                    Remove Key
                  </Button>
                </div>
              </div>
              
              {keyValidationStatus === 'invalid' && keyValidationError && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{keyValidationError}</AlertDescription>
                </Alert>
              )}
              
              {keyValidationStatus === 'valid' && (
                <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-800">
                    ✓ Your GitHub API key is valid and ready to use for repository scanning. 
                    This allows for higher rate limits and access to private repositories (if permissions allow).
                  </p>
                </div>
              )}
              
              {keyValidationStatus === 'unknown' && (
                <p className="text-sm text-gray-600">
                  Your GitHub API key is configured but not yet validated. Click "Revalidate" to verify the key works correctly.
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {showGithubKeyInput ? (
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium">GitHub Personal Access Token</label>
                    <Input
                      type="password"
                      placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                      value={githubApiKey}
                      onChange={(e) => {
                        setGithubApiKey(e.target.value)
                        setKeyValidationStatus('unknown')
                        setKeyValidationError('')
                      }}
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Create a token with 'repo' scope at GitHub Settings → Developer Settings → Personal Access Tokens
                    </p>
                  </div>
                  
                  {keyValidationStatus === 'invalid' && keyValidationError && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{keyValidationError}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="flex space-x-2">
                    <Button
                      onClick={handleValidateKey}
                      disabled={!githubApiKey.trim() || isValidatingKey}
                    >
                      {isValidatingKey ? 'Validating...' : 'Validate Key'}
                    </Button>
                    <Button
                      onClick={handleSaveGithubKey}
                      disabled={!githubApiKey.trim() || keyValidationStatus !== 'valid' || isValidatingKey}
                    >
                      Save Key
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setShowGithubKeyInput(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      <span className="text-sm font-medium text-yellow-800">GitHub API Key Not Configured</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowGithubKeyInput(true)}
                    >
                      Add Key
                    </Button>
                  </div>
                  <p className="text-sm text-gray-600">
                    Adding a GitHub API key will enhance scanning capabilities with higher rate limits 
                    and access to more repository data. Without a key, scanning may be limited by GitHub's 
                    anonymous rate limits.
                  </p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Active Scan Progress */}
      {scans.some(scan => scan.status === 'RUNNING') && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 animate-spin" />
              Active Scans
            </CardTitle>
          </CardHeader>
          <CardContent>
            {scans.filter(scan => scan.status === 'RUNNING').map((scan) => (
              <div key={scan.id} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {getTypeIcon(scan.type)}
                    <span className="font-medium">{scan.name}</span>
                  </div>
                  <Badge className={getStatusColor(scan.status)}>
                    {getStatusIcon(scan.status)}
                    {scan.status}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Scanning: {formatTarget(scan.target)}</span>
                    <span>{Math.round(scanProgress)}%</span>
                  </div>
                  <Progress value={scanProgress} className="h-2" />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleStopScan(scan.id)}
                >
                  Stop Scan
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Real-time Status Indicator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              {isConnected ? <Wifi className="h-5 w-5 text-green-600" /> : <WifiOff className="h-5 w-5 text-red-600" />}
              Real-time Status
            </span>
            {lastUpdate && (
              <span className="text-sm text-gray-500">
                Last update: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </CardTitle>
          <CardDescription>
            {isConnected 
              ? "Connected to real-time updates server" 
              : "Using fallback polling mode (WebSocket disconnected)"
            }
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Recent Scans */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Scans</CardTitle>
          <CardDescription>Your latest secret scanning activities</CardDescription>
        </CardHeader>
        <CardContent>
          {scans.length === 0 ? (
            <div className="text-center py-8">
              <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No scans yet</h3>
              <p className="text-gray-500">Create your first scan to start detecting secrets</p>
            </div>
          ) : (
            <div className="space-y-4">
              {scans
                .filter(scan => scan.status !== 'RUNNING')
                .map((scan) => (
                <div key={scan.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      {getTypeIcon(scan.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-sm font-medium text-gray-900 truncate">
                          {scan.name}
                        </h3>
                        <Badge className={getStatusColor(scan.status)}>
                          {getStatusIcon(scan.status)}
                          {scan.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 truncate">
                        {formatTarget(scan.target)}
                      </p>
                      <p className="text-xs text-gray-400">
                        {getTypeName(scan.type)} • {new Date(scan.createdAt).toLocaleDateString()}
                        {scan.completedAt && ` • Completed in ${Math.round((new Date(scan.completedAt).getTime() - new Date(scan.startedAt || scan.createdAt).getTime()) / 1000)}s`}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">Findings:</span>
                      <Badge className={getSeverityColor(scan._count?.findings || 0)}>
                        {scan._count?.findings || 0}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewFindings(scan.id)}
                        title="View Findings"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewScanDetails(scan.id)}
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteScan(scan.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      </div>
    </RBACGuard>
  )
}