'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield,
  Database,
  Activity,
  Target,
  Zap,
  FileText,
  Download,
  Calendar,
  Filter
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface SecurityMetrics {
  totalMonitors: number
  activeMonitors: number
  totalScans: number
  completedScans: number
  totalLeaks: number
  criticalLeaks: number
  totalTokens: number
  validTokens: number
  totalNetworkAssets: number
  recentAlerts: number
}

interface TrendData {
  period: string
  monitors: number
  scans: number
  leaks: number
  tokens: number
  assets: number
}

interface SeverityBreakdown {
  critical: number
  high: number
  medium: number
  low: number
}

export function AnalyticsDashboard() {
  const [metrics, setMetrics] = useState<SecurityMetrics>({
    totalMonitors: 0,
    activeMonitors: 0,
    totalScans: 0,
    completedScans: 0,
    totalLeaks: 0,
    criticalLeaks: 0,
    totalTokens: 0,
    validTokens: 0,
    totalNetworkAssets: 0,
    recentAlerts: 0
  })
  const [trendData, setTrendData] = useState<TrendData[]>([])
  const [severityBreakdown, setSeverityBreakdown] = useState<SeverityBreakdown>({
    critical: 0,
    high: 0,
    medium: 0,
    low: 0
  })
  const [isLoading, setIsLoading] = useState(true)
  const [selectedPeriod, setSelectedPeriod] = useState('7d')
  const { toast } = useToast()

  useEffect(() => {
    fetchAnalyticsData()
  }, [selectedPeriod])

  const fetchAnalyticsData = async () => {
    try {
      setIsLoading(true)
      
      const response = await fetch('/api/monitoring/stats')
      if (response.ok) {
        const data = await response.json()
        setMetrics(data.metrics || {
          totalMonitors: 0,
          activeMonitors: 0,
          totalScans: 0,
          completedScans: 0,
          totalLeaks: 0,
          criticalLeaks: 0,
          totalTokens: 0,
          validTokens: 0,
          totalNetworkAssets: 0,
          recentAlerts: 0
        })
        setTrendData(data.trendData || [])
        setSeverityBreakdown(data.severityBreakdown || {
          critical: 0,
          high: 0,
          medium: 0,
          low: 0
        })
      } else {
        // Set default empty data if API fails
        setMetrics({
          totalMonitors: 0,
          activeMonitors: 0,
          totalScans: 0,
          completedScans: 0,
          totalLeaks: 0,
          criticalLeaks: 0,
          totalTokens: 0,
          validTokens: 0,
          totalNetworkAssets: 0,
          recentAlerts: 0
        })
        setTrendData([])
        setSeverityBreakdown({
          critical: 0,
          high: 0,
          medium: 0,
          low: 0
        })
      }
      setIsLoading(false)
    } catch (error) {
      console.error('Error fetching analytics data:', error)
      toast({
        title: "Error",
        description: "Failed to fetch analytics data",
        variant: "destructive"
      })
      setIsLoading(false)
    }
  }

  const calculateTrend = (current: number, previous: number): { value: number; isPositive: boolean } => {
    if (previous === 0) return { value: 0, isPositive: true }
    const change = ((current - previous) / previous) * 100
    return {
      value: Math.abs(change),
      isPositive: current >= previous
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500'
      case 'high': return 'bg-orange-500'
      case 'medium': return 'bg-yellow-500'
      case 'low': return 'bg-green-500'
      default: return 'bg-gray-500'
    }
  }

  const getTrendIcon = (isPositive: boolean) => {
    return isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />
  }

  const generateReport = async (format: 'pdf' | 'html') => {
    try {
      toast({
        title: "Generating Report",
        description: `Security report is being generated in ${format.toUpperCase()} format...`,
      })
      
      // Simulate report generation delay
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      if (format === 'html') {
        await generateHTMLReport()
      } else {
        await generatePDFReport()
      }
      
      toast({
        title: "Report Generated",
        description: `Security report has been generated successfully in ${format.toUpperCase()} format`,
      })
    } catch (error) {
      console.error('Error generating report:', error)
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive"
      })
    }
  }

  const generateHTMLReport = () => {
    const reportHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Security Sentinel Report</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
          .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #333; padding-bottom: 20px; }
          .section { margin-bottom: 30px; }
          .metric { display: inline-block; margin: 10px; padding: 15px; border: 1px solid #ddd; border-radius: 5px; min-width: 150px; }
          .metric-value { font-size: 24px; font-weight: bold; color: #333; }
          .metric-label { font-size: 14px; color: #666; }
          .severity { display: inline-block; margin: 5px; padding: 10px; border-radius: 50%; color: white; font-weight: bold; }
          .critical { background-color: #dc2626; }
          .high { background-color: #f97316; }
          .medium { background-color: #eab308; }
          .low { background-color: #16a34a; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
          th { background-color: #f8f9fa; }
          .trend-up { color: #16a34a; }
          .trend-down { color: #dc2626; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Security Sentinel Report</h1>
          <p>Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}</p>
          <p>Report Period: ${selectedPeriod}</p>
        </div>
        
        <div class="section">
          <h2>Executive Summary</h2>
          <p>This security report provides a comprehensive overview of your organization's security posture, including monitoring activities, scan results, and threat intelligence.</p>
        </div>
        
        <div class="section">
          <h2>Key Metrics</h2>
          <div class="metric">
            <div class="metric-value">${metrics.activeMonitors}</div>
            <div class="metric-label">Active Monitors</div>
          </div>
          <div class="metric">
            <div class="metric-value">${metrics.completedScans}</div>
            <div class="metric-label">Completed Scans</div>
          </div>
          <div class="metric">
            <div class="metric-value">${metrics.totalLeaks}</div>
            <div class="metric-label">Security Leaks</div>
          </div>
          <div class="metric">
            <div class="metric-value">${metrics.totalNetworkAssets.toLocaleString()}</div>
            <div class="metric-label">Network Assets</div>
          </div>
        </div>
        
        <div class="section">
          <h2>Security Posture Overview</h2>
          <p>Breakdown of security findings by severity level:</p>
          <div style="margin: 20px 0;">
            <span class="severity critical">${severityBreakdown.critical}</span> Critical
            <span class="severity high">${severityBreakdown.high}</span> High
            <span class="severity medium">${severityBreakdown.medium}</span> Medium
            <span class="severity low">${severityBreakdown.low}</span> Low
          </div>
        </div>
        
        <div class="section">
          <h2>Activity Trends</h2>
          <table>
            <thead>
              <tr>
                <th>Period</th>
                <th>Monitors</th>
                <th>Scans</th>
                <th>Leaks</th>
                <th>Assets</th>
              </tr>
            </thead>
            <tbody>
              ${trendData.map(data => `
                <tr>
                  <td>${data.period}</td>
                  <td>${data.monitors}</td>
                  <td>${data.scans}</td>
                  <td>${data.leaks}</td>
                  <td>${data.assets}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        
        <div class="section">
          <h2>Recommendations</h2>
          <ul>
            <li>Continue monitoring GitHub repositories for leaked credentials</li>
            <li>Address critical security leaks immediately</li>
            <li>Expand network reconnaissance coverage</li>
            <li>Implement regular security scanning schedules</li>
            <li>Enhance token validation processes</li>
          </ul>
        </div>
        
        <div class="section">
          <h2>Report Information</h2>
          <p><strong>Generated by:</strong> Security Sentinel Platform</p>
          <p><strong>Generation Time:</strong> ${new Date().toISOString()}</p>
          <p><strong>Data Period:</strong> ${selectedPeriod}</p>
          <p><strong>Total Records Analyzed:</strong> ${metrics.totalMonitors + metrics.totalScans + metrics.totalLeaks + metrics.totalNetworkAssets}</p>
        </div>
      </body>
      </html>
    `
    
    const blob = new Blob([reportHTML], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `security-report-${new Date().toISOString().split('T')[0]}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const generatePDFReport = async () => {
    try {
      // Dynamically import jsPDF and html2canvas
      const [{ default: jsPDF }, { default: html2canvas }] = await Promise.all([
        import('jspdf'),
        import('html2canvas')
      ])
      
      // Create a temporary div with the report content
      const tempDiv = document.createElement('div')
      tempDiv.innerHTML = `
        <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto;">
          <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px;">
            <h1 style="margin: 0;">Security Sentinel Report</h1>
            <p style="margin: 5px 0;">Generated on ${new Date().toLocaleDateString()}</p>
            <p style="margin: 0;">Report Period: ${selectedPeriod}</p>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Key Metrics</h2>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0;">
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.activeMonitors}</div>
                <div style="font-size: 14px; color: #666;">Active Monitors</div>
              </div>
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.completedScans}</div>
                <div style="font-size: 14px; color: #666;">Completed Scans</div>
              </div>
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.totalLeaks}</div>
                <div style="font-size: 14px; color: #666;">Security Leaks</div>
              </div>
              <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px;">
                <div style="font-size: 24px; font-weight: bold; color: #333;">${metrics.totalNetworkAssets.toLocaleString()}</div>
                <div style="font-size: 14px; color: #666;">Network Assets</div>
              </div>
            </div>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Security Posture</h2>
            <div style="display: flex; gap: 20px; margin: 20px 0; flex-wrap: wrap;">
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #dc2626; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.critical}</div>
                <div style="font-size: 14px;">Critical</div>
              </div>
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #f97316; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.high}</div>
                <div style="font-size: 14px;">High</div>
              </div>
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #eab308; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.medium}</div>
                <div style="font-size: 14px;">Medium</div>
              </div>
              <div style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 50%; background-color: #16a34a; color: white; font-weight: bold; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">${severityBreakdown.low}</div>
                <div style="font-size: 14px;">Low</div>
              </div>
            </div>
          </div>
          
          <div style="margin-bottom: 30px;">
            <h2>Activity Trends</h2>
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
              <thead>
                <tr style="background-color: #f8f9fa;">
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Period</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Monitors</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Scans</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Leaks</th>
                  <th style="border: 1px solid #ddd; padding: 12px; text-align: left;">Assets</th>
                </tr>
              </thead>
              <tbody>
                ${trendData.map(data => `
                  <tr>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.period}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.monitors}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.scans}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.leaks}</td>
                    <td style="border: 1px solid #ddd; padding: 12px;">${data.assets}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <div>
            <h2>Recommendations</h2>
            <ul style="padding-left: 20px;">
              <li>Continue monitoring GitHub repositories for leaked credentials</li>
              <li>Address critical security leaks immediately</li>
              <li>Expand network reconnaissance coverage</li>
              <li>Implement regular security scanning schedules</li>
              <li>Enhance token validation processes</li>
            </ul>
          </div>
        </div>
      `
      
      tempDiv.style.position = 'absolute'
      tempDiv.style.left = '-9999px'
      document.body.appendChild(tempDiv)
      
      try {
        const canvas = await html2canvas(tempDiv, {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff'
        })
        
        const imgData = canvas.toDataURL('image/png')
        const pdf = new jsPDF('p', 'mm', 'a4')
        
        const imgWidth = 210
        const pageHeight = 295
        const imgHeight = (canvas.height * imgWidth) / canvas.width
        let heightLeft = imgHeight
        
        let position = 0
        
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
        
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight
          pdf.addPage()
          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
          heightLeft -= pageHeight
        }
        
        pdf.save(`security-report-${new Date().toISOString().split('T')[0]}.pdf`)
      } finally {
        document.body.removeChild(tempDiv)
      }
    } catch (error) {
      console.error('Error generating PDF:', error)
      throw error
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Security Analytics</h2>
          <p className="text-muted-foreground">
            Comprehensive security reports and analytics dashboard
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  const monitorTrend = calculateTrend(metrics.activeMonitors, metrics.activeMonitors - 2)
  const scanTrend = calculateTrend(metrics.completedScans, metrics.completedScans - 8)
  const leakTrend = calculateTrend(metrics.totalLeaks, metrics.totalLeaks - 5)
  const tokenTrend = calculateTrend(metrics.validTokens, metrics.validTokens - 15)
  const assetTrend = calculateTrend(metrics.totalNetworkAssets, metrics.totalNetworkAssets - 200)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Security Analytics</h2>
          <p className="text-muted-foreground">
            Comprehensive security reports and analytics dashboard
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <select 
            className="p-2 border rounded-md"
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
          <div className="flex space-x-2">
            <Button onClick={() => generateReport('pdf')}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <Button onClick={() => generateReport('html')} variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Download HTML
            </Button>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Monitors</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.activeMonitors}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(monitorTrend.isPositive)}
              <span className={monitorTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {monitorTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <Progress value={(metrics.activeMonitors / metrics.totalMonitors) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Scans</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.completedScans}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(scanTrend.isPositive)}
              <span className={scanTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {scanTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <Progress value={(metrics.completedScans / metrics.totalScans) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Security Leaks</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.totalLeaks}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(!leakTrend.isPositive)}
              <span className={!leakTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {leakTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <div className="flex items-center space-x-1 mt-2">
              <Badge variant="destructive" className="text-xs">
                {metrics.criticalLeaks} Critical
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Network Assets</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.totalNetworkAssets.toLocaleString()}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              {getTrendIcon(assetTrend.isPositive)}
              <span className={assetTrend.isPositive ? 'text-green-600' : 'text-red-600'}>
                {assetTrend.value.toFixed(1)}%
              </span>
              <span>from last period</span>
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              Discovered via ZoomEye
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Severity Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Posture Overview
          </CardTitle>
          <CardDescription>Breakdown of security findings by severity level</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            {Object.entries(severityBreakdown).map(([severity, count]) => (
              <div key={severity} className="text-center">
                <div className={`w-16 h-16 rounded-full ${getSeverityColor(severity)} flex items-center justify-center mx-auto mb-2`}>
                  <span className="text-white font-bold text-lg">{count}</span>
                </div>
                <div className="text-sm font-medium capitalize">{severity}</div>
                <div className="text-xs text-gray-500">
                  {((count / metrics.totalLeaks) * 100).toFixed(1)}% of total
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Trend Analysis */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Activity Trends
            </CardTitle>
            <CardDescription>Security monitoring activities over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {trendData.map((data, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm font-medium">{data.period}</span>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Activity className="h-3 w-3 text-blue-500" />
                      <span className="text-xs">{data.monitors}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Target className="h-3 w-3 text-green-500" />
                      <span className="text-xs">{data.scans}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <AlertTriangle className="h-3 w-3 text-red-500" />
                      <span className="text-xs">{data.leaks}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Database className="h-3 w-3 text-purple-500" />
                      <span className="text-xs">{data.assets}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Recent Alerts
            </CardTitle>
            <CardDescription>Latest security events and notifications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { title: 'Critical API Key Leak', severity: 'critical', time: '2 minutes ago' },
                { title: 'High-Severity Token Validated', severity: 'high', time: '15 minutes ago' },
                { title: 'New Network Assets Discovered', severity: 'medium', time: '1 hour ago' },
                { title: 'Scan Completed Successfully', severity: 'low', time: '2 hours ago' },
                { title: 'Monitor Status Update', severity: 'low', time: '3 hours ago' }
              ].map((alert, index) => (
                <div key={index} className="flex items-center justify-between p-2 border rounded">
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${getSeverityColor(alert.severity)}`} />
                    <span className="text-sm font-medium">{alert.title}</span>
                  </div>
                  <span className="text-xs text-gray-500">{alert.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Summary Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Platform Summary
          </CardTitle>
          <CardDescription>Overall security platform performance and coverage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {metrics.totalMonitors + metrics.totalScans + metrics.totalTokens}
              </div>
              <div className="text-sm text-gray-600">Total Security Tasks</div>
              <div className="text-xs text-gray-500">Monitors + Scans + Tokens</div>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {Math.round(((metrics.completedScans + metrics.validTokens) / (metrics.totalScans + metrics.totalTokens)) * 100)}%
              </div>
              <div className="text-sm text-gray-600">Success Rate</div>
              <div className="text-xs text-gray-500">Completed operations</div>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {metrics.totalNetworkAssets.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Network Coverage</div>
              <div className="text-xs text-gray-500">Assets discovered</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Features Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Enhanced Security Features
          </CardTitle>
          <CardDescription>Advanced capabilities powered by the enhanced Sentinel platform</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Shield className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold">900+ Secret Types</h3>
              </div>
              <p className="text-sm text-gray-600">
                Advanced pattern and entropy analysis for comprehensive secret detection across multiple platforms
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Activity className="h-5 w-5 text-green-600" />
                <h3 className="font-semibold">Multi-Platform Monitoring</h3>
              </div>
              <p className="text-sm text-gray-600">
                Integrated support for GitHub, GitLab, and Bitbucket with real-time monitoring capabilities
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Database className="h-5 w-5 text-purple-600" />
                <h3 className="font-semibold">Threat Intelligence</h3>
              </div>
              <p className="text-sm text-gray-600">
                VirusTotal and AbuseIPDB integration for advanced threat correlation and analysis
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Zap className="h-5 w-5 text-orange-600" />
                <h3 className="font-semibold">Automated Remediation</h3>
              </div>
              <p className="text-sm text-gray-600">
                Support for AWS, Azure, GCP, GitHub, and GitLab automated security response
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Target className="h-5 w-5 text-red-600" />
                <h3 className="font-semibold">Network Intelligence</h3>
              </div>
              <p className="text-sm text-gray-600">
                ZoomEye MCP server integration for comprehensive network asset reconnaissance
              </p>
            </div>
            
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <FileText className="h-5 w-5 text-indigo-600" />
                <h3 className="font-semibold">Compliance Reporting</h3>
              </div>
              <p className="text-sm text-gray-600">
                Built-in compliance frameworks for GDPR, HIPAA, PCI DSS, and SOC 2 requirements
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}