'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { RBACGuard } from '@/components/auth/rbac-guard'
import { 
  Key, 
  Plus, 
  CheckCircle, 
  XCircle, 
  Clock,
  Copy,
  ExternalLink,
  Github,
  Cloud,
  MessageSquare,
  Gamepad2,
  Shield,
  Server,
  Database,
  AlertTriangle
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface TokenVerification {
  id: string
  token: string
  type: string
  service: string
  isValid: boolean | null
  metadata: string
  status: string
  createdAt: string
}

interface NewVerificationForm {
  token: string
  type: string
  service: string
}

const TOKEN_TYPES = [
  { value: 'GITHUB', label: 'GitHub', icon: Github, color: 'bg-gray-900' },
  { value: 'AWS', label: 'AWS', icon: Cloud, color: 'bg-orange-500' },
  { value: 'AZURE', label: 'Azure', icon: Cloud, color: 'bg-blue-500' },
  { value: 'GCP', label: 'Google Cloud', icon: Cloud, color: 'bg-green-500' },
  { value: 'SLACK', label: 'Slack', icon: MessageSquare, color: 'bg-purple-500' },
  { value: 'DISCORD', label: 'Discord', icon: Gamepad2, color: 'bg-indigo-500' },
  { value: 'CUSTOM', label: 'Custom', icon: Key, color: 'bg-gray-500' }
]

const PREDEFINED_SERVICES = {
  GITHUB: ['github.com', 'api.github.com', 'gist.github.com'],
  AWS: ['aws.amazon.com', 'console.aws.amazon.com', 'api.amazonaws.com'],
  AZURE: ['portal.azure.com', 'management.azure.com', 'login.microsoftonline.com'],
  GCP: ['console.cloud.google.com', 'cloud.google.com', 'api.cloud.google.com'],
  SLACK: ['slack.com', 'api.slack.com'],
  DISCORD: ['discord.com', 'discordapp.com', 'api.discord.com']
}

export function TokenVerifier() {
  const { data: session } = useSession()
  const [verifications, setVerifications] = useState<TokenVerification[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isVerifying, setIsVerifying] = useState(false)
  const [newVerification, setNewVerification] = useState<NewVerificationForm>({
    token: '',
    type: 'GITHUB',
    service: 'github.com'
  })
  const [validationError, setValidationError] = useState('')
  const [showToken, setShowToken] = useState<Record<string, boolean>>({})
  const [showTokenInput, setShowTokenInput] = useState(false)
  const { toast } = useToast()

  // Get user ID from session or use a valid default
  const userId = session?.user?.id || 'cmekggvj90000jv7wua1z6qe3' // Admin user ID as fallback

  useEffect(() => {
    fetchVerifications()
    
    // Only set up polling for pending verifications to reduce unnecessary refreshes
    const interval = setInterval(() => {
      const hasPendingVerifications = verifications.some(v => v.status === 'PENDING')
      if (hasPendingVerifications) {
        fetchVerifications()
      }
    }, 8000) // Poll every 8 seconds instead of 3, and only when there are pending verifications

    return () => clearInterval(interval)
  }, [verifications.some(v => v.status === 'PENDING')]) // Only re-run when pending verification status changes

  const fetchVerifications = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/tokens?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setVerifications(data.verifications || [])
      }
    } catch (error) {
      console.error('Error fetching verifications:', error)
      toast({
        title: "Error",
        description: "Failed to fetch verifications",
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const validateForm = (): boolean => {
    if (!newVerification.token.trim()) {
      setValidationError('Token is required')
      return false
    }

    if (!newVerification.type) {
      setValidationError('Token type is required')
      return false
    }

    if (!newVerification.service.trim()) {
      setValidationError('Service is required')
      return false
    }

    // Basic format validation based on token type
    const token = newVerification.token.trim()
    switch (newVerification.type) {
      case 'GITHUB':
        if (!token.match(/^(ghp_|gho_|ghu_)[0-9a-zA-Z_]{36}$/) && 
            !token.match(/^[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}$/)) {
          setValidationError('Invalid GitHub token format')
          return false
        }
        break
      case 'AWS':
        if (!token.match(/^AKIA[0-9A-Z]{16}$/) && 
            !token.match(/^[0-9a-zA-Z/+]{40}$/) &&
            !token.match(/^AwsSecret[A-Za-z0-9/+=]{40}$/)) {
          setValidationError('Invalid AWS token format')
          return false
        }
        break
      case 'SLACK':
        if (!token.match(/^xox[baprs]-[0-9a-zA-Z-]{43,}$/) &&
            !token.match(/^https:\/\/hooks\.slack\.com\/services\/[A-Z0-9]+\/[A-Z0-9]+\/[A-Za-z0-9_]+$/)) {
          setValidationError('Invalid Slack token format')
          return false
        }
        break
      case 'DISCORD':
        if (!token.match(/^[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}$/) &&
            !token.match(/^https:\/\/discord\.com\/api\/webhooks\/[0-9]+\/[A-Za-z0-9_-]+$/)) {
          setValidationError('Invalid Discord token format')
          return false
        }
        break
    }

    setValidationError('')
    return true
  }

  const handleVerifyToken = async () => {
    if (!validateForm()) return

    try {
      setIsVerifying(true)
      
      const response = await fetch('/api/tokens', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newVerification,
          userId
        })
      })

      if (response.ok) {
        const data = await response.json()
        setVerifications(prev => [data.verification, ...prev])
        setNewVerification({
          token: '',
          type: 'GITHUB',
          service: 'github.com'
        })
        toast({
          title: "Verification Started",
          description: "Token verification is in progress",
        })
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to verify token",
          variant: "destructive"
        })
      }
    } catch (error) {
      console.error('Error verifying token:', error)
      toast({
        title: "Error",
        description: "Failed to verify token",
        variant: "destructive"
      })
    } finally {
      setIsVerifying(false)
    }
  }

  const handleCopyToken = (token: string) => {
    navigator.clipboard.writeText(token)
    toast({
      title: "Copied",
      description: "Token copied to clipboard",
    })
  }

  const toggleShowToken = (id: string) => {
    setShowToken(prev => ({
      ...prev,
      [id]: !prev[id]
    }))
  }

  const getStatusColor = (status: string, isValid?: boolean | null) => {
    if (status === 'PENDING') return 'bg-yellow-100 text-yellow-800 border-yellow-200'
    if (status === 'ERROR') return 'bg-red-100 text-red-800 border-red-200'
    if (status === 'VERIFIED') {
      return isValid ? 'bg-green-100 text-green-800 border-green-200' : 'bg-red-100 text-red-800 border-red-200'
    }
    if (status === 'FAILED') return 'bg-red-100 text-red-800 border-red-200'
    return 'bg-gray-100 text-gray-800 border-gray-200'
  }

  const getStatusIcon = (status: string, isValid?: boolean | null) => {
    if (status === 'PENDING') return <Clock className="h-3 w-3 animate-spin" />
    if (status === 'ERROR') return <AlertTriangle className="h-3 w-3" />
    if (status === 'VERIFIED') {
      return isValid ? <CheckCircle className="h-3 w-3" /> : <XCircle className="h-3 w-3" />
    }
    if (status === 'FAILED') return <XCircle className="h-3 w-3" />
    return <Clock className="h-3 w-3" />
  }

  const getTokenTypeInfo = (type: string) => {
    return TOKEN_TYPES.find(t => t.value === type) || TOKEN_TYPES[6]
  }

  const redactToken = (token: string, show: boolean = false) => {
    if (show) return token
    if (token.length <= 8) return '*'.repeat(token.length)
    return token.substring(0, 4) + '*'.repeat(token.length - 8) + token.substring(token.length - 4)
  }

  const formatMetadata = (metadata: string) => {
    try {
      const parsed = JSON.parse(metadata)
      return JSON.stringify(parsed, null, 2)
    } catch {
      return metadata
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Token Verifier</h2>
          <p className="text-muted-foreground">
            Verify and validate tokens from various services and platforms
          </p>
        </div>
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <RBACGuard requiredPermissions={['write']}>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Token Verifier</h2>
          <p className="text-muted-foreground">
            Verify and validate tokens from various services and platforms
          </p>
        </div>

      {/* Verify New Token */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Verify Token
          </CardTitle>
          <CardDescription>Check if a token is valid and obtain information about it</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {validationError && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{validationError}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium">Token Type</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={newVerification.type}
                onChange={(e) => {
                  setNewVerification(prev => ({ 
                    ...prev, 
                    type: e.target.value,
                    service: PREDEFINED_SERVICES[e.target.value as keyof typeof PREDEFINED_SERVICES]?.[0] || ''
                  }))
                }}
              >
                {TOKEN_TYPES.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium">Service</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={newVerification.service}
                onChange={(e) => setNewVerification(prev => ({ ...prev, service: e.target.value }))}
              >
                {PREDEFINED_SERVICES[newVerification.type as keyof typeof PREDEFINED_SERVICES]?.map(service => (
                  <option key={service} value={service}>{service}</option>
                )) || (
                  <>
                    <option value="">Select or enter service</option>
                    <option value="custom">Custom Service</option>
                  </>
                )}
              </select>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">Token</label>
            <div className="relative">
              <Input
                type={showTokenInput ? "text" : "password"}
                placeholder="Paste your token here"
                value={newVerification.token}
                onChange={(e) => setNewVerification(prev => ({ ...prev, token: e.target.value }))}
                className="pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2"
                onClick={() => setShowTokenInput(!showTokenInput)}
              >
                {showTokenInput ? "Hide" : "Show"}
              </Button>
            </div>
          </div>
          
          <Button 
            onClick={handleVerifyToken} 
            disabled={isVerifying}
            className="w-full"
          >
            {isVerifying ? 'Verifying...' : 'Verify Token'}
          </Button>
        </CardContent>
      </Card>

      {/* Recent Verifications */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Verifications</CardTitle>
          <CardDescription>Your latest token verification results</CardDescription>
        </CardHeader>
        <CardContent>
          {verifications.length === 0 ? (
            <div className="text-center py-8">
              <Key className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No verifications yet</h3>
              <p className="text-gray-500">Verify your first token to see results here</p>
            </div>
          ) : (
            <div className="space-y-4">
              {verifications.map((verification) => {
                const tokenInfo = getTokenTypeInfo(verification.type)
                let metadata = null
                try {
                  metadata = verification.metadata ? JSON.parse(verification.metadata) : null
                } catch (error) {
                  console.error('Error parsing metadata:', error)
                  metadata = null
                }
                
                return (
                  <div key={verification.id} className="border rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-lg ${tokenInfo.color}`}>
                          <tokenInfo.icon className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="text-sm font-medium">{tokenInfo.label}</h3>
                            <Badge className={getStatusColor(verification.status, verification.isValid)}>
                              {getStatusIcon(verification.status, verification.isValid)}
                              {verification.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-500">{verification.service}</p>
                          <p className="text-xs text-gray-400">
                            {new Date(verification.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleShowToken(verification.id)}
                        >
                          {showToken[verification.id] ? 'Hide' : 'Show'}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyToken(verification.token)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs font-medium text-gray-500">Token</label>
                        <div className="font-mono text-sm bg-gray-100 p-2 rounded">
                          {redactToken(verification.token, showToken[verification.id])}
                        </div>
                      </div>
                      
                      {verification.status === 'VERIFIED' && metadata && (
                        <div>
                          <label className="text-xs font-medium text-gray-500">Verification Details</label>
                          <div className="bg-gray-50 p-3 rounded text-sm">
                            {metadata.type && (
                              <div className="mb-2">
                                <span className="font-medium">Type: </span>
                                <span className="text-gray-600">{metadata.type}</span>
                              </div>
                            )}
                            {metadata.user && (
                              <div className="mb-2">
                                <span className="font-medium">User: </span>
                                <span className="text-gray-600">
                                  {metadata.user.login || metadata.user.username || metadata.user.email || 'N/A'}
                                </span>
                              </div>
                            )}
                            {metadata.scopes && metadata.scopes.length > 0 && (
                              <div className="mb-2">
                                <span className="font-medium">Scopes: </span>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {metadata.scopes.map((scope: string, index: number) => (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      {scope}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                            {metadata.note && (
                              <div className="text-xs text-gray-500 italic">
                                {metadata.note}
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {verification.status === 'ERROR' && metadata.error && (
                        <Alert variant="destructive">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription>{metadata.error}</AlertDescription>
                        </Alert>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
      </div>
    </RBACGuard>
  )
}